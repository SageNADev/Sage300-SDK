/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class CompanyProfile : ModelBase
    {


        /// <summary>
        /// CompanyProfile cunstructor
        /// </summary>
        public CompanyProfile()
        {
            CompanyProfileContact=new CompanyProfileContact();
            Address=new Address();
            CompanyProfileOptions=new CompanyProfileOptions();
            DefaultRateType=new CurrencyRateType();
            CompanyProfileEmail = new CompanyProfileEmail();
        }
        /// <summary>
        /// Gets or sets DatabaseID 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DatabaseID", ResourceType = typeof (CompanyProfileResx))]
        [Key]
        [ViewField(Name = Fields.DatabaseId, Id = Index.DatabaseId, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DatabaseId { get; set; }

        /// <summary>
        /// Gets or sets Address
        /// </summary>
        public Address Address { get; set; }

        /// <summary>
        /// Gets or sets DefaultRateType
        /// </summary>
        public CurrencyRateType DefaultRateType { get; set; }

        /// <summary>
        /// Gets or sets LegalName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LegalName", ResourceType = typeof (CompanyProfileResx))]
        [ViewField(Name = Fields.LegalName, Id = Index.LegalName, FieldType = EntityFieldType.Char, Size = 60)]
        public string LegalName { get; set; }

        /// <summary>
        /// Gets or sets CompanyProfileContact
        /// </summary>
        public CompanyProfileContact CompanyProfileContact { get; set; }

        /// <summary>
        /// Gets or sets CompanyProfileOptions
        /// </summary>
        public CompanyProfileOptions CompanyProfileOptions { get; set; }
        
        /// <summary>
        /// Gets or sets Company email settings
        /// </summary>
        public CompanyProfileEmail CompanyProfileEmail { get; set; }

        /// <summary>
        /// Property for FormatPhoneNumber 
        /// </summary>
        [Display(Name = "FormatPhone", ResourceType = typeof (CompanyProfileResx))]
        [ViewField(Name = Fields.FormatPhoneNumber, Id = Index.FormatPhoneNumber, FieldType = EntityFieldType.Bool, Size = 2)]
        public string FormatPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets Default Rate Type
        /// </summary>
        [Display(Name = "DefaultRateType", ResourceType = typeof (CompanyProfileResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultRateTypeCode, Id = Index.DefaultRateTypeCode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string DefaultRateTypeCode { get; set; }

        /// <summary>
        /// Gets or sets Payments Acceptance Organization Information
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PaymentsAcceptanceOrgInfo, Id = Index.PaymentsAcceptanceOrgInfo, FieldType = EntityFieldType.Byte, Size = 240)]
        public byte[] PaymentsAcceptanceOrgInfo { get; set; }

        /// <summary>
        /// Gets or sets Payments Acceptance Company
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PaymentsAcceptanceCompany, Id = Index.PaymentsAcceptanceCompany, FieldType = EntityFieldType.Byte, Size = 32)]
        public byte[] PaymentsAcceptanceCompany { get; set; }

        /// <summary>
        /// Gets or sets Payments Acceptance Country
        /// </summary>
        [Display(Name = "Country", ResourceType = typeof(CompanyProfileResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PaymentsAcceptanceCountry, Id = Index.PaymentsAcceptanceCountry, FieldType = EntityFieldType.Int, Size = 2)]
        public CountryCodes PaymentsAcceptanceCountry { get; set; }

        /// <summary>
        /// Gets or sets Payments Acceptance Country Code
        /// </summary>
        [Display(Name = "CountryCode", ResourceType = typeof(CompanyProfileResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PaymentsAcceptanceCountryCode, Id = Index.PaymentsAcceptanceCountryCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string PaymentsAcceptanceCountryCode { get; set; }

        /// <summary>
        /// Gets or sets Default Rate Type Description
        /// </summary>
        public string DefaultRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets the list of available Countries for Payments Acceptance
        /// </summary>
        [IsMvcSpecific]
        [IgnoreExportImport]
        public IEnumerable<SelectList> PaymentsAcceptanceCountryList { get; set; }

        /// <summary>
        /// Property for SD&A Subdomain
        /// </summary>
        [ViewField(Name = Fields.SDASubdomain, Id = Index.SDASubdomain, FieldType = EntityFieldType.Char, Size = 100)]
        public string SDASubdomain { get; set; }
    }
}
