/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is BankDistributionSetDetail Entity
    /// </summary>
    public partial class BankDistributionSetDetail : ModelBase
    {
        #region Public Properties

        /// <summary>
        /// Gets or sets DistributionSetCode 
        /// </summary>
        [Display(Name = "DISTSET", ResourceType = typeof (BankDistributionSetsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DistributionSetCode, Id = Index.DistributionSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSetCode { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(BankDistributionSetsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [Display(Name = "DISTCODE", ResourceType = typeof (BankDistributionSetsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GLAccount 
        /// </summary>
        [Display(Name = "ACCOUNT", ResourceType = typeof (BankDistributionSetsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets Amount 
        /// </summary>
        [Display(Name = "AMOUNT", ResourceType = typeof(BankDistributionSetsResx))]    
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets Distribution Code Description 
        /// </summary>
        [Display(Name = "DISTCODEDESCRIPTION", ResourceType = typeof (BankDistributionSetsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCodeDescription, Id = Index.DistributionCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DistributionCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets AccountDescription 
        /// </summary>
        [Display(Name = "ACCTDESC", ResourceType = typeof (BankDistributionSetsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.AccountDescription, Id = Index.AccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets Line 
        /// </summary>
        [Display(Name = "Line", ResourceType = typeof(BKCommonResx))]           
        [ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
        public long Line { get; set; }

        #endregion
    }
}
