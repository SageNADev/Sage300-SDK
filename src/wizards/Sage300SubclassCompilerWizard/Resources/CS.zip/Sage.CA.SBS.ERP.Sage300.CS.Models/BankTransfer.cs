/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using FiscalPeriod = Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.FiscalPeriod;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class BankTransfer
    /// </summary>
    public partial class BankTransfer : ModelBase
    {
        /// <summary>
        /// Gets or sets TransferNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransferNumber", ResourceType = typeof(BankTransfersResx))]
        [Key]
        [ViewField(Name = Fields.TransferNumber, Id = Index.TransferNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string TransferNumber { get; set; }

        /// <summary>
        /// Gets or sets Date 
        /// </summary>
        [ViewField(Name = Fields.Date, Id = Index.Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransferDesc", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransferRef", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYearPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransferBank 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.TransferBank, Id = Index.TransferBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string TransferBank { get; set; }

        /// <summary>
        /// Gets or sets TransferSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.TransferSourceCurrency, Id = Index.TransferSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TransferSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets TransferRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.TransferRateDate, Id = Index.TransferRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransferRateDate { get; set; }

        /// <summary>
        /// Gets or sets TransferRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PFPFromRTCap", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.TransferRateType, Id = Index.TransferRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TransferRateType { get; set; }

        /// <summary>
        /// Gets or sets TransferRateFactor 
        /// </summary>
        [Display(Name = "RateFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TransferRateFactor, Id = Index.TransferRateFactor, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TransferRateFactor { get; set; }

        /// <summary>
        /// Gets or sets TransferRateSpread 
        /// </summary>
        [ViewField(Name = Fields.TransferRateSpread, Id = Index.TransferRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TransferRateSpread { get; set; }

        /// <summary>
        /// Gets or sets TransferRateOperator 
        /// </summary>
        [ViewField(Name = Fields.TransferRateOperator, Id = Index.TransferRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public TransferRateOperator TransferRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TransferSourceAmount 
        /// </summary>
        [Display(Name = "TransferAm", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.TransferSourceAmount, Id = Index.TransferSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransferSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets TransferFunctionalAmount 
        /// </summary>
        [Display(Name = "FuncTransferAm", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.TransferFunctionalAmount, Id = Index.TransferFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransferFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets DepositBank 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.DepositBank, Id = Index.DepositBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DepositBank { get; set; }

        /// <summary>
        /// Gets or sets DepositSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.DepositSourceCurrency, Id = Index.DepositSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string DepositSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets DepositRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.DepositRateDate, Id = Index.DepositRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DepositRateDate { get; set; }

        /// <summary>
        /// Gets or sets DepositRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PFPFromRTCap", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.DepositRateType, Id = Index.DepositRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string DepositRateType { get; set; }

        /// <summary>
        /// Gets or sets DepositRateFactor 
        /// </summary>
        [Display(Name = "RateFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DepositRateFactor, Id = Index.DepositRateFactor, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal DepositRateFactor { get; set; }

        /// <summary>
        /// Gets or sets DepositRateSpread 
        /// </summary>
        [ViewField(Name = Fields.DepositRateSpread, Id = Index.DepositRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal DepositRateSpread { get; set; }

        /// <summary>
        /// Gets or sets DepositRateOperator 
        /// </summary>
        [ViewField(Name = Fields.DepositRateOperator, Id = Index.DepositRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public TransferRateOperator DepositRateOperator { get; set; }

        /// <summary>
        /// Gets or sets DepositSourceAmount 
        /// </summary>
        [Display(Name = "DepositAmt", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.DepositSourceAmount, Id = Index.DepositSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalAmount 
        /// </summary>
        [Display(Name = "FuncDepositAm", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.DepositFunctionalAmount, Id = Index.DepositFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets PostDate 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PopupDateOVERRIDE", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.PostDate, Id = Index.PostDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostDate { get; set; }

        /// <summary>
        /// Gets or sets TransferFunctionalFixed? 
        /// </summary>
        [ViewField(Name = Fields.TransferFunctionalFixed, Id = Index.TransferFunctionalFixed, FieldType = EntityFieldType.Bool, Size = 2)]
        public long TransferFunctionalFixed { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalFixed? 
        /// </summary>
        [ViewField(Name = Fields.DepositFunctionalFixed, Id = Index.DepositFunctionalFixed, FieldType = EntityFieldType.Bool, Size = 2)]
        public long DepositFunctionalFixed { get; set; }

        /// <summary>
        /// Gets or sets TransferDepositFixed? 
        /// </summary>
        [ViewField(Name = Fields.TransferDepositFixed, Id = Index.TransferDepositFixed, FieldType = EntityFieldType.Bool, Size = 2)]
        public long TransferDepositFixed { get; set; }

        /// <summary>
        /// Gets or sets TransferBankDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCodeDesc", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.TransferBankDescription, Id = Index.TransferBankDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransferBankDescription { get; set; }

        /// <summary>
        /// Gets or sets TransferBankCurrencyDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCodeDesription", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.TransferBankCurrencyDescription, Id = Index.TransferBankCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransferBankCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TransferCurrencyStatement 
        /// </summary>        
        [ViewField(Name = Fields.TransferCurrencyStatement, Id = Index.TransferCurrencyStatement, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TransferCurrencyStatement { get; set; }

        /// <summary>
        /// Gets or sets TransferMulticurrency? 
        /// </summary>
        [ViewField(Name = Fields.TransferMulticurrency, Id = Index.TransferMulticurrency, FieldType = EntityFieldType.Bool, Size = 2)]
        public long TransferMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets DepositBankDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCodeDesc", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.DepositBankDescription, Id = Index.DepositBankDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DepositBankDescription { get; set; }

        /// <summary>
        /// Gets or sets DepositBankCurrencyDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCodeDesription", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.DepositBankCurrencyDescription, Id = Index.DepositBankCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DepositBankCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets DepositCurrencyStatement 
        /// </summary>
        [ViewField(Name = Fields.DepositCurrencyStatement, Id = Index.DepositCurrencyStatement, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string DepositCurrencyStatement { get; set; }

        /// <summary>
        /// Gets or sets DepositMulticurrency? 
        /// </summary>
        [ViewField(Name = Fields.DepositMulticurrency, Id = Index.DepositMulticurrency, FieldType = EntityFieldType.Bool, Size = 2)]
        public long DepositMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets TransferDepositConversion 
        /// </summary>
        [ViewField(Name = Fields.TransferDepositConversion, Id = Index.TransferDepositConversion, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TransferDepositConversion { get; set; }

        /// <summary>
        /// Gets or sets TransferDepositRateOperation 
        /// </summary>
        [Display(Name = "PFRBKTFRHTrateopCap", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TransferDepositRateOperation, Id = Index.TransferDepositRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TransferRateOperator TransferDepositRateOperation { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalDefaultAmount 
        /// </summary>
        [Display(Name = "FuncDepositAm", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.DepositFunctionalDefaultAmount, Id = Index.DepositFunctionalDefaultAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositFunctionalDefaultAmount { get; set; }

        /// <summary>
        /// Gets or sets DepositSourceDefaultAmount 
        /// </summary>
        [ViewField(Name = Fields.DepositSourceDefaultAmount, Id = Index.DepositSourceDefaultAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositSourceDefaultAmount { get; set; }

        /// <summary>
        /// Gets or sets TransferRateTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateTypeDesc", ResourceType = typeof(CurrencyRateTypesResx))]
        [ViewField(Name = Fields.TransferRateTypeDescription, Id = Index.TransferRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransferRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets DepositRateTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateTypeDesc", ResourceType = typeof(CurrencyRateTypesResx))]
        [ViewField(Name = Fields.DepositRateTypeDescription, Id = Index.DepositRateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DepositRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets NumericTransferNumber 
        /// </summary>
        [ViewField(Name = Fields.NumericTransferNumber, Id = Index.NumericTransferNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NumericTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets TransferTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TransferTypeDescription, Id = Index.TransferTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransferTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccountDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string GLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets TransferBankAccount 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BANKACCOUNT", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.TransferBankAccount, Id = Index.TransferBankAccount, FieldType = EntityFieldType.Char, Size = 22)]
        public string TransferBankAccount { get; set; }

        /// <summary>
        /// Gets or sets DepositBankAccount 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BANKACCOUNT", ResourceType = typeof(BankTransfersResx))]
        [ViewField(Name = Fields.DepositBankAccount, Id = Index.DepositBankAccount, FieldType = EntityFieldType.Char, Size = 22)]
        public string DepositBankAccount { get; set; }

        /// <summary>
        /// Gets or sets List of GL Recurring entries
        /// </summary>
        /// <value>The recurring entries.</value>
        public EnumerableResponse<BankTransferDetail> BankTransferDetail { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        public short SessionWarnDays { get; set; }
    }
}
