// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Process
{
    /// <summary>
    /// Partial class for BankDepositPrintingFunction
    /// </summary>
    public partial class BankDepositPrintingFunction : ModelBase
    {
        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Function Function { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets BankCode
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets FromDepositNumber
        /// </summary>
        [ViewField(Name = Fields.FromDepositNumber, Id = Index.FromDepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal FromDepositNumber { get; set; }

        /// <summary>
        /// Gets or sets ToDepositNumber
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ToDepositNumber, Id = Index.ToDepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal ToDepositNumber { get; set; }

        #region UI Strings
        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
            get { return EnumUtility.GetStringValue(Function); }
        }
        #endregion
    }
}
