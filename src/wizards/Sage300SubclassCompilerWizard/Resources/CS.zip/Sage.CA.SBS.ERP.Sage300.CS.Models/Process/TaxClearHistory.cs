// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Process
{
    /// <summary>
    /// Partial class for TaxClearHistory
    /// </summary>
    public partial class TaxClearHistory : ModelBase
    {
        /// <summary>
        /// Gets or sets AuthorityFrom
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AuthorityFrom", ResourceType = typeof (TaxClearHistoryResx))]
        [ViewField(Name = Fields.AuthorityFrom, Id = Index.AuthorityFrom, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AuthorityFrom { get; set; }

        /// <summary>
        /// Gets or sets AuthorityTo
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AuthorityTo", ResourceType = typeof (TaxClearHistoryResx))]
        [ViewField(Name = Fields.AuthorityTo, Id = Index.AuthorityTo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AuthorityTo { get; set; }

        /// <summary>
        /// Gets or sets ClearRecordsBy
        /// </summary>
        [Display(Name = "ClearRecordsBy", ResourceType = typeof (TaxClearHistoryResx))]
        [ViewField(Name = Fields.ClearRecordsBy, Id = Index.ClearRecordsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public ClearRecordsBy ClearRecordsBy { get; set; }

        /// <summary>
        /// Gets or sets TypeOfRecordToClear
        /// </summary>
        [Display(Name = "TypeOfRecordToClear", ResourceType = typeof (TaxClearHistoryResx))]
        [ViewField(Name = Fields.TypeOfRecordToClear, Id = Index.TypeOfRecordToClear, FieldType = EntityFieldType.Int, Size = 2)]
        public TypeOfRecordToClear TypeOfRecordToClear { get; set; }

        /// <summary>
        /// Gets or sets MethodOfClearingClasses
        /// </summary>
        [Display(Name = "MethodOfClearingClasses", ResourceType = typeof (TaxClearHistoryResx))]
        [ViewField(Name = Fields.MethodOfClearingClasses, Id = Index.MethodOfClearingClasses, FieldType = EntityFieldType.Int, Size = 2)]
        public MethodOfClearingClasses MethodOfClearingClasses { get; set; }

        /// <summary>
        /// Gets or sets FromItemClass
        /// </summary>
        [Display(Name = "FromItemClass", ResourceType = typeof (TaxClearHistoryResx))]
        [ViewField(Name = Fields.FromItemClass, Id = Index.FromItemClass, FieldType = EntityFieldType.Int, Size = 2)]
        public FromItemClass FromItemClass { get; set; }

        /// <summary>
        /// Gets or sets ToItemClass
        /// </summary>
        [Display(Name = "ToItemClass", ResourceType = typeof (TaxClearHistoryResx))]
        [ViewField(Name = Fields.ToItemClass, Id = Index.ToItemClass, FieldType = EntityFieldType.Int, Size = 2)]
        public ToItemClass ToItemClass { get; set; }

        /// <summary>
        /// Gets or set From Year
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromYear, Id = Index.FromYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets From Period
        /// </summary>
        [ViewField(Name = Fields.FromPeriod, Id = Index.FromPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets To Year
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToYear, Id = Index.ToYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets To Period
        /// </summary>
        [ViewField(Name = Fields.ToPeriod, Id = Index.ToPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets From Document Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromDate, Id = Index.FromDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or sets To Documnet Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToDate, Id = Index.ToDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Gets or sets ClearOnSales Boolean value.
        /// </summary>
        [Display(Name = "ClearOnSales", ResourceType = typeof(TaxClearHistoryResx))]
        public bool ClearOnSales { get; set; }

        /// <summary>
        /// Gets or sets ClearOnPurchase Boolean value.
        /// </summary>
        [Display(Name = "ClearOnPurchase", ResourceType = typeof(TaxClearHistoryResx))]
        public bool ClearOnPurchase { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ClearRecordsBy string value
        /// </summary>
        public string ClearRecordsByString
        {
         get { return EnumUtility.GetStringValue(ClearRecordsBy); }
        }

        /// <summary>
        /// Gets TypeOfRecordToClear string value
        /// </summary>
        public string TypeOfRecordToClearString
        {
         get { return EnumUtility.GetStringValue(TypeOfRecordToClear); }
        }

        /// <summary>
        /// Gets MethodOfClearingClasses string value
        /// </summary>
        public string MethodOfClearingClassesString
        {
         get { return EnumUtility.GetStringValue(MethodOfClearingClasses); }
        }

        /// <summary>
        /// Gets FromItemClass string value
        /// </summary>
        public string FromItemClassString
        {
         get { return EnumUtility.GetStringValue(FromItemClass); }
        }

        /// <summary>
        /// Gets ToItemClass string value
        /// </summary>
        public string ToItemClassString
        {
         get { return EnumUtility.GetStringValue(ToItemClass); }
        }

        #endregion
    }
}
