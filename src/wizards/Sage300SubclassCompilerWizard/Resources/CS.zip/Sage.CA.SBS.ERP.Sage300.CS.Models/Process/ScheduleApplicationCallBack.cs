// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Process
{
    /// <summary>
    /// Partial class for Schedule
    /// </summary>
    public partial class ScheduleApplicationCallBack : ModelBase
    {
        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SCHEDKEY
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.SCHEDKEY, Id = Index.SCHEDKEY, FieldType = EntityFieldType.Char, Size = 12)]
        public string SCHEDKEY { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RUNDATE
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RUNDATE, Id = Index.RUNDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RUNDATE { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RUNNEXT
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RUNNEXT, Id = Index.RUNNEXT, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RUNNEXT { get; set; }

        #region UI Strings

        #endregion
    }
}
