/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class PrintCheck
    /// </summary>
    public partial class PrintCheck : ModelBase
    {
        /// <summary>
        /// Gets or sets the Source Application
        /// </summary>
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets Bank 
        /// </summary>
        public string Bank { get; set; }

        /// <summary>
        /// Gets or sets Message 
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the Bank details
        /// </summary>
        public Banks Banks { get; set; }

        /// <summary>
        /// Gets or sets the Stock Code
        /// </summary>
        public CheckStock CheckStock { get; set; }

        /// <summary>
        /// Gets or sets the BankCheckRegisters
        /// </summary>
        public EnumerableResponse<BankCheckRegister> BankCheckRegisters { get; set; }

        /// <summary>
        /// Gets or sets the Stock Type
        /// </summary>
        public StockType StockType { get; set; }

        /// <summary>
        /// Gets or sets the Bank Check Printing Function
        /// </summary>
        public BankCheckPrintingFunction BankCheckPrintingFunction { get; set; }

        #region Report related properties

        /// <summary>
        /// Gets or sets the Report File
        /// </summary>
        public string ReportFile { get; set; }

        /// <summary>
        /// Gets or sets the start Serial Number
        /// </summary>
        public long StartSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets the end Serial Number
        /// </summary>
        public long EndSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets whether the masked SSN needs to be printed or not
        /// </summary>
        public string printSSN { get; set; }

        /// <summary>
        /// Gets or sets the Report GUID
        /// </summary>
        public Guid ReportToken { get; set; }

        /// <summary>
        /// Gets or sets whether report is generate
        /// </summary>
        public bool IsReportGenerated { get; set; }

        /// <summary>
        /// Gets or sets whether check stock occurs
        /// </summary>
        public bool IsCheckStockError { get; set; }

        /// <summary>
        /// Gets or sets whether ti 
        /// </summary>
        public bool IsClosePrintCheck { get; set; }

        /// <summary>
        /// Gets or sets flag continue to print
        /// </summary>
        public bool IsContinue { get; set; } = false;

        #endregion
    }
}