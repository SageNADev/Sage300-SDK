// Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. 

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
using FiscalPeriod = Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.FiscalPeriod;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// BankTransactionHeader class
    /// </summary>
    public partial class BankTransactionHeader : ModelBase
    {

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BankCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionHeaderSerial 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "TransactionHeaderSerial", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionHeaderSerial, Id = Index.TransactionHeaderSerial, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long TransactionHeaderSerial { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber 
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(BankReconcileStatementResx))]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public BankEntryType TransactionType { get; set; }

        /// <summary>ReconciliationPostingYear
        /// Gets or sets OldSerialNumber 
        /// </summary>
        [Display(Name = "OldSerialNumber", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.OldSerialNumber, Id = Index.OldSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long OldSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public EntryType EntryType { get; set; }

        /// <summary>
        /// Gets or sets TransactionReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionReference", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionReference, Id = Index.TransactionReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionReference { get; set; }

        /// <summary>
        /// Gets or sets TransactionDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDescription", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionDescription, Id = Index.TransactionDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionDescription { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate 
        /// </summary>
        // [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]	
        [Display(Name = "TransactionDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransactionSlipPrinted 
        /// </summary>
        [Display(Name = "TransactionSlipPrinted", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionSlipPrinted, Id = Index.TransactionSlipPrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSlipPrinted TransactionSlipPrinted { get; set; }

        /// <summary>
        /// Gets or sets TransactionTotal 
        /// </summary>
        [Display(Name = "TransactionTotal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionTotal, Id = Index.TransactionTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionTotal { get; set; }

        /// <summary>
        /// Gets or sets TransactionTotalinStatement 
        /// </summary>
        [Display(Name = "TransactionTotalinStatement", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionTotalinStatement, Id = Index.TransactionTotalinStatement, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionTotalinStatement { get; set; }

        /// <summary>
        /// Gets or sets FiscalTransactionTotal 
        /// </summary>
        [Display(Name = "FiscalTransactionTotal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalTransactionTotal, Id = Index.FiscalTransactionTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalTransactionTotal { get; set; }

        /// <summary>
        /// Gets or sets NextTransactionDetailLine 
        /// </summary>
        [Display(Name = "NextTransactionDetailLine", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.NextTransactionDetailLine, Id = Index.NextTransactionDetailLine, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextTransactionDetailLine { get; set; }

        /// <summary>
        /// Gets or sets Lines 
        /// </summary>
        [Display(Name = "Lines", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets LinesOutstanding 
        /// </summary>
        [Display(Name = "LinesOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesOutstanding, Id = Index.LinesOutstanding, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesOutstanding { get; set; }

        /// <summary>
        /// Gets or sets LinesReconciled 
        /// </summary>
        [Display(Name = "LinesReconciled", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesReconciled, Id = Index.LinesReconciled, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesReconciled { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus 
        /// </summary>
        [Display(Name = "TransactionStatus", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionStatus TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationError 
        /// </summary>
        [Display(Name = "ReconciliationError", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationError, Id = Index.ReconciliationError, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationError { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationErrorPending 
        /// </summary>
        [Display(Name = "ReconciliationErrorPending", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationErrorPending, Id = Index.ReconciliationErrorPending, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationErrorPending { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeGain 
        /// </summary>
        [Display(Name = "ReconciliationExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationExchangeGain, Id = Index.ReconciliationExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeLoss 
        /// </summary>
        [Display(Name = "ReconciliationExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationExchangeLoss, Id = Index.ReconciliationExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationAmount 
        /// </summary>
        [Display(Name = "ReconciliationAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationAmount, Id = Index.ReconciliationAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationOutstandingAmt 
        /// </summary>
        [Display(Name = "ReconciliationOutstandingAmt", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationOutstandingAmt, Id = Index.ReconciliationOutstandingAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationOutstandingAmt { get; set; }

        /// <summary>
        /// Gets or sets TransactionRecordedinSummary 
        /// </summary>
        [Display(Name = "TransactionRecordedinSummary", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionRecordedinSummary, Id = Index.TransactionRecordedinSummary, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionRecordedinSummary TransactionRecordedinSummary { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationCreditCardCharg 
        /// </summary>
        [Display(Name = "ReconciliationCreditCardCharges", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationCreditCardCharg, Id = Index.ReconciliationCreditCardCharg, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationCreditCardCharg { get; set; }

        /// <summary>
        /// Gets or sets AmountCleared 
        /// </summary>
        [Display(Name = "AmountCleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.AmountCleared, Id = Index.AmountCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountCleared { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTransactionAmount 
        /// </summary>
        [Display(Name = "FunctionalTransactionAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FunctionalTransactionAmount, Id = Index.FunctionalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTransactionTotal 
        /// </summary>
        [Display(Name = "FunctionalTransactionTotal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FunctionalTransactionTotal, Id = Index.FunctionalTransactionTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTransactionTotal { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationClearedAmount 
        /// </summary>
        [Display(Name = "ReconciliationClearedAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationClearedAmount, Id = Index.ReconciliationClearedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationClearedAmount { get; set; }

        /// <summary>
        /// Gets or sets WriteOffAmount 
        /// </summary>
        [Display(Name = "WriteOffAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.WriteOffAmount, Id = Index.WriteOffAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WriteOffAmount { get; set; }

        /// <summary>
        /// Gets or sets OutstandingAmount 
        /// </summary>
        [Display(Name = "OutstandingAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.OutstandingAmount, Id = Index.OutstandingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OutstandingAmount { get; set; }

        /// <summary>
        /// Gets or sets VarianceType 
        /// </summary>
        [Display(Name = "VarianceType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.VarianceType, Id = Index.VarianceType, FieldType = EntityFieldType.Int, Size = 2)]
        public VarianceType VarianceType { get; set; }

        /// <summary>
        /// Gets or sets LinesCanReverseInvoice 
        /// </summary>
        [Display(Name = "LinesCanReverseInvoice", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesCanReverseInvoice, Id = Index.LinesCanReverseInvoice, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesCanReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReconciliationDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationDate, Id = Index.ReconciliationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReconciliationDate { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationStatus 
        /// </summary>
        [Display(Name = "ReconciliationStatus", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationStatus, Id = Index.ReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciliationStatus ReconciliationStatus { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReconciliationDescription", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationDescription, Id = Index.ReconciliationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReconciliationDescription { get; set; }

        /// <summary>
        /// Gets or sets LinesJournalled 
        /// </summary>
        [Display(Name = "LinesJournalled", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesJournalled, Id = Index.LinesJournalled, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesJournalled { get; set; }

        /// <summary>
        /// Gets or sets LinesPurged 
        /// </summary>
        [Display(Name = "LinesPurged", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesPurged, Id = Index.LinesPurged, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesPurged { get; set; }

        /// <summary>
        /// Gets or sets LinesProcessed 
        /// </summary>
        [Display(Name = "LinesProcessed", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesProcessed, Id = Index.LinesProcessed, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesProcessed { get; set; }

        /// <summary>
        /// Gets or sets ClearToFuturePeriod 
        /// </summary>
        [Display(Name = "ClearToFuturePeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ClearToFuturePeriod, Id = Index.ClearToFuturePeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClearToFuturePeriod { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToFuture 
        /// </summary>
        [Display(Name = "FiscalClearedToFuture", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalClearedToFuture, Id = Index.FiscalClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToCurrent 
        /// </summary>
        [Display(Name = "FiscalClearedToCurrent", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalClearedToCurrent, Id = Index.FiscalClearedToCurrent, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToCurrent { get; set; }

        /// <summary>
        /// Gets or sets ReconciledandJournaledTransac 
        /// </summary>
        [Display(Name = "ReconciledandJournaledTransaction", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciledandJournaledTransac, Id = Index.ReconciledandJournaledTransac, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciledandJournaledTransac ReconciledandJournaledTransac { get; set; }

        /// <summary>
        /// Gets or sets PaymentPayeeName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentPayeeName", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PaymentPayeeName, Id = Index.PaymentPayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentPayeeName { get; set; }

        /// <summary>
        /// Gets or sets PaymentVendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentVendorName", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PaymentVendorName, Id = Index.PaymentVendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentVendorName { get; set; }

        /// <summary>
        /// Gets or sets BankEntryOrTransferNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankEntryOrTransferNumber", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.BankEntryOrTransferNumber, Id = Index.BankEntryOrTransferNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string BankEntryOrTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets LinesCreditCard 
        /// </summary>
        [Display(Name = "LinesCreditCard", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesCreditCard, Id = Index.LinesCreditCard, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesCreditCard { get; set; }

        /// <summary>
        /// Gets or sets LinesExchangeDifference 
        /// </summary>
        [Display(Name = "LinesExchangeDifference", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LinesExchangeDifference, Id = Index.LinesExchangeDifference, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesExchangeDifference { get; set; }

        /// <summary>
        /// Gets or sets ReverseInvoice 
        /// </summary>
        [Display(Name = "ReverseInvoice", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReverseInvoice, Id = Index.ReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSlipPrinted ReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets ReconcilebyDetailReconciled 
        /// </summary>
        [Display(Name = "ReconcilebyDetailReconciled", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconcilebyDetailReconciled, Id = Index.ReconcilebyDetailReconciled, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconcilebyDetailReconciled { get; set; }

        /// <summary>
        /// Gets or sets ReconcilebyDetailOutstanding 
        /// </summary>
        [Display(Name = "ReconcilebyDetailOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconcilebyDetailOutstanding, Id = Index.ReconcilebyDetailOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconcilebyDetailOutstanding { get; set; }

        /// <summary>
        /// Gets or sets CurrentPeriodsWriteOff 
        /// </summary>
        [Display(Name = "CurrentPeriodsWriteOff", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.CurrentPeriodsWriteOff, Id = Index.CurrentPeriodsWriteOff, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentPeriodsWriteOff { get; set; }

        /// <summary>
        /// Gets or sets TOCLEARR 
        /// </summary>
        [Display(Name = "ClearToReconciliationPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TOCLEARR, Id = Index.TOCLEARR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TOCLEARR { get; set; }

        /// <summary>
        /// Gets or sets TOCLEARR field attributes
        /// </summary>
        [IsMvcSpecific]
        [IgnoreExportImport]
        public int TOCLEARRAttributes { get; set; }

        /// <summary>
        /// Gets or sets FiscalWriteOffToThisPeriod 
        /// </summary>
        [Display(Name = "FiscalWriteOffToThisPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWriteOffToThisPeriod, Id = Index.FiscalWriteOffToThisPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWriteOffToThisPeriod { get; set; }

        /// <summary>
        /// Gets or sets FiscalRemainingOutstanding 
        /// </summary>
        [Display(Name = "FiscalRemainingOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalRemainingOutstanding, Id = Index.FiscalRemainingOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalRemainingOutstanding { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaWriteOffs 
        /// </summary>
        [Display(Name = "TotalDeltaWriteOffs", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeltaWriteOffs, Id = Index.TotalDeltaWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaBankErrors 
        /// </summary>
        [Display(Name = "TotalDeltaBankErrors", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeltaBankErrors, Id = Index.TotalDeltaBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaBankErrors { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaExchangeGain 
        /// </summary>
        [Display(Name = "TotalDeltaExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeltaExchangeGain, Id = Index.TotalDeltaExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaExchangeLoss 
        /// </summary>
        [Display(Name = "TotalDeltaExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeltaExchangeLoss, Id = Index.TotalDeltaExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaCreditCardCharge 
        /// </summary>
        [Display(Name = "TotalDeltaCreditCardCharge", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeltaCreditCardCharge, Id = Index.TotalDeltaCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaCreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaCleared 
        /// </summary>
        [Display(Name = "TotalDeltaCleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeltaCleared, Id = Index.TotalDeltaCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaCleared { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaFunctionalAmount 
        /// </summary>
        [Display(Name = "TotalDeltaFunctionalAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeltaFunctionalAmount, Id = Index.TotalDeltaFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StatementCurrency", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationWriteOffSum 
        /// </summary>
        [Display(Name = "ReconciliationWriteOffSum", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationWriteOffSum, Id = Index.ReconciliationWriteOffSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationWriteOffSum { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationpostingYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReconciliationPostingYear", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationpostingYear, Id = Index.ReconciliationpostingYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ReconciliationpostingYear { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationpostingPeriod 
        /// </summary>
        [Display(Name = "ReconciliationpostingPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationpostingPeriod, Id = Index.ReconciliationpostingPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationpostingPeriod { get; set; }

        /// <summary>
        /// Gets or sets TotalDeposits 
        /// </summary>
        [Display(Name = "TotalDeposits", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDeposits, Id = Index.TotalDeposits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeposits { get; set; }

        /// <summary>
        /// Gets or sets DepositsinTransit 
        /// </summary>
        [Display(Name = "DepositsinTransit", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositsinTransit, Id = Index.DepositsinTransit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositsinTransit { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalTotal 
        /// </summary>
        [Display(Name = "DepositFunctionalTotal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositFunctionalTotal, Id = Index.DepositFunctionalTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositFunctionalTotal { get; set; }

        /// <summary>
        /// Gets or sets SumofDepositTotalWriteOffs 
        /// </summary>
        [Display(Name = "SumofDepositTotalWriteOffs", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SumofDepositTotalWriteOffs, Id = Index.SumofDepositTotalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SumofDepositTotalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositBankErrors 
        /// </summary>
        [Display(Name = "TotalDepositBankErrors", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositBankErrors, Id = Index.TotalDepositBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositBankErrors { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositExchangeGain 
        /// </summary>
        [Display(Name = "TotalDepositExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositExchangeGain, Id = Index.TotalDepositExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositExchangeLoss 
        /// </summary>
        [Display(Name = "TotalDepositExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositExchangeLoss, Id = Index.TotalDepositExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositCreditCardCharge 
        /// </summary>
        [Display(Name = "TotalDepositCreditCardCharge", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositCreditCardCharge, Id = Index.TotalDepositCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositCreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositCleared 
        /// </summary>
        [Display(Name = "TotalDepositCleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositCleared, Id = Index.TotalDepositCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositCleared { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositWriteOffToThis 
        /// </summary>
        [Display(Name = "FiscalDepositWriteOffToThis", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositWriteOffToThis, Id = Index.FiscalDepositWriteOffToThis, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositWriteOffToThis { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositBankErrors 
        /// </summary>
        [Display(Name = "FiscalDepositBankErrors", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositBankErrors, Id = Index.FiscalDepositBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositBankErrors { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositExchangeGain 
        /// </summary>
        [Display(Name = "FiscalDepositExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositExchangeGain, Id = Index.FiscalDepositExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositExchangeLoss 
        /// </summary>
        [Display(Name = "FiscalDepositExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositExchangeLoss, Id = Index.FiscalDepositExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositCreditCardCharg 
        /// </summary>
        [Display(Name = "FiscalDepositCreditCardCharg", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositCreditCardCharg, Id = Index.FiscalDepositCreditCardCharg, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositCreditCardCharg { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositCleared 
        /// </summary>
        [Display(Name = "FiscalDepositCleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositCleared, Id = Index.FiscalDepositCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositCleared { get; set; }

        /// <summary>
        /// Gets or sets DepositClearedwithExchangeRa 
        /// </summary>
        [Display(Name = "DepositClearedwithExchangeRa", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositClearedwithExchangeRa, Id = Index.DepositClearedwithExchangeRa, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositClearedwithExchangeRa { get; set; }

        /// <summary>
        /// Gets or sets DepositsInTransitToFiscPer 
        /// </summary>
        [Display(Name = "DepositsInTransitToFiscPer", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositsInTransitToFiscPer, Id = Index.DepositsInTransitToFiscPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositsInTransitToFiscPer { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositClearedToFuture 
        /// </summary>
        [Display(Name = "FiscalDepositClearedToFuture", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositClearedToFuture, Id = Index.FiscalDepositClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets TotalChecks 
        /// </summary>
        [Display(Name = "TotalChecks", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalChecks, Id = Index.TotalChecks, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalChecks { get; set; }

        /// <summary>
        /// Gets or sets ChecksOutstanding 
        /// </summary>
        [Display(Name = "ChecksOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ChecksOutstanding, Id = Index.ChecksOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChecksOutstanding { get; set; }

        /// <summary>
        /// Gets or sets WithdrawalFunctionalTotal 
        /// </summary>
        [Display(Name = "WithdrawalFunctionalTotal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.WithdrawalFunctionalTotal, Id = Index.WithdrawalFunctionalTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WithdrawalFunctionalTotal { get; set; }

        /// <summary>
        /// Gets or sets SumofWithdrawalTotalWriteOf 
        /// </summary>
        [Display(Name = "SumofWithdrawalTotalWriteOf", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SumofWithdrawalTotalWriteOf, Id = Index.SumofWithdrawalTotalWriteOf, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SumofWithdrawalTotalWriteOf { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalBankErrors 
        /// </summary>
        [Display(Name = "TotalWithdrawalBankErrors", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalWithdrawalBankErrors, Id = Index.TotalWithdrawalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalBankErrors { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalExchangeGain 
        /// </summary>
        [Display(Name = "TotalWithdrawalExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalWithdrawalExchangeGain, Id = Index.TotalWithdrawalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalExchangeLoss 
        /// </summary>
        [Display(Name = "TotalWithdrawalExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalWithdrawalExchangeLoss, Id = Index.TotalWithdrawalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalCreditCardCha 
        /// </summary>
        [Display(Name = "TotalWithdrawalCreditCardCha", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalWithdrawalCreditCardCha, Id = Index.TotalWithdrawalCreditCardCha, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalCreditCardCha { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalCleared 
        /// </summary>
        [Display(Name = "TotalWithdrawalCleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalWithdrawalCleared, Id = Index.TotalWithdrawalCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalCleared { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalWriteOffToT 
        /// </summary>
        [Display(Name = "FiscalWithdrawalWriteOffToT", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalWriteOffToT, Id = Index.FiscalWithdrawalWriteOffToT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalWriteOffToT { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalBankErrors 
        /// </summary>
        [Display(Name = "FiscalWithdrawalBankErrors", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalBankErrors, Id = Index.FiscalWithdrawalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalBankErrors { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalExchangeGain 
        /// </summary>
        [Display(Name = "FiscalWithdrawalExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalExchangeGain, Id = Index.FiscalWithdrawalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalExchangeLoss 
        /// </summary>
        [Display(Name = "FiscalWithdrawalExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalExchangeLoss, Id = Index.FiscalWithdrawalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalCreditCardCh 
        /// </summary>
        [Display(Name = "FiscalWithdrawalCreditCardCh", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalCreditCardCh, Id = Index.FiscalWithdrawalCreditCardCh, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalCreditCardCh { get; set; }

        /// <summary>
        /// Gets or sets RECWPCLR 
        /// </summary>
        [Display(Name = "ClearToReconciliationPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.RECWPCLR, Id = Index.RECWPCLR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RECWPCLR { get; set; }

        /// <summary>
        /// Gets or sets ChecksClearedwithExchRateD 
        /// </summary>
        [Display(Name = "ChecksClearedwithExchRateD", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ChecksClearedwithExchRateD, Id = Index.ChecksClearedwithExchRateD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChecksClearedwithExchRateD { get; set; }

        /// <summary>
        /// Gets or sets ChecksOutstandingToFiscPer 
        /// </summary>
        [Display(Name = "ChecksOutstandingToFiscPer", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ChecksOutstandingToFiscPer, Id = Index.ChecksOutstandingToFiscPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChecksOutstandingToFiscPer { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalClearedToFut 
        /// </summary>
        [Display(Name = "FiscalWithdrawalClearedToFut", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalClearedToFut, Id = Index.FiscalWithdrawalClearedToFut, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalClearedToFut { get; set; }

        /// <summary>
        /// Gets or sets FiscalMiscellaneousEntry 
        /// </summary>
        [Display(Name = "FiscalMiscellaneousEntry", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalMiscellaneousEntry, Id = Index.FiscalMiscellaneousEntry, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalMiscellaneousEntry { get; set; }

        /// <summary>
        /// Gets or sets PaymentMiscEntriesToFiscal 
        /// </summary>
        [Display(Name = "PaymentMiscEntriesToFiscal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PaymentMiscEntriesToFiscal, Id = Index.PaymentMiscEntriesToFiscal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentMiscEntriesToFiscal { get; set; }

        /// <summary>
        /// Gets or sets DepositMiscEntriesToFiscal 
        /// </summary>
        [Display(Name = "DepositMiscEntriesToFiscal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositMiscEntriesToFiscal, Id = Index.DepositMiscEntriesToFiscal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositMiscEntriesToFiscal { get; set; }

        /// <summary>
        /// Gets or sets PaymentMiscEntriesToFuture 
        /// </summary>
        [Display(Name = "PaymentMiscEntriesToFuture", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PaymentMiscEntriesToFuture, Id = Index.PaymentMiscEntriesToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentMiscEntriesToFuture { get; set; }

        /// <summary>
        /// Gets or sets DepositMiscEntriesToFuture 
        /// </summary>
        [Display(Name = "DepositMiscEntriesToFuture", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositMiscEntriesToFuture, Id = Index.DepositMiscEntriesToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositMiscEntriesToFuture { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositBookAmount 
        /// </summary>
        [Display(Name = "FiscalDepositBookAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositBookAmount, Id = Index.FiscalDepositBookAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositBookAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalBookAmount 
        /// </summary>
        [Display(Name = "FiscalWithdrawalBookAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalBookAmount, Id = Index.FiscalWithdrawalBookAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalBookAmount { get; set; }

        /// <summary>
        /// Gets or sets DetailAccessPortal 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DetailAccessPortal, Id = Index.DetailAccessPortal, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSlipPrinted DetailAccessPortal { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationDelta 
        /// </summary>
        [Display(Name = "ReconciliationDelta", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationDelta, Id = Index.ReconciliationDelta, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationDelta { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
          [Display(Name = "ProcessCommandCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets List of BankTransactionDetails
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<BankTransactionDetail> BankTransactionDetails { get; set; }

        [IgnoreExportImport]
        public BankJournalTransactionHeader BankJTransactionHeaders { get; set; }


        /// <summary>
        ///  Gets or sets FromTransactionNumber 
        /// </summary>
        [IgnoreExportImport]
        [IgnorePreferences]
        [Range(typeof(Decimal), "0", "999999999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal FromTransactionNumber { get; set; }

        /// <summary>
        /// Get Reconciliation Amount Decimals
        /// </summary>
        public string ReconciliationAmountDecimals { get; set; }

        #region Finder Display Properties

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string TransactionSlipPrintedString
        {
            get { return EnumUtility.GetStringValue(TransactionSlipPrinted); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string TransactionStatusString
        {
            get { return EnumUtility.GetStringValue(TransactionStatus); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string EntryTypeString
        {
            get { return EnumUtility.GetStringValue(EntryType); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string TransactionRecordedinSummaryString
        {
            get { return EnumUtility.GetStringValue(TransactionRecordedinSummary); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        // Used in Bank Transaction Header Finder
        [IgnoreExportImport]
        public string VarianceTypeString
        {
            get { return EnumUtility.GetStringValue(VarianceType); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string ReconciliationStatusString
        {
            get { return EnumUtility.GetStringValue(ReconciliationStatus); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string ReconciledandJournaledTransacString
        {
            get { return EnumUtility.GetStringValue(ReconciledandJournaledTransac); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string ReverseInvoiceString
        {
            get { return EnumUtility.GetStringValue(ReverseInvoice); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string DetailAccessPortalString
        {
            get { return EnumUtility.GetStringValue(DetailAccessPortal); }
        }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandCodeString
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        #endregion Finder Dispay Properties

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }


        /// <summary>
        /// To Get or Set Event type of EnumerableResponse Items
        /// </summary>
        /// <value>Event Type.</value>
        [IgnoreExportImport]
        public int EventTypeID { get; set; }

        /// <summary>
        /// Gets or sets the list of available Reconciliation Options
        /// </summary>
        [IsMvcSpecific]
        [IgnoreExportImport]
        public List<SelectList> ReconciliationStatusOptions { get; set; }

        /// <summary>
        /// Gets or sets flag identifying whether the record has been reconciled or not.
        /// </summary>
        [IsMvcSpecific]
        [IgnoreExportImport]
        public bool Reconciled
        {
            get; set; 
        }

        #region Grid Hidden Calculation
        /// <summary>
        /// Get and Set Grid Line Number
        /// </summary>
        [IgnoreExportImport]
        public int LineNumber { get; set; }

        /// <summary>
        /// Get and Set ReceiptCurrencyEqualBankCurrency
        /// </summary>
        [IgnoreExportImport]
        public bool ReceiptCurrencyEqualBankCurrency { get; set; }

        /// <summary>
        /// Get and Set CreditCardTransactionType
        /// </summary>
        [IgnoreExportImport]
        public bool CreditCardTransactionType { get; set; }

        /// <summary>
        /// Get and Set LineNonEditable
        /// </summary>
        [IgnoreExportImport]
        public bool LineNonEditable { get; set; }

        /// <summary>
        /// Get and Set RecieptEntryLineNonEditable
        /// </summary>
        [IgnoreExportImport]
        public bool RecieptEntryLineNonEditable { get; set; }


        /// <summary>
        /// Get and Set ReoconcileBydepositeIsPosted
        /// </summary>
        [IgnoreExportImport]
        public bool ReoconcileBydepositeIsPosted { get; set; }

        /// <summary>
        /// Get and Set NonEditableReverseInvoice
        /// </summary>
        [IgnoreExportImport]
        public bool NonEditableReverseInvoice { get; set; }

        /// <summary>
        /// Get and Set DeletedRecieptEntry
        /// </summary>
        [IgnoreExportImport]
        public bool DeletedRecieptEntry { get; set; } 

        /// <summary>
        /// Get and Set the Source application
        /// </summary>
        [IgnoreExportImport]
        public string GridSourceApplication { get; set; }

        /// <summary>
        /// Get and Set the Old Reconciliation Status
        /// </summary>
        [IgnoreExportImport]
        public ReconciliationStatus OldReconciliationStatus { get; set; } 

        #endregion
    }
}
