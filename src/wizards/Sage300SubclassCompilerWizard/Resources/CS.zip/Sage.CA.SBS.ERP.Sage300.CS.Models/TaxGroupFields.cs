/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of TaxGroups Constants 
    /// </summary>
    public partial class TaxGroup
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TX0003";

        /// <summary>
        /// Contains list of TaxGroups Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroupCode = "GROUPID";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TTYPE";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";
            /// <summary>
            /// Property for TaxReportingCurrency 
            /// </summary>
            public const string TaxReportingCurrency = "SRCCURN";
            /// <summary>
            /// Property for TaxAuthority1 
            /// </summary>
            public const string TaxAuthority1 = "AUTHORITY1";
            /// <summary>
            /// Property for TaxAuthority2 
            /// </summary>
            public const string TaxAuthority2 = "AUTHORITY2";
            /// <summary>
            /// Property for TaxAuthority3 
            /// </summary>
            public const string TaxAuthority3 = "AUTHORITY3";
            /// <summary>
            /// Property for TaxAuthority4 
            /// </summary>
            public const string TaxAuthority4 = "AUTHORITY4";
            /// <summary>
            /// Property for TaxAuthority5 
            /// </summary>
            public const string TaxAuthority5 = "AUTHORITY5";
            /// <summary>
            /// Property for Taxable1 
            /// </summary>
            public const string Taxable1 = "TAXABLE1";
            /// <summary>
            /// Property for Taxable2 
            /// </summary>
            public const string Taxable2 = "TAXABLE2";
            /// <summary>
            /// Property for Taxable3 
            /// </summary>
            public const string Taxable3 = "TAXABLE3";
            /// <summary>
            /// Property for Taxable4 
            /// </summary>
            public const string Taxable4 = "TAXABLE4";
            /// <summary>
            /// Property for Taxable5 
            /// </summary>
            public const string Taxable5 = "TAXABLE5";
            /// <summary>
            /// Property for TaxCalculationMethod 
            /// </summary>
            public const string TaxCalculationMethod = "CALCMETHOD";
            /// <summary>
            /// Property for LastMaintained 
            /// </summary>
            public const string LastMaintained = "LASTMAINT";
            /// <summary>
            /// Property for Surtax1 
            /// </summary>
            public const string Surtax1 = "SURTAX1";
            /// <summary>
            /// Property for Surtax2 
            /// </summary>
            public const string Surtax2 = "SURTAX2";
            /// <summary>
            /// Property for Surtax3 
            /// </summary>
            public const string Surtax3 = "SURTAX3";
            /// <summary>
            /// Property for Surtax4 
            /// </summary>
            public const string Surtax4 = "SURTAX4";
            /// <summary>
            /// Property for Surtax5 
            /// </summary>
            public const string Surtax5 = "SURTAX5";
            /// <summary>
            /// Property for SurtaxOnAuthority1 
            /// </summary>
            public const string SurtaxOnAuthority1 = "SURAUTH1";
            /// <summary>
            /// Property for SurtaxOnAuthority2 
            /// </summary>
            public const string SurtaxOnAuthority2 = "SURAUTH2";
            /// <summary>
            /// Property for SurtaxOnAuthority3 
            /// </summary>
            public const string SurtaxOnAuthority3 = "SURAUTH3";
            /// <summary>
            /// Property for SurtaxOnAuthority4 
            /// </summary>
            public const string SurtaxOnAuthority4 = "SURAUTH4";
            /// <summary>
            /// Property for SurtaxOnAuthority5 
            /// </summary>
            public const string SurtaxOnAuthority5 = "SURAUTH5";
            /// <summary>
            /// Property for TaxReportingRateType 
            /// </summary>
            public const string TaxReportingRateType = "TRATETYPE";

            #endregion
        }


        /// <summary>
        /// Contains list of TaxGroups Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroupCode = 1;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 2;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;
            /// <summary>
            /// Property Indexer for TaxReportingCurrency 
            /// </summary>
            public const int TaxReportingCurrency = 4;
            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 5;
            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 6;
            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 7;
            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 8;
            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 9;
            /// <summary>
            /// Property Indexer for Taxable1 
            /// </summary>
            public const int Taxable1 = 10;
            /// <summary>
            /// Property Indexer for Taxable2 
            /// </summary>
            public const int Taxable2 = 11;
            /// <summary>
            /// Property Indexer for Taxable3 
            /// </summary>
            public const int Taxable3 = 12;
            /// <summary>
            /// Property Indexer for Taxable4 
            /// </summary>
            public const int Taxable4 = 13;
            /// <summary>
            /// Property Indexer for Taxable5 
            /// </summary>
            public const int Taxable5 = 14;
            /// <summary>
            /// Property Indexer for TaxCalculationMethod 
            /// </summary>
            public const int TaxCalculationMethod = 15;
            /// <summary>
            /// Property Indexer for LastMaintained 
            /// </summary>
            public const int LastMaintained = 16;
            /// <summary>
            /// Property Indexer for Surtax1 
            /// </summary>
            public const int Surtax1 = 17;
            /// <summary>
            /// Property Indexer for Surtax2 
            /// </summary>
            public const int Surtax2 = 18;
            /// <summary>
            /// Property Indexer for Surtax3 
            /// </summary>
            public const int Surtax3 = 19;
            /// <summary>
            /// Property Indexer for Surtax4 
            /// </summary>
            public const int Surtax4 = 20;
            /// <summary>
            /// Property Indexer for Surtax5 
            /// </summary>
            public const int Surtax5 = 21;
            /// <summary>
            /// Property Indexer for SurtaxOnAuthority1 
            /// </summary>
            public const int SurtaxOnAuthority1 = 22;
            /// <summary>
            /// Property Indexer for SurtaxOnAuthority2 
            /// </summary>
            public const int SurtaxOnAuthority2 = 23;
            /// <summary>
            /// Property Indexer for SurtaxOnAuthority3 
            /// </summary>
            public const int SurtaxOnAuthority3 = 24;
            /// <summary>
            /// Property Indexer for SurtaxOnAuthority4 
            /// </summary>
            public const int SurtaxOnAuthority4 = 25;
            /// <summary>
            /// Property Indexer for SurtaxOnAuthority5 
            /// </summary>
            public const int SurtaxOnAuthority5 = 26;
            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 27;

            #endregion
        }


    }
}
