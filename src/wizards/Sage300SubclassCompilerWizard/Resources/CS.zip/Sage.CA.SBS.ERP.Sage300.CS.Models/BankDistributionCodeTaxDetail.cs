// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// class BankDistributionCodeTaxDetail
    /// </summary>
    public partial class BankDistributionCodeTaxDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof (BankDistributionCodesResx))]
        [Key]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "TrxTaxAuth", ResourceType = typeof (BankDistributionCodesResx))]
        [ViewField(Name = Fields.TaxAuthorityCode, Id = Index.TaxAuthorityCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthorityCode { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass 
        /// </summary>
        [Display(Name = "TrxTaxClass", ResourceType = typeof (BankDistributionCodesResx))]
        [ViewField(Name = Fields.ItemTaxClass, Id = Index.ItemTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int ItemTaxClass { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded 
        /// </summary>
        [Display(Name = "TrxTaxIncl", ResourceType = typeof (BankDistributionCodesResx))]
        [ViewField(Name = Fields.TaxIncluded, Id = Index.TaxIncluded, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxIncluded { get; set; }

        /// <summary>
        /// To get the string value of the TaxIncluded property
        /// </summary>
        public string TaxIncludedString
        {
            get { return EnumUtility.GetStringValue(TaxIncluded); }
        }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription 
        /// </summary>
        [Display(Name = "TrxTaxAuthDesc", ResourceType = typeof (BankDistributionCodesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthorityDescription, Id = Index.TaxAuthorityDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxClassDescription 
        /// </summary>
        [Display(Name = "TrxTaxClassDesc", ResourceType = typeof (BankDistributionCodesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TaxClassDescription, Id = Index.TaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClassDescription { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }
    }
}
