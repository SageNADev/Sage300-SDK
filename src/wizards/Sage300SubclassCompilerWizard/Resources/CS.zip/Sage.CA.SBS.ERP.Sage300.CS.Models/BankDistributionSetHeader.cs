/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is BankDistributionSetHeader entity
    /// </summary>
    public partial class BankDistributionSetHeader : ModelBase
    {
        #region Public Properties
        /// <summary>
        /// Gets or sets DistributionSetCode 
        /// </summary>
        [Display(Name = "DISTSET", ResourceType = typeof(BankDistributionSetsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DistributionSetCode, Id = Index.DistributionSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSetCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "DistributionSetDesc", ResourceType = typeof(BankDistributionSetsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(BankDistributionSetsResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(BankDistributionSetsResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(BankDistributionSetsResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets NumberofLines 
        /// </summary>
        [Display(Name = "NumberofLines", ResourceType = typeof(BankDistributionSetsResx))]
        [ViewField(Name = Fields.NumberofLines, Id = Index.NumberofLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofLines { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDecimals 
        /// </summary>
         [Display(Name = "CurrencyDecimals", ResourceType = typeof(BankDistributionSetsResx))]
        [ViewField(Name = Fields.CurrencyDecimals, Id = Index.CurrencyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int CurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets List of BankDistributionSetDetails
        /// </summary>
        public EnumerableResponse<BankDistributionSetDetail> BankDistributionSetDetails { get; set; }

        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        public bool IsMultiCurrrency { get; set; }

        #endregion

        }
}
