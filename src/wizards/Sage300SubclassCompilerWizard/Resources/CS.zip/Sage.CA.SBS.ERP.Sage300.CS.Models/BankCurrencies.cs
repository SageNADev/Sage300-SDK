/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// 
    /// </summary>
	public partial class BankCurrencies : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "BankCodeRequired", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(8, ErrorMessageResourceName = "BankCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		public string BankCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "CurrencyCodeRequired", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(3, ErrorMessageResourceName = "CurrencyCodeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		public string CurrencyCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets CheckRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "CheckRateTypeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string CheckRateType {get; set;}
		 
  		/// <summary>
        /// Gets or sets DepositRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "DepositRateTypeMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string DepositRateType {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeGainAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "ExchangeGainAccountMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string ExchangeGainAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeLossAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "ExchangeLossAccountMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string ExchangeLossAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets RoundingAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "RoundingAccountMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string RoundingAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets CurrencyDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "CurrencyDescriptionMaximumLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string CurrencyDescription {get; set;}
		    }
}
