// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// class Tax Classes
    /// </summary>
    public partial class TaxClasses : ModelBase
    {
        /// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets ClassType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        public ClassType ClassType { get; set; }

        /// <summary>
        /// Gets or sets Class 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        public int Class { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Exempt 
        /// </summary>
        [Display(Name = "Exempt", ResourceType = typeof (TaxClassesResx))]
        public AllowTaxInPrice Exempt { get; set; }

        /// <summary>
        /// Gets the Exemptstring.
        /// </summary>
        /// <value>The Exemptstring.</value>
        public string Exemptstring
        {
            get { return EnumUtility.GetStringValue(Exempt); }
        }
    }
}