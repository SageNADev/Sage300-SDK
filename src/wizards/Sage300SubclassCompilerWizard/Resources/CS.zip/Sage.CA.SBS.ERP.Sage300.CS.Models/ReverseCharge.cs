// Copyright (c) 2018 Sage  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for ReverseCharge
    /// </summary>
    public partial class ReverseCharge : ModelBase
    {
        /// <summary>
        /// Add class indexer
        /// </summary>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public object this[string propertyName]
        {
            get { return this.GetType().GetProperty(propertyName).GetValue(this, null); }
            set { this.GetType().GetProperty(propertyName).SetValue(this, value, null); }
        }
        /// <summary>
        /// Gets or sets TaxAuthority
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionType", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets ThresholdAmount
        /// </summary>
        [Display(Name = "ThresholdAmount", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.ThresholdAmount, Id = Index.ThresholdAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ThresholdAmount { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0101
        /// </summary>
        [Display(Name = "REVCHG0101", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0101, Id = Index.REVCHG0101, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0101 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0102
        /// </summary>
        [Display(Name = "REVCHG0102", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0102, Id = Index.REVCHG0102, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0102 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0103
        /// </summary>
        [Display(Name = "REVCHG0103", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0103, Id = Index.REVCHG0103, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0103 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0104
        /// </summary>
        [Display(Name = "REVCHG0104", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0104, Id = Index.REVCHG0104, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0104 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0105
        /// </summary>
        [Display(Name = "REVCHG0105", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0105, Id = Index.REVCHG0105, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0105 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0106
        /// </summary>
        [Display(Name = "REVCHG0106", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0106, Id = Index.REVCHG0106, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0106 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0107
        /// </summary>
        [Display(Name = "REVCHG0107", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0107, Id = Index.REVCHG0107, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0107 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0108
        /// </summary>
        [Display(Name = "REVCHG0108", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0108, Id = Index.REVCHG0108, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0108 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0109
        /// </summary>
        [Display(Name = "REVCHG0109", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0109, Id = Index.REVCHG0109, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0109 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0110
        /// </summary>
        [Display(Name = "REVCHG0110", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0110, Id = Index.REVCHG0110, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0110 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0201
        /// </summary>
        [Display(Name = "REVCHG0201", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0201, Id = Index.REVCHG0201, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0201 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0202
        /// </summary>
        [Display(Name = "REVCHG0202", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0202, Id = Index.REVCHG0202, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0202 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0203
        /// </summary>
        [Display(Name = "REVCHG0203", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0203, Id = Index.REVCHG0203, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0203 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0204
        /// </summary>
        [Display(Name = "REVCHG0204", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0204, Id = Index.REVCHG0204, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0204 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0205
        /// </summary>
        [Display(Name = "REVCHG0205", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0205, Id = Index.REVCHG0205, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0205 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0206
        /// </summary>
        [Display(Name = "REVCHG0206", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0206, Id = Index.REVCHG0206, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0206 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0207
        /// </summary>
        [Display(Name = "REVCHG0207", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0207, Id = Index.REVCHG0207, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0207 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0208
        /// </summary>
        [Display(Name = "REVCHG0208", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0208, Id = Index.REVCHG0208, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0208 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0209
        /// </summary>
        [Display(Name = "REVCHG0209", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0209, Id = Index.REVCHG0209, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0209 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0210
        /// </summary>
        [Display(Name = "REVCHG0210", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0210, Id = Index.REVCHG0210, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0210 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0301
        /// </summary>
        [Display(Name = "REVCHG0301", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0301, Id = Index.REVCHG0301, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0301 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0302
        /// </summary>
        [Display(Name = "REVCHG0302", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0302, Id = Index.REVCHG0302, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0302 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0303
        /// </summary>
        [Display(Name = "REVCHG0303", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0303, Id = Index.REVCHG0303, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0303 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0304
        /// </summary>
        [Display(Name = "REVCHG0304", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0304, Id = Index.REVCHG0304, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0304 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0305
        /// </summary>
        [Display(Name = "REVCHG0305", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0305, Id = Index.REVCHG0305, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0305 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0306
        /// </summary>
        [Display(Name = "REVCHG0306", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0306, Id = Index.REVCHG0306, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0306 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0307
        /// </summary>
        [Display(Name = "REVCHG0307", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0307, Id = Index.REVCHG0307, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0307 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0308
        /// </summary>
        [Display(Name = "REVCHG0308", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0308, Id = Index.REVCHG0308, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0308 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0309
        /// </summary>
        [Display(Name = "REVCHG0309", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0309, Id = Index.REVCHG0309, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0309 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0310
        /// </summary>
        [Display(Name = "REVCHG0310", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0310, Id = Index.REVCHG0310, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0310 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0401
        /// </summary>
        [Display(Name = "REVCHG0401", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0401, Id = Index.REVCHG0401, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0401 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0402
        /// </summary>
        [Display(Name = "REVCHG0402", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0402, Id = Index.REVCHG0402, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0402 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0403
        /// </summary>
        [Display(Name = "REVCHG0403", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0403, Id = Index.REVCHG0403, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0403 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0404
        /// </summary>
        [Display(Name = "REVCHG0404", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0404, Id = Index.REVCHG0404, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0404 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0405
        /// </summary>
        [Display(Name = "REVCHG0405", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0405, Id = Index.REVCHG0405, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0405 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0406
        /// </summary>
        [Display(Name = "REVCHG0406", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0406, Id = Index.REVCHG0406, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0406 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0407
        /// </summary>
        [Display(Name = "REVCHG0407", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0407, Id = Index.REVCHG0407, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0407 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0408
        /// </summary>
        [Display(Name = "REVCHG0408", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0408, Id = Index.REVCHG0408, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0408 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0409
        /// </summary>
        [Display(Name = "REVCHG0409", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0409, Id = Index.REVCHG0409, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0409 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0410
        /// </summary>
        [Display(Name = "REVCHG0410", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0410, Id = Index.REVCHG0410, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0410 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0501
        /// </summary>
        [Display(Name = "REVCHG0501", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0501, Id = Index.REVCHG0501, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0501 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0502
        /// </summary>
        [Display(Name = "REVCHG0502", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0502, Id = Index.REVCHG0502, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0502 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0503
        /// </summary>
        [Display(Name = "REVCHG0503", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0503, Id = Index.REVCHG0503, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0503 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0504
        /// </summary>
        [Display(Name = "REVCHG0504", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0504, Id = Index.REVCHG0504, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0504 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0505
        /// </summary>
        [Display(Name = "REVCHG0505", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0505, Id = Index.REVCHG0505, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0505 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0506
        /// </summary>
        [Display(Name = "REVCHG0506", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0506, Id = Index.REVCHG0506, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0506 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0507
        /// </summary>
        [Display(Name = "REVCHG0507", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0507, Id = Index.REVCHG0507, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0507 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0508
        /// </summary>
        [Display(Name = "REVCHG0508", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0508, Id = Index.REVCHG0508, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0508 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0509
        /// </summary>
        [Display(Name = "REVCHG0509", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0509, Id = Index.REVCHG0509, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0509 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0510
        /// </summary>
        [Display(Name = "REVCHG0510", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0510, Id = Index.REVCHG0510, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0510 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0601
        /// </summary>
        [Display(Name = "REVCHG0601", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0601, Id = Index.REVCHG0601, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0601 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0602
        /// </summary>
        [Display(Name = "REVCHG0602", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0602, Id = Index.REVCHG0602, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0602 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0603
        /// </summary>
        [Display(Name = "REVCHG0603", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0603, Id = Index.REVCHG0603, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0603 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0604
        /// </summary>
        [Display(Name = "REVCHG0604", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0604, Id = Index.REVCHG0604, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0604 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0605
        /// </summary>
        [Display(Name = "REVCHG0605", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0605, Id = Index.REVCHG0605, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0605 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0606
        /// </summary>
        [Display(Name = "REVCHG0606", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0606, Id = Index.REVCHG0606, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0606 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0607
        /// </summary>
        [Display(Name = "REVCHG0607", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0607, Id = Index.REVCHG0607, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0607 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0608
        /// </summary>
        [Display(Name = "REVCHG0608", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0608, Id = Index.REVCHG0608, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0608 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0609
        /// </summary>
        [Display(Name = "REVCHG0609", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0609, Id = Index.REVCHG0609, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0609 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0610
        /// </summary>
        [Display(Name = "REVCHG0610", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0610, Id = Index.REVCHG0610, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0610 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0701
        /// </summary>
        [Display(Name = "REVCHG0701", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0701, Id = Index.REVCHG0701, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0701 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0702
        /// </summary>
        [Display(Name = "REVCHG0702", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0702, Id = Index.REVCHG0702, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0702 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0703
        /// </summary>
        [Display(Name = "REVCHG0703", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0703, Id = Index.REVCHG0703, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0703 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0704
        /// </summary>
        [Display(Name = "REVCHG0704", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0704, Id = Index.REVCHG0704, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0704 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0705
        /// </summary>
        [Display(Name = "REVCHG0705", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0705, Id = Index.REVCHG0705, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0705 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0706
        /// </summary>
        [Display(Name = "REVCHG0706", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0706, Id = Index.REVCHG0706, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0706 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0707
        /// </summary>
        [Display(Name = "REVCHG0707", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0707, Id = Index.REVCHG0707, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0707 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0708
        /// </summary>
        [Display(Name = "REVCHG0708", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0708, Id = Index.REVCHG0708, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0708 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0709
        /// </summary>
        [Display(Name = "REVCHG0709", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0709, Id = Index.REVCHG0709, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0709 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0710
        /// </summary>
        [Display(Name = "REVCHG0710", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0710, Id = Index.REVCHG0710, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0710 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0801
        /// </summary>
        [Display(Name = "REVCHG0801", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0801, Id = Index.REVCHG0801, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0801 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0802
        /// </summary>
        [Display(Name = "REVCHG0802", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0802, Id = Index.REVCHG0802, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0802 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0803
        /// </summary>
        [Display(Name = "REVCHG0803", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0803, Id = Index.REVCHG0803, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0803 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0804
        /// </summary>
        [Display(Name = "REVCHG0804", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0804, Id = Index.REVCHG0804, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0804 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0805
        /// </summary>
        [Display(Name = "REVCHG0805", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0805, Id = Index.REVCHG0805, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0805 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0806
        /// </summary>
        [Display(Name = "REVCHG0806", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0806, Id = Index.REVCHG0806, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0806 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0807
        /// </summary>
        [Display(Name = "REVCHG0807", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0807, Id = Index.REVCHG0807, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0807 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0808
        /// </summary>
        [Display(Name = "REVCHG0808", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0808, Id = Index.REVCHG0808, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0808 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0809
        /// </summary>
        [Display(Name = "REVCHG0809", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0809, Id = Index.REVCHG0809, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0809 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0810
        /// </summary>
        [Display(Name = "REVCHG0810", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0810, Id = Index.REVCHG0810, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0810 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0901
        /// </summary>
        [Display(Name = "REVCHG0901", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0901, Id = Index.REVCHG0901, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0901 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0902
        /// </summary>
        [Display(Name = "REVCHG0902", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0902, Id = Index.REVCHG0902, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0902 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0903
        /// </summary>
        [Display(Name = "REVCHG0903", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0903, Id = Index.REVCHG0903, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0903 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0904
        /// </summary>
        [Display(Name = "REVCHG0904", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0904, Id = Index.REVCHG0904, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0904 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0905
        /// </summary>
        [Display(Name = "REVCHG0905", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0905, Id = Index.REVCHG0905, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0905 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0906
        /// </summary>
        [Display(Name = "REVCHG0906", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0906, Id = Index.REVCHG0906, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0906 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0907
        /// </summary>
        [Display(Name = "REVCHG0907", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0907, Id = Index.REVCHG0907, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0907 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0908
        /// </summary>
        [Display(Name = "REVCHG0908", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0908, Id = Index.REVCHG0908, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0908 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0909
        /// </summary>
        [Display(Name = "REVCHG0909", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0909, Id = Index.REVCHG0909, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0909 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG0910
        /// </summary>
        [Display(Name = "REVCHG0910", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG0910, Id = Index.REVCHG0910, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG0910 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1001
        /// </summary>
        [Display(Name = "REVCHG1001", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1001, Id = Index.REVCHG1001, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1001 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1002
        /// </summary>
        [Display(Name = "REVCHG1002", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1002, Id = Index.REVCHG1002, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1002 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1003
        /// </summary>
        [Display(Name = "REVCHG1003", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1003, Id = Index.REVCHG1003, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1003 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1004
        /// </summary>
        [Display(Name = "REVCHG1004", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1004, Id = Index.REVCHG1004, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1004 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1005
        /// </summary>
        [Display(Name = "REVCHG1005", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1005, Id = Index.REVCHG1005, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1005 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1006
        /// </summary>
        [Display(Name = "REVCHG1006", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1006, Id = Index.REVCHG1006, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1006 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1007
        /// </summary>
        [Display(Name = "REVCHG1007", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1007, Id = Index.REVCHG1007, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1007 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1008
        /// </summary>
        [Display(Name = "REVCHG1008", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1008, Id = Index.REVCHG1008, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1008 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1009
        /// </summary>
        [Display(Name = "REVCHG1009", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1009, Id = Index.REVCHG1009, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1009 { get; set; }

        /// <summary>
        /// Gets or sets REVCHG1010
        /// </summary>
        [Display(Name = "REVCHG1010", ResourceType = typeof (ReverseChargeResx))]
        [ViewField(Name = Fields.REVCHG1010, Id = Index.REVCHG1010, FieldType = EntityFieldType.Bool, Size = 2)]
        public ReverseChargeType REVCHG1010 { get; set; }

        /// <summary>
        /// Gets or sets InputTaxAccount Name
        /// </summary>
        [Display(Name = "InputTaxAccount", ResourceType = typeof(TaxAuthoritiesResx))]
        [MaxLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[ViewField(Name = Fields.InputTaxAccount, Id = Index.InputTaxAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InputTaxAccount { get; set; }

        /// <summary>
        /// Gets or sets OutputTaxAccount Name
        /// </summary>
        [Display(Name = "OutputTaxAccount", ResourceType = typeof(TaxAuthoritiesResx))]
        [MaxLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[ViewField(Name = Fields.OutputTaxAccount, Id = Index.OutputTaxAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string OutputTaxAccount { get; set; }
    }
}
