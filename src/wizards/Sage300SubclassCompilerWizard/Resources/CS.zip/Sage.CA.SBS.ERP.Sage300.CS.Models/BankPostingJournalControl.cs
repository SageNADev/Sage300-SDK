//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is BankPostingJournalControl entity
    /// </summary>
    public partial class BankPostingJournalControl : ModelBase
    {

        /// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets FromBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromBank, Id = Index.FromBank, FieldType = EntityFieldType.Char, Size = 8)]
        public string FromBank { get; set; }

        /// <summary>
        /// Gets or sets ToBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToBank, Id = Index.ToBank, FieldType = EntityFieldType.Char, Size = 8)]
        public string ToBank { get; set; }

        /// <summary>
        /// Gets or sets DatePostedtoGL 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DatePostedtoGL, Id = Index.DatePostedtoGL, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePostedtoGL { get; set; }

        /// <summary>
        /// Gets or sets PostingUser 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingUser, Id = Index.PostingUser, FieldType = EntityFieldType.Char, Size = 8)]
        public string PostingUser { get; set; }

        /// <summary>
        /// Gets or sets PostingStatus 
        /// </summary>
        [ViewField(Name = Fields.PostingStatus, Id = Index.PostingStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PostingStatus PostingStatus { get; set; }

        /// <summary>
        /// Gets or sets LastDateJournalPrinted 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastDateJournalPrinted, Id = Index.LastDateJournalPrinted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastDateJournalPrinted { get; set; }

        /// <summary>
        /// Gets or sets CreateGOrLBatches 
        /// </summary>

        [ViewField(Name = Fields.CreateGorLBatches, Id = Index.CreateGorLBatches, FieldType = EntityFieldType.Bool, Size = 2)]
        public CreateGorLBatches CreateGorLBatches { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateGOrLBatches 
        /// </summary>

        [ViewField(Name = Fields.ConsolidateGorLBatches, Id = Index.ConsolidateGorLBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidateGorLBatches ConsolidateGorLBatches { get; set; }

        /// <summary>
        /// Gets or sets CreateGOrLTransactionsBy 
        /// </summary>

        [ViewField(Name = Fields.CreateGorLTransactionsBy, Id = Index.CreateGorLTransactionsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateGorLTransactionsBy CreateGorLTransactionsBy { get; set; }

        /// <summary>
        /// Gets or sets GOrLBatchNumber 
        /// </summary>

        [ViewField(Name = Fields.GorLBatchNumber, Id = Index.GorLBatchNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal GorLBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets GOrLBatchTransferred 
        /// </summary>

        [ViewField(Name = Fields.GorLBatchTransferred, Id = Index.GorLBatchTransferred, FieldType = EntityFieldType.Bool, Size = 2)]
        public long GorLBatchTransferred { get; set; }

        /// <summary>
        /// Gets or sets PostingType 
        /// </summary>

        [ViewField(Name = Fields.PostingType, Id = Index.PostingType, FieldType = EntityFieldType.Int, Size = 2)]
        public PostingType PostingType { get; set; }

        /// <summary>
        /// Gets or sets BankSequence 
        /// </summary>

        [ViewField(Name = Fields.BankSequence, Id = Index.BankSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long BankSequence { get; set; }

        /// <summary>
        /// Gets or sets Printed? 
        /// </summary>

        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Printed Printed { get; set; }

        #region UI

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string</value>
        public string TypePrinted
        {
            get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string</value>
        public string TypePosting
        {
            get { return EnumUtility.GetStringValue(PostingType); }
        }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string</value>
        public string TypeCreateGorLBatches
        {
            get { return EnumUtility.GetStringValue(CreateGorLBatches); }
        }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string</value>
        public string TypeConsolidateGorLBatches
        {
            get { return EnumUtility.GetStringValue(ConsolidateGorLBatches); }
        }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string</value>
        public string TypeCreateGorLTransactionsBy
        {
            get { return EnumUtility.GetStringValue(CreateGorLTransactionsBy); }
        }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string</value>
        public string TypePostingStatus
        {
            get { return EnumUtility.GetStringValue(PostingStatus); }
        }

        /// <summary>
        /// Gets or sets GOrLBatchTransferred 
        /// </summary>

        public string TypeGorLBatchTransferred
        {
            get { return EnumUtility.GetStringValue((BooleanType)GorLBatchTransferred); }
        }

        #endregion
    }
}
