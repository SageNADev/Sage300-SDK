﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class CompanyProfileOptions
    /// </summary>
    public class CompanyProfileOptions : ModelBase
    {
        /// <summary>
        /// Gets or sets Location Type 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationType", ResourceType = typeof(CompanyProfileResx))]
        public string LocationType { get; set; }

        /// <summary>
        /// Gets or sets Location Code 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationCode", ResourceType = typeof(CompanyProfileResx))]
        public string LocationCode { get; set; }

        /// <summary>
        /// Gets or sets Country Code 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CountryCode", ResourceType = typeof(CompanyProfileResx))]
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or sets Branch 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Branch", ResourceType = typeof(CompanyProfileResx))]
        public string Branch { get; set; }

        /// <summary>
        /// Gets or sets NumberofFiscalPeriods
        /// </summary>
        [Display(Name = "NumFiscalPeriods", ResourceType = typeof(CompanyProfileResx))]
        public NumberofFiscalPeriods NumberofFiscalPeriods { get; set; }

        /// <summary>
        /// Gets or sets Quarterwith4Periods
        /// </summary>
        [Display(Name = "Qtr4Periods", ResourceType = typeof(CompanyProfileResx))]
        public Quarterwith4Periods Quarterwith4Periods { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(CommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or Sets Currency Description.
        /// </summary>
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
          [Display(Name = "Multicurrency", ResourceType = typeof(CommonResx))]
        public bool IsMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets IsMulticurrencyReadOnly
        /// </summary>
        public bool IsMulticurrencyReadOnly { get; set; }

        /// <summary>
        /// Gets or sets WarningDateRange
        /// </summary>
        [Display(Name = "WarningDateRange", ResourceType = typeof(CompanyProfileResx))]
        [Range(0, 999, ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int WarningDateRange { get; set; }

        /// <summary>
        /// Gets or sets Euro
        /// </summary>
        public long Euro { get; set; }

        /// <summary>
        /// Gets or sets Reporting Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ReportingCurrency { get; set; }

        /// <summary>
        /// Gets or sets LockedFiscalPeriod
        /// </summary>
        [Display(Name = "LockedFiscalPeriod", ResourceType = typeof(CompanyProfileResx))]
        public LockedFiscalPeriod LockedFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets InactiveGOrLAccount
        /// </summary>
        [Display(Name = "InactiveAccount", ResourceType = typeof(CompanyProfileResx))]
        public LockedFiscalPeriod InactiveGorLAccount { get; set; }

        /// <summary>
        /// Gets or sets NonexistentGOrLAccount
        /// </summary>
        [Display(Name = "NoExistAccount", ResourceType = typeof(CompanyProfileResx))]
        public LockedFiscalPeriod NonexistentGorLAccount { get; set; }

        /// <summary>
        /// Gets or sets GainOrLossAccountingMethod
        /// </summary>
        [Display(Name = "GainLossAcctMethod", ResourceType = typeof(CompanyProfileResx))]
        public GainOrLossAccountingMethod GainOrLossAccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets IsAccountingMethodReadOnly
        /// </summary>
        public bool IsAccountingMethodReadOnly { get; set; }

        /// <summary>
        ///  Gets or sets Multicurrency
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof(CompanyProfileResx))]
        public string Multicurrency { get; set; }
    }
}