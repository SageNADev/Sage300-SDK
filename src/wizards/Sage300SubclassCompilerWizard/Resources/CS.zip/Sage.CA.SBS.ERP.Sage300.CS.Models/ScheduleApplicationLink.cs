// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
	/// <summary>
	/// Partial class for ScheduleApplicationLink
	/// </summary>
	public partial class ScheduleApplicationLink : ModelBase
    {
        #region Properties

        /// <summary>
		/// Gets or sets ScheduleCode
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ScheduleCode, Id = Index.ScheduleCode, FieldType = EntityFieldType.Char, Size = 12)]
		public string ScheduleCode { get; set; }

		/// <summary>
		/// Gets or sets ScheduleLink
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ScheduleLink, Id = Index.ScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ScheduleLink { get; set; }

		/// <summary>
		/// Gets or sets APPLICATIO
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Application, Id = Index.Application, FieldType = EntityFieldType.Char, Size = 2)]
		public string Application { get; set; }

		/// <summary>
		/// Gets or sets ApplicationType
		/// </summary>
		[StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ApplicationType, Id = Index.ApplicationType, FieldType = EntityFieldType.Char, Size = 4)]
		public string ApplicationType { get; set; }

		/// <summary>
		/// Gets or sets JobTypes
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.JobTypes, Id = Index.JobTypes, FieldType = EntityFieldType.Char, Size = 60)]
		public string JobTypes { get; set; }

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 80)]
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets APPLICATID
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ApplicationID, Id = Index.ApplicationID, FieldType = EntityFieldType.Char, Size = 60)]
		public string ApplicationID { get; set; }

		/// <summary>
		/// Gets or sets LastRunDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.LastRunDate, Id = Index.LastRunDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? LastRunDate { get; set; }

		/// <summary>
		/// Gets or sets NextRunDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.NextRunDate, Id = Index.NextRunDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? NextRunDate { get; set; }

		#endregion
	}
}
