/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class represents a Model for Bank Entry Header
    /// </summary>
    public partial class BankEntryHeader : ModelBase
    {

        /// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "SequenceNumber", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets BankEntryNumber 
        /// </summary>
        [Display(Name = "BankEntryNo", ResourceType = typeof(PostEntriesResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankEntryNumber, Id = Index.BankEntryNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string BankEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Display(Name = "BankCode", ResourceType = typeof(BankEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets DateCreated 
        /// </summary>
        [Display(Name = "DateCreated", ResourceType = typeof(BankEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateCreated, Id = Index.DateCreated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or sets BankEntryType 
        /// </summary>
        [Display(Name = "BankEntryType", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.BankEntryType, Id = Index.BankEntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public BankEntryType BankEntryType { get; set; }

        /// <summary>
        /// Gets or sets EntryDescription 
        /// </summary>
        [Display(Name = "EntryDesc", ResourceType = typeof(BankEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EntryDescription, Id = Index.EntryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string EntryDescription { get; set; }

        /// <summary>
        /// Gets or sets EntryTotalWithoutTax 
        /// </summary>
        [Display(Name = "EntryTotalWithoutTax", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.EntryTotalWithoutTax, Id = Index.EntryTotalWithoutTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EntryTotalWithoutTax { get; set; }

        /// <summary>
        /// Gets or sets FuncEntryTotalWithoutTax 
        /// </summary>
        [Display(Name = "FuncEntryTotalWithoutTax", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.FuncEntryTotalWithoutTax, Id = Index.FuncEntryTotalWithoutTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncEntryTotalWithoutTax { get; set; }

        /// <summary>
        /// Gets or sets EntryTotal 
        /// </summary>
        [Display(Name = "BankEntryTotSour", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.EntryTotal, Id = Index.EntryTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EntryTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncEntryTotal 
        /// </summary>
        [Display(Name = "BankEntryTotFunc", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.FuncEntryTotal, Id = Index.FuncEntryTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncEntryTotal { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RatetypeFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ExchangeRateType, Id = Index.ExchangeRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ExchangeRateType { get; set; }

        /// <summary>
        /// Gets or sets BankEntryCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankEntryCurrency", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.BankEntryCurrency, Id = Index.BankEntryCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BankEntryCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RatedateFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExchangeRateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread 
        /// </summary>
        [Display(Name = "RatespreadFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        [Display(Name = "RateopFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingRateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets BankEntryDate 
        /// </summary>
        [Display(Name = "EntDateFLD", ResourceType = typeof(BKCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankEntryDate, Id = Index.BankEntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BankEntryDate { get; set; }

        /// <summary>
        /// Gets or sets BankEntryYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankEntryYear", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.BankEntryYear, Id = Index.BankEntryYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string BankEntryYear { get; set; }

        /// <summary>
        /// Gets or sets BankEntryPeriod 
        /// </summary>
        [Display(Name = "BankEntryPeriod", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.BankEntryPeriod, Id = Index.BankEntryPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int BankEntryPeriod { get; set; }

        /// <summary>
        /// Gets or sets CompletedStatus 
        /// </summary>
        [Display(Name = "CompletedStatus", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.CompletedStatus, Id = Index.CompletedStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CompletedStatus CompletedStatus { get; set; }

        /// <summary>
        /// Gets or sets Comments 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntBigcommentFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public BankEntryStatus Status { get; set; }

        /// <summary>
        /// Gets or sets ReconcilationDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecdateFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ReconcilationDate, Id = Index.ReconcilationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReconcilationDate { get; set; }

        /// <summary>
        /// Gets or sets ReconcilationYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecyearFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ReconcilationYear, Id = Index.ReconcilationYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ReconcilationYear { get; set; }

        /// <summary>
        /// Gets or sets ReconcilationPeriod 
        /// </summary>
        [Display(Name = "RecperiodFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ReconcilationPeriod, Id = Index.ReconcilationPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconcilationPeriod { get; set; }

        /// <summary>
        /// Gets or sets NumberofLines 
        /// </summary>
        [Display(Name = "NumberofLines", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.NumberofLines, Id = Index.NumberofLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofLines { get; set; }

        /// <summary>
        /// Gets or sets BankEntrySerialNumber 
        /// </summary>
        [Display(Name = "BankEntrySerialNumber", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.BankEntrySerialNumber, Id = Index.BankEntrySerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long BankEntrySerialNumber { get; set; }

        /// <summary>
        /// Gets or sets RunId 
        /// </summary>
        [Display(Name = "RunId", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.RunId, Id = Index.RunId, FieldType = EntityFieldType.Long, Size = 4)]
        public long RunId { get; set; }

        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets OFXTransactionID 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OFXTransactionID", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.OFXTransactionID, Id = Index.OFXTransactionID, FieldType = EntityFieldType.Char, Size = 50)]
        public string OFXTransactionID { get; set; }

        /// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public SubmissionType EntryType { get; set; }

        /// <summary>
        /// Gets or sets DistributionSet 
        /// </summary>
        [Display(Name = "DISTSet", ResourceType = typeof(BankEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionSet, Id = Index.DistributionSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionSet { get; set; }

        /// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        [Display(Name = "PostingSequence", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets BankName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankName", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankName, Id = Index.BankName, FieldType = EntityFieldType.Char, Size = 60)]
        public string BankName { get; set; }

        /// <summary>
        /// Gets or sets BankAccount 
        /// </summary>
        [Display(Name = "BankAcct", ResourceType = typeof(BankEntryResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankAccount, Id = Index.BankAccount, FieldType = EntityFieldType.Char, Size = 22)]
        public string BankAccount { get; set; }

        /// <summary>
        /// Gets or sets BankStatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.BankStatementCurrency, Id = Index.BankStatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string BankStatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets DistributionSetDesc 
        /// </summary>
        [Display(Name = "DistSetDesc", ResourceType = typeof(BankEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DistributionSetDesc, Id = Index.DistributionSetDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string DistributionSetDesc { get; set; }

        /// <summary>
        /// Gets or sets TotalStatementAmount 
        /// </summary>
        [Display(Name = "TotalStatementAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalStatementAmount, Id = Index.TotalStatementAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalStatementAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalEntryAmount 
        /// </summary>
        [Display(Name = "FiscalEntryAmount", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.FiscalEntryAmount, Id = Index.FiscalEntryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalEntryAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciledEntryAmount 
        /// </summary>
        [Display(Name = "ReconciledEntryAmount", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.ReconciledEntryAmount, Id = Index.ReconciledEntryAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciledEntryAmount { get; set; }

        /// <summary>
        /// Gets or sets DefaultNewDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultNewDocumentNumber", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.DefaultNewDocumentNumber, Id = Index.DefaultNewDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultNewDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets AgingRecondays 
        /// </summary>
        [Display(Name = "AgingRecondays", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.AgingRecondays, Id = Index.AgingRecondays, FieldType = EntityFieldType.Int, Size = 2)]
        public int AgingRecondays { get; set; }

        /// <summary>
        /// Gets or sets KeepInputEntryNo 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.KeepInputEntryNo, Id = Index.KeepInputEntryNo, FieldType = EntityFieldType.Int, Size = 2)]
        public int KeepInputEntryNo { get; set; }

        /// <summary>
        /// Gets or sets BankEntryCurrencyDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankEntryCurrencyDesc", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.BankEntryCurrencyDesc, Id = Index.BankEntryCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string BankEntryCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets DefaultBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DefaultBankCode, Id = Index.DefaultBankCode, FieldType = EntityFieldType.Char, Size = 8)]
        public string DefaultBankCode { get; set; }

        /// <summary>
        /// Gets or sets ErrorinAutoBank 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ErrorinAutoBank, Id = Index.ErrorinAutoBank, FieldType = EntityFieldType.Bool, Size = 2)]
        public long ErrorinAutoBank { get; set; }

        /// <summary>
        /// Gets or sets List of BankEntryDetails
        /// </summary>
        public EnumerableResponse<BankEntryDetail> BankEntryDetails { get; set; }

        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        public bool IsMultiCurrrency { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        public short SessionWarnDays { get; set; }

        /// <summary>
        /// Get or set for Bank Currency Count
        /// </summary>
        public int BankCurrencyCount { get; set; }

        /// <summary>
        /// Get or Set From reconcile Bank
        /// </summary>
        public bool IsFromReconcileOFX { get; set; }

        /// <summary>
        /// Gets or sets Comments 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntBigcommentFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 60)]
        public string Comment { get; set; }

        #region Finder Values

        /// <summary>
        /// To get the string of Entry Type property
        /// </summary>
        /// <value>The Entry Type string.</value>
        public string BankEntryTypeString
        {
            get { return EnumUtility.GetStringValue(BankEntryType); }
        }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        /// <value>The Status string.</value>
        public string CompletedStatusString
        {
            get { return EnumUtility.GetStringValue(CompletedStatus); }
        }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        /// <value>The Status string.</value>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// To get the string of Payment Type property
        /// </summary>
        /// <value>The Payment Type string.</value>
        public string PaymentTypeString
        {
            get { return EnumUtility.GetStringValue(PaymentType); }
        }

        /// <summary>
        /// To get the string of Entry Type property
        /// </summary>
        /// <value>The Entry Type string.</value>
        public string EntryTypeString
        {
            get { return EnumUtility.GetStringValue(EntryType); }
        }

        /// <summary>
        /// To get the string of Rate Operation property
        /// </summary>
        /// <value>The Rate Operation string.</value>
        public string RateOperationString
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        #endregion

    }
}
