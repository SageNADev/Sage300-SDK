// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

# region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Model class for BankTransactionPortalSuperview
    /// </summary>
    public partial class BankTransactionPortalSuperview : ModelBase
    {
        #region properties

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8)]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionHeaderSerial 
        /// </summary>        
        [ViewField(Name = Fields.TransactionHeaderSerial, Id = Index.TransactionHeaderSerial, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long TransactionHeaderSerial { get; set; }

        /// <summary>
        /// Gets or sets TransactionDetailLine 
        /// </summary>
        [ViewField(Name = Fields.TransactionDetailLine, Id = Index.TransactionDetailLine, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionDetailLine { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2)]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets Operation 
        /// </summary>        
        [ViewField(Name = Fields.Operation, Id = Index.Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public Operation Operation { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public EntryType EntryType { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber 
        /// </summary>
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets Transaction Reference (Original property is HREFERENCE)
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TransactionReference, Id = Index.TransactionReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionReference { get; set; }

        /// <summary>
        /// Gets or sets Description (Original property is DESC)
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus 
        /// </summary>
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets DefaultReconciliationStatus 
        /// </summary>
        [ViewField(Name = Fields.DefaultReconciliationStatus, Id = Index.DefaultReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int DefaultReconciliationStatus { get; set; }

        /// <summary>
        /// Gets or sets OldSerialNumber 
        /// </summary>
        [ViewField(Name = Fields.OldSerialNumber, Id = Index.OldSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long OldSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets LinesReconciled 
        /// </summary>
        [ViewField(Name = Fields.LinesReconciled, Id = Index.LinesReconciled, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesReconciled { get; set; }

        /// <summary>
        /// Gets or sets LinesJournalled 
        /// </summary>
        [ViewField(Name = Fields.LinesJournalled, Id = Index.LinesJournalled, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesJournalled { get; set; }

        /// <summary>
        /// Gets or sets LinesProcessed 
        /// </summary>
        [ViewField(Name = Fields.LinesProcessed, Id = Index.LinesProcessed, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesProcessed { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationClearedAmount 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationClearedAmount, Id = Index.ReconciliationClearedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationClearedAmount { get; set; }

        /// <summary>
        /// Gets or sets ReceiptStatus 
        /// </summary>
        [ViewField(Name = Fields.ReceiptStatus, Id = Index.ReceiptStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReceiptStatus { get; set; }

        /// <summary>
        /// Gets or sets DetailTransactionType 
        /// </summary>
        [ViewField(Name = Fields.DetailTransactionType, Id = Index.DetailTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.DetailTransactionType DetailTransactionType { get; set; }

        /// <summary>
        /// Gets or sets RemittanceID 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RemittanceID, Id = Index.RemittanceID, FieldType = EntityFieldType.Char, Size = 24)]
        public string RemittanceID { get; set; }

        /// <summary>
        /// Gets or sets BankSerialDateRemitSerialLine (Original property is DATEREMIT)
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateRemit, Id = Index.DateRemit, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateRemit { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>

        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.PostingSequenceNumber, Id = Index.PostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Referece (Original property is REFERENCE) 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Referece, Id = Index.Referece, FieldType = EntityFieldType.Char, Size = 60)]
        public string Referece { get; set; }

        /// <summary>
        /// Gets or sets Reconcile Comment (Original property is COMMENT)
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReconcileComment, Id = Index.ReconcileComment, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReconcileComment { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationStatus 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationStatus, Id = Index.ReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationStatus { get; set; }

        /// <summary>
        /// Gets or sets PayerCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PayerCode, Id = Index.PayerCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string PayerCode { get; set; }

        /// <summary>
        /// Gets or sets PayeeName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PayeeName, Id = Index.PayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PayeeName { get; set; }

        /// <summary>
        /// Gets or sets VendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets SourceAmount 
        /// </summary>
        [ViewField(Name = Fields.SourceAmount, Id = Index.SourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalAmount, Id = Index.FunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeRateType, Id = Index.ExchangeRateType, FieldType = EntityFieldType.Char, Size = 2)]
        public string ExchangeRateType { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptCurrency, Id = Index.ReceiptCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string ReceiptCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExchangeRateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread 
        /// </summary>
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperation { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets DrilldownType 
        /// </summary>
        [ViewField(Name = Fields.DrilldownType, Id = Index.DrilldownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrilldownType { get; set; }

        /// <summary>
        /// Gets or sets DrilldownLink 
        /// </summary>
        [ViewField(Name = Fields.DrilldownLink, Id = Index.DrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrilldownLink { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets CheckStockCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CheckStockCode, Id = Index.CheckStockCode, FieldType = EntityFieldType.Char, Size = 6)]
        public string CheckStockCode { get; set; }

        /// <summary>
        /// Gets or sets OFXTransactionID 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.OFXTransactionID, Id = Index.OFXTransactionID, FieldType = EntityFieldType.Char, Size = 50)]
        public string OFXTransactionID { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets SourceDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceDocumentNumber, Id = Index.SourceDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string SourceDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CanReverseInvoice 
        /// </summary>
        [ViewField(Name = Fields.CanReverseInvoice, Id = Index.CanReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public int CanReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets ReverseInvoice 
        /// </summary>
        [ViewField(Name = Fields.ReverseInvoice, Id = Index.ReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets DistributionCodeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCodeDescription, Id = Index.DistributionCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DistributionCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets GLAccountDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.GLAccountDescription, Id = Index.GLAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReconciliationPostingDate, Id = Index.ReconciliationPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReconciliationPostingDate { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReconciliationPostingYear, Id = Index.ReconciliationPostingYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string ReconciliationPostingYear { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingPeriod 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationPostingPeriod, Id = Index.ReconciliationPostingPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationPostingPeriod { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",  ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets ReconciledAndJournaledTransaction 
        /// </summary>
        //[ViewField(Name = Fields.ReconciledAndJournaledTransaction, Id = Index.ReconciledAndJournaledTransaction, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciledAndJournaledTransaction { get; set; }

        /// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets Reconciled 
        /// </summary>
        [ViewField(Name = Fields.Reconciled, Id = Index.Reconciled, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Reconciled { get; set; }

        /// <summary>
        /// Gets or sets DocumentPostedDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocumentPostedDate, Id = Index.DocumentPostedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentPostedDate { get; set; }

        /// <summary>
        /// Gets or sets SummatedTransactionAmount 
        /// </summary>
        [ViewField(Name = Fields.SummatedTransactionAmount, Id = Index.SummatedTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SummatedTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceCurrencyDescription, Id = Index.SourceCurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SourceCurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets ProcessResultCode 
        /// </summary>
        [ViewField(Name = Fields.ProcessResultCode, Id = Index.ProcessResultCode, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessResultCode { get; set; }

        #endregion

        /// <summary>
        ///  Gets or sets FromTransactionNumber 
        /// </summary>
        public decimal FromTransactionNumber { get; set; }
    }
}
