﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums; // For common enumerations

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class SageHROptions : ModelBase
    {
        /// <summary>
        /// Gets or sets OptionId
        /// </summary>
        /// 
        [Key]
        [ViewField(Name = Fields.OptionId, Id = Index.OptionId, FieldType = EntityFieldType.Char, Size = 2)]
        public string OptionId { get; set; }

        /// <summary>
        /// Gets or sets Employee Sync Settings
        /// </summary>
        [ViewField(Name = Fields.AutoSyncEmployee, Id = Index.AutoSyncEmployee, FieldType = EntityFieldType.Int, Size = 2)]
        public SyncEmployeeOption AutoSyncEmployee { get; set; }

        /// <summary>
        /// Gets or sets Publish Payslip Setting
        /// </summary>
        [ViewField(Name = Fields.AutoSyncPaySlip, Id = Index.AutoSyncPaySlip, FieldType = EntityFieldType.Int, Size = 2)]
        public PublishPayslipOption AutoSyncPaySlip { get; set; }

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        /// <summary>
        /// Gets or sets HRSageId
        /// </summary>
        [ViewField(Name = Fields.HRSageId, Id = Index.HRSageId, FieldType = EntityFieldType.Char, Size = 200)]  
        public string HRSageId { get; set; }

        /// <summary>
        /// Gets or sets HQActive
        /// </summary>
        [ViewField(Name = Fields.HQActive, Id = Index.HQActive, FieldType = EntityFieldType.Int, Size = 2)]
        public int HQActive { get; set; }

        /// <summary>
        /// Gets or sets HQActive
        /// </summary>
        [ViewField(Name = Fields.Onboarded, Id = Index.Onboarded, FieldType = EntityFieldType.Int, Size = 2)]
        public int Onboarded { get; set; }

        /// <summary>
        /// Gets or sets HQActive
        /// </summary>
        [ViewField(Name = Fields.HQReadOnly, Id = Index.HQReadonly, FieldType = EntityFieldType.Int, Size = 2)]
        public int HQReadOnly { get; set; }

        /// <summary>
        /// Gets or sets License Active
        /// </summary>
        [ViewField(Name = Fields.LicenseActive, Id = Index.LicenseActive, FieldType = EntityFieldType.Int, Size = 2)]
        public int LicenseActive { get; set; }

        /// <summary>
        /// Gets or sets CPMeetsMinimumRequirements
        /// </summary>
        public int CPMeetsMinimumRequirements { get; set; }

        /// <summary>
        /// Gets or sets UPMeetsMinimumRequirements
        /// </summary>
        public int UPMeetsMinimumRequirements { get; set; }
    }
}
