/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;

// ReSharper disable once CheckNamespace


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class FiscalSet : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountNumber 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "AccountNumber", ResourceType = typeof(GLCommonResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        ///// <summary>
        ///// Gets or sets Fiscalsetfromyear 
        ///// </summary>
        //[StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        ////[Display(Name = "From", ResourceType = typeof(CommonResx))]
        //public string Fiscalsetfromyear { get; set; }

        ///// <summary>
        ///// Gets or sets Fiscalsettoyear 
        ///// </summary>
        //[StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        ////[Display(Name = "To", ResourceType = typeof(CommonResx))]
        //public string Fiscalsettoyear { get; set; }

        /// <summary>
        /// Gets or sets Fiscalsetyear
        /// </summary>
        [Key]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Fiscalsetyear, Id = Index.Fiscalsetyear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Fiscalsetyear { get; set; }

        /// <summary>
        /// Gets or sets FiscalsetDesignator
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalsetDesignator, Id = Index.FiscalsetDesignator, FieldType = EntityFieldType.Char, Size = 1)]
        public FiscalSetDesignator FiscalsetDesignator { get; set; }

        /// <summary>
        /// Gets or sets FiscalsetDesignator 
        /// </summary>
        public FiscalSetDesignator FiscalsetDesignator1 { get; set; }

        private FiscalSetDesignator? _fiscalsetDesignator2 ;

        /// <summary>
        /// Gets or sets FiscalsetDesignator 
        /// </summary>
        public FiscalSetDesignator FiscalsetDesignator2 {
            get
            {
                if (_fiscalsetDesignator2 == null)
                {
                    return FiscalSetDesignator.Budget1;
                }
                return (FiscalSetDesignator)_fiscalsetDesignator2;
            }
            set { _fiscalsetDesignator2 = value; }
        }

        /// <summary>
        /// Gets or sets Currencycode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Currencycode", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.Currencycode, Id = Index.Currencycode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currencycode { get; set; }

        /// <summary>
        /// Gets or sets Currencytype 
        /// </summary>
        [ViewField(Name = Fields.Currencytype, Id = Index.Currencytype, FieldType = EntityFieldType.Char, Size = 1)]
        public FiscalSetCurrencyType Currencytype { get; set; }

        /// <summary>
        /// Gets or sets Sourcecurrencydecimals 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Sourcecurrencydecimals", ResourceType = typeof(FiscalSetResx))]
        [ViewField(Name = Fields.Sourcecurrencydecimals, Id = Index.Sourcecurrencydecimals, FieldType = EntityFieldType.Char, Size = 1)]
        public string Sourcecurrencydecimals { get; set; }

        /// <summary>
        /// Gets or sets Beginningbalance 
        /// </summary>
        [ViewField(Name = Fields.Beginningbalance, Id = Index.Beginningbalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Beginningbalance { get; set; }

        /// <summary>
        /// Gets or sets Period01netamount 
        /// </summary>
        [ViewField(Name = Fields.Period01Netamount, Id = Index.Period01Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period01Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period02netamount 
        /// </summary>
        [ViewField(Name = Fields.Period02Netamount, Id = Index.Period02Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period02Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period03netamount 
        /// </summary>
        [ViewField(Name = Fields.Period03Netamount, Id = Index.Period03Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period03Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period04netamount 
        /// </summary>
        [ViewField(Name = Fields.Period04Netamount, Id = Index.Period04Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period04Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period05netamount 
        /// </summary>
        [ViewField(Name = Fields.Period05Netamount, Id = Index.Period05Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period05Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period06netamount 
        /// </summary>
        [ViewField(Name = Fields.Period06Netamount, Id = Index.Period06Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period06Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period07netamount 
        /// </summary>
        [ViewField(Name = Fields.Period07Netamount, Id = Index.Period07Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period07Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period08netamount 
        /// </summary>
        [ViewField(Name = Fields.Period08Netamount, Id = Index.Period08Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period08Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period09netamount 
        /// </summary>
        [ViewField(Name = Fields.Period09Netamount, Id = Index.Period09Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period09Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period10netamount 
        /// </summary>
        [ViewField(Name = Fields.Period10Netamount, Id = Index.Period10Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period10Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period11netamount 
        /// </summary>
        [ViewField(Name = Fields.Period11Netamount, Id = Index.Period11Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period11Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period12netamount 
        /// </summary>
        [ViewField(Name = Fields.Period12Netamount, Id = Index.Period12Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period12Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period13netamount 
        /// </summary>
        [ViewField(Name = Fields.Period13Netamount, Id = Index.Period13Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period13Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period14netamount 
        /// </summary>
        [ViewField(Name = Fields.Period14Netamount, Id = Index.Period14Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period14Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period15netamount 
        /// </summary>
        [ViewField(Name = Fields.Period15Netamount, Id = Index.Period15Netamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period15Netamount { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ReservedDate", ResourceType = typeof(FiscalSetResx))]
        public string ReservedDate { get; set; }

        /// <summary>
        /// Gets or sets Allowspecificcurrenciesswitch 
        /// </summary>
        [ViewField(Name = Fields.Allowspecificcurrenciesswitch, Id = Index.Allowspecificcurrenciesswitch, FieldType = EntityFieldType.Int, Size = 2)]
        public FiscalSetAllowSpecificCurrenciesSwitch Allowspecificcurrenciesswitch { get; set; }

        /// <summary>
        /// Gets or sets Processasytdbalancesswitch 
        /// </summary>
        [ViewField(Name = Fields.Processasytdbalancesswitch, Id = Index.Processasytdbalancesswitch, FieldType = EntityFieldType.Int, Size = 2)]
        public FiscalSetProcessasytdbalancesSwitch Processasytdbalancesswitch { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDupdateswitch 
        /// </summary>
        public int ReserveDupdateswitch { get; set; }

        /// <summary>
        /// Gets or sets Yeartodateamount 
        /// </summary>
        [ViewField(Name = Fields.Yeartodateamount, Id = Index.Yeartodateamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Yeartodateamount { get; set; }

        /// <summary>
        /// Gets or sets Period01balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period01Balanceamount, Id = Index.Period01Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period01Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period02balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period02Balanceamount, Id = Index.Period02Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period02Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period03balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period03Balanceamount, Id = Index.Period03Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period03Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period04balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period04Balanceamount, Id = Index.Period04Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period04Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period05balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period05Balanceamount, Id = Index.Period05Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period05Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period06balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period06Balanceamount, Id = Index.Period06Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period06Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period07balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period07Balanceamount, Id = Index.Period07Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period07Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period08balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period08Balanceamount, Id = Index.Period08Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period08Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period09balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period09Balanceamount, Id = Index.Period09Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period09Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period10balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period10Balanceamount, Id = Index.Period10Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period10Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period11balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period11Balanceamount, Id = Index.Period11Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period11Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period12balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period12Balanceamount, Id = Index.Period12Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period12Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period13balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period13Balanceamount, Id = Index.Period13Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period13Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period14balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period14Balanceamount, Id = Index.Period14Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period14Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period15balanceamount 
        /// </summary>
        [ViewField(Name = Fields.Period15Balanceamount, Id = Index.Period15Balanceamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Period15Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Replacementswitch 
        /// </summary>
        [ViewField(Name = Fields.Replacementswitch, Id = Index.Replacementswitch, FieldType = EntityFieldType.Int, Size = 2)]
        public FiscalSetReplacementSwitch Replacementswitch { get; set; }

        /// <summary>
        /// Gets or sets Overrideratetypecode 
        /// </summary>
        //[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [ViewField(Name = Fields.Overrideratetypecode, Id = Index.Overrideratetypecode, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string Overrideratetypecode { get; set; }

        /// <summary>
        /// Gets or sets Overriderate 
        /// </summary>
        [ViewField(Name = Fields.Overriderate, Id = Index.Overriderate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Overriderate { get; set; }

        /// <summary>
        /// Gets or sets Activityswitch 
        /// </summary>
        [ViewField(Name = Fields.Activityswitch, Id = Index.Activityswitch, FieldType = EntityFieldType.Int, Size = 2)]
        public FiscalSetActivitySwitch Activityswitch { get; set; }

        /// <summary>
        /// Gets or sets Rollupswitch 
        /// </summary>
        [ViewField(Name = Fields.Rollupswitch, Id = Index.Rollupswitch, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Rollupswitch { get; set; }
    }
}
