﻿using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public class CompanyProfileEmail : ModelBase
    {
        /// <summary>
        /// Gets or sets email server name 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ServerName", ResourceType = typeof (CompanyProfileResx))]
        public string ServerName { get; set; }

        /// <summary>
        /// Gets or sets email server port 
        /// </summary>
        [Range(0, 32767, ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ServerPort", ResourceType = typeof (CompanyProfileResx))]
        public int? ServerPort { get; set; }

        /// <summary>
        /// Gets or sets email user name 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserName", ResourceType = typeof(CompanyProfileResx))]
        public string Username { get; set; }

        /// <summary>
        /// Gets or sets email server password 
        /// </summary>
        [StringLength(96, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Password", ResourceType = typeof(CompanyProfileResx))]
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets email address 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmailAddress", ResourceType = typeof(CompanyProfileResx))]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Gets or sets email address 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BccEmailAddress", ResourceType = typeof(CompanyProfileResx))]
        public string BccEmailAddress { get; set; }

        /// <summary>
        /// Gets or sets email send to 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SendTo", ResourceType = typeof(CompanyProfileResx))]
        public string SendTo { get; set; }


        /// <summary>
        /// Gets or sets use ssl
        /// </summary>
        [Display(Name = "UseSSL", ResourceType = typeof(CompanyProfileResx))]
        public bool UseSSL { get; set; }

        /// <summary>
        /// Gets or sets email send method
        /// </summary>
        [Display(Name = "EmailMethod", ResourceType = typeof(CompanyProfileResx))]
        public EmailSendMethod EmailMethod { get; set; }
    }
}
