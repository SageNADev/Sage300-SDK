/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{

    /// <summary>
    /// This class is used for Tax group model.
    /// </summary>
    public partial class TaxGroup : ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(TaxGroupsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupCode, Id = Index.TaxGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroupCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionType", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionTypeEnum TransactionType { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DESCRIPTION", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurr", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxReportingCurrency, Id = Index.TaxReportingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrency { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets Taxable1 
        /// </summary>
        [Display(Name = "Taxable1", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Taxable1, Id = Index.Taxable1, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Taxable1 { get; set; }

        /// <summary>
        /// Gets or sets Taxable2 
        /// </summary>
        [Display(Name = "Taxable2", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Taxable2, Id = Index.Taxable2, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Taxable2 { get; set; }

        /// <summary>
        /// Gets or sets Taxable3 
        /// </summary>
        [Display(Name = "Taxable3", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Taxable3, Id = Index.Taxable3, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Taxable3 { get; set; }

        /// <summary>
        /// Gets or sets Taxable4 
        /// </summary>
        [Display(Name = "Taxable4", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Taxable4, Id = Index.Taxable4, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Taxable4 { get; set; }

        /// <summary>
        /// Gets or sets Taxable5 
        /// </summary>
        [Display(Name = "Taxable5", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Taxable5, Id = Index.Taxable5, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Taxable5 { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationMethod 
        /// </summary>
        [Display(Name = "TaxCalcMeth", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxCalculationMethod, Id = Index.TaxCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxCalculationMethodEnum TaxCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(TaxGroupsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets Surtax1 
        /// </summary>
        [Display(Name = "Surtax1", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Surtax1, Id = Index.Surtax1, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Surtax1 { get; set; }

        /// <summary>
        /// Gets or sets Surtax2 
        /// </summary>
        [Display(Name = "Surtax2", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Surtax2, Id = Index.Surtax2, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Surtax2 { get; set; }

        /// <summary>
        /// Gets or sets Surtax3 
        /// </summary>
        [Display(Name = "Surtax3", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Surtax3, Id = Index.Surtax3, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Surtax3 { get; set; }

        /// <summary>
        /// Gets or sets Surtax4 
        /// </summary>
        [Display(Name = "Surtax4", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Surtax4, Id = Index.Surtax4, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Surtax4 { get; set; }

        /// <summary>
        /// Gets or sets Surtax5 
        /// </summary>
        [Display(Name = "Surtax5", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.Surtax5, Id = Index.Surtax5, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxableEnum Surtax5 { get; set; }

        /// <summary>
        /// Gets or sets SurtaxOnAuthority1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SurtaxOnAuthority1", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.SurtaxOnAuthority1, Id = Index.SurtaxOnAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string SurtaxOnAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets SurtaxOnAuthority2 
        /// </summary>
        [Display(Name = "SurtaxOnAuthority2", ResourceType = typeof(TaxGroupsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SurtaxOnAuthority2, Id = Index.SurtaxOnAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string SurtaxOnAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets SurtaxOnAuthority3 
        /// </summary>
        [Display(Name = "SurtaxOnAuthority3", ResourceType = typeof(TaxGroupsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SurtaxOnAuthority3, Id = Index.SurtaxOnAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string SurtaxOnAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets SurtaxOnAuthority4 
        /// </summary>
        [Display(Name = "SurtaxOnAuthority4", ResourceType = typeof(TaxGroupsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SurtaxOnAuthority4, Id = Index.SurtaxOnAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string SurtaxOnAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets SurtaxOnAuthority5 
        /// </summary>
        [Display(Name = "SurtaxOnAuthority5", ResourceType = typeof(TaxGroupsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SurtaxOnAuthority5, Id = Index.SurtaxOnAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string SurtaxOnAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets the tax group details.
        /// </summary>
        /// <value>
        /// The tax group details.
        /// </value>
        public EnumerableResponse<TaxAuthorityGroup> TaxGroupDetails { get; set; }

        #endregion

        #region EnumStrings
        /// <summary>
        /// Gets the transaction type string.
        /// </summary>
        /// <value>
        /// The transaction type string.
        /// </value>
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }



        /// <summary>
        /// Gets the tax calculation method string.
        /// </summary>
        /// <value>
        /// The tax calculation method string.
        /// </value>
        public string TaxCalculationMethodString
        {
            get { return EnumUtility.GetStringValue(TaxCalculationMethod); }
        }

        /// <summary>
        /// Gets the taxable1 string.
        /// </summary>
        /// <value>
        /// The taxable1 string.
        /// </value>
        public string Taxable1String
        {
            get { return EnumUtility.GetStringValue(Taxable1); }
        }

        /// <summary>
        /// Gets the taxable2 string.
        /// </summary>
        /// <value>
        /// The taxable2 string.
        /// </value>
        public string Taxable2String
        {
            get { return EnumUtility.GetStringValue(Taxable2); }
        }

        /// <summary>
        /// Gets the taxable3 string.
        /// </summary>
        /// <value>
        /// The taxable3 string.
        /// </value>
        public string Taxable3String
        {
            get { return EnumUtility.GetStringValue(Taxable3); }
        }

        /// <summary>
        /// Gets the taxable4 string.
        /// </summary>
        /// <value>
        /// The taxable4 string.
        /// </value>
        public string Taxable4String
        {
            get { return EnumUtility.GetStringValue(Taxable4); }
        }

        /// <summary>
        /// Gets the taxable5 string.
        /// </summary>
        /// <value>
        /// The taxable5 string.
        /// </value>
        public string Taxable5String
        {
            get { return EnumUtility.GetStringValue(Taxable5); }
        }

        /// <summary>
        /// Gets the surtax1 string.
        /// </summary>
        /// <value>
        /// The surtax1 string.
        /// </value>
        public string Surtax1String
        {
            get { return EnumUtility.GetStringValue(Surtax1); }
        }

        /// <summary>
        /// Gets the surtax2 string.
        /// </summary>
        /// <value>
        /// The surtax2 string.
        /// </value>
        public string Surtax2String
        {
            get { return EnumUtility.GetStringValue(Surtax2); }
        }

        /// <summary>
        /// Gets the surtax3 string.
        /// </summary>
        /// <value>
        /// The surtax3 string.
        /// </value>
        public string Surtax3String
        {
            get { return EnumUtility.GetStringValue(Surtax3); }
        }

        /// <summary>
        /// Gets the surtax4 string.
        /// </summary>
        /// <value>
        /// The surtax4 string.
        /// </value>
        public string Surtax4String
        {
            get { return EnumUtility.GetStringValue(Surtax4); }
        }

        /// <summary>
        /// Gets the surtax5 string.
        /// </summary>
        /// <value>
        /// The surtax5 string.
        /// </value>
        public string Surtax5String
        {
            get { return EnumUtility.GetStringValue(Surtax5); }
        }

        #endregion

    }
}
