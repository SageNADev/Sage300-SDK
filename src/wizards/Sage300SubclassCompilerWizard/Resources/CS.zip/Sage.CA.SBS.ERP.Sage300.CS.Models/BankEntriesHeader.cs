// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is BankEntriesHeader entity
    /// </summary>
	public partial class BankEntriesHeader : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
 		public long SequenceNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntryNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankEntryNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets DateCreated 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string DateCreated {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntryType 
        /// </summary>
        
 		public BankEntryType BankEntryType {get; set;}

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string.</value>
        public string TypeBankEntry
        {
            get { return EnumUtility.GetStringValue(BankEntryType); }
        }
		 
  		/// <summary>
        /// Gets or sets EntryDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string EntryDescription {get; set;}
		 
  		/// <summary>
        /// Gets or sets EntryTotalWithoutTax 
        /// </summary>
        
 		public decimal EntryTotalWithoutTax {get; set;}
		 
  		/// <summary>
        /// Gets or sets FuncEntryTotalWithoutTax 
        /// </summary>
        
 		public decimal FuncEntryTotalWithoutTax {get; set;}
		 
  		/// <summary>
        /// Gets or sets EntryTotal 
        /// </summary>
        
 		public decimal EntryTotal {get; set;}
		 
  		/// <summary>
        /// Gets or sets FuncEntryTotal 
        /// </summary>
        
 		public decimal FuncEntryTotal {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string ExchangeRateType {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntryCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankEntryCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string ExchangeRateDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        
 		public decimal ExchangeRate {get; set;}
		 
  		/// <summary>
        /// Gets or sets RateSpread 
        /// </summary>
        
 		public decimal RateSpread {get; set;}
		 
  		/// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        
 		public RateOperation RateOperation {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntryDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public DateTime BankEntryDate {get; set;}

  		/// <summary>
        /// Gets or sets BankEntryYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankEntryYear {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntryPeriod 
        /// </summary>
        
 		public int BankEntryPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets CompletedStatus 
        /// </summary>
        
 		public CompletedStatus CompletedStatus {get; set;}
		 
  		/// <summary>
        /// Gets or sets Comments 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Comments {get; set;}
		 
  		/// <summary>
        /// Gets or sets Status 
        /// </summary>
        
 		public PostStatus Status {get; set;}

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string.</value>
        public string TypeStatus
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

  		/// <summary>
        /// Gets or sets ReconcilationDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string ReconcilationDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets ReconcilationYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string ReconcilationYear {get; set;}
		 
  		/// <summary>
        /// Gets or sets ReconcilationPeriod 
        /// </summary>
        
 		public int ReconcilationPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofLines 
        /// </summary>
        
 		public long NumberofLines {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntrySerialNumber 
        /// </summary>
        
 		public long BankEntrySerialNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets RunId 
        /// </summary>
        
 		public long RunId {get; set;}
		 
  		/// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        
 		public PaymentType PaymentType {get; set;}
		 
  		/// <summary>
        /// Gets or sets OFXTransactionID 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string OfxTransactionID {get; set;}
		 
  		/// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        
 		public EntryType EntryType {get; set;}
		 
  		/// <summary>
        /// Gets or sets DistributionSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string DistributionSet {get; set;}
		 
  		/// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        
 		public decimal PostingSequence {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankName {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankAccount 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankStatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankStatementCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets DistributionSetDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string DistributionSetDesc {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalStatementAmount 
        /// </summary>
        
 		public decimal TotalStatementAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalEntryAmount 
        /// </summary>
        
 		public decimal FiscalEntryAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets ReconciledEntryAmount 
        /// </summary>
        
 		public decimal ReconciledEntryAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultNewDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string DefaultNewDocumentNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets ProcessCommand 
        /// </summary>
        
 		public ProcessCommand ProcessCommand {get; set;}
		 
  		/// <summary>
        /// Gets or sets AgingRecondays 
        /// </summary>
        
 		public int AgingRecondays {get; set;}
		 
  		/// <summary>
        /// Gets or sets KeepInputEntryNo 
        /// </summary>
        
 		public int KeepInputEntryNo {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntryCurrencyDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankEntryCurrencyDesc {get; set;}
		 
  		/// <summary>
        /// Gets or sets DefaultBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string DefaultBankCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets ErrorinAutoBank 
        /// </summary>
        
 		public long ErrorinAutoBank {get; set;}
		    }
}
