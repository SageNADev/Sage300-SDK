﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for EmployeeSelection
    /// </summary>
    public partial class EmployeeSelection : ModelBase
    {
        /// <summary>
        /// Gets or sets RecordNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public long RecordNumber { get; set; }

        /// <summary>
        /// Gets or sets SelectedForSyncing
        /// </summary>
        [Display(Name = "SelectedForSyncing", ResourceType = typeof(SageHRResx))]
        public SelectedForSyncing SelectedForSyncing { get; set; }

        /// <summary>
        /// Gets or sets OriginApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginApplication", ResourceType = typeof(SageHRResx))]
        public string OriginApplication { get; set; }

        /// <summary>
        /// Gets or sets EmployeeIDERP
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeId", ResourceType = typeof(SageHRResx))]
        public string EmployeeIDERP { get; set; }

        /// <summary>
        /// Gets or sets FullName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeName", ResourceType = typeof(SageHRResx))]
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(SageHRResx))]
        public SyncEmployeeStatus Status { get; set; }

        /// <summary>
        /// Gets or sets SageIDEmail
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SageIDEmail", ResourceType = typeof(SageHRResx))]
        public string SageIDEmail { get; set; }

        /// <summary>
        /// Gets or sets InviteToSageHR
        /// </summary>
        [Display(Name = "SendInvite", ResourceType = typeof(SageHRResx))]
        public InviteToSageHR InviteToSageHR { get; set; }

        /// <summary>
        /// Gets or sets EmployeeIDSageHR
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string EmployeeIDSageHR { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(SageHRResx))]
        public ProcessCmdEmployeeSelection ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets IncludeInactiveAndTerminated
        /// </summary>
        [Display(Name = "IncludeInactiveAndTerminated", ResourceType = typeof(SageHRResx))]
        public IncludeInactiveAndTerminated IncludeInactiveAndTerminated { get; set; }

        /// <summary>
        /// Gets or sets SearchText
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string SearchText { get; set; }

        /// <summary>
        /// Gets the Status options
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> SendInviteList
        {
            get
            {
                return EnumUtility.GetItemsList<InviteToSageHR>().ToList();
            }
        }
    }
}

