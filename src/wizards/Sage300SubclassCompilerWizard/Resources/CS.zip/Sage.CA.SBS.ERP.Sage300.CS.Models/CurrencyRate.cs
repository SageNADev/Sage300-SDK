// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class CurrencyRate
    /// </summary>
    public partial class CurrencyRate : ModelBase
    {
        public CurrencyRate()
        {
            RateOperation = RateOperation.Multiply;
        }
        /// <summary>
        /// Gets or sets ToCurrency 
        /// </summary>
        [Display(Name = "HOMECUR", ResourceType = typeof(CurrencyRatesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.ToCurrency, Id = Index.ToCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ToCurrency { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [Display(Name = "PFPFromRTCap", ResourceType = typeof(CurrencyRatesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets FromCurrency 
        /// </summary>
        [Display(Name = "FromCurrency", ResourceType = typeof(CurrencyRatesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.FromCurrency, Id = Index.FromCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string FromCurrency { get; set; }

        /// <summary>
        /// Gets or sets RateDate 
        /// </summary>
        [Display(Name = "RateDate", ResourceType = typeof(CurrencyRatesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets Rate 
        /// </summary>
        [Display(Name = "Rate", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.Rate, Id = Index.Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Rate { get; set; }

        /// <summary>
        /// Gets or sets Spread 
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.Spread, Id = Index.Spread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Spread { get; set; }

        /// <summary>
        /// Gets or sets DateMatching 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateMatch", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.DateMatching, Id = Index.DateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public DateMatching DateMatching { get; set; }

        /// <summary>
        /// Date Matching string
        /// </summary>
        public string DateMatchingString
        {
            get { return EnumUtility.GetStringValue(DateMatching); }
        }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateOperation", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Rate operation enum
        /// </summary>
        public string RateOperationString
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets or sets PropagateChangesImmediately 
        /// </summary>
        [Display(Name = "PropagateChangesImmediately", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.PropagateChangesImmediately, Id = Index.PropagateChangesImmediately, FieldType = EntityFieldType.Bool, Size = 2)]
        public PropagateChangesImmediately PropagateChangesImmediately { get; set; }

        /// <summary>
        /// PropagateChangesImmediately string
        /// </summary>
        public string PropagateChangesImmediatelyString
        {
            get { return EnumUtility.GetStringValue(PropagateChangesImmediately); }
        }


        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }
    }
}
