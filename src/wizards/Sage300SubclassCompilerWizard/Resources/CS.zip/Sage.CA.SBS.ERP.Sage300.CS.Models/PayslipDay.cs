// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.CS.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for PayslipDay
    /// </summary>
    public partial class PayslipDay : ModelBase
    {
        /// <summary>
        /// Gets or sets PaymentDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckDate", ResourceType = typeof (PayslipDayResx))]
        [ViewField(Name = Fields.PaymentDate, Id = Index.PaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PaymentDate { get; set; }

        /// <summary>
        /// Gets or sets LastPayslipRecordNumber
        /// </summary>
        [Display(Name = "LastPayslipRecordNumber", ResourceType = typeof (PayslipDayResx))]
        [ViewField(Name = Fields.LastPayslipRecordNumber, Id = Index.LastPayslipRecordNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int LastPayslipRecordNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof (PayslipDayResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.ProcessCmdPublishPayslip ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets IncludeInactiveAndTerminated
        /// </summary>
        [Display(Name = "IncludeInactiveAndTerminated", ResourceType = typeof (PayslipDayResx))]
        [ViewField(Name = Fields.IncludeInactiveAndTerminated, Id = Index.IncludeInactiveAndTerminated, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.IncludeInactiveAndTerminated IncludeInactiveAndTerminated { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString => EnumUtility.GetStringValue(ProcessCommandCode);

        /// <summary>
        /// Gets IncludeInactiveAndTerminated string value
        /// </summary>
        public string IncludeInactiveAndTerminatedString => EnumUtility.GetStringValue(IncludeInactiveAndTerminated);

        #endregion
    }
}
