// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class for Fiscal Application Status 
    /// </summary>
    public partial class FiscalStatus : ModelBase
    {
        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "FiscalYear", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets Application 
        /// </summary>
        [Key]
        [Display(Name = "Application", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Application, Id = Index.Application, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string Application { get; set; }

        /// <summary>
        /// Gets or sets Period1Status 
        /// </summary>
        [Display(Name = "Period1Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period1Status, Id = Index.Period1Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period1Status { get; set; }

        /// <summary>
        /// Gets or sets Period2Status 
        /// </summary>
        [Display(Name = "Period2Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period2Status, Id = Index.Period2Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period2Status { get; set; }

        /// <summary>
        /// Gets or sets Period3Status 
        /// </summary>
        [Display(Name = "Period3Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period3Status, Id = Index.Period3Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period3Status { get; set; }

        /// <summary>
        /// Gets or sets Period4Status 
        /// </summary>
        [Display(Name = "Period4Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period4Status, Id = Index.Period4Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period4Status { get; set; }

        /// <summary>
        /// Gets or sets Period5Status 
        /// </summary>
        [Display(Name = "Period5Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period5Status, Id = Index.Period5Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period5Status { get; set; }

        /// <summary>
        /// Gets or sets Period6Status 
        /// </summary>
        [Display(Name = "Period6Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period6Status, Id = Index.Period6Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period6Status { get; set; }

        /// <summary>
        /// Gets or sets Period7Status 
        /// </summary>
        [Display(Name = "Period7Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period7Status, Id = Index.Period7Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period7Status { get; set; }

        /// <summary>
        /// Gets or sets Period8Status 
        /// </summary>
        [Display(Name = "Period8Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period8Status, Id = Index.Period8Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period8Status { get; set; }

        /// <summary>
        /// Gets or sets Period9Status 
        /// </summary>
        [Display(Name = "Period9Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period9Status, Id = Index.Period9Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period9Status { get; set; }

        /// <summary>
        /// Gets or sets Period10Status 
        /// </summary>
        [Display(Name = "Period10Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period10Status, Id = Index.Period10Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period10Status { get; set; }

        /// <summary>
        /// Gets or sets Period11Status 
        /// </summary>
        [Display(Name = "Period11Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period11Status, Id = Index.Period11Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period11Status { get; set; }

        /// <summary>
        /// Gets or sets Period12Status 
        /// </summary>
        [Display(Name = "Period12Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period12Status, Id = Index.Period12Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period12Status { get; set; }

        /// <summary>
        /// Gets or sets Period13Status 
        /// </summary>
        [Display(Name = "Period13Status", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Period13Status, Id = Index.Period13Status, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodStatus Period13Status { get; set; }

        /// <summary>
        /// Application Description
        /// </summary>
        public string Description { get; set; }
    }
}
