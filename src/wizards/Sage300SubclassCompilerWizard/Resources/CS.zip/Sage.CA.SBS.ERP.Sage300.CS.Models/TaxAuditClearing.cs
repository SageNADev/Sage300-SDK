/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class Tax Audit Clearing
    /// </summary>
    public partial class TaxAuditClearing : ModelBase
    {

        /// <summary>
        /// Gets or sets AuthorityFrom 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorityFrom, Id = Index.AuthorityFrom, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AuthorityFrom { get; set; }

        /// <summary>
        /// Gets or sets AuthorityTo 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AuthorityTo, Id = Index.AuthorityTo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string AuthorityTo { get; set; }

        /// <summary>
        /// Gets or sets ClearRecordsBy 
        /// </summary>

        [ViewField(Name = Fields.ClearRecordsBy, Id = Index.ClearRecordsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public ClearRecordsBy ClearRecordsBy { get; set; }

        /// <summary>
        /// Gets or sets ReportAsOfYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReportAsOfYear, Id = Index.ReportAsOfYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string ReportAsOfYear { get; set; }

        /// <summary>
        /// Gets or sets ReportAsOfPeriod 
        /// </summary>

        [ViewField(Name = Fields.ReportAsOfPeriod, Id = Index.ReportAsOfPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportAsOfPeriod ReportAsOfPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReportAsOfDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReportAsOfDate, Id = Index.ReportAsOfDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ReportAsOfDate { get; set; }

        /// <summary>
        /// Gets or sets TypeofRecordtoClear 
        /// </summary>

        [ViewField(Name = Fields.TypeofRecordtoClear, Id = Index.TypeofRecordtoClear, FieldType = EntityFieldType.Int, Size = 2)]
        public TypeofRecordtoClear TypeofRecordtoClear { get; set; }

        /// <summary>
        /// Gets or sets MethodofClearingClasses 
        /// </summary>

        [ViewField(Name = Fields.MethodofClearingClasses, Id = Index.MethodofClearingClasses, FieldType = EntityFieldType.Int, Size = 2)]
        public MethodofClearingClasses MethodofClearingClasses { get; set; }

        /// <summary>
        /// Gets or sets FromItemClass 
        /// </summary>

        [ViewField(Name = Fields.FromItemClass, Id = Index.FromItemClass, FieldType = EntityFieldType.Int, Size = 2)]
        public FromItemClass FromItemClass { get; set; }

        /// <summary>
        /// Gets or sets ToItemClass 
        /// </summary>

        [ViewField(Name = Fields.ToItemClass, Id = Index.ToItemClass, FieldType = EntityFieldType.Int, Size = 2)]
        public FromItemClass ToItemClass { get; set; }


        /// <summary>
        /// Gets or sets FromFiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromFiscalYear, Id = Index.FromFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FromFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FromFiscalPeriod 
        /// </summary>

        [ViewField(Name = Fields.FromFiscalPeriod, Id = Index.FromFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportAsOfPeriod FromFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ToFiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToFiscalYear, Id = Index.ToFiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string ToFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets ToFiscalPeriod 
        /// </summary>

        [ViewField(Name = Fields.ToFiscalPeriod, Id = Index.ToFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportAsOfPeriod ToFiscalPeriod { get; set; }
    }
}

