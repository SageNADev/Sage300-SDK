﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// class Bank Currency
    /// </summary>
     public partial   class BankCurrency: ModelBase
    {
        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
         [Display(Name = "BankFLD", ResourceType = typeof(BKCommonResx))]
         public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CurrencyCode", ResourceType = typeof(BankResx))]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets CheckRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckRateType", ResourceType = typeof(BKCommonResx))]
        public string CheckRateType { get; set; }

        /// <summary>
        /// Gets or sets DepositRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DepositRateType", ResourceType = typeof(BKCommonResx))]
        public string DepositRateType { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGainAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExchangeGainAccount", ResourceType = typeof(BKCommonResx))]
        public string ExchangeGainAccount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLossAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExchangeLossAccount", ResourceType = typeof(BKCommonResx))]
        public string ExchangeLossAccount { get; set; }

        /// <summary>
        /// Gets or sets RoundingAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RoundingAccount", ResourceType = typeof(BKCommonResx))]
        public string RoundingAccount { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(BankResx))]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets the sequential line number for the recurring entry detail items
        /// </summary>
        /// <value>The line number.</value>
        [IgnoreExportImport]
        public int LineNumber { get; set; }

    }
}
