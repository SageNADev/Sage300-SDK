// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.GLIntegration;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class for Bank G/L Integration
    /// </summary>
    public partial class BankGLIntegration : BaseGLReferenceIntegration
    {

        /// <summary>
        /// Gets or sets Source Transaction Type 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "TRANSTYPE", ResourceType = typeof(BankGLIntegrationResx))]
        //[ViewField(Name = Fields.SourceTransactionType, Id = Index.SourceTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public SourceTransactionType SourceTransactionType { get; set; }

        /// <summary>
        /// Gets or sets GL Transaction Field 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "GLFIELD", ResourceType = typeof(BankGLIntegrationResx))]
        public new  GLTransactionField GLTransactionField { get; set; }

        /// <summary>
        /// Gets or sets Separator
        /// </summary>
        [Display(Name = "SEPARATOR", ResourceType = typeof(BankGLIntegrationResx))]
        //[ViewField(Name = Fields.Separator, Id = Index.Separator, FieldType = EntityFieldType.Int, Size = 2)]
        public new Separator Separator { get; set; }

        //The following properties don't have display attribute as it is not mapped to UI controls directly//

        /// <summary>
        /// Gets or sets Included Segment1 
        /// </summary>
        //[ViewField(Name = Fields.IncludedSegment1, Id = Index.IncludedSegment1, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludedSegment1 IncludedSegment1 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment2 
        /// </summary>
        //[ViewField(Name = Fields.IncludedSegment2, Id = Index.IncludedSegment2, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludedSegment1 IncludedSegment2 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment3 
        /// </summary>
        //[ViewField(Name = Fields.IncludedSegment3, Id = Index.IncludedSegment3, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludedSegment1 IncludedSegment3 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment4 
        /// </summary>
        //[ViewField(Name = Fields.IncludedSegment4, Id = Index.IncludedSegment4, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludedSegment1 IncludedSegment4 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment5 
        /// </summary>
        //[ViewField(Name = Fields.IncludedSegment5, Id = Index.IncludedSegment5, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludedSegment1 IncludedSegment5 { get; set; }

        /// <summary>
        /// Gets or sets Segment Counter 
        /// </summary>
        [ViewField(Name = Fields.SegmentCounter, Id = Index.SegmentCounter, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentCounter { get; set; }

        #region override UI properties

        //The following properties don't have display attribute as it is not mapped to UI controls directly

        /// <summary>
        /// Gets or sets Source Transaction Type Value 
        /// </summary>
        public override int SourceTransactionTypeValue
        {
            get { return Convert.ToInt32(SourceTransactionType); }
            set { SourceTransactionType = (SourceTransactionType)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment1 Value 
        /// </summary>
        public override int IncludedSegment1Value
        {
            get { return Convert.ToInt32(IncludedSegment1); }
            set { IncludedSegment1 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment2 Value 
        /// </summary>
        public override int IncludedSegment2Value
        {
            get { return Convert.ToInt32(IncludedSegment2); }
            set { IncludedSegment2 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment3 Value 
        /// </summary>
        public override int IncludedSegment3Value
        {
            get { return Convert.ToInt32(IncludedSegment3); }
            set { IncludedSegment3 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment4 Value 
        /// </summary>
        public override int IncludedSegment4Value
        {
            get { return Convert.ToInt32(IncludedSegment4); }
            set { IncludedSegment4 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment5 Value 
        /// </summary>
        public override int IncludedSegment5Value
        {
            get { return Convert.ToInt32(IncludedSegment5); }
            set { IncludedSegment5 = (IncludedSegment1)value; }
        }

        #endregion
    }
}
