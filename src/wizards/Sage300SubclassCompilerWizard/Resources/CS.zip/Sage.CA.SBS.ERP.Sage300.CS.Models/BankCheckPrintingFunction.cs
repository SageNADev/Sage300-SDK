// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 


using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// BankCheckPrintingFunction class
    /// </summary>
    public partial class BankCheckPrintingFunction : ModelBase
    {
        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ApplicationRunNumber 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ApplicationRunNumber, Id = Index.ApplicationRunNumber, FieldType = EntityFieldType.Char, Size = 10)]
        public string ApplicationRunNumber { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets CheckStockCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CheckStockCode, Id = Index.CheckStockCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CheckStockCode { get; set; }

        /// <summary>
        /// Gets or sets NumberofPrintPhases 
        /// </summary>

        [ViewField(Name = Fields.NumberofPrintPhases, Id = Index.NumberofPrintPhases, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberofPrintPhases { get; set; }

        /// <summary>
        /// Gets or sets AdviceLines 
        /// </summary>

        [ViewField(Name = Fields.AdviceLines, Id = Index.AdviceLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long AdviceLines { get; set; }

        /// <summary>
        /// Gets or sets CheckRunPrepared? 
        /// </summary>

        public bool? CheckRunPrepared{get;set;}

        /// <summary>
        /// Gets or sets Language 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Language, Id = Index.Language, FieldType = EntityFieldType.Char, Size = 3)]
        public string Language { get; set; }

        /// <summary>
        /// Gets or sets LanguageCode 
        /// </summary>

        [ViewField(Name = Fields.LanguageCode, Id = Index.LanguageCode, FieldType = EntityFieldType.Int, Size = 2)]
        public LanguageCode LanguageCode { get; set; }

        /// <summary>
        /// Gets or sets UnprintedChecksForThisLanguage 
        /// </summary>

        //[ViewField(Name = Fields.UnprintedChecksForThisLanguage, Id = Index.UnprintedChecksForThisLanguage, FieldType = EntityFieldType.Long, Size = 4)]
        public long UnprintedChecksForThisLanguage { get; set; }

        /// <summary>
        /// Gets or sets ChecksForThisLanguagePosted 
        /// </summary>
        public bool? ChecksForThisLanguagePosted {get;set;}

        /// <summary>
        /// Gets or sets StockType 
        /// </summary>
        [ViewField(Name = Fields.StockType, Id = Index.StockType, FieldType = EntityFieldType.Int, Size = 2)]
        public int StockType { get; set; }

        /// <summary>
        /// Gets or sets Function 
        /// </summary>
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Function Function { get; set; }

        /// <summary>
        /// Gets or sets CurrentPrintPhase 
        /// </summary>
        [ViewField(Name = Fields.CurrentPrintPhase, Id = Index.CurrentPrintPhase, FieldType = EntityFieldType.Int, Size = 2)]
        public int CurrentPrintPhase { get; set; }

        /// <summary>
        /// Gets or sets NumberofChecks 
        /// </summary>
        [ViewField(Name = Fields.NumberofChecks, Id = Index.NumberofChecks, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long NumberofChecks { get; set; }

        /// <summary>
        /// Gets or sets FromCheckNumber 
        /// </summary>
        [ViewField(Name = Fields.FromCheckNumber, Id = Index.FromCheckNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal FromCheckNumber { get; set; }

        /// <summary>
        /// Gets or sets ToCheckNumber 
        /// </summary>
        [ViewField(Name = Fields.ToCheckNumber, Id = Index.ToCheckNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal ToCheckNumber { get; set; }

        /// <summary>
        /// Gets or sets FromSerialNumber 
        /// </summary>
        [ViewField(Name = Fields.FromSerialNumber, Id = Index.FromSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long FromSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets ToSerialNumber 
        /// </summary>
        [ViewField(Name = Fields.ToSerialNumber, Id = Index.ToSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long ToSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Criteria 
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Criteria, Id = Index.Criteria, FieldType = EntityFieldType.Char, Size = 255)]
        public string Criteria { get; set; }

        /// <summary>
        /// Gets or sets CheckStatus 
        /// </summary>
        [ViewField(Name = Fields.CheckStatus, Id = Index.CheckStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckStatus CheckStatus { get; set; }

        /// <summary>
        /// Gets or sets Reprinting 
        /// </summary>
        [ViewField(Name = Fields.Reprinting, Id = Index.Reprinting, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Reprinting { get; set; }

        /// <summary>
        /// Gets or sets CurrentLanguageForThisBank 
        /// </summary>
        [ViewField(Name = Fields.CurrentLanguageForThisBank, Id = Index.CurrentLanguageForThisBank, FieldType = EntityFieldType.Int, Size = 2)]
        public LanguageCode CurrentLanguageForThisBank { get; set; }

        /// <summary>
        /// Gets or sets LanguagesForThisBank 
        /// </summary>
        [ViewField(Name = Fields.LanguagesForThisBank, Id = Index.LanguagesForThisBank, FieldType = EntityFieldType.Int, Size = 2)]
        public int LanguagesForThisBank { get; set; }

        /// <summary>
        /// Gets or sets UnpostedLanguagesForThisBank 
        /// </summary>
        [ViewField(Name = Fields.UnpostedLanguagesForThisBank, Id = Index.UnpostedLanguagesForThisBank, FieldType = EntityFieldType.Int, Size = 2)]
        public int UnpostedLanguagesForThisBank { get; set; }

        /// <summary>
        /// Gets or sets UnprintedChecksForThisBank 
        /// </summary>
        [ViewField(Name = Fields.UnprintedChecksForThisBank, Id = Index.UnprintedChecksForThisBank, FieldType = EntityFieldType.Long, Size = 4)]
        public long UnprintedChecksForThisBank { get; set; }

        /// <summary>
        /// Gets or sets BankName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.BankName, Id = Index.BankName, FieldType = EntityFieldType.Char, Size = 60)]
        public string BankName { get; set; }

        /// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets StatementCurrencyName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.StatementCurrencyName, Id = Index.StatementCurrencyName, FieldType = EntityFieldType.Char, Size = 60)]
        public string StatementCurrencyName { get; set; }

        /// <summary>
        /// Gets or sets ChecksforthisBankPosted? 
        /// </summary>
        [ViewField(Name = Fields.ChecksforthisBankPosted, Id = Index.ChecksforthisBankPosted, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool? ChecksforthisBankPosted { get; set; }

        /// <summary>
        /// Gets or sets ModeofOperation 
        /// </summary>
        [ViewField(Name = Fields.ModeofOperation, Id = Index.ModeofOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public ModeofOperation ModeofOperation { get; set; }

        /// <summary>
        /// Gets or sets HidePrintedChecks 
        /// </summary>
        [ViewField(Name = Fields.HidePrintedChecks, Id = Index.HidePrintedChecks, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool HidePrintedChecks { get; set; }

        /// <summary>
        /// Gets or sets Banks 
        /// </summary>
        [ViewField(Name = Fields.Banks, Id = Index.Banks, FieldType = EntityFieldType.Int, Size = 2)]
        public Banks Banks { get; set; }

        /// <summary>
        /// Gets or sets BanksForThisRun 
        /// </summary>
        [ViewField(Name = Fields.BanksForThisRun, Id = Index.BanksForThisRun, FieldType = EntityFieldType.Int, Size = 2)]
        public int BanksForThisRun { get; set; }

        /// <summary>
        /// Gets or sets UnpostedBanksForThisRun 
        /// </summary>
        [ViewField(Name = Fields.UnpostedBanksForThisRun, Id = Index.UnpostedBanksForThisRun, FieldType = EntityFieldType.Int, Size = 2)]
        public int UnpostedBanksForThisRun { get; set; }

        /// <summary>
        /// Gets or sets UnprintedCheckCountTotal 
        /// </summary>
        [ViewField(Name = Fields.UnprintedCheckCountTotal, Id = Index.UnprintedCheckCountTotal, FieldType = EntityFieldType.Long, Size = 4)]
        public long UnprintedCheckCountTotal { get; set; }

        /// <summary>
        /// Gets or sets CheckForm 
        /// </summary>
        [StringLength(260, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CheckForm, Id = Index.CheckForm, FieldType = EntityFieldType.Char, Size = 260)]
        public string CheckForm { get; set; }

        /// <summary>
        /// Gets or sets AdviceForm 
        /// </summary>
        [StringLength(260, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.AdviceForm, Id = Index.AdviceForm, FieldType = EntityFieldType.Char, Size = 260)]
        public string AdviceForm { get; set; }
    }
}
