// Copyright (c) 2024 Sage Software, Inc. All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.CS.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for ConnectedBridgeOnboarding
    /// </summary>
    public partial class ConnectedBridgeOnboarding : ModelBase
    {
        /// <summary>
        /// Gets or sets RecordNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecordNumber", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.RecordNumber, Id = Index.RecordNumber, FieldType = EntityFieldType.Char, Size = 20)]
        public string RecordNumber { get; set; }

        /// <summary>
        /// Gets or sets Payload
        /// </summary>
        [Display(Name = "Payload", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.Payload, Id = Index.Payload, FieldType = EntityFieldType.Byte, Size = 3800)]
        public byte[] Payload { get; set; }

        /// <summary>
        /// Gets or sets OrganisationID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrganisationID", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.OrganisationID, Id = Index.OrganisationID, FieldType = EntityFieldType.Char, Size = 36)]
        public string OrganisationID { get; set; }

        /// <summary>
        /// Gets or sets CompanyID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompanyID", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.CompanyID, Id = Index.CompanyID, FieldType = EntityFieldType.Char, Size = 36)]
        public string CompanyID { get; set; }

        /// <summary>
        /// Gets or sets SigningKey
        /// </summary>
        [StringLength(64, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SigningKey", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.SigningKey, Id = Index.SigningKey, FieldType = EntityFieldType.Char, Size = 64)]
        public string SigningKey { get; set; }

        /// <summary>
        /// Gets or sets AccountID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountID", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.AccountID, Id = Index.AccountID, FieldType = EntityFieldType.Char, Size = 36)]
        public string AccountID { get; set; }

        /// <summary>
        /// Gets or sets ProductSubscriptionID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProductSubscriptionID", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.ProductSubscriptionID, Id = Index.ProductSubscriptionID, FieldType = EntityFieldType.Char, Size = 36)]
        public string ProductSubscriptionID { get; set; }

        /// <summary>
        /// Gets or sets ApplicationID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApplicationID", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.ApplicationID, Id = Index.ApplicationID, FieldType = EntityFieldType.Char, Size = 36)]
        public string ApplicationID { get; set; }

        /// <summary>
        /// Gets or sets ClientID
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ClientID", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.ClientID, Id = Index.ClientID, FieldType = EntityFieldType.Char, Size = 10)]
        public string ClientID { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialNumber", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 20)]
        public string SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets SageIDUser
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SageIDUser", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.SageIDUser, Id = Index.SageIDUser, FieldType = EntityFieldType.Char, Size = 200)]
        public string SageIDUser { get; set; }

        /// <summary>
        /// Gets or sets RefreshToken
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RefreshToken", ResourceType = typeof (ConnectedBridgeOnboardingResx))]
        [ViewField(Name = Fields.RefreshToken, Id = Index.RefreshToken, FieldType = EntityFieldType.Char, Size = 200)]
        public string RefreshToken { get; set; }

        #region UI Strings

        #endregion
    }
}