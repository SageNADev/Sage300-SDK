// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Bank Transaction Reversal model
    /// </summary>
    public partial class BankTransactionReversal : ModelBase
    {
        /// <summary>
        /// BankTransactionReversal Constructor
        /// </summary>
        public BankTransactionReversal()
        {
            BankTransactionReversalDetails = new EnumerableResponse<BankTransactionReversalDetail>();
        }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(ReverseTransactionsResx))]
        [Key]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8)]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets DetailSequence 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.DetailSequence, Id = Index.DetailSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long DetailSequence { get; set; }

        /// <summary>
        /// Gets or sets ReverseDocument 
        /// </summary>
        [Display(Name = "ReverseDocument", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.ReverseDocument, Id = Index.ReverseDocument, FieldType = EntityFieldType.Int, Size = 2)]
        public ReverseDocument ReverseDocument { get; set; }

        /// <summary>
        /// Gets or sets ReverseInvoice 
        /// </summary>
        [Display(Name = "ReverseInvoice", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.ReverseInvoice, Id = Index.ReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public ReverseInvoice ReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets ReversalDate 
        /// </summary>
        [Display(Name = "ReversalDate", ResourceType = typeof(ReverseTransactionsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReversalDate, Id = Index.ReversalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ReversalDate { get; set; }

        /// <summary>
        /// Gets or sets ReversalFiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReversalFiscalYear, Id = Index.ReversalFiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string ReversalFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets ReversalFiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.ReversalFiscalPeriod, Id = Index.ReversalFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReversalFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReversalReason 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReasonForReversal", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.ReversalReason, Id = Index.ReversalReason, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReversalReason { get; set; }

        /// <summary>
        /// Gets or sets TransactionHeaderSerial 
        /// </summary>
        [ViewField(Name = Fields.TransactionHeaderSerial, Id = Index.TransactionHeaderSerial, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long TransactionHeaderSerial { get; set; }

        /// <summary>
        /// Gets or sets TransactionDetailLine 
        /// </summary>
        [ViewField(Name = Fields.TransactionDetailLine, Id = Index.TransactionDetailLine, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionDetailLine { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2)]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionType { get; set; }

        /// <summary>
        /// Gets or sets HeaderType 
        /// </summary>
        [ViewField(Name = Fields.HeaderType, Id = Index.HeaderType, FieldType = EntityFieldType.Int, Size = 2)]
        public int HeaderType { get; set; }

        /// <summary>
        /// Gets or sets DetailType 
        /// </summary>
        [ViewField(Name = Fields.DetailType, Id = Index.DetailType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailType { get; set; }

        /// <summary>
        /// Gets or sets RemittanceID 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Number", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.RemittanceId, Id = Index.RemittanceId, FieldType = EntityFieldType.Char, Size = 24)]
        public string RemittanceId { get; set; }

        /// <summary>
        /// Gets or sets DrilldownType 
        /// </summary>
        [ViewField(Name = Fields.DrilldownType, Id = Index.DrilldownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrilldownType { get; set; }

        /// <summary>
        /// Gets or sets DrilldownLink 
        /// </summary>
        [ViewField(Name = Fields.DrilldownLink, Id = Index.DrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public string DrilldownLink { get; set; }

        /// <summary>
        /// Gets or sets RemittanceDate 
        /// </summary>
        [ViewField(Name = Fields.RemittanceDate, Id = Index.RemittanceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RemittanceDate { get; set; }

        /// <summary>
        /// Gets or sets TransactionFunctionalAmount 
        /// </summary>
        [ViewField(Name = Fields.TransactionFunctionalAmount, Id = Index.TransactionFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets TransactionSourceAmount 
        /// </summary>
        [ViewField(Name = Fields.TransactionSourceAmount, Id = Index.TransactionSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets TransactionSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TransactionSourceCurrency, Id = Index.TransactionSourceCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string TransactionSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets PayorCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PayorCode, Id = Index.PayorCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PayorCode { get; set; }

        /// <summary>
        /// Gets or sets PayorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PayorName, Id = Index.PayorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PayorName { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCodeReverseTransactions ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets ProcessBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProcessBankCode, Id = Index.ProcessBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string ProcessBankCode { get; set; }

        /// <summary>
        /// Gets or sets ProcessSourceApplication 
        /// </summary>
        [Display(Name = "SourceApplication", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.ProcessSourceApplication, Id = Index.ProcessSourceApplication, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessSourceApplication ProcessSourceApplication { get; set; }

        /// <summary>
        /// Gets SourceApplicationProcess
        /// </summary>
        public string SourceApplicationProcess
        {
            get { return EnumUtility.GetStringValue(ProcessSourceApplication); }
        }

        /// <summary>
        /// Gets or sets ReverseMultipleTransactions 
        /// </summary>
        [Display(Name = "ReverseMultipleTransactions", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.ReverseMultipleTransactions, Id = Index.ReverseMultipleTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public ReverseMultipleTransactions ReverseMultipleTransactions { get; set; }

        /// <summary>
        /// Gets or sets ReverseTransactionType 
        /// </summary>
        [ViewField(Name = Fields.ReverseTransactionType, Id = Index.ReverseTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReverseTransactionType ReverseTransactionType { get; set; }

        /// <summary>
        /// Gets or sets RemittanceIDFrom 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemittanceIdFrom, Id = Index.RemittanceIdFrom, FieldType = EntityFieldType.Char, Size = 24)]
        public string RemittanceIdFrom { get; set; }

        /// <summary>
        /// Gets or sets RemittanceIDTo 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemittanceIdTo, Id = Index.RemittanceIdTo, FieldType = EntityFieldType.Char, Size = 24)]
        public string RemittanceIdTo { get; set; }

        /// <summary>
        /// Gets or sets RemittanceDateFrom 
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemittanceDateFrom, Id = Index.RemittanceDateFrom, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RemittanceDateFrom { get; set; }

        /// <summary>
        /// Gets or sets RemittanceDateTo 
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RemittanceDateTo, Id = Index.RemittanceDateTo, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RemittanceDateTo { get; set; }

        /// <summary>
        /// Gets or sets FuncTransactionAmountFrom 
        /// </summary>
        [ViewField(Name = Fields.FuncTransactionAmountFrom, Id = Index.FuncTransactionAmountFrom, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTransactionAmountFrom { get; set; }

        /// <summary>
        /// Gets or sets FuncTransactionAmountTo 
        /// </summary>
        [ViewField(Name = Fields.FuncTransactionAmountTo, Id = Index.FuncTransactionAmountTo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTransactionAmountTo { get; set; }

        /// <summary>
        /// Gets or sets SrceTransactionAmountFrom 
        /// </summary>
        [Display(Name = "SourceAmount", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.SrceTransactionAmountFrom, Id = Index.SrceTransactionAmountFrom, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTransactionAmountFrom { get; set; }

        /// <summary>
        /// Gets or sets SrceTransactionAmountTo 
        /// </summary>
        [Display(Name = "SourceAmount", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.SrceTransactionAmountTo, Id = Index.SrceTransactionAmountTo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTransactionAmountTo { get; set; }

        /// <summary>
        /// Gets or sets SrceCurrencyFrom 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrency", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.SrceCurrencyFrom, Id = Index.SrceCurrencyFrom, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SrceCurrencyFrom { get; set; }

        /// <summary>
        /// Gets or sets SrceCurrencyTo 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrency", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.SrceCurrencyTo, Id = Index.SrceCurrencyTo, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SrceCurrencyTo { get; set; }

        /// <summary>
        /// Gets or sets PayerCodeFrom 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PayerCodeFrom, Id = Index.PayerCodeFrom, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PayerCodeFrom { get; set; }

        /// <summary>
        /// Gets or sets PayerCodeTo 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PayerCodeTo, Id = Index.PayerCodeTo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PayerCodeTo { get; set; }

        /// <summary>
        /// Gets or sets ProcessBankAccountNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProcessBankAccountNumber, Id = Index.ProcessBankAccountNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string ProcessBankAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessBankAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProcessBankAccount, Id = Index.ProcessBankAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string ProcessBankAccount { get; set; }

        /// <summary>
        /// Gets or sets ProcessStatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProcessStatementCurrency, Id = Index.ProcessStatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string ProcessStatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets DuplicateRemittanceID 
        /// </summary>
        [ViewField(Name = Fields.DuplicateRemittanceId, Id = Index.DuplicateRemittanceId, FieldType = EntityFieldType.Int, Size = 2)]
        public ReverseMultipleTransactions DuplicateRemittanceId { get; set; }

        /// <summary>
        /// Gets or sets NumberofReversals 
        /// </summary>
        [ViewField(Name = Fields.NumberofReversals, Id = Index.NumberofReversals, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofReversals { get; set; }

        /// <summary>
        /// Gets or sets RestartRunID 
        /// </summary>
        [ViewField(Name = Fields.RestartRunId, Id = Index.RestartRunId, FieldType = EntityFieldType.Long, Size = 4)]
        public long RestartRunId { get; set; }

        /// <summary>
        /// Gets or sets Hasrestartrecord 
        /// </summary>
        [ViewField(Name = Fields.Hasrestartrecord, Id = Index.Hasrestartrecord, FieldType = EntityFieldType.Int, Size = 2)]
        public ReverseMultipleTransactions Hasrestartrecord { get; set; }

        /// <summary>
        /// Gets or sets IsMultiCurrency 
        /// </summary>
        public bool IsBankWithMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Statement Currency
        /// </summary>
        public string BankStatementCurrency { get; set; }

        /// <summary>
        /// List of BankTransactionReversal Detail
        /// </summary>
        public EnumerableResponse<BankTransactionReversalDetail> BankTransactionReversalDetails { get; set; }

        #region Security Properties

        /// <summary>
        /// Gets or sets IsAPReverse
        /// </summary>
        public bool IsAPReverse { get; set; }

        /// <summary>
        /// Gets or sets IsARReverse
        /// </summary>
        public bool IsARReverse { get; set; }

        /// <summary>
        /// Gets or sets IsBkReverse
        /// </summary>
        /// Not changing this Property name according to Re-Sharper. Just keeping it consistent with Previous values
        public bool IsBKReverse { get; set; }

        #endregion
    }
}
