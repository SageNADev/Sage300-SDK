/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// class ImportOFXStatements
    /// </summary>
    public partial class ImportOFXStatement : ModelBase
    {
        /// <summary>
        /// Property for Bank Code 
        /// </summary>
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Property for Unique ID
        /// </summary>
        [ViewField(Name = Fields.UniqueID, Id = Index.UniqueID, FieldType = EntityFieldType.Long, Size = 4)]
        public long UniqueID { get; set; }

        /// <summary>
        /// Property for Serial Number of Bank Transaction
        /// </summary>
        [ViewField(Name = Fields.SerialNumberOfBankTransaction, Id = Index.SerialNumberOfBankTransaction, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialNumberOfBankTransaction { get; set; }

        /// <summary>
        /// Property for Line Number of Bank Transaction
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.LineNumberOfBankTransaction, Id = Index.LineNumberOfBankTransaction, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineNumberOfBankTransaction { get; set; }

        /// <summary>
        /// Property for Posted Date
        /// </summary>
        [Display(Name = "BankClearedDate", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.PostedDate, Id = Index.PostedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostedDate { get; set; }

        /// <summary>
        /// Property for Distribution Code
        /// </summary>
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public int DistributionCode { get; set; }

        /// <summary>
        /// Property for Withdrawal Number
        /// </summary>
        [ViewField(Name = Fields.WithdrawalNumber, Id = Index.WithdrawalNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string WithdrawalNumber { get; set; }

        /// <summary>
        /// Property for Reference
        /// </summary>
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Property for Comment
        /// </summary>
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 60)]
        public string Comment { get; set; }

        /// <summary>
        /// Property for Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Property for Source Amount
        /// </summary>
        [Display(Name = "SourceAmount", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.SourceAmount, Id = Index.SourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceAmount { get; set; }

        /// <summary>
        /// Property for Statement Currency
        /// </summary>
        [Display(Name = "StatementCurrency", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Property for Is Amount in Statement Currency
        /// </summary>
        [ViewField(Name = Fields.IsAmountInStatementCurrency, Id = Index.IsAmountInStatementCurrency, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IsAmountInStatementCurrency { get; set; }

        /// <summary>
        /// Property for Payee Code
        /// </summary>
        [ViewField(Name = Fields.PayeeCode, Id = Index.PayeeCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string PayeeCode { get; set; }

        /// <summary>
        /// Property for Payee Name
        /// </summary>
        [ViewField(Name = Fields.PayeeName, Id = Index.PayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PayeeName { get; set; }

        /// <summary>
        /// Property for Rate Type
        /// </summary>
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Property for SourceCurrency
        /// </summary>
        [Display(Name = "SourceCurrency", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.SourceCurrency, Id = Index.SourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SourceCurrency { get; set; }

        /// <summary>
        /// Property for Rate Date
        /// </summary>
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string RateDate { get; set; }

        /// <summary>
        /// Property for Rate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.Rate, Id = Index.Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Rate { get; set; }

        /// <summary>
        /// Property for Rate Spread
        /// </summary>
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Property for Rate Operator
        /// </summary>
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperator RateOperator { get; set; }

        /// <summary>
        /// Property for G/L Account
        /// </summary>
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Property for Post Now
        /// </summary>
        [ViewField(Name = Fields.PostNow, Id = Index.PostNow, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostNow { get; set; }

        /// <summary>
        /// Property for Entry Type
        /// </summary>
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public int EntryType { get; set; }

        /// <summary>
        /// Property for Transaction Type
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public OFXTransactionType TransactionType { get; set; }

        /// <summary>
        /// Get Enum Value for Transaction Type
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ReconcileOFXStatementResx))]
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Property for OFX Transaction ID
        /// </summary>
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.OFXTransactionID, Id = Index.OFXTransactionID, FieldType = EntityFieldType.Char, Size = 50)]
        public string OFXTransactionID { get; set; }

        /// <summary>
        /// Property for Reconciliation Year
        /// </summary>
        [ViewField(Name = Fields.ReconciliationYear, Id = Index.ReconciliationYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ReconciliationYear { get; set; }

        /// <summary>
        /// Property for Reconciliation Period
        /// </summary>
        [ViewField(Name = Fields.ReconciliationPeriod, Id = Index.ReconciliationPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationPeriod { get; set; }

        /// <summary>
        /// Property for  Match Found
        /// </summary>
        [ViewField(Name = Fields.MatchFound, Id = Index.MatchFound, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool MatchFound { get; set; }

        /// <summary>
        /// Property for Memo
        /// </summary>
        [Display(Name = "Memo", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ViewField(Name = Fields.Memo, Id = Index.Memo, FieldType = EntityFieldType.Char, Size = 255)]
        public string Memo { get; set; }

        /// <summary>
        /// The Banks related to the ImportOFXStatements
        /// </summary>
        /// <value>Bank detail.</value>
        public EnumerableResponse<Banks> Banks { get; set; }

        /// <summary>
        /// Gets Decimal places for SourceCurrency
        /// </summary>
        public string SourceCurrencyDecimalPlaces { get; set; }

        /// <summary>
        /// Gets Decimal places for StatementCurrency
        /// </summary>
        public string StatementCurrencyDecimalPlaces { get; set; }
    }
}
