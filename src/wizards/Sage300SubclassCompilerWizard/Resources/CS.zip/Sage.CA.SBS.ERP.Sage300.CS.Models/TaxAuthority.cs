/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// class Tax Authorities
    /// </summary>
    public partial class TaxAuthority : ModelBase
    {
        /// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [Display(Name = "TxAuthRecType", ResourceType = typeof(TaxAuthoritiesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.TaxAuthorityCode, Id = Index.TaxAuthorityCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthorityCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "TxAuthDesc", ResourceType = typeof(TaxAuthoritiesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrency 
        /// </summary>
        [Display(Name = "TxRepCurr", ResourceType = typeof(TaxAuthoritiesResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingCurrency, Id = Index.TaxReportingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrency { get; set; }

        /// <summary>
        /// Gets or sets MaximumTaxAllowable 
        /// </summary>
        [Display(Name = "MaxTaxAll", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.MaximumTaxAllowable, Id = Index.MaximumTaxAllowable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumTaxAllowable { get; set; }

        /// <summary>
        /// Gets or sets NoTaxChargedBelow 
        /// </summary>
        [Display(Name = "NoTxChar", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.NoTaxChargedBelow, Id = Index.NoTaxChargedBelow, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NoTaxChargedBelow { get; set; }

        /// <summary>
        /// Gets or sets TaxBase 
        /// </summary>
        [Display(Name = "TxBase", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.TaxBase, Id = Index.TaxBase, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxBase TaxBase { get; set; }

        /// <summary>
        /// Gets or sets AllowTaxInPrice 
        /// </summary>
        [Display(Name = "AllTaxInPrice", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.AllowTaxInPrice, Id = Index.AllowTaxInPrice, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowTaxInPrice AllowTaxInPrice { get; set; }

        /// <summary>
        /// Gets or sets TaxLiabilityAccount 
        /// </summary>
        [Display(Name = "TxLiabilityAcct", ResourceType = typeof(TaxAuthoritiesResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxLiabilityAccount, Id = Index.TaxLiabilityAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxLiabilityAccount { get; set; }

        /// <summary>
        /// Gets or sets ReportLevel 
        /// </summary>
        [Display(Name = "RepLevel", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.ReportLevel, Id = Index.ReportLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportLevel ReportLevel { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverable 
        /// </summary>
        [Display(Name = "TxRecover", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.TaxRecoverable, Id = Index.TaxRecoverable, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowTaxInPrice TaxRecoverable { get; set; }

        /// <summary>
        /// Gets or sets RecoverableRate 
        /// </summary>
        [Display(Name = "RecoRate", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.RecoverableRate, Id = Index.RecoverableRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal RecoverableRate { get; set; }

        /// <summary>
        /// Gets or sets RecoverableTaxAccount 
        /// </summary>
        [Display(Name = "RecoTxAcct", ResourceType = typeof(TaxAuthoritiesResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RecoverableTaxAccount, Id = Index.RecoverableTaxAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RecoverableTaxAccount { get; set; }

        /// <summary>
        /// Gets or sets ExpenseSeparately 
        /// </summary>
        [Display(Name = "ExpSeparate", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.ExpenseSeparately, Id = Index.ExpenseSeparately, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowTaxInPrice ExpenseSeparately { get; set; }

        /// <summary>
        /// Gets or sets ExpenseAccount 
        /// </summary>
        [Display(Name = "ExpAcct", ResourceType = typeof(TaxAuthoritiesResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpenseAccount, Id = Index.ExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets TaxType 
        /// </summary>
        [Display(Name = "TxType", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.TaxType, Id = Index.TaxType, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxType TaxType { get; set; }

        /// <summary>
        /// Gets or sets ReportTaxonRetainageDocument 
        /// </summary>
        [Display(Name = "RepTaxRetainage", ResourceType = typeof(TaxAuthoritiesResx))]
        [ViewField(Name = Fields.ReportTaxonRetainageDocument, Id = Index.ReportTaxonRetainageDocument, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportTaxonRetainageDocument ReportTaxonRetainageDocument { get; set; }

        /// <summary>
        /// Gets or sets Reference Number
        /// </summary>
        [Display(Name ="RefNumber", ResourceType =typeof(TaxAuthoritiesResx))]
        [MaxLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RefNumber, Id = Index.RefNumber, FieldType = EntityFieldType.Char, Size = 60)]
        public string RefNumber { get; set; }

        /// <summary>
        /// Gets or sets Reference Name
        /// </summary>
        [Display(Name ="RefName", ResourceType =typeof(TaxAuthoritiesResx))]
        [MaxLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RefName, Id = Index.RefName, FieldType = EntityFieldType.Char, Size = 60)]
        public string RefName { get; set; }

        /// <summary>
        /// Gets or sets AccountWithHolding Name
        /// </summary>
        [Display(Name = "AccountWithHolding", ResourceType = typeof(TaxAuthoritiesResx))]
        [MaxLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountWithHolding, Id = Index.AccountWithHolding, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountWithHolding { get; set; }

        /// <summary>
        /// Gets or sets InputTaxAccount Name
        /// </summary>
        [Display(Name = "InputTaxAccount", ResourceType = typeof(TaxAuthoritiesResx))]
        [MaxLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InputTaxAccount, Id = Index.InputTaxAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InputTaxAccount { get; set; }

        /// <summary>
        /// Gets or sets OutputTaxAccount Name
        /// </summary>
        [Display(Name = "OutputTaxAccount", ResourceType = typeof(TaxAuthoritiesResx))]
        [MaxLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OutputTaxAccount, Id = Index.OutputTaxAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string OutputTaxAccount { get; set; }

        /// <summary>
        /// Gets or sets the entry mode for tax authority
        /// </summary>
        /// <value>The TaxBase.</value>
        [Display(Name = "TxBase", ResourceType = typeof(TaxAuthoritiesResx))]
        public string TaxBaseString
        {
            get { return EnumUtility.GetStringValue(TaxBase); }
        }

        /// <summary>
        /// Gets or sets the AllowTaxInPriceString for tax authority
        /// </summary>
        /// <value>The AllowTaxInPriceString.</value>
        [Display(Name = "AllTaxInPrice", ResourceType = typeof(TaxAuthoritiesResx))]
        public string AllowTaxInPriceString
        {
            get { return EnumUtility.GetStringValue(AllowTaxInPrice); }
        }

        /// <summary>
        /// Gets or sets the AllowTaxInPriceString for tax authority
        /// </summary>
        /// <value>The AllowTaxInPriceString.</value>
        [Display(Name = "TxRecover", ResourceType = typeof(TaxAuthoritiesResx))]
        public string TaxRecoverableString
        {
            get { return EnumUtility.GetStringValue(TaxRecoverable); }
        }

        /// <summary>
        /// Gets or sets the AllowTaxInPriceString for tax authority
        /// </summary>
        /// <value>The AllowTaxInPriceString.</value>
        [Display(Name = "ExpSeparate", ResourceType = typeof(TaxAuthoritiesResx))]
        public string ExpenseSeparatelyString
        {
            get { return EnumUtility.GetStringValue(ExpenseSeparately); }

        }

        /// <summary>
        /// Gets or sets the ReportTaxonRetainageDocumentString for tax authority
        /// </summary>
        [Display(Name = "RepTaxRetainage", ResourceType = typeof(TaxAuthoritiesResx))]
        public string ReportTaxonRetainageDocumentString
        {
            get { return EnumUtility.GetStringValue(ReportTaxonRetainageDocument); }
        }

        /// <summary>
        /// Gets or sets the TaxTypeString for tax authority
        /// </summary>
        [Display(Name = "TxType", ResourceType = typeof(TaxAuthoritiesResx))]
        public string TaxTypeString
        {
            get { return EnumUtility.GetStringValue(TaxType); }
        }

        /// <summary>
        /// Gets or sets the ReportLevelString for tax authority
        /// </summary>
        [Display(Name = "RepLevel", ResourceType = typeof(TaxAuthoritiesResx))]
        public string ReportLevelString
        {
            get { return EnumUtility.GetStringValue(ReportLevel); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [allow tax price].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [allow tax price]; otherwise, <c>false</c>.
        /// </value>
        [Display(Name = "AllTaxInPrice", ResourceType = typeof(TaxAuthoritiesResx))]
        public bool AllowTaxPrice
        {
            get { return AllowTaxInPrice != AllowTaxInPrice.No; }
            set
            {
                AllowTaxInPrice = value
                    ? AllowTaxInPrice.Yes
                    : AllowTaxInPrice.No;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [expense separate].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [expense separate]; otherwise, <c>false</c>.
        /// </value>
        [Display(Name = "ExpSeparate", ResourceType = typeof(TaxAuthoritiesResx))]
        public bool ExpenseSeparate
        {
            get { return ExpenseSeparately != AllowTaxInPrice.No; }
            set
            {
                ExpenseSeparately = value
                    ? AllowTaxInPrice.Yes
                    : AllowTaxInPrice.No;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether [recover tax].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [recover tax]; otherwise, <c>false</c>.
        /// </value>
        [Display(Name = "TxRecover", ResourceType = typeof(TaxAuthoritiesResx))]
        public bool RecoverTax
        {
            get { return TaxRecoverable != AllowTaxInPrice.No; }
            set
            {
                TaxRecoverable = value
                    ? AllowTaxInPrice.Yes
                    : AllowTaxInPrice.No;
            }
        }

        /// <summary>
        /// Get or set for  IsMultiCurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets TaxClassDetails.
        /// </summary>
        public EnumerableResponse<TaxClass> TaxClassDetails { get; set; }
    }
}
