/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// class Tax Classes
    /// </summary>
    public partial class TaxClass : ModelBase
    {

        /// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TxAuthRecType", ResourceType = typeof(TaxClassesResx))]
        [Key]
        [ViewField(Name = Fields.TaxAuthorityCode, Id = Index.TaxAuthorityCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthorityCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionType", ResourceType = typeof(TaxClassesResx))]
        [Key]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets ClassType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ClassType", ResourceType = typeof(TaxClassesResx))]
        [Key]
        [ViewField(Name = Fields.ClassType, Id = Index.ClassType, FieldType = EntityFieldType.Int, Size = 2)]
        public ClassType ClassType { get; set; }

        /// <summary>
        /// Gets or sets Vendor Class Type 
        /// </summary>
        [Display(Name = "ClassType", ResourceType = typeof(TaxClassesResx))]
        public VendorClassType VendorClassType
        {
            get { return ClassType == ClassType.Customers ? VendorClassType.Vendors : VendorClassType.Items; }
        }

        /// <summary>
        /// Gets or sets Class 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass", ResourceType = typeof(TaxClassesResx))]
        [Key]
        [ViewField(Name = Fields.Class, Id = Index.Class, FieldType = EntityFieldType.Int, Size = 2)]
        public int Class { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClassDesc", ResourceType = typeof(TaxClassesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Exempt 
        /// </summary>
        [Display(Name = "Exempt", ResourceType = typeof(TaxClassesResx))]
        [ViewField(Name = Fields.Exempt, Id = Index.Exempt, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowTaxInPrice Exempt { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets the Exemptstring.
        /// </summary>
        /// <value>The Exemptstring.</value>
        public string Exemptstring
        {
            get { return EnumUtility.GetStringValue(Exempt); }
        }

        /// <summary>
        /// Gets the TransactionTypestring.
        /// </summary>
        /// <value>The TransactionTypestring.</value>
        public string TransactionTypestring
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Gets the ClassTypestring.
        /// </summary>
        /// <value>The ClassTypestring.</value>
        public string ClassTypestring
        {
            get { return EnumUtility.GetStringValue(ClassType); }
        }


        /// <summary>
        /// Gets the Vendor Class Type string.
        /// </summary>
        /// <value>The  Vendor Class Type string.</value>
        public string VendorClassTypestring
        {
            get { return EnumUtility.GetStringValue(VendorClassType); }
        }
    }
}
