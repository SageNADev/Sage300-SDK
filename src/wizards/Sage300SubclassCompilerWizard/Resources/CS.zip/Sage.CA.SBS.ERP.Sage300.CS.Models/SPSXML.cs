// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
     /// <summary>
     /// Partial class for SPSXML
     /// </summary>
     public partial class SPSXML : ModelBase
     {
          /// <summary>
          /// Gets or sets Bank
          /// </summary>
          [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Bank {get; set;}

          /// <summary>
          /// Gets or sets CurrencyCode
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string CurrencyCode {get; set;}

          /// <summary>
          /// Gets or sets Action
          /// </summary>
          public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Action Action {get; set;}

          /// <summary>
          /// Gets or sets TransactionID
          /// </summary>
         [Key] 
         [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string TransactionID {get; set;}

          /// <summary>
          /// Gets or sets ResponseIndicator
          /// </summary>
          [StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string ResponseIndicator {get; set;}

          /// <summary>
          /// Gets or sets ResponseCode
          /// </summary>
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string ResponseCode {get; set;}

          /// <summary>
          /// Gets or sets ResponseMessage
          /// </summary>
          [StringLength(32, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string ResponseMessage {get; set;}

          // TODO: The naming convention of this property has to be manually evaluated
          /// <summary>
          /// Gets or sets GUID
          /// </summary>
          [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string GUID {get; set;}

          /// <summary>
          /// Gets or sets ExpireDate
          /// </summary>
          [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string ExpireDate {get; set;}

          /// <summary>
          /// Gets or sets Last4
          /// </summary>
          [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Last4 {get; set;}

          /// <summary>
          /// Gets or sets PaymentDescription
          /// </summary>
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string PaymentDescription {get; set;}

          /// <summary>
          /// Gets or sets PaymentTypeID
          /// </summary>
          [StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string PaymentTypeID {get; set;}

          /// <summary>
          /// Gets or sets Reference1
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Reference1 {get; set;}

          /// <summary>
          /// Gets or sets Reference2
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Reference2 {get; set;}

          /// <summary>
          /// Gets or sets Amount
          /// </summary>
          [StringLength(9, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Amount {get; set;}

          /// <summary>
          /// Gets or sets AuthorizationCode
          /// </summary>
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string AuthorizationCode {get; set;}

          /// <summary>
          /// Gets or sets VANReference
          /// </summary>
          [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string VANReference {get; set;}

          /// <summary>
          /// Gets or sets Name
          /// </summary>
          [StringLength(103, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Name {get; set;}

          /// <summary>
          /// Gets or sets AddressLine1
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string AddressLine1 {get; set;}

          /// <summary>
          /// Gets or sets AddressLine2
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string AddressLine2 {get; set;}

          /// <summary>
          /// Gets or sets City
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string City {get; set;}

          /// <summary>
          /// Gets or sets State
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string State {get; set;}

          /// <summary>
          /// Gets or sets ZipCode
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string ZipCode {get; set;}

          /// <summary>
          /// Gets or sets Country
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Country {get; set;}

          /// <summary>
          /// Gets or sets Email
          /// </summary>
          [StringLength(256, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Email {get; set;}

          /// <summary>
          /// Gets or sets Telephone
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Telephone {get; set;}

          /// <summary>
          /// Gets or sets Fax
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Fax {get; set;}

          /// <summary>
          /// Gets or sets AVSResult
          /// </summary>
          [StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string AVSResult {get; set;}

          /// <summary>
          /// Gets or sets CVVResult
          /// </summary>
          [StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string CVVResult {get; set;}

          /// <summary>
          /// Gets or sets TransactionDate
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string TransactionDate {get; set;}

          /// <summary>
          /// Gets or sets BatchReference
          /// </summary>
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string BatchReference {get; set;}

          /// <summary>
          /// Gets or sets SettlementType
          /// </summary>
          [StringLength(1, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string SettlementType {get; set;}

          /// <summary>
          /// Gets or sets SettlementDate
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string SettlementDate {get; set;}

          /// <summary>
          /// Gets or sets TransactionType
          /// </summary>
          [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string TransactionType {get; set;}

          // TODO: The naming convention of this property has to be manually evaluated
          /// <summary>
          /// Gets or sets CUSTNMB
          /// </summary>
          [StringLength(17, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string CUSTNMB {get; set;}

          /// <summary>
          /// Gets or sets TaxAmount
          /// </summary>
          [StringLength(9, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string TaxAmount {get; set;}

          /// <summary>
          /// Gets or sets ProcessingCode
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string ProcessingCode {get; set;}

          /// <summary>
          /// Gets or sets MerchantID
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string MerchantID {get; set;}

          /// <summary>
          /// Gets or sets MerchantInfo
          /// </summary>
          public byte[] MerchantInfo {get; set;}

          /// <summary>
          /// Gets or sets Active
          /// </summary>
          public bool Active {get; set;}

          /// <summary>
          /// Gets or sets XMLString
          /// </summary>
          [StringLength(20000, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string XMLString {get; set;}

          /// <summary>
          /// Gets or sets ResponseIslogged
          /// </summary>
          public ResponseIslogged ResponseIslogged {get; set;}

          // TODO: The naming convention of this property has to be manually evaluated
          /// <summary>
          /// Gets or sets IDCUST
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string IDCUST {get; set;}

          /// <summary>
          /// Gets or sets CardID
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string CardID {get; set;}

          /// <summary>
          /// Gets or sets DocumentNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string DocumentNumber {get; set;}

          /// <summary>
          /// Gets or sets CardDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string CardDescription {get; set;}

          /// <summary>
          /// Gets or sets CardComment
          /// </summary>
          [StringLength(255, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string CardComment {get; set;}

          /// <summary>
          /// Gets or sets SPSRequestProcessCompletedFl
          /// </summary>
          public SPSRequestProcessCompletedFl SPSRequestProcessCompletedFl {get; set;}

          /// <summary>
          /// Gets or sets Application
          /// </summary>
          [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          public string Application {get; set;}

     }
}
