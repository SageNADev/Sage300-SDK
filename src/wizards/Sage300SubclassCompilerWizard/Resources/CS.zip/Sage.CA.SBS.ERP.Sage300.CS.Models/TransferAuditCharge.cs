// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.BK.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
     /// <summary>
     /// Partial class for TransferAuditCharge
     /// </summary>
     public partial class TransferAuditCharge : ModelBase
     {
          /// <summary>
          /// Gets or sets PostingSequence
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
          public decimal PostingSequence {get; set;}

          /// <summary>
          /// Gets or sets KeySequence
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.KeySequence, Id = Index.KeySequence, FieldType = EntityFieldType.Decimal, Size = 5)]
          public decimal KeySequence {get; set;}

          /// <summary>
          /// Gets or sets ChargeLine
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ChargeLine, Id = Index.ChargeLine, FieldType = EntityFieldType.Int, Size = 2)]
          public ChargeLine ChargeLine {get; set;}

          /// <summary>
          /// Gets or sets ChargeBank
          /// </summary>
          [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ChargeBank, Id = Index.ChargeBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
          public string ChargeBank {get; set;}

          /// <summary>
          /// Gets or sets TransferChargeDistribCode
          /// </summary>
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferChargeDistribCode, Id = Index.TransferChargeDistribCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string TransferChargeDistribCode {get; set;}

          /// <summary>
          /// Gets or sets TransferChargeGLAccount
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferChargeGLAccount, Id = Index.TransferChargeGLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
          public string TransferChargeGLAccount {get; set;}

          /// <summary>
          /// Gets or sets TransferChargeSourceCurrency
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferChargeSourceCurrency, Id = Index.TransferChargeSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
          public string TransferChargeSourceCurrency {get; set;}

          /// <summary>
          /// Gets or sets TransferChargeSourceAmount
          /// </summary>
          [ViewField(Name = Fields.TransferChargeSourceAmount, Id = Index.TransferChargeSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TransferChargeSourceAmount {get; set;}

          /// <summary>
          /// Gets or sets ExchangeRateType
          /// </summary>
          [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ExchangeRateType, Id = Index.ExchangeRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
          public string ExchangeRateType {get; set;}

          /// <summary>
          /// Gets or sets ExchangeRateDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime ExchangeRateDate {get; set;}

          /// <summary>
          /// Gets or sets ExchangeRate
          /// </summary>
          [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal ExchangeRate {get; set;}

          /// <summary>
          /// Gets or sets RateOperation
          /// </summary>
          [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
          public RateOperation RateOperation {get; set;}

          /// <summary>
          /// Gets or sets TransferChargeFunctionalAmt
          /// </summary>
          [ViewField(Name = Fields.TransferChargeFunctionalAmt, Id = Index.TransferChargeFunctionalAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TransferChargeFunctionalAmt {get; set;}

          /// <summary>
          /// Gets or sets TransferChargeGLOverride
          /// </summary>
          [ViewField(Name = Fields.TransferChargeGLOverride, Id = Index.TransferChargeGLOverride, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TransferChargeGLOverride {get; set;}

          /// <summary>
          /// Gets or sets ChargeGLDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ChargeGLDescription, Id = Index.ChargeGLDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string ChargeGLDescription {get; set;}

          /// <summary>
          /// Gets or sets Taxable
          /// </summary>
          [ViewField(Name = Fields.Taxable, Id = Index.Taxable, FieldType = EntityFieldType.Int, Size = 2)]
          public Taxable Taxable {get; set;}

          /// <summary>
          /// Gets or sets TaxAmountCalculation
          /// </summary>
          [ViewField(Name = Fields.TaxAmountCalculation, Id = Index.TaxAmountCalculation, FieldType = EntityFieldType.Int, Size = 2)]
          public Taxable TaxAmountCalculation {get; set;}

          /// <summary>
          /// Gets or sets TaxGroup
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string TaxGroup {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority1
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string TaxAuthority1 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority2
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string TaxAuthority2 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority3
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string TaxAuthority3 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority4
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string TaxAuthority4 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority5
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string TaxAuthority5 {get; set;}

          /// <summary>
          /// Gets or sets TaxVendorClass1
          /// </summary>
          [ViewField(Name = Fields.TaxVendorClass1, Id = Index.TaxVendorClass1, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxVendorClass1 {get; set;}

          /// <summary>
          /// Gets or sets TaxVendorClass2
          /// </summary>
          [ViewField(Name = Fields.TaxVendorClass2, Id = Index.TaxVendorClass2, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxVendorClass2 {get; set;}

          /// <summary>
          /// Gets or sets TaxVendorClass3
          /// </summary>
          [ViewField(Name = Fields.TaxVendorClass3, Id = Index.TaxVendorClass3, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxVendorClass3 {get; set;}

          /// <summary>
          /// Gets or sets TaxVendorClass4
          /// </summary>
          [ViewField(Name = Fields.TaxVendorClass4, Id = Index.TaxVendorClass4, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxVendorClass4 {get; set;}

          /// <summary>
          /// Gets or sets TaxVendorClass5
          /// </summary>
          [ViewField(Name = Fields.TaxVendorClass5, Id = Index.TaxVendorClass5, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxVendorClass5 {get; set;}

          /// <summary>
          /// Gets or sets TaxItemClass1
          /// </summary>
          [ViewField(Name = Fields.TaxItemClass1, Id = Index.TaxItemClass1, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxItemClass1 {get; set;}

          /// <summary>
          /// Gets or sets TaxItemClass2
          /// </summary>
          [ViewField(Name = Fields.TaxItemClass2, Id = Index.TaxItemClass2, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxItemClass2 {get; set;}

          /// <summary>
          /// Gets or sets TaxItemClass3
          /// </summary>
          [ViewField(Name = Fields.TaxItemClass3, Id = Index.TaxItemClass3, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxItemClass3 {get; set;}

          /// <summary>
          /// Gets or sets TaxItemClass4
          /// </summary>
          [ViewField(Name = Fields.TaxItemClass4, Id = Index.TaxItemClass4, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxItemClass4 {get; set;}

          /// <summary>
          /// Gets or sets TaxItemClass5
          /// </summary>
          [ViewField(Name = Fields.TaxItemClass5, Id = Index.TaxItemClass5, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxItemClass5 {get; set;}

          /// <summary>
          /// Gets or sets TaxInclude1
          /// </summary>
          [ViewField(Name = Fields.TaxInclude1, Id = Index.TaxInclude1, FieldType = EntityFieldType.Int, Size = 2)]
          public AllowedType TaxInclude1 {get; set;}

          /// <summary>
          /// Gets or sets TaxInclude2
          /// </summary>
          [ViewField(Name = Fields.TaxInclude2, Id = Index.TaxInclude2, FieldType = EntityFieldType.Int, Size = 2)]
          public AllowedType TaxInclude2 { get; set; }

          /// <summary>
          /// Gets or sets TaxInclude3
          /// </summary>
          [ViewField(Name = Fields.TaxInclude3, Id = Index.TaxInclude3, FieldType = EntityFieldType.Int, Size = 2)]
          public AllowedType TaxInclude3 { get; set; }

          /// <summary>
          /// Gets or sets TaxInclude4
          /// </summary>
          [ViewField(Name = Fields.TaxInclude4, Id = Index.TaxInclude4, FieldType = EntityFieldType.Int, Size = 2)]
          public AllowedType TaxInclude4 { get; set; }

          /// <summary>
          /// Gets or sets TaxInclude5
          /// </summary>
          [ViewField(Name = Fields.TaxInclude5, Id = Index.TaxInclude5, FieldType = EntityFieldType.Int, Size = 2)]
          public AllowedType TaxInclude5 { get; set; }

          /// <summary>
          /// Gets or sets TaxBaseAmount1
          /// </summary>
          [ViewField(Name = Fields.TaxBaseAmount1, Id = Index.TaxBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseAmount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseAmount2
          /// </summary>
          [ViewField(Name = Fields.TaxBaseAmount2, Id = Index.TaxBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseAmount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseAmount3
          /// </summary>
          [ViewField(Name = Fields.TaxBaseAmount3, Id = Index.TaxBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseAmount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseAmount4
          /// </summary>
          [ViewField(Name = Fields.TaxBaseAmount4, Id = Index.TaxBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseAmount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseAmount5
          /// </summary>
          [ViewField(Name = Fields.TaxBaseAmount5, Id = Index.TaxBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseAmount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseRetainageamount1
          /// </summary>
          [ViewField(Name = Fields.TaxBaseRetainageamount1, Id = Index.TaxBaseRetainageamount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseRetainageamount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseRetainageamount2
          /// </summary>
          [ViewField(Name = Fields.TaxBaseRetainageamount2, Id = Index.TaxBaseRetainageamount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseRetainageamount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseRetainageamount3
          /// </summary>
          [ViewField(Name = Fields.TaxBaseRetainageamount3, Id = Index.TaxBaseRetainageamount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseRetainageamount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseRetainageamount4
          /// </summary>
          [ViewField(Name = Fields.TaxBaseRetainageamount4, Id = Index.TaxBaseRetainageamount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseRetainageamount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseRetainageamount5
          /// </summary>
          [ViewField(Name = Fields.TaxBaseRetainageamount5, Id = Index.TaxBaseRetainageamount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxBaseRetainageamount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxBaseCalculationMethod
          /// </summary>
          [ViewField(Name = Fields.TaxBaseCalculationMethod, Id = Index.TaxBaseCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
          public Taxable TaxBaseCalculationMethod {get; set;}

          /// <summary>
          /// Gets or sets TaxAmount1
          /// </summary>
          [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAmount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxAmount2
          /// </summary>
          [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAmount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxAmount3
          /// </summary>
          [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAmount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxAmount4
          /// </summary>
          [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAmount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxAmount5
          /// </summary>
          [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAmount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxableAMount
          /// </summary>
          [ViewField(Name = Fields.TaxableAMount, Id = Index.TaxableAMount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxableAMount {get; set;}

          /// <summary>
          /// Gets or sets NonTaxableAmount
          /// </summary>
          [ViewField(Name = Fields.NonTaxableAmount, Id = Index.NonTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal NonTaxableAmount {get; set;}

          /// <summary>
          /// Gets or sets TaxTotal
          /// </summary>
          [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxTotal {get; set;}

          /// <summary>
          /// Gets or sets DocumentTotalBeforeTax
          /// </summary>
          [ViewField(Name = Fields.DocumentTotalBeforeTax, Id = Index.DocumentTotalBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal DocumentTotalBeforeTax {get; set;}

          /// <summary>
          /// Gets or sets DocumentTotalIncludingTax
          /// </summary>
          [ViewField(Name = Fields.DocumentTotalIncludingTax, Id = Index.DocumentTotalIncludingTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal DocumentTotalIncludingTax {get; set;}

          /// <summary>
          /// Gets or sets TaxDistributionamount
          /// </summary>
          [ViewField(Name = Fields.TaxDistributionamount, Id = Index.TaxDistributionamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxDistributionamount {get; set;}

          /// <summary>
          /// Gets or sets TotalIncludedAmount
          /// </summary>
          [ViewField(Name = Fields.TotalIncludedAmount, Id = Index.TotalIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TotalIncludedAmount {get; set;}

          /// <summary>
          /// Gets or sets TotalExcludedAmount
          /// </summary>
          [ViewField(Name = Fields.TotalExcludedAmount, Id = Index.TotalExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TotalExcludedAmount {get; set;}

          /// <summary>
          /// Gets or sets TaxNetDistributionAmount
          /// </summary>
          [ViewField(Name = Fields.TaxNetDistributionAmount, Id = Index.TaxNetDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxNetDistributionAmount {get; set;}

          /// <summary>
          /// Gets or sets TaxGrossDistributionAmount
          /// </summary>
          [ViewField(Name = Fields.TaxGrossDistributionAmount, Id = Index.TaxGrossDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxGrossDistributionAmount {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAmount1
          /// </summary>
          [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxExpenseAmount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAmount2
          /// </summary>
          [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxExpenseAmount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAmount3
          /// </summary>
          [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxExpenseAmount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAmount4
          /// </summary>
          [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxExpenseAmount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAmount5
          /// </summary>
          [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxExpenseAmount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAMount1
          /// </summary>
          [ViewField(Name = Fields.TaxRecoverableAMount1, Id = Index.TaxRecoverableAMount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxRecoverableAMount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAMount2
          /// </summary>
          [ViewField(Name = Fields.TaxRecoverableAMount2, Id = Index.TaxRecoverableAMount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxRecoverableAMount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAMount3
          /// </summary>
          [ViewField(Name = Fields.TaxRecoverableAMount3, Id = Index.TaxRecoverableAMount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxRecoverableAMount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAMount4
          /// </summary>
          [ViewField(Name = Fields.TaxRecoverableAMount4, Id = Index.TaxRecoverableAMount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxRecoverableAMount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAMount5
          /// </summary>
          [ViewField(Name = Fields.TaxRecoverableAMount5, Id = Index.TaxRecoverableAMount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxRecoverableAMount5 {get; set;}

          /// <summary>
          /// Gets or sets TotalTaxAllocatedAmount
          /// </summary>
          [ViewField(Name = Fields.TotalTaxAllocatedAmount, Id = Index.TotalTaxAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TotalTaxAllocatedAmount {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAmount1
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAmount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAmount2
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAmount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAmount3
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAmount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAmount4
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAmount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAmount5
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAmount5 {get; set;}

          /// <summary>
          /// Gets or sets TotalTaxReportingAllocAmt
          /// </summary>
          [ViewField(Name = Fields.TotalTaxReportingAllocAmt, Id = Index.TotalTaxReportingAllocAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TotalTaxReportingAllocAmt {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingExpensedAmount
          /// </summary>
          [ViewField(Name = Fields.TaxReportingExpensedAmount, Id = Index.TaxReportingExpensedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingExpensedAmount {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRecoverableAmount
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRecoverableAmount, Id = Index.TaxReportingRecoverableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingRecoverableAmount {get; set;}

          /// <summary>
          /// Gets or sets TotalTaxReportingAmount
          /// </summary>
          [ViewField(Name = Fields.TotalTaxReportingAmount, Id = Index.TotalTaxReportingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TotalTaxReportingAmount {get; set;}

          /// <summary>
          /// Gets or sets TaxVersion
          /// </summary>
          [ViewField(Name = Fields.TaxVersion, Id = Index.TaxVersion, FieldType = EntityFieldType.Long, Size = 4)]
          public long TaxVersion {get; set;}

          /// <summary>
          /// Gets or sets TaxCalculationReportingMethod
          /// </summary>
          [ViewField(Name = Fields.TaxCalculationReportingMethod, Id = Index.TaxCalculationReportingMethod, FieldType = EntityFieldType.Int, Size = 2)]
          public Taxable TaxCalculationReportingMethod {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAccount1
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxExpenseAccount1, Id = Index.TaxExpenseAccount1, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxExpenseAccount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAccount2
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxExpenseAccount2, Id = Index.TaxExpenseAccount2, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxExpenseAccount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAccount3
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxExpenseAccount3, Id = Index.TaxExpenseAccount3, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxExpenseAccount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAccount4
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxExpenseAccount4, Id = Index.TaxExpenseAccount4, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxExpenseAccount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxExpenseAccount5
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxExpenseAccount5, Id = Index.TaxExpenseAccount5, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxExpenseAccount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAccount1
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxRecoverableAccount1, Id = Index.TaxRecoverableAccount1, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxRecoverableAccount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAccount2
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxRecoverableAccount2, Id = Index.TaxRecoverableAccount2, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxRecoverableAccount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAccount3
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxRecoverableAccount3, Id = Index.TaxRecoverableAccount3, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxRecoverableAccount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAccount4
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxRecoverableAccount4, Id = Index.TaxRecoverableAccount4, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxRecoverableAccount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxRecoverableAccount5
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxRecoverableAccount5, Id = Index.TaxRecoverableAccount5, FieldType = EntityFieldType.Char, Size = 45)]
          public string TaxRecoverableAccount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingCurrencyCode
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
          public string TaxReportingCurrencyCode {get; set;}

          /// <summary>
          /// Gets or sets TaxGroupDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxGroupDescription {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthorityDescription1
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthorityDescription1, Id = Index.TaxAuthorityDescription1, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxAuthorityDescription1 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthorityDescription2
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthorityDescription2, Id = Index.TaxAuthorityDescription2, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxAuthorityDescription2 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthorityDescription3
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthorityDescription3, Id = Index.TaxAuthorityDescription3, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxAuthorityDescription3 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthorityDescription4
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthorityDescription4, Id = Index.TaxAuthorityDescription4, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxAuthorityDescription4 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthorityDescription5
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthorityDescription5, Id = Index.TaxAuthorityDescription5, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxAuthorityDescription5 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClassDescription1
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.VendorTaxClassDescription1, Id = Index.VendorTaxClassDescription1, FieldType = EntityFieldType.Char, Size = 60)]
          public string VendorTaxClassDescription1 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClassDescription2
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.VendorTaxClassDescription2, Id = Index.VendorTaxClassDescription2, FieldType = EntityFieldType.Char, Size = 60)]
          public string VendorTaxClassDescription2 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClassDescription3
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.VendorTaxClassDescription3, Id = Index.VendorTaxClassDescription3, FieldType = EntityFieldType.Char, Size = 60)]
          public string VendorTaxClassDescription3 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClassDescription4
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.VendorTaxClassDescription4, Id = Index.VendorTaxClassDescription4, FieldType = EntityFieldType.Char, Size = 60)]
          public string VendorTaxClassDescription4 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClassDescription5
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.VendorTaxClassDescription5, Id = Index.VendorTaxClassDescription5, FieldType = EntityFieldType.Char, Size = 60)]
          public string VendorTaxClassDescription5 {get; set;}

          /// <summary>
          /// Gets or sets ItemTaxClassDescription1
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemTaxClassDescription1, Id = Index.ItemTaxClassDescription1, FieldType = EntityFieldType.Char, Size = 60)]
          public string ItemTaxClassDescription1 {get; set;}

          /// <summary>
          /// Gets or sets ItemTaxClassDescription2
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemTaxClassDescription2, Id = Index.ItemTaxClassDescription2, FieldType = EntityFieldType.Char, Size = 60)]
          public string ItemTaxClassDescription2 {get; set;}

          /// <summary>
          /// Gets or sets ItemTaxClassDescription3
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemTaxClassDescription3, Id = Index.ItemTaxClassDescription3, FieldType = EntityFieldType.Char, Size = 60)]
          public string ItemTaxClassDescription3 {get; set;}

          /// <summary>
          /// Gets or sets ItemTaxClassDescription4
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemTaxClassDescription4, Id = Index.ItemTaxClassDescription4, FieldType = EntityFieldType.Char, Size = 60)]
          public string ItemTaxClassDescription4 {get; set;}

          /// <summary>
          /// Gets or sets ItemTaxClassDescription5
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemTaxClassDescription5, Id = Index.ItemTaxClassDescription5, FieldType = EntityFieldType.Char, Size = 60)]
          public string ItemTaxClassDescription5 {get; set;}

          /// <summary>
          /// Gets or sets FuncGrossDistributionAmount
          /// </summary>
          [ViewField(Name = Fields.FuncGrossDistributionAmount, Id = Index.FuncGrossDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FuncGrossDistributionAmount {get; set;}

          /// <summary>
          /// Gets or sets FunctionalExpensedAmount1
          /// </summary>
          [ViewField(Name = Fields.FunctionalExpensedAmount1, Id = Index.FunctionalExpensedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalExpensedAmount1 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalExpensedAmount2
          /// </summary>
          [ViewField(Name = Fields.FunctionalExpensedAmount2, Id = Index.FunctionalExpensedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalExpensedAmount2 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalExpensedAmount3
          /// </summary>
          [ViewField(Name = Fields.FunctionalExpensedAmount3, Id = Index.FunctionalExpensedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalExpensedAmount3 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalExpensedAmount4
          /// </summary>
          [ViewField(Name = Fields.FunctionalExpensedAmount4, Id = Index.FunctionalExpensedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalExpensedAmount4 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalExpensedAmount5
          /// </summary>
          [ViewField(Name = Fields.FunctionalExpensedAmount5, Id = Index.FunctionalExpensedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalExpensedAmount5 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalRecoverableAmount1
          /// </summary>
          [ViewField(Name = Fields.FunctionalRecoverableAmount1, Id = Index.FunctionalRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalRecoverableAmount1 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalRecoverableAmount2
          /// </summary>
          [ViewField(Name = Fields.FunctionalRecoverableAmount2, Id = Index.FunctionalRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalRecoverableAmount2 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalRecoverableAmount3
          /// </summary>
          [ViewField(Name = Fields.FunctionalRecoverableAmount3, Id = Index.FunctionalRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalRecoverableAmount3 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalRecoverableAmount4
          /// </summary>
          [ViewField(Name = Fields.FunctionalRecoverableAmount4, Id = Index.FunctionalRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalRecoverableAmount4 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalRecoverableAmount5
          /// </summary>
          [ViewField(Name = Fields.FunctionalRecoverableAmount5, Id = Index.FunctionalRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalRecoverableAmount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRate
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRate, Id = Index.TaxReportingRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TaxReportingRate {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRateType
          /// </summary>
          [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2)]
          public string TaxReportingRateType {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRateDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime TaxReportingRateDate {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRateOperation
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxReportingRateOperation {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingCurrencyDesc
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxReportingCurrencyDesc, Id = Index.TaxReportingCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxReportingCurrencyDesc {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRateTypeDesc
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxReportingRateTypeDesc, Id = Index.TaxReportingRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxReportingRateTypeDesc {get; set;}

          /// <summary>
          /// Gets or sets TaxRate1
          /// </summary>
          [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TaxRate1 {get; set;}

          /// <summary>
          /// Gets or sets TaxRate2
          /// </summary>
          [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TaxRate2 {get; set;}

          /// <summary>
          /// Gets or sets TaxRate3
          /// </summary>
          [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TaxRate3 {get; set;}

          /// <summary>
          /// Gets or sets TaxRate4
          /// </summary>
          [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TaxRate4 {get; set;}

          /// <summary>
          /// Gets or sets TaxRate5
          /// </summary>
          [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TaxRate5 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalNetOfTax
          /// </summary>
          [ViewField(Name = Fields.FunctionalNetOfTax, Id = Index.FunctionalNetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalNetOfTax {get; set;}

          /// <summary>
          /// Gets or sets FunctionalTotalTaxAllocated
          /// </summary>
          [ViewField(Name = Fields.FunctionalTotalTaxAllocated, Id = Index.FunctionalTotalTaxAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalTotalTaxAllocated {get; set;}

          /// <summary>
          /// Gets or sets FunctionalTaxTotal
          /// </summary>
          [ViewField(Name = Fields.FunctionalTaxTotal, Id = Index.FunctionalTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalTaxTotal {get; set;}

          /// <summary>
          /// Gets or sets TaxAllocatedAmount1
          /// </summary>
          [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAllocatedAmount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxAllocatedAmount2
          /// </summary>
          [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAllocatedAmount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxAllocatedAmount3
          /// </summary>
          [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAllocatedAmount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxAllocatedAmount4
          /// </summary>
          [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAllocatedAmount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxAllocatedAmount5
          /// </summary>
          [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxAllocatedAmount5 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingExpensed1
          /// </summary>
          [ViewField(Name = Fields.TaxReportingExpensed1, Id = Index.TaxReportingExpensed1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingExpensed1 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingExpensed2
          /// </summary>
          [ViewField(Name = Fields.TaxReportingExpensed2, Id = Index.TaxReportingExpensed2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingExpensed2 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingExpensed3
          /// </summary>
          [ViewField(Name = Fields.TaxReportingExpensed3, Id = Index.TaxReportingExpensed3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingExpensed3 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingExpensed4
          /// </summary>
          [ViewField(Name = Fields.TaxReportingExpensed4, Id = Index.TaxReportingExpensed4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingExpensed4 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingExpensed5
          /// </summary>
          [ViewField(Name = Fields.TaxReportingExpensed5, Id = Index.TaxReportingExpensed5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingExpensed5 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRecoverableAmt1
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingRecoverableAmt1 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRecoverableAmt2
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingRecoverableAmt2 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRecoverableAmt3
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingRecoverableAmt3 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRecoverableAmt4
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingRecoverableAmt4 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingRecoverableAmt5
          /// </summary>
          [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingRecoverableAmt5 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAllocatedAmount1
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAllocatedAmount1 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAllocatedAmount2
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAllocatedAmount2 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAllocatedAmount3
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAllocatedAmount3 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAllocatedAmount4
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAllocatedAmount4 {get; set;}

          /// <summary>
          /// Gets or sets TaxReportingAllocatedAmount5
          /// </summary>
          [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TaxReportingAllocatedAmount5 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalAllocatedAmount1
          /// </summary>
          [ViewField(Name = Fields.FunctionalAllocatedAmount1, Id = Index.FunctionalAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalAllocatedAmount1 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalAllocatedAmount2
          /// </summary>
          [ViewField(Name = Fields.FunctionalAllocatedAmount2, Id = Index.FunctionalAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalAllocatedAmount2 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalAllocatedAmount3
          /// </summary>
          [ViewField(Name = Fields.FunctionalAllocatedAmount3, Id = Index.FunctionalAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalAllocatedAmount3 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalAllocatedAmount4
          /// </summary>
          [ViewField(Name = Fields.FunctionalAllocatedAmount4, Id = Index.FunctionalAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalAllocatedAmount4 {get; set;}

          /// <summary>
          /// Gets or sets FunctionalAllocatedAmount5
          /// </summary>
          [ViewField(Name = Fields.FunctionalAllocatedAmount5, Id = Index.FunctionalAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal FunctionalAllocatedAmount5 {get; set;}

     }
}
