// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.CS.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for Payslip
    /// </summary>
    public partial class Payslip : ModelBase
    {
        /// <summary>
        /// Gets or sets PaymentDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentDate", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.PaymentDate, Id = Index.PaymentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PaymentDate { get; set; }

        /// <summary>
        /// Gets or sets RecordNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecordNumber", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.RecordNumber, Id = Index.RecordNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int RecordNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalModule
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalModule", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.OriginalModule, Id = Index.OriginalModule, FieldType = EntityFieldType.Char, Size = 2)]
        public string OriginalModule { get; set; }

        /// <summary>
        /// Gets or sets Employee
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Employee", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.Employee, Id = Index.Employee, FieldType = EntityFieldType.Char, Size = 12)]
        public string Employee { get; set; }

        /// <summary>
        /// Gets or sets SelectedForPublishing
        /// </summary>
        [Display(Name = "SelectedForPublishing", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.SelectedForPublishing, Id = Index.SelectedForPublishing, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.SelectedForPublishing SelectedForPublishing { get; set; }

        /// <summary>
        /// Gets or sets PublishSetting
        /// </summary>
        [Display(Name = "PublishSetting", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.PublishSetting, Id = Index.PublishSetting, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.PublishSetting PublishSetting { get; set; }

        /// <summary>
        /// Gets or sets PayslipUploadStatus
        /// </summary>
        [Display(Name = "PayslipUploadStatus", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.PayslipUploadStatus, Id = Index.PayslipUploadStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.PayslipUploadStatus PayslipUploadStatus { get; set; }

        /// <summary>
        /// Gets or sets SageHRPayslipID
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SageHRPayslipID", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.SageHRPayslipID, Id = Index.SageHRPayslipID, FieldType = EntityFieldType.Char, Size = 36)]
        public string SageHRPayslipID { get; set; }

        /// <summary>
        /// Gets or sets CheckPDFUploadStatus
        /// </summary>
        [Display(Name = "CheckPDFUploadStatus", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.CheckPDFUploadStatus, Id = Index.CheckPDFUploadStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.CheckPDFUploadStatus CheckPDFUploadStatus { get; set; }

        /// <summary>
        /// Gets or sets CheckPDFFilePath
        /// </summary>
        [StringLength(255, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckPDFFilePath", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.CheckPDFFilePath, Id = Index.CheckPDFFilePath, FieldType = EntityFieldType.Char, Size = 255)]
        public string CheckPDFFilePath { get; set; }

        /// <summary>
        /// Gets or sets PeriodStartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodStartDate", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.PeriodStartDate, Id = Index.PeriodStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodStartDate { get; set; }

        /// <summary>
        /// Gets or sets PeriodEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEndDate", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.PeriodEndDate, Id = Index.PeriodEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEndDate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeLastName
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeLastName", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeLastName, Id = Index.EmployeeLastName, FieldType = EntityFieldType.Char, Size = 20)]
        public string EmployeeLastName { get; set; }

        /// <summary>
        /// Gets or sets EmployeeFirstName
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeFirstName", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeFirstName, Id = Index.EmployeeFirstName, FieldType = EntityFieldType.Char, Size = 20)]
        public string EmployeeFirstName { get; set; }

        /// <summary>
        /// Gets or sets EmployeeMiddleName
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeMiddleName", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeMiddleName, Id = Index.EmployeeMiddleName, FieldType = EntityFieldType.Char, Size = 20)]
        public string EmployeeMiddleName { get; set; }

        /// <summary>
        /// Gets or sets TotalHours
        /// </summary>
        [Display(Name = "TotalHours", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalHours, Id = Index.TotalHours, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalHours { get; set; }

        /// <summary>
        /// Gets or sets TotalDeductions
        /// </summary>
        [Display(Name = "TotalDeductions", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalDeductions, Id = Index.TotalDeductions, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeductions { get; set; }

        /// <summary>
        /// Gets or sets TotalDeductionsYTD
        /// </summary>
        [Display(Name = "TotalDeductionsYTD", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalDeductionsYTD, Id = Index.TotalDeductionsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeductionsYTD { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxes
        /// </summary>
        [Display(Name = "TotalTaxes", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalTaxes, Id = Index.TotalTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxes { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxesYTD
        /// </summary>
        [Display(Name = "TotalTaxesYTD", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalTaxesYTD, Id = Index.TotalTaxesYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxesYTD { get; set; }

        /// <summary>
        /// Gets or sets TotalCashBenefits
        /// </summary>
        [Display(Name = "TotalCashBenefits", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalCashBenefits, Id = Index.TotalCashBenefits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCashBenefits { get; set; }

        /// <summary>
        /// Gets or sets TotalCashBenefitsYTD
        /// </summary>
        [Display(Name = "TotalCashBenefitsYTD", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalCashBenefitsYTD, Id = Index.TotalCashBenefitsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCashBenefitsYTD { get; set; }

        /// <summary>
        /// Gets or sets TotalNonCashBenefits
        /// </summary>
        [Display(Name = "TotalNonCashBenefits", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalNonCashBenefits, Id = Index.TotalNonCashBenefits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalNonCashBenefits { get; set; }

        /// <summary>
        /// Gets or sets TotalNonCashBenefitsYTD
        /// </summary>
        [Display(Name = "TotalNonCashBenefitsYTD", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalNonCashBenefitsYTD, Id = Index.TotalNonCashBenefitsYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalNonCashBenefitsYTD { get; set; }

        /// <summary>
        /// Gets or sets TotalGross
        /// </summary>
        [Display(Name = "TotalGross", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalGross, Id = Index.TotalGross, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalGross { get; set; }

        /// <summary>
        /// Gets or sets TotalGrossYTD
        /// </summary>
        [Display(Name = "TotalGrossYTD", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.TotalGrossYTD, Id = Index.TotalGrossYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalGrossYTD { get; set; }

        /// <summary>
        /// Gets or sets NetPay
        /// </summary>
        [Display(Name = "NetPay", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.NetPay, Id = Index.NetPay, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPay { get; set; }

        /// <summary>
        /// Gets or sets NetPayYTD
        /// </summary>
        [Display(Name = "NetPayYTD", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.NetPayYTD, Id = Index.NetPayYTD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetPayYTD { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SSNSIN
        /// </summary>
        [StringLength(11, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SSNSIN", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.SSNSIN, Id = Index.SSNSIN, FieldType = EntityFieldType.Char, Size = 11)]
        public string SSNSIN { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeAddress1", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeAddress1, Id = Index.EmployeeAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmployeeAddress1 { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeAddress2", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeAddress2, Id = Index.EmployeeAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmployeeAddress2 { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeAddress3", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeAddress3, Id = Index.EmployeeAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmployeeAddress3 { get; set; }

        /// <summary>
        /// Gets or sets EmployeeAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeAddress4", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeAddress4, Id = Index.EmployeeAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmployeeAddress4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "State", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Char, Size = 30)]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets EmployeeFullName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeFullName", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.EmployeeFullName, Id = Index.EmployeeFullName, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmployeeFullName { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber
        /// </summary>
        [Display(Name = "CheckNumber", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets ProcessDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessDate", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.ProcessDate, Id = Index.ProcessDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ProcessDate { get; set; }

        /// <summary>
        /// Gets or sets PaymentCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCurrency", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.PaymentCurrency, Id = Index.PaymentCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string PaymentCurrency { get; set; }

        /// <summary>
        /// Gets or sets PayFrequency
        /// </summary>
        [Display(Name = "PayFrequency", ResourceType = typeof (PayslipResx))]
        [ViewField(Name = Fields.PayFrequency, Id = Index.PayFrequency, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.PayFrequency PayFrequency { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets SelectedForPublishing string value
        /// </summary>
        public string SelectedForPublishingString => EnumUtility.GetStringValue(SelectedForPublishing);

        /// <summary>
        /// Gets PublishSetting string value
        /// </summary>
        public string PublishSettingString => EnumUtility.GetStringValue(PublishSetting);

        /// <summary>
        /// Gets PayslipUploadStatus string value
        /// </summary>
        public string PayslipUploadStatusString => EnumUtility.GetStringValue(PayslipUploadStatus);

        /// <summary>
        /// Gets CheckPDFUploadStatus string value
        /// </summary>
        public string CheckPDFUploadStatusString => EnumUtility.GetStringValue(CheckPDFUploadStatus);

        /// <summary>
        /// Gets PayFrequency string value
        /// </summary>
        public string PayFrequencyString => EnumUtility.GetStringValue(PayFrequency);

        #endregion
    }
}
