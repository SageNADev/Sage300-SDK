﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This class is used for cutom class for grid in tax Group
    /// </summary>
    public class TaxAuthorityGroup : ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets the tax authority.
        /// </summary>
        /// <value>
        /// The tax authority.
        /// </value>
        [Display(Name = "AUTHORITY", ResourceType = typeof(TaxGroupsResx))]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets the tax authority description.
        /// </summary>
        /// <value>
        /// The tax authority description.
        /// </value>
        [Display(Name = "DESCRIPTION", ResourceType = typeof(TaxGroupsResx))]
        public string TaxAuthorityDescription { get; set; }


        /// <summary>
        /// Gets or sets the taxable.
        /// </summary>
        /// <value>
        /// The taxable.
        /// </value>
        [Display(Name = "TaxCalculationMethod", ResourceType = typeof(TaxGroupsResx))]
        public TaxableEnum Taxable { get; set; }


        /// <summary>
        /// Gets or sets the surtax.
        /// </summary>
        /// <value>
        /// The surtax.
        /// </value>
        [Display(Name = "SURTAX", ResourceType = typeof(TaxGroupsResx))]
        public TaxableEnum Surtax { get; set; }

        /// <summary>
        /// Gets or sets the surtax on authority.
        /// </summary>
        /// <value>
        /// The surtax on authority.
        /// </value>
        [Display(Name = "SURAUTH", ResourceType = typeof(TaxGroupsResx))]
        public string SurtaxOnAuthority { get; set; }


        /// <summary>
        /// Gets or sets the surtax on authority description.
        /// </summary>
        /// <value>
        /// The surtax on authority description.
        /// </value>
        [Display(Name = "SURDESC", ResourceType = typeof(TaxGroupsResx))]
        public string SurtaxOnAuthorityDescription { get; set; }

        #endregion

        #region Enum Properties

        /// <summary>
        /// Gets the taxable1 string.
        /// </summary>
        /// <value>
        /// The taxable1 string.
        /// </value>
        public string TaxableString{ get; set; }

      
        /// <summary>
        /// Gets the surtax1 string.
        /// </summary>
        /// <value>
        /// The surtax1 string.
        /// </value>
        public string SurtaxString{ get; set; }
        #endregion
    }
}
