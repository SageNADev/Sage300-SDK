﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of TaxTracking Constants 
    /// </summary>
	public partial class TaxTracking 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "TX0011";

        /// <summary>
        /// Contains list of TaxTracking Fields Constants
        /// </summary>
	    public class Fields
        {
            #region Properties
	     
        /// <summary>
        /// Property for Sequence 
        /// </summary>
	    public const string Sequence = "SEQUENCE";

	    /// <summary>
        /// Property for TaxAuthority 
        /// </summary>
	    public const string TaxAuthority  = "AUTHORITY";

	    /// <summary>
        /// Property for TransactionType 
        /// </summary>
	    public const string TransactionType  = "TYPE";

	    /// <summary>
        /// Property for FiscalYear 
        /// </summary>
	    public const string FiscalYear  = "FISCYEAR";

	    /// <summary>
        /// Property for FiscalPeriod 
        /// </summary>
	    public const string FiscalPeriod  = "FISCPERIOD";

	    /// <summary>
        /// Property for CustomerOrVendorID 
        /// </summary>
	    public const string CustomerOrVendorID  = "CUSTVEND";

	    /// <summary>
        /// Property for DocumentDate 
        /// </summary>
	    public const string DocumentDate  = "DOCDATE";

	    /// <summary>
        /// Property for SourceApplication 
        /// </summary>
	    public const string SourceApplication  = "SRCEAPP";

	    /// <summary>
        /// Property for DocumentType 
        /// </summary>
	    public const string DocumentType  = "DOCTYPE";

	    /// <summary>
        /// Property for DocumentNo 
        /// </summary>
	    public const string DocumentNo  = "DOCNUMBER";

	    /// <summary>
        /// Property for PostingDate 
        /// </summary>
	    public const string PostingDate  = "POSTDATE";

	    /// <summary>
        /// Property for CustOrVendTaxClass 
        /// </summary>
	    public const string CustOrVendTaxClass  = "BUYERCLASS";

	    /// <summary>
        /// Property for CountryCode 
        /// </summary>
	    public const string CountryCode  = "COUNTRY";

	    /// <summary>
        /// Property for ReportDate 
        /// </summary>
	    public const string ReportDate  = "REPORTDATE";

	    /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "DESCRIPTIO";

	    /// <summary>
        /// Property for ForeignInvoice 
        /// </summary>
	    public const string ForeignInvoice  = "ISFOREIGN";

	    /// <summary>
        /// Property for HomeCurrencyCode 
        /// </summary>
	    public const string HomeCurrencyCode  = "HCURN";

	    /// <summary>
        /// Property for RateType 
        /// </summary>
	    public const string RateType  = "RATETYPE";

	    /// <summary>
        /// Property for SourceCurrencyCode 
        /// </summary>
	    public const string SourceCurrencyCode  = "SCURN";

	    /// <summary>
        /// Property for RateDate 
        /// </summary>
	    public const string RateDate  = "RATEDATE";

	    /// <summary>
        /// Property for Rate 
        /// </summary>
	    public const string Rate  = "RATE";

	    /// <summary>
        /// Property for CustomerOrVendorName 
        /// </summary>
	    public const string CustomerOrVendorName  = "CUSTVENDNM";

	    /// <summary>
        /// Property for DecimalsinSourceCurrency 
        /// </summary>
	    public const string DecimalsinSourceCurrency  = "SDECIMAL";

	    /// <summary>
        /// Property for InvoiceAmtinSourceCurrency 
        /// </summary>
	    public const string InvoiceAmtinSourceCurrency  = "SINVAMT";

	    /// <summary>
        /// Property for InvoiceAmtinFuncCurrency 
        /// </summary>
	    public const string InvoiceAmtinFuncCurrency  = "HINVAMT";

	    /// <summary>
        /// Property for Recoverable 
        /// </summary>
	    public const string Recoverable  = "RECOVERABL";

	    /// <summary>
        /// Property for ExpenseSeparately 
        /// </summary>
	    public const string ExpenseSeparately  = "EXPSEPARTE";

	    /// <summary>
        /// Property for RecoverableRate 
        /// </summary>
	    public const string RecoverableRate  = "RATERECOV";

	    /// <summary>
        /// Property for RecovAmtinSourceCurrency 
        /// </summary>
	    public const string RecovAmtinSourceCurrency  = "SRECOVRAMT";

	    /// <summary>
        /// Property for RecovAmtinFuncCurrency 
        /// </summary>
	    public const string RecovAmtinFuncCurrency  = "HRECOVRAMT";

	    /// <summary>
        /// Property for TaxReportingCurrencyCode 
        /// </summary>
	    public const string TaxReportingCurrencyCode  = "TCURN";

	    /// <summary>
        /// Property for DecimalsinTaxReportingCurren 
        /// </summary>
	    public const string DecimalsinTaxReportingCurren  = "TDECIMAL";

	    /// <summary>
        /// Property for TaxReportingRateType 
        /// </summary>
	    public const string TaxReportingRateType  = "TRATETYPE";

	    /// <summary>
        /// Property for TaxReportingRateDate 
        /// </summary>
	    public const string TaxReportingRateDate  = "TRATEDATE";

	    /// <summary>
        /// Property for TaxReportingRate 
        /// </summary>
	    public const string TaxReportingRate  = "TRATE";

	    /// <summary>
        /// Property for RateOperation 
        /// </summary>
	    public const string RateOperation  = "RATEOP";

	    /// <summary>
        /// Property for TaxReportingRateOperation 
        /// </summary>
	    public const string TaxReportingRateOperation  = "TRATEOP";

	    /// <summary>
        /// Property for RecovAmtinTaxReportingCurr 
        /// </summary>
	    public const string RecovAmtinTaxReportingCurr  = "TRECOVRAMT";

        /// <summary>
        /// Property for FromFiscalYear 
        /// </summary>
        public const string FromFiscalYear = "FROMYEAR";

        /// <summary>
        /// Property for FromFiscalPeriod 
        /// </summary>
        public const string FromFiscalPeriod = "FROMPRD";

        /// <summary>
        /// Property for ToFiscalYear 
        /// </summary>
        public const string ToFiscalYear = "TOYEAR";

        /// <summary>
        /// Property for ToFiscalPeriod 
        /// </summary>
        public const string ToFiscalPeriod = "TOPRD";

        #endregion
	    }


		/// <summary>
        /// Contains list of TaxTracking Index Constants
        /// </summary>
	    public class Index
        {
            #region Properties
        
        /// <summary>
        /// Property Indexer for Sequence 
        /// </summary>
	    public const int  Sequence = 1;

	    /// <summary>
        /// Property Indexer for TaxAuthority 
        /// </summary>
	    public const int TaxAuthority  = 2;

	    /// <summary>
        /// Property Indexer for TransactionType 
        /// </summary>
	    public const int TransactionType  = 3;

	    /// <summary>
        /// Property Indexer for FiscalYear 
        /// </summary>
	    public const int FiscalYear  = 4;

	    /// <summary>
        /// Property Indexer for FiscalPeriod 
        /// </summary>
	    public const int FiscalPeriod  = 5;

	    /// <summary>
        /// Property Indexer for CustomerOrVendorID 
        /// </summary>
	    public const int CustomerOrVendorID  = 6;

	    /// <summary>
        /// Property Indexer for DocumentDate 
        /// </summary>
	    public const int DocumentDate  = 7;

	    /// <summary>
        /// Property Indexer for SourceApplication 
        /// </summary>
	    public const int SourceApplication  = 8;

	    /// <summary>
        /// Property Indexer for DocumentType 
        /// </summary>
	    public const int DocumentType  = 9;

	    /// <summary>
        /// Property Indexer for DocumentNo 
        /// </summary>
	    public const int DocumentNo  = 10;

	    /// <summary>
        /// Property Indexer for PostingDate 
        /// </summary>
	    public const int PostingDate  = 11;

	    /// <summary>
        /// Property Indexer for CustOrVendTaxClass 
        /// </summary>
	    public const int CustOrVendTaxClass  = 12;

	    /// <summary>
        /// Property Indexer for CountryCode 
        /// </summary>
	    public const int CountryCode  = 13;

	    /// <summary>
        /// Property Indexer for ReportDate 
        /// </summary>
	    public const int ReportDate  = 14;

	    /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 15;

	    /// <summary>
        /// Property Indexer for ForeignInvoice 
        /// </summary>
	    public const int ForeignInvoice  = 16;

	    /// <summary>
        /// Property Indexer for HomeCurrencyCode 
        /// </summary>
	    public const int HomeCurrencyCode  = 17;

	    /// <summary>
        /// Property Indexer for RateType 
        /// </summary>
	    public const int RateType  = 18;

	    /// <summary>
        /// Property Indexer for SourceCurrencyCode 
        /// </summary>
	    public const int SourceCurrencyCode  = 19;

	    /// <summary>
        /// Property Indexer for RateDate 
        /// </summary>
	    public const int RateDate  = 20;

	    /// <summary>
        /// Property Indexer for Rate 
        /// </summary>
	    public const int Rate  = 21;

	    /// <summary>
        /// Property Indexer for CustomerOrVendorName 
        /// </summary>
	    public const int CustomerOrVendorName  = 22;

	    /// <summary>
        /// Property Indexer for DecimalsinSourceCurrency 
        /// </summary>
	    public const int DecimalsinSourceCurrency  = 23;

	    /// <summary>
        /// Property Indexer for InvoiceAmtinSourceCurrency 
        /// </summary>
	    public const int InvoiceAmtinSourceCurrency  = 24;

	    /// <summary>
        /// Property Indexer for InvoiceAmtinFuncCurrency 
        /// </summary>
	    public const int InvoiceAmtinFuncCurrency  = 25;

	    /// <summary>
        /// Property Indexer for Recoverable 
        /// </summary>
	    public const int Recoverable  = 26;

	    /// <summary>
        /// Property Indexer for ExpenseSeparately 
        /// </summary>
	    public const int ExpenseSeparately  = 27;

	    /// <summary>
        /// Property Indexer for RecoverableRate 
        /// </summary>
	    public const int RecoverableRate  = 28;

	    /// <summary>
        /// Property Indexer for RecovAmtinSourceCurrency 
        /// </summary>
	    public const int RecovAmtinSourceCurrency  = 29;

	    /// <summary>
        /// Property Indexer for RecovAmtinFuncCurrency 
        /// </summary>
	    public const int RecovAmtinFuncCurrency  = 30;

	    /// <summary>
        /// Property Indexer for TaxReportingCurrencyCode 
        /// </summary>
	    public const int TaxReportingCurrencyCode  = 31;

	    /// <summary>
        /// Property Indexer for DecimalsinTaxReportingCurren 
        /// </summary>
	    public const int DecimalsinTaxReportingCurren  = 32;

	    /// <summary>
        /// Property Indexer for TaxReportingRateType 
        /// </summary>
	    public const int TaxReportingRateType  = 33;

	    /// <summary>
        /// Property Indexer for TaxReportingRateDate 
        /// </summary>
	    public const int TaxReportingRateDate  = 34;

	    /// <summary>
        /// Property Indexer for TaxReportingRate 
        /// </summary>
	    public const int TaxReportingRate  = 35;

	    /// <summary>
        /// Property Indexer for RateOperation 
        /// </summary>
	    public const int RateOperation  = 36;

	    /// <summary>
        /// Property Indexer for TaxReportingRateOperation 
        /// </summary>
	    public const int TaxReportingRateOperation  = 37;

	    /// <summary>
        /// Property Indexer for RecovAmtinTaxReportingCurr 
        /// </summary>
	    public const int RecovAmtinTaxReportingCurr  = 38;

        /// <summary>
        /// Property Indexer for FromFiscalYear 
        /// </summary>
        public const int FromFiscalYear = 39;

        /// <summary>
        /// Property Indexer for FromFiscalPeriod 
        /// </summary>
        public const int FromFiscalPeriod = 40;

        /// <summary>
        /// Property Indexer for ToFiscalYear 
        /// </summary>
        public const int ToFiscalYear = 41;

        /// <summary>
        /// Property Indexer for ToFiscalPeriod 
        /// </summary>
        public const int ToFiscalPeriod = 42;

        #endregion
	    }

	
	}
}

