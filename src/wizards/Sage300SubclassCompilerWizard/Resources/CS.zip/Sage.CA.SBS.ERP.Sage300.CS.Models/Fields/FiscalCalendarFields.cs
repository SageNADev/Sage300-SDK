﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using System.CodeDom;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

// ReSharper disable CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Fiscal Calendar Constants
    /// </summary>
    public partial class FiscalCalendar
    {
        #region Public Field

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "CS0002";

        #endregion

        #region Fields

        /// <summary>
        /// Fiscal Calendar Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";

            /// <summary>
            /// Property for Number of Fiscal Periods 
            /// </summary>
            public const string NumberofFiscalPeriods = "PERIODS";

            /// <summary>
            /// Property for Quarter with 4 Periods 
            /// </summary>
            public const string Quarterwith4Periods = "QTR4PERD";

            /// <summary>
            /// Property for Active 
            /// </summary>
            public const string Active = "ACTIVE";

            /// <summary>
            /// Property for Active 
            /// </summary>
            [IsMvcSpecific]
            public const string ActiveText = "ACTIVE";

            /// <summary>
            /// Property for Fiscal Period1 StartDate 
            /// </summary>
            public const string FiscalPeriod1StartDate = "BGNDATE1";

            /// <summary>
            /// Property for Fiscal Period2 StartDate 
            /// </summary>
            public const string FiscalPeriod2StartDate = "BGNDATE2";

            /// <summary>
            /// Property for Fiscal Period3 StartDate 
            /// </summary>
            public const string FiscalPeriod3StartDate = "BGNDATE3";

            /// <summary>
            /// Property for Fiscal Period4 StartDate 
            /// </summary>
            public const string FiscalPeriod4StartDate = "BGNDATE4";

            /// <summary>
            /// Property for Fiscal Period5 StartDate 
            /// </summary>
            public const string FiscalPeriod5StartDate = "BGNDATE5";

            /// <summary>
            /// Property for Fiscal Period6 StartDate 
            /// </summary>
            public const string FiscalPeriod6StartDate = "BGNDATE6";

            /// <summary>
            /// Property for Fiscal Period7 StartDate 
            /// </summary>
            public const string FiscalPeriod7StartDate = "BGNDATE7";

            /// <summary>
            /// Property for Fiscal Period8 StartDate 
            /// </summary>
            public const string FiscalPeriod8StartDate = "BGNDATE8";

            /// <summary>
            /// Property for Fiscal Period9 StartDate 
            /// </summary>
            public const string FiscalPeriod9StartDate = "BGNDATE9";

            /// <summary>
            /// Property for Fiscal Period10 StartDate 
            /// </summary>
            public const string FiscalPeriod10StartDate = "BGNDATE10";

            /// <summary>
            /// Property for Fiscal Period11 StartDate 
            /// </summary>
            public const string FiscalPeriod11StartDate = "BGNDATE11";

            /// <summary>
            /// Property for Fiscal Period12 StartDate 
            /// </summary>
            public const string FiscalPeriod12StartDate = "BGNDATE12";

            /// <summary>
            /// Property for Fiscal Period13 StartDate 
            /// </summary>
            public const string FiscalPeriod13StartDate = "BGNDATE13";

            /// <summary>
            /// Property for Fiscal Period1 EndDate 
            /// </summary>
            public const string FiscalPeriod1EndDate = "ENDDATE1";

            /// <summary>
            /// Property for Fiscal Period2 EndDate 
            /// </summary>
            public const string FiscalPeriod2EndDate = "ENDDATE2";

            /// <summary>
            /// Property for Fiscal Period3 EndDate 
            /// </summary>
            public const string FiscalPeriod3EndDate = "ENDDATE3";

            /// <summary>
            /// Property for Fiscal Period4 EndDate 
            /// </summary>
            public const string FiscalPeriod4EndDate = "ENDDATE4";

            /// <summary>
            /// Property for Fiscal Period5 EndDate 
            /// </summary>
            public const string FiscalPeriod5EndDate = "ENDDATE5";

            /// <summary>
            /// Property for Fiscal Period6 EndDate 
            /// </summary>
            public const string FiscalPeriod6EndDate = "ENDDATE6";

            /// <summary>
            /// Property for Fiscal Period7 EndDate 
            /// </summary>
            public const string FiscalPeriod7EndDate = "ENDDATE7";

            /// <summary>
            /// Property for Fiscal Period8 EndDate 
            /// </summary>
            public const string FiscalPeriod8EndDate = "ENDDATE8";

            /// <summary>
            /// Property for Fiscal Period9 EndDate 
            /// </summary>
            public const string FiscalPeriod9EndDate = "ENDDATE9";

            /// <summary>
            /// Property for Fiscal Period10 EndDate 
            /// </summary>
            public const string FiscalPeriod10EndDate = "ENDDATE10";

            /// <summary>
            /// Property for Fiscal Period11 EndDate 
            /// </summary>
            public const string FiscalPeriod11EndDate = "ENDDATE11";

            /// <summary>
            /// Property for Fiscal Period12 EndDate 
            /// </summary>
            public const string FiscalPeriod12EndDate = "ENDDATE12";

            /// <summary>
            /// Property for Fiscal Period13 EndDate 
            /// </summary>
            public const string FiscalPeriod13EndDate = "ENDDATE13";

            /// <summary>
            /// Property for Adjustment Period Status 
            /// </summary>
            public const string AdjustmentPeriodStatus = "STATUSADJ";

            /// <summary>
            /// Property for Adjustment Period Status 
            /// </summary>
            [IsMvcSpecific]
            public const string AdjustmentPeriodStatusText = "STATUSADJ";

            /// <summary>
            /// Property for Closing Period Status 
            /// </summary>
            public const string ClosingPeriodStatus = "STATUSCLS";

            /// <summary>
            /// Property for Closing Period Status 
            /// </summary>
            [IsMvcSpecific]
            public const string ClosingPeriodStatusText = "STATUSCLS";

            /// <summary>
            /// Property for Command 
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for Command 
            /// </summary>
            [IsMvcSpecific]
            public const string CommandText = "PROCESSCMD";

            /// <summary>
            /// Property for Application 
            /// </summary>
            public const string Application = "GOTPGM";

            /// <summary>
            /// Property for Open 
            /// </summary>
            public const string Open = "PGMDESC";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Fiscal Calendar Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 1;

            /// <summary>
            /// Property Indexer for Number of Fiscal Periods 
            /// </summary>
            public const int NumberofFiscalPeriods = 2;

            /// <summary>
            /// Property Indexer for Quarter with4 Periods 
            /// </summary>
            public const int Quarterwith4Periods = 3;

            /// <summary>
            /// Property Indexer for Active 
            /// </summary>
            public const int Active = 4;

            /// <summary>
            /// Property Indexer for Active 
            /// </summary>
            public const int ActiveText = 4;

            /// <summary>
            /// Property Indexer for Fiscal Period1 StartDate 
            /// </summary>
            public const int FiscalPeriod1StartDate = 5;

            /// <summary>
            /// Property Indexer for Fiscal Period2 StartDate 
            /// </summary>
            public const int FiscalPeriod2StartDate = 6;

            /// <summary>
            /// Property Indexer for Fiscal Period3 StartDate 
            /// </summary>
            public const int FiscalPeriod3StartDate = 7;

            /// <summary>
            /// Property Indexer for Fiscal Period4 StartDate 
            /// </summary>
            public const int FiscalPeriod4StartDate = 8;

            /// <summary>
            /// Property Indexer for Fiscal Period5 StartDate 
            /// </summary>
            public const int FiscalPeriod5StartDate = 9;

            /// <summary>
            /// Property Indexer for Fiscal Period6 StartDate 
            /// </summary>
            public const int FiscalPeriod6StartDate = 10;

            /// <summary>
            /// Property Indexer for Fiscal Period7 StartDate 
            /// </summary>
            public const int FiscalPeriod7StartDate = 11;

            /// <summary>
            /// Property Indexer for Fiscal Period8 StartDate 
            /// </summary>
            public const int FiscalPeriod8StartDate = 12;

            /// <summary>
            /// Property Indexer for Fiscal Period9 StartDate 
            /// </summary>
            public const int FiscalPeriod9StartDate = 13;

            /// <summary>
            /// Property Indexer for Fiscal Period10 StartDate 
            /// </summary>
            public const int FiscalPeriod10StartDate = 14;

            /// <summary>
            /// Property Indexer for Fiscal Period11 StartDate 
            /// </summary>
            public const int FiscalPeriod11StartDate = 15;

            /// <summary>
            /// Property Indexer for Fiscal Period12 StartDate 
            /// </summary>
            public const int FiscalPeriod12StartDate = 16;

            /// <summary>
            /// Property Indexer for Fiscal Period13 StartDate 
            /// </summary>
            public const int FiscalPeriod13StartDate = 17;

            /// <summary>
            /// Property Indexer for Fiscal Period1 EndDate 
            /// </summary>
            public const int FiscalPeriod1EndDate = 18;

            /// <summary>
            /// Property Indexer for Fiscal Period2 EndDate 
            /// </summary>
            public const int FiscalPeriod2EndDate = 19;

            /// <summary>
            /// Property Indexer for Fiscal Period3 EndDate 
            /// </summary>
            public const int FiscalPeriod3EndDate = 20;

            /// <summary>
            /// Property Indexer for Fiscal Period4 EndDate 
            /// </summary>
            public const int FiscalPeriod4EndDate = 21;

            /// <summary>
            /// Property Indexer for Fiscal Period5 EndDate 
            /// </summary>
            public const int FiscalPeriod5EndDate = 22;

            /// <summary>
            /// Property Indexer for Fiscal Period6 EndDate 
            /// </summary>
            public const int FiscalPeriod6EndDate = 23;

            /// <summary>
            /// Property Indexer for Fiscal Period7 EndDate 
            /// </summary>
            public const int FiscalPeriod7EndDate = 24;

            /// <summary>
            /// Property Indexer for Fiscal Period8 EndDate 
            /// </summary>
            public const int FiscalPeriod8EndDate = 25;

            /// <summary>
            /// Property Indexer for Fiscal Period9 EndDate 
            /// </summary>
            public const int FiscalPeriod9EndDate = 26;

            /// <summary>
            /// Property Indexer for Fiscal Period10 EndDate 
            /// </summary>
            public const int FiscalPeriod10EndDate = 27;

            /// <summary>
            /// Property Indexer for Fiscal Period11 EndDate 
            /// </summary>
            public const int FiscalPeriod11EndDate = 28;

            /// <summary>
            /// Property Indexer for Fiscal Period12 EndDate 
            /// </summary>
            public const int FiscalPeriod12EndDate = 29;

            /// <summary>
            /// Property Indexer for Fiscal Period13 EndDate 
            /// </summary>
            public const int FiscalPeriod13EndDate = 30;

            /// <summary>
            /// Property Indexer for Adjustment Period Status 
            /// </summary>
            public const int AdjustmentPeriodStatus = 31;

            /// <summary>
            /// Property Indexer for Adjustment Period Status 
            /// </summary>
            public const int AdjustmentPeriodStatusText = 31;

            /// <summary>
            /// Property Indexer for Closing Period Status 
            /// </summary>
            public const int ClosingPeriodStatus = 32;

            /// <summary>
            /// Property Indexer for Closing Period Status 
            /// </summary>
            public const int ClosingPeriodStatusText = 32;

            /// <summary>
            /// Property Indexer for Command 
            /// </summary>
            public const int Command = 60;

            /// <summary>
            /// Property Indexer for Command 
            /// </summary>
            public const int CommandText = 60;

            /// <summary>
            /// Property Indexer for Application 
            /// </summary>
            public const int Application = 61;

            /// <summary>
            /// Property Indexer for Open 
            /// </summary>
            public const int Open = 62;

            #endregion
        }

        #endregion
    }
}