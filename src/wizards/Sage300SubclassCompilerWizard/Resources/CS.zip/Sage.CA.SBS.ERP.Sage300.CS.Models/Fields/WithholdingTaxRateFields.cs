/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of WithholdingTaxRate Constants
    /// </summary>
    public partial class WithholdingTaxRate
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "TX0016";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes => new Dictionary<string, string>();

        #region Fields

        /// <summary>
        /// Contains list of WithholdingTaxRate Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for TaxAuthority
            /// </summary>
            public const string TaxAuthority = "AUTHORITY";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TTYPE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            /// <summary>
            /// Property for WithholdingTaxBase
            /// </summary>
            public const string WithholdingTaxBase = "WHBASETYPE";

            /// <summary>
            /// Property for Num1099CPRSCode
            /// </summary>
            public const string Num1099CPRSCode = "ID1099CLAS";

            /// <summary>
            /// Property for BuyerClass1ItemClass1Rate
            /// </summary>
            public const string BuyerClass1ItemClass1Rate = "WHRATE0101";

            /// <summary>
            /// Property for BuyerClass1ItemClass2Rate
            /// </summary>
            public const string BuyerClass1ItemClass2Rate = "WHRATE0102";

            /// <summary>
            /// Property for BuyerClass1ItemClass3Rate
            /// </summary>
            public const string BuyerClass1ItemClass3Rate = "WHRATE0103";

            /// <summary>
            /// Property for BuyerClass1ItemClass4Rate
            /// </summary>
            public const string BuyerClass1ItemClass4Rate = "WHRATE0104";

            /// <summary>
            /// Property for BuyerClass1ItemClass5Rate
            /// </summary>
            public const string BuyerClass1ItemClass5Rate = "WHRATE0105";

            /// <summary>
            /// Property for BuyerClass1ItemClass6Rate
            /// </summary>
            public const string BuyerClass1ItemClass6Rate = "WHRATE0106";

            /// <summary>
            /// Property for BuyerClass1ItemClass7Rate
            /// </summary>
            public const string BuyerClass1ItemClass7Rate = "WHRATE0107";

            /// <summary>
            /// Property for BuyerClass1ItemClass8Rate
            /// </summary>
            public const string BuyerClass1ItemClass8Rate = "WHRATE0108";

            /// <summary>
            /// Property for BuyerClass1ItemClass9Rate
            /// </summary>
            public const string BuyerClass1ItemClass9Rate = "WHRATE0109";

            /// <summary>
            /// Property for BuyerClass1ItemClass10Rate
            /// </summary>
            public const string BuyerClass1ItemClass10Rate = "WHRATE0110";

            /// <summary>
            /// Property for BuyerClass2ItemClass1Rate
            /// </summary>
            public const string BuyerClass2ItemClass1Rate = "WHRATE0201";

            /// <summary>
            /// Property for BuyerClass2ItemClass2Rate
            /// </summary>
            public const string BuyerClass2ItemClass2Rate = "WHRATE0202";

            /// <summary>
            /// Property for BuyerClass2ItemClass3Rate
            /// </summary>
            public const string BuyerClass2ItemClass3Rate = "WHRATE0203";

            /// <summary>
            /// Property for BuyerClass2ItemClass4Rate
            /// </summary>
            public const string BuyerClass2ItemClass4Rate = "WHRATE0204";

            /// <summary>
            /// Property for BuyerClass2ItemClass5Rate
            /// </summary>
            public const string BuyerClass2ItemClass5Rate = "WHRATE0205";

            /// <summary>
            /// Property for BuyerClass2ItemClass6Rate
            /// </summary>
            public const string BuyerClass2ItemClass6Rate = "WHRATE0206";

            /// <summary>
            /// Property for BuyerClass2ItemClass7Rate
            /// </summary>
            public const string BuyerClass2ItemClass7Rate = "WHRATE0207";

            /// <summary>
            /// Property for BuyerClass2ItemClass8Rate
            /// </summary>
            public const string BuyerClass2ItemClass8Rate = "WHRATE0208";

            /// <summary>
            /// Property for BuyerClass2ItemClass9Rate
            /// </summary>
            public const string BuyerClass2ItemClass9Rate = "WHRATE0209";

            /// <summary>
            /// Property for BuyerClass2ItemClass10Rate
            /// </summary>
            public const string BuyerClass2ItemClass10Rate = "WHRATE0210";

            /// <summary>
            /// Property for BuyerClass3ItemClass1Rate
            /// </summary>
            public const string BuyerClass3ItemClass1Rate = "WHRATE0301";

            /// <summary>
            /// Property for BuyerClass3ItemClass2Rate
            /// </summary>
            public const string BuyerClass3ItemClass2Rate = "WHRATE0302";

            /// <summary>
            /// Property for BuyerClass3ItemClass3Rate
            /// </summary>
            public const string BuyerClass3ItemClass3Rate = "WHRATE0303";

            /// <summary>
            /// Property for BuyerClass3ItemClass4Rate
            /// </summary>
            public const string BuyerClass3ItemClass4Rate = "WHRATE0304";

            /// <summary>
            /// Property for BuyerClass3ItemClass5Rate
            /// </summary>
            public const string BuyerClass3ItemClass5Rate = "WHRATE0305";

            /// <summary>
            /// Property for BuyerClass3ItemClass6Rate
            /// </summary>
            public const string BuyerClass3ItemClass6Rate = "WHRATE0306";

            /// <summary>
            /// Property for BuyerClass3ItemClass7Rate
            /// </summary>
            public const string BuyerClass3ItemClass7Rate = "WHRATE0307";

            /// <summary>
            /// Property for BuyerClass3ItemClass8Rate
            /// </summary>
            public const string BuyerClass3ItemClass8Rate = "WHRATE0308";

            /// <summary>
            /// Property for BuyerClass3ItemClass9Rate
            /// </summary>
            public const string BuyerClass3ItemClass9Rate = "WHRATE0309";

            /// <summary>
            /// Property for BuyerClass3ItemClass10Rate
            /// </summary>
            public const string BuyerClass3ItemClass10Rate = "WHRATE0310";

            /// <summary>
            /// Property for BuyerClass4ItemClass1Rate
            /// </summary>
            public const string BuyerClass4ItemClass1Rate = "WHRATE0401";

            /// <summary>
            /// Property for BuyerClass4ItemClass2Rate
            /// </summary>
            public const string BuyerClass4ItemClass2Rate = "WHRATE0402";

            /// <summary>
            /// Property for BuyerClass4ItemClass3Rate
            /// </summary>
            public const string BuyerClass4ItemClass3Rate = "WHRATE0403";

            /// <summary>
            /// Property for BuyerClass4ItemClass4Rate
            /// </summary>
            public const string BuyerClass4ItemClass4Rate = "WHRATE0404";

            /// <summary>
            /// Property for BuyerClass4ItemClass5Rate
            /// </summary>
            public const string BuyerClass4ItemClass5Rate = "WHRATE0405";

            /// <summary>
            /// Property for BuyerClass4ItemClass6Rate
            /// </summary>
            public const string BuyerClass4ItemClass6Rate = "WHRATE0406";

            /// <summary>
            /// Property for BuyerClass4ItemClass7Rate
            /// </summary>
            public const string BuyerClass4ItemClass7Rate = "WHRATE0407";

            /// <summary>
            /// Property for BuyerClass4ItemClass8Rate
            /// </summary>
            public const string BuyerClass4ItemClass8Rate = "WHRATE0408";

            /// <summary>
            /// Property for BuyerClass4ItemClass9Rate
            /// </summary>
            public const string BuyerClass4ItemClass9Rate = "WHRATE0409";

            /// <summary>
            /// Property for BuyerClass4ItemClass10Rate
            /// </summary>
            public const string BuyerClass4ItemClass10Rate = "WHRATE0410";

            /// <summary>
            /// Property for BuyerClass5ItemClass1Rate
            /// </summary>
            public const string BuyerClass5ItemClass1Rate = "WHRATE0501";

            /// <summary>
            /// Property for BuyerClass5ItemClass2Rate
            /// </summary>
            public const string BuyerClass5ItemClass2Rate = "WHRATE0502";

            /// <summary>
            /// Property for BuyerClass5ItemClass3Rate
            /// </summary>
            public const string BuyerClass5ItemClass3Rate = "WHRATE0503";

            /// <summary>
            /// Property for BuyerClass5ItemClass4Rate
            /// </summary>
            public const string BuyerClass5ItemClass4Rate = "WHRATE0504";

            /// <summary>
            /// Property for BuyerClass5ItemClass5Rate
            /// </summary>
            public const string BuyerClass5ItemClass5Rate = "WHRATE0505";

            /// <summary>
            /// Property for BuyerClass5ItemClass6Rate
            /// </summary>
            public const string BuyerClass5ItemClass6Rate = "WHRATE0506";

            /// <summary>
            /// Property for BuyerClass5ItemClass7Rate
            /// </summary>
            public const string BuyerClass5ItemClass7Rate = "WHRATE0507";

            /// <summary>
            /// Property for BuyerClass5ItemClass8Rate
            /// </summary>
            public const string BuyerClass5ItemClass8Rate = "WHRATE0508";

            /// <summary>
            /// Property for BuyerClass5ItemClass9Rate
            /// </summary>
            public const string BuyerClass5ItemClass9Rate = "WHRATE0509";

            /// <summary>
            /// Property for BuyerClass5ItemClass10Rate
            /// </summary>
            public const string BuyerClass5ItemClass10Rate = "WHRATE0510";

            /// <summary>
            /// Property for BuyerClass6ItemClass1Rate
            /// </summary>
            public const string BuyerClass6ItemClass1Rate = "WHRATE0601";

            /// <summary>
            /// Property for BuyerClass6ItemClass2Rate
            /// </summary>
            public const string BuyerClass6ItemClass2Rate = "WHRATE0602";

            /// <summary>
            /// Property for BuyerClass6ItemClass3Rate
            /// </summary>
            public const string BuyerClass6ItemClass3Rate = "WHRATE0603";

            /// <summary>
            /// Property for BuyerClass6ItemClass4Rate
            /// </summary>
            public const string BuyerClass6ItemClass4Rate = "WHRATE0604";

            /// <summary>
            /// Property for BuyerClass6ItemClass5Rate
            /// </summary>
            public const string BuyerClass6ItemClass5Rate = "WHRATE0605";

            /// <summary>
            /// Property for BuyerClass6ItemClass6Rate
            /// </summary>
            public const string BuyerClass6ItemClass6Rate = "WHRATE0606";

            /// <summary>
            /// Property for BuyerClass6ItemClass7Rate
            /// </summary>
            public const string BuyerClass6ItemClass7Rate = "WHRATE0607";

            /// <summary>
            /// Property for BuyerClass6ItemClass8Rate
            /// </summary>
            public const string BuyerClass6ItemClass8Rate = "WHRATE0608";

            /// <summary>
            /// Property for BuyerClass6ItemClass9Rate
            /// </summary>
            public const string BuyerClass6ItemClass9Rate = "WHRATE0609";

            /// <summary>
            /// Property for BuyerClass6ItemClass10Rate
            /// </summary>
            public const string BuyerClass6ItemClass10Rate = "WHRATE0610";

            /// <summary>
            /// Property for BuyerClass7ItemClass1Rate
            /// </summary>
            public const string BuyerClass7ItemClass1Rate = "WHRATE0701";

            /// <summary>
            /// Property for BuyerClass7ItemClass2Rate
            /// </summary>
            public const string BuyerClass7ItemClass2Rate = "WHRATE0702";

            /// <summary>
            /// Property for BuyerClass7ItemClass3Rate
            /// </summary>
            public const string BuyerClass7ItemClass3Rate = "WHRATE0703";

            /// <summary>
            /// Property for BuyerClass7ItemClass4Rate
            /// </summary>
            public const string BuyerClass7ItemClass4Rate = "WHRATE0704";

            /// <summary>
            /// Property for BuyerClass7ItemClass5Rate
            /// </summary>
            public const string BuyerClass7ItemClass5Rate = "WHRATE0705";

            /// <summary>
            /// Property for BuyerClass7ItemClass6Rate
            /// </summary>
            public const string BuyerClass7ItemClass6Rate = "WHRATE0706";

            /// <summary>
            /// Property for BuyerClass7ItemClass7Rate
            /// </summary>
            public const string BuyerClass7ItemClass7Rate = "WHRATE0707";

            /// <summary>
            /// Property for BuyerClass7ItemClass8Rate
            /// </summary>
            public const string BuyerClass7ItemClass8Rate = "WHRATE0708";

            /// <summary>
            /// Property for BuyerClass7ItemClass9Rate
            /// </summary>
            public const string BuyerClass7ItemClass9Rate = "WHRATE0709";

            /// <summary>
            /// Property for BuyerClass7ItemClass10Rate
            /// </summary>
            public const string BuyerClass7ItemClass10Rate = "WHRATE0710";

            /// <summary>
            /// Property for BuyerClass8ItemClass1Rate
            /// </summary>
            public const string BuyerClass8ItemClass1Rate = "WHRATE0801";

            /// <summary>
            /// Property for BuyerClass8ItemClass2Rate
            /// </summary>
            public const string BuyerClass8ItemClass2Rate = "WHRATE0802";

            /// <summary>
            /// Property for BuyerClass8ItemClass3Rate
            /// </summary>
            public const string BuyerClass8ItemClass3Rate = "WHRATE0803";

            /// <summary>
            /// Property for BuyerClass8ItemClass4Rate
            /// </summary>
            public const string BuyerClass8ItemClass4Rate = "WHRATE0804";

            /// <summary>
            /// Property for BuyerClass8ItemClass5Rate
            /// </summary>
            public const string BuyerClass8ItemClass5Rate = "WHRATE0805";

            /// <summary>
            /// Property for BuyerClass8ItemClass6Rate
            /// </summary>
            public const string BuyerClass8ItemClass6Rate = "WHRATE0806";

            /// <summary>
            /// Property for BuyerClass8ItemClass7Rate
            /// </summary>
            public const string BuyerClass8ItemClass7Rate = "WHRATE0807";

            /// <summary>
            /// Property for BuyerClass8ItemClass8Rate
            /// </summary>
            public const string BuyerClass8ItemClass8Rate = "WHRATE0808";

            /// <summary>
            /// Property for BuyerClass8ItemClass9Rate
            /// </summary>
            public const string BuyerClass8ItemClass9Rate = "WHRATE0809";

            /// <summary>
            /// Property for BuyerClass8ItemClass10Rate
            /// </summary>
            public const string BuyerClass8ItemClass10Rate = "WHRATE0810";

            /// <summary>
            /// Property for BuyerClass9ItemClass1Rate
            /// </summary>
            public const string BuyerClass9ItemClass1Rate = "WHRATE0901";

            /// <summary>
            /// Property for BuyerClass9ItemClass2Rate
            /// </summary>
            public const string BuyerClass9ItemClass2Rate = "WHRATE0902";

            /// <summary>
            /// Property for BuyerClass9ItemClass3Rate
            /// </summary>
            public const string BuyerClass9ItemClass3Rate = "WHRATE0903";

            /// <summary>
            /// Property for BuyerClass9ItemClass4Rate
            /// </summary>
            public const string BuyerClass9ItemClass4Rate = "WHRATE0904";

            /// <summary>
            /// Property for BuyerClass9ItemClass5Rate
            /// </summary>
            public const string BuyerClass9ItemClass5Rate = "WHRATE0905";

            /// <summary>
            /// Property for BuyerClass9ItemClass6Rate
            /// </summary>
            public const string BuyerClass9ItemClass6Rate = "WHRATE0906";

            /// <summary>
            /// Property for BuyerClass9ItemClass7Rate
            /// </summary>
            public const string BuyerClass9ItemClass7Rate = "WHRATE0907";

            /// <summary>
            /// Property for BuyerClass9ItemClass8Rate
            /// </summary>
            public const string BuyerClass9ItemClass8Rate = "WHRATE0908";

            /// <summary>
            /// Property for BuyerClass9ItemClass9Rate
            /// </summary>
            public const string BuyerClass9ItemClass9Rate = "WHRATE0909";

            /// <summary>
            /// Property for BuyerClass9ItemClass10Rate
            /// </summary>
            public const string BuyerClass9ItemClass10Rate = "WHRATE0910";

            /// <summary>
            /// Property for BuyerClass10ItemClass1Rate
            /// </summary>
            public const string BuyerClass10ItemClass1Rate = "WHRATE1001";

            /// <summary>
            /// Property for BuyerClass10ItemClass2Rate
            /// </summary>
            public const string BuyerClass10ItemClass2Rate = "WHRATE1002";

            /// <summary>
            /// Property for BuyerClass10ItemClass3Rate
            /// </summary>
            public const string BuyerClass10ItemClass3Rate = "WHRATE1003";

            /// <summary>
            /// Property for BuyerClass10ItemClass4Rate
            /// </summary>
            public const string BuyerClass10ItemClass4Rate = "WHRATE1004";

            /// <summary>
            /// Property for BuyerClass10ItemClass5Rate
            /// </summary>
            public const string BuyerClass10ItemClass5Rate = "WHRATE1005";

            /// <summary>
            /// Property for BuyerClass10ItemClass6Rate
            /// </summary>
            public const string BuyerClass10ItemClass6Rate = "WHRATE1006";

            /// <summary>
            /// Property for BuyerClass10ItemClass7Rate
            /// </summary>
            public const string BuyerClass10ItemClass7Rate = "WHRATE1007";

            /// <summary>
            /// Property for BuyerClass10ItemClass8Rate
            /// </summary>
            public const string BuyerClass10ItemClass8Rate = "WHRATE1008";

            /// <summary>
            /// Property for BuyerClass10ItemClass9Rate
            /// </summary>
            public const string BuyerClass10ItemClass9Rate = "WHRATE1009";

            /// <summary>
            /// Property for BuyerClass10ItemClass10Rate
            /// </summary>
            public const string BuyerClass10ItemClass10Rate = "WHRATE1010";

            /// <summary>
            /// Property for WithholdingTaxAccount
            /// </summary>
            public const string WithholdingTaxAccount = "ACCTWHT";
        }

        #endregion

        #region Index Constants

        /// <summary>
        /// Contains list of WithholdingTaxRate Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for TaxAuthority
            /// </summary>
            public const int TaxAuthority = 1;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 2;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 3;

            /// <summary>
            /// Property Indexer for WithholdingTaxBase
            /// </summary>
            public const int WithholdingTaxBase = 4;

            /// <summary>
            /// Property Indexer for Num1099CPRSCode
            /// </summary>
            public const int Num1099CPRSCode = 5;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass1Rate
            /// </summary>
            public const int BuyerClass1ItemClass1Rate = 6;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass2Rate
            /// </summary>
            public const int BuyerClass1ItemClass2Rate = 7;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass3Rate
            /// </summary>
            public const int BuyerClass1ItemClass3Rate = 8;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass4Rate
            /// </summary>
            public const int BuyerClass1ItemClass4Rate = 9;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass5Rate
            /// </summary>
            public const int BuyerClass1ItemClass5Rate = 10;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass6Rate
            /// </summary>
            public const int BuyerClass1ItemClass6Rate = 11;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass7Rate
            /// </summary>
            public const int BuyerClass1ItemClass7Rate = 12;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass8Rate
            /// </summary>
            public const int BuyerClass1ItemClass8Rate = 13;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass9Rate
            /// </summary>
            public const int BuyerClass1ItemClass9Rate = 14;

            /// <summary>
            /// Property Indexer for BuyerClass1ItemClass10Rate
            /// </summary>
            public const int BuyerClass1ItemClass10Rate = 15;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass1Rate
            /// </summary>
            public const int BuyerClass2ItemClass1Rate = 16;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass2Rate
            /// </summary>
            public const int BuyerClass2ItemClass2Rate = 17;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass3Rate
            /// </summary>
            public const int BuyerClass2ItemClass3Rate = 18;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass4Rate
            /// </summary>
            public const int BuyerClass2ItemClass4Rate = 19;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass5Rate
            /// </summary>
            public const int BuyerClass2ItemClass5Rate = 20;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass6Rate
            /// </summary>
            public const int BuyerClass2ItemClass6Rate = 21;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass7Rate
            /// </summary>
            public const int BuyerClass2ItemClass7Rate = 22;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass8Rate
            /// </summary>
            public const int BuyerClass2ItemClass8Rate = 23;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass9Rate
            /// </summary>
            public const int BuyerClass2ItemClass9Rate = 24;

            /// <summary>
            /// Property Indexer for BuyerClass2ItemClass10Rate
            /// </summary>
            public const int BuyerClass2ItemClass10Rate = 25;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass1Rate
            /// </summary>
            public const int BuyerClass3ItemClass1Rate = 26;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass2Rate
            /// </summary>
            public const int BuyerClass3ItemClass2Rate = 27;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass3Rate
            /// </summary>
            public const int BuyerClass3ItemClass3Rate = 28;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass4Rate
            /// </summary>
            public const int BuyerClass3ItemClass4Rate = 29;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass5Rate
            /// </summary>
            public const int BuyerClass3ItemClass5Rate = 30;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass6Rate
            /// </summary>
            public const int BuyerClass3ItemClass6Rate = 31;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass7Rate
            /// </summary>
            public const int BuyerClass3ItemClass7Rate = 32;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass8Rate
            /// </summary>
            public const int BuyerClass3ItemClass8Rate = 33;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass9Rate
            /// </summary>
            public const int BuyerClass3ItemClass9Rate = 34;

            /// <summary>
            /// Property Indexer for BuyerClass3ItemClass10Rate
            /// </summary>
            public const int BuyerClass3ItemClass10Rate = 35;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass1Rate
            /// </summary>
            public const int BuyerClass4ItemClass1Rate = 36;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass2Rate
            /// </summary>
            public const int BuyerClass4ItemClass2Rate = 37;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass3Rate
            /// </summary>
            public const int BuyerClass4ItemClass3Rate = 38;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass4Rate
            /// </summary>
            public const int BuyerClass4ItemClass4Rate = 39;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass5Rate
            /// </summary>
            public const int BuyerClass4ItemClass5Rate = 40;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass6Rate
            /// </summary>
            public const int BuyerClass4ItemClass6Rate = 41;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass7Rate
            /// </summary>
            public const int BuyerClass4ItemClass7Rate = 42;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass8Rate
            /// </summary>
            public const int BuyerClass4ItemClass8Rate = 43;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass9Rate
            /// </summary>
            public const int BuyerClass4ItemClass9Rate = 44;

            /// <summary>
            /// Property Indexer for BuyerClass4ItemClass10Rate
            /// </summary>
            public const int BuyerClass4ItemClass10Rate = 45;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass1Rate
            /// </summary>
            public const int BuyerClass5ItemClass1Rate = 46;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass2Rate
            /// </summary>
            public const int BuyerClass5ItemClass2Rate = 47;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass3Rate
            /// </summary>
            public const int BuyerClass5ItemClass3Rate = 48;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass4Rate
            /// </summary>
            public const int BuyerClass5ItemClass4Rate = 49;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass5Rate
            /// </summary>
            public const int BuyerClass5ItemClass5Rate = 50;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass6Rate
            /// </summary>
            public const int BuyerClass5ItemClass6Rate = 51;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass7Rate
            /// </summary>
            public const int BuyerClass5ItemClass7Rate = 52;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass8Rate
            /// </summary>
            public const int BuyerClass5ItemClass8Rate = 53;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass9Rate
            /// </summary>
            public const int BuyerClass5ItemClass9Rate = 54;

            /// <summary>
            /// Property Indexer for BuyerClass5ItemClass10Rate
            /// </summary>
            public const int BuyerClass5ItemClass10Rate = 55;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass1Rate
            /// </summary>
            public const int BuyerClass6ItemClass1Rate = 56;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass2Rate
            /// </summary>
            public const int BuyerClass6ItemClass2Rate = 57;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass3Rate
            /// </summary>
            public const int BuyerClass6ItemClass3Rate = 58;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass4Rate
            /// </summary>
            public const int BuyerClass6ItemClass4Rate = 59;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass5Rate
            /// </summary>
            public const int BuyerClass6ItemClass5Rate = 60;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass6Rate
            /// </summary>
            public const int BuyerClass6ItemClass6Rate = 61;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass7Rate
            /// </summary>
            public const int BuyerClass6ItemClass7Rate = 62;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass8Rate
            /// </summary>
            public const int BuyerClass6ItemClass8Rate = 63;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass9Rate
            /// </summary>
            public const int BuyerClass6ItemClass9Rate = 64;

            /// <summary>
            /// Property Indexer for BuyerClass6ItemClass10Rate
            /// </summary>
            public const int BuyerClass6ItemClass10Rate = 65;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass1Rate
            /// </summary>
            public const int BuyerClass7ItemClass1Rate = 66;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass2Rate
            /// </summary>
            public const int BuyerClass7ItemClass2Rate = 67;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass3Rate
            /// </summary>
            public const int BuyerClass7ItemClass3Rate = 68;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass4Rate
            /// </summary>
            public const int BuyerClass7ItemClass4Rate = 69;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass5Rate
            /// </summary>
            public const int BuyerClass7ItemClass5Rate = 70;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass6Rate
            /// </summary>
            public const int BuyerClass7ItemClass6Rate = 71;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass7Rate
            /// </summary>
            public const int BuyerClass7ItemClass7Rate = 72;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass8Rate
            /// </summary>
            public const int BuyerClass7ItemClass8Rate = 73;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass9Rate
            /// </summary>
            public const int BuyerClass7ItemClass9Rate = 74;

            /// <summary>
            /// Property Indexer for BuyerClass7ItemClass10Rate
            /// </summary>
            public const int BuyerClass7ItemClass10Rate = 75;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass1Rate
            /// </summary>
            public const int BuyerClass8ItemClass1Rate = 76;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass2Rate
            /// </summary>
            public const int BuyerClass8ItemClass2Rate = 77;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass3Rate
            /// </summary>
            public const int BuyerClass8ItemClass3Rate = 78;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass4Rate
            /// </summary>
            public const int BuyerClass8ItemClass4Rate = 79;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass5Rate
            /// </summary>
            public const int BuyerClass8ItemClass5Rate = 80;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass6Rate
            /// </summary>
            public const int BuyerClass8ItemClass6Rate = 81;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass7Rate
            /// </summary>
            public const int BuyerClass8ItemClass7Rate = 82;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass8Rate
            /// </summary>
            public const int BuyerClass8ItemClass8Rate = 83;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass9Rate
            /// </summary>
            public const int BuyerClass8ItemClass9Rate = 84;

            /// <summary>
            /// Property Indexer for BuyerClass8ItemClass10Rate
            /// </summary>
            public const int BuyerClass8ItemClass10Rate = 85;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass1Rate
            /// </summary>
            public const int BuyerClass9ItemClass1Rate = 86;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass2Rate
            /// </summary>
            public const int BuyerClass9ItemClass2Rate = 87;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass3Rate
            /// </summary>
            public const int BuyerClass9ItemClass3Rate = 88;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass4Rate
            /// </summary>
            public const int BuyerClass9ItemClass4Rate = 89;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass5Rate
            /// </summary>
            public const int BuyerClass9ItemClass5Rate = 90;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass6Rate
            /// </summary>
            public const int BuyerClass9ItemClass6Rate = 91;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass7Rate
            /// </summary>
            public const int BuyerClass9ItemClass7Rate = 92;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass8Rate
            /// </summary>
            public const int BuyerClass9ItemClass8Rate = 93;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass9Rate
            /// </summary>
            public const int BuyerClass9ItemClass9Rate = 94;

            /// <summary>
            /// Property Indexer for BuyerClass9ItemClass10Rate
            /// </summary>
            public const int BuyerClass9ItemClass10Rate = 95;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass1Rate
            /// </summary>
            public const int BuyerClass10ItemClass1Rate = 96;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass2Rate
            /// </summary>
            public const int BuyerClass10ItemClass2Rate = 97;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass3Rate
            /// </summary>
            public const int BuyerClass10ItemClass3Rate = 98;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass4Rate
            /// </summary>
            public const int BuyerClass10ItemClass4Rate = 99;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass5Rate
            /// </summary>
            public const int BuyerClass10ItemClass5Rate = 100;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass6Rate
            /// </summary>
            public const int BuyerClass10ItemClass6Rate = 101;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass7Rate
            /// </summary>
            public const int BuyerClass10ItemClass7Rate = 102;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass8Rate
            /// </summary>
            public const int BuyerClass10ItemClass8Rate = 103;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass9Rate
            /// </summary>
            public const int BuyerClass10ItemClass9Rate = 104;

            /// <summary>
            /// Property Indexer for BuyerClass10ItemClass10Rate
            /// </summary>
            public const int BuyerClass10ItemClass10Rate = 105;

            /// <summary>
            /// Property Indexer for WithholdingTaxAccount
            /// </summary>
            public const int WithholdingTaxAccount = 200;
        }

        #endregion
    }
}