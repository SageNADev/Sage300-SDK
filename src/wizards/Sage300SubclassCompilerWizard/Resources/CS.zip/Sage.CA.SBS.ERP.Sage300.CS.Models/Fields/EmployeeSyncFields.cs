/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
	/// <summary>
	/// Contains list of Sync Constants
	/// </summary>
	public partial class EmployeeSync
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "HQ0006";

		#region Properties

		/// <summary>
		/// Contains list of Sync Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for OriginalModule
			/// </summary>
			public const string OriginalModule = "ORIGINAPP";

			/// <summary>
			/// Property for EmployeeID
			/// </summary>
			public const string EmployeeID = "EMPLOYEE";

			/// <summary>
			/// Property for ProcessCommandCode
			/// </summary>
			public const string ProcessCommandCode = "PROCESSCMD";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of Sync Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for OriginalModule
			/// </summary>
			public const int OriginalModule = 1;

			/// <summary>
			/// Property Indexer for EmployeeID
			/// </summary>
			public const int EmployeeID = 2;

			/// <summary>
			/// Property Indexer for ProcessCommandCode
			/// </summary>
			public const int ProcessCommandCode = 7;

		}

		#endregion

	}
}
