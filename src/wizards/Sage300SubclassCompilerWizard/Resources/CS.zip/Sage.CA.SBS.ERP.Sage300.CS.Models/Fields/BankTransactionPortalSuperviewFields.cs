// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankTransactionPortalSupervie Constants 
    /// </summary>
	public partial class BankTransactionPortalSuperview
    {

        # region constants

        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "BK0850";

        #endregion

        /// <summary>
        /// Contains list of BankTransactionPortalSupervie Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for TransactionHeaderSerial 
            /// </summary>
            public const string TransactionHeaderSerial = "SERIAL";

            /// <summary>
            /// Property for TransactionDetailLine 
            /// </summary>
            public const string TransactionDetailLine = "LINE";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";

            /// <summary>
            /// Property for Operation 
            /// </summary>
            public const string Operation = "OPCODE";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryType = "ENTRYTYPE";

            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property Indexer for TransactionDate (Original property is TRANSDATE)
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Gets or sets TransactionReference (Original property is HREFERENCE)
            /// </summary>
            public const string TransactionReference = "HREFERENCE";

            /// <summary>
            /// Property for (Original property is DESC)
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for TransactionStatus 
            /// </summary>
            public const string TransactionStatus = "HSTATUS";

            /// <summary>
            /// Property for DefaultReconciliationStatus 
            /// </summary>
            public const string DefaultReconciliationStatus = "HRECSTATUS";

            /// <summary>
            /// Property for OldSerialNumber 
            /// </summary>
            public const string OldSerialNumber = "OLDSERIAL";

            /// <summary>
            /// Property for LinesReconciled 
            /// </summary>
            public const string LinesReconciled = "LINESREC";

            /// <summary>
            /// Property for LinesJournalled 
            /// </summary>
            public const string LinesJournalled = "LINESJOUR";

            /// <summary>
            /// Property for LinesProcessed 
            /// </summary>
            public const string LinesProcessed = "LINESPROC";

            /// <summary>
            /// Property for ReconciliationClearedAmount 
            /// </summary>
            public const string ReconciliationClearedAmount = "TOCLEAR";

            /// <summary>
            /// Property for ReceiptStatus 
            /// </summary>
            public const string ReceiptStatus = "STATUS";

            /// <summary>
            /// Property for DetailTransactionType 
            /// </summary>
            public const string DetailTransactionType = "TYPE";

            /// <summary>
            /// Property for RemittanceID 
            /// </summary>
            public const string RemittanceID = "IDREMIT";

            /// <summary>
            /// Gets or sets BankSerialDateRemitSerialLine (Original property is DATEREMIT)
            /// </summary>
            public const string DateRemit = "DATEREMIT";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "BATCHNBR";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "ENTRYNBR";

            /// <summary>
            /// Property for PostingSequenceNumber 
            /// </summary>
            public const string PostingSequenceNumber = "POSTSEQ";

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Gets or sets Referece (Original property is REFERENCE) 
            /// </summary>
            public const string Referece = "REFERENCE";

            /// <summary>
            /// Gets or sets Reconcile Comment (Original property is COMMENT)
            /// </summary>
            public const string ReconcileComment = "COMMENT";

            /// <summary>
            /// Property for ReconciliationStatus 
            /// </summary>
            public const string ReconciliationStatus = "RECSTATUS";

            /// <summary>
            /// Property for PayerCode 
            /// </summary>
            public const string PayerCode = "PAYORID";

            /// <summary>
            /// Property for PayeeName 
            /// </summary>
            public const string PayeeName = "PAYORNAME";

            /// <summary>
            /// Property for VendorName 
            /// </summary>
            public const string VendorName = "VENDORNAME";

            /// <summary>
            /// Property for SourceAmount 
            /// </summary>
            public const string SourceAmount = "SRCEAMOUNT";

            /// <summary>
            /// Property for FunctionalAmount 
            /// </summary>
            public const string FunctionalAmount = "FUNCAMOUNT";

            /// <summary>
            /// Property for ExchangeRateType 
            /// </summary>
            public const string ExchangeRateType = "RATETYPE";

            /// <summary>
            /// Property for ReceiptCurrency 
            /// </summary>
            public const string ReceiptCurrency = "SRCECURN";

            /// <summary>
            /// Property for ExchangeRateDate 
            /// </summary>
            public const string ExchangeRateDate = "RATEDATE";

            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateSpread 
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for RateOperation 
            /// </summary>
            public const string RateOperation = "RATEOP";

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for GLAccount 
            /// </summary>
            public const string GLAccount = "GLACCOUNT";

            /// <summary>
            /// Property for DrilldownType 
            /// </summary>
            public const string DrilldownType = "DDTYPE";

            /// <summary>
            /// Property for DrilldownLink 
            /// </summary>
            public const string DrilldownLink = "DDLINK";

            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for CheckStockCode 
            /// </summary>
            public const string CheckStockCode = "CHKFORM";

            /// <summary>
            /// Property for OFXTransactionID 
            /// </summary>
            public const string OFXTransactionID = "OFXTID";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCPERIOD";

            /// <summary>
            /// Property for SourceDocumentNumber 
            /// </summary>
            public const string SourceDocumentNumber = "SRCEDOCNUM";

            /// <summary>
            /// Property for CanReverseInvoice 
            /// </summary>
            public const string CanReverseInvoice = "CANREVINVC";

            /// <summary>
            /// Property for ReverseInvoice 
            /// </summary>
            public const string ReverseInvoice = "REVINVC";

            /// <summary>
            /// Property for DistributionCodeDescription 
            /// </summary>
            public const string DistributionCodeDescription = "DCODEDESC";

            /// <summary>
            /// Property for GLAccountDescription 
            /// </summary>
            public const string GLAccountDescription = "GLACCOUNTD";

            /// <summary>
            /// Property for ReconciliationPostingDate 
            /// </summary>
            public const string ReconciliationPostingDate = "POSTDATE";

            /// <summary>
            /// Property for ReconciliationPostingYear 
            /// </summary>
            public const string ReconciliationPostingYear = "POSTYEAR";

            /// <summary>
            /// Property for ReconciliationPostingPeriod 
            /// </summary>
            public const string ReconciliationPostingPeriod = "POSTPERIOD";

            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "CURFUNC";

            /// <summary>
            /// Property for StatementCurrency 
            /// </summary>
            public const string StatementCurrency = "CURSTMT";

            /// <summary>
            /// Property for ReconciledandJournaledTransac 
            /// </summary>
            public const string ReconciledandJournaledTransac = "COMPLETED";

            /// <summary>
            /// Property for PostingSequence 
            /// </summary>
            public const string PostingSequence = "PSTSEQ";

            /// <summary>
            /// Property for Reconciled 
            /// </summary>
            public const string Reconciled = "RECONCILED";

            /// <summary>
            /// Property for DocumentPostedDate 
            /// </summary>
            public const string DocumentPostedDate = "POSTED";

            /// <summary>
            /// Property for SummatedTransactionAmount 
            /// </summary>
            public const string SummatedTransactionAmount = "SUMAMOUNT";

            /// <summary>
            /// Property for SourceCurrencyDescription 
            /// </summary>
            public const string SourceCurrencyDescription = "CURNAME";

            /// <summary>
            /// Property for ProcessResultCode 
            /// </summary>
            public const string ProcessResultCode = "RESULTCODE";

            #endregion
        }
        
        /// <summary>
        /// Contains list of BankTransactionPortalSupervie Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;

            /// <summary>
            /// Property Indexer for TransactionHeaderSerial 
            /// </summary>
            public const int TransactionHeaderSerial = 2;

            /// <summary>
            /// Property Indexer for TransactionDetailLine 
            /// </summary>
            public const int TransactionDetailLine = 3;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 4;

            /// <summary>
            /// Property Indexer for Operation 
            /// </summary>
            public const int Operation = 5;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 6;

            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryType = 7;

            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 8;

            /// <summary>
            /// Property Indexer for TransactionDate (Original property is TRANSDATE)
            /// </summary>
            public const int TransactionDate = 9;

            /// <summary>
            /// Gets or sets TransactionReference (Original property is HREFERENCE)
            /// </summary>
            public const int TransactionReference = 10;

            /// <summary>
            /// Gets or sets Description (Original property is DESC)
            /// </summary>
            public const int Description = 11;

            /// <summary>
            /// Property Indexer for TransactionStatus 
            /// </summary>
            public const int TransactionStatus = 12;

            /// <summary>
            /// Property Indexer for DefaultReconciliationStatus 
            /// </summary>
            public const int DefaultReconciliationStatus = 13;

            /// <summary>
            /// Property Indexer for OldSerialNumber 
            /// </summary>
            public const int OldSerialNumber = 14;

            /// <summary>
            /// Property Indexer for LinesReconciled 
            /// </summary>
            public const int LinesReconciled = 15;

            /// <summary>
            /// Property Indexer for LinesJournalled 
            /// </summary>
            public const int LinesJournalled = 16;

            /// <summary>
            /// Property Indexer for LinesProcessed 
            /// </summary>
            public const int LinesProcessed = 17;

            /// <summary>
            /// Property Indexer for ReconciliationClearedAmount 
            /// </summary>
            public const int ReconciliationClearedAmount = 18;

            /// <summary>
            /// Property Indexer for ReceiptStatus 
            /// </summary>
            public const int ReceiptStatus = 19;

            /// <summary>
            /// Property Indexer for DetailTransactionType 
            /// </summary>
            public const int DetailTransactionType = 20;

            /// <summary>
            /// Property Indexer for RemittanceID 
            /// </summary>
            public const int RemittanceID = 21;

            /// <summary>
            /// Gets or sets BankSerialDateRemitSerialLine (Original property is DATEREMIT)
            /// </summary>
            public const int DateRemit = 22;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 23;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 24;

            /// <summary>
            /// Property Indexer for PostingSequenceNumber 
            /// </summary>
            public const int PostingSequenceNumber = 25;

            /// <summary>
            /// Gets or sets Referece (Original property is REFERENCE) 
            /// </summary>
            public const int Referece = 26;

            /// <summary>
            /// Gets or sets Reconcile Comment (Original property is COMMENT)
            /// </summary>
            public const int ReconcileComment = 27;

            /// <summary>
            /// Property Indexer for ReconciliationStatus 
            /// </summary>
            public const int ReconciliationStatus = 28;

            /// <summary>
            /// Property Indexer for PayerCode 
            /// </summary>
            public const int PayerCode = 29;

            /// <summary>
            /// Property Indexer for PayeeName 
            /// </summary>
            public const int PayeeName = 30;

            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
            public const int VendorName = 31;

            /// <summary>
            /// Property Indexer for SourceAmount 
            /// </summary>
            public const int SourceAmount = 32;

            /// <summary>
            /// Property Indexer for FunctionalAmount 
            /// </summary>
            public const int FunctionalAmount = 33;

            /// <summary>
            /// Property Indexer for ExchangeRateType 
            /// </summary>
            public const int ExchangeRateType = 34;

            /// <summary>
            /// Property Indexer for ReceiptCurrency 
            /// </summary>
            public const int ReceiptCurrency = 35;

            /// <summary>
            /// Property Indexer for ExchangeRateDate 
            /// </summary>
            public const int ExchangeRateDate = 36;

            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 37;

            /// <summary>
            /// Property Indexer for RateSpread 
            /// </summary>
            public const int RateSpread = 38;

            /// <summary>
            /// Property Indexer for RateOperation 
            /// </summary>
            public const int RateOperation = 39;

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 40;

            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
            public const int GLAccount = 41;

            /// <summary>
            /// Property Indexer for DrilldownType 
            /// </summary>
            public const int DrilldownType = 47;

            /// <summary>
            /// Property Indexer for DrilldownLink 
            /// </summary>
            public const int DrilldownLink = 48;

            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 49;

            /// <summary>
            /// Property Indexer for CheckStockCode 
            /// </summary>
            public const int CheckStockCode = 50;

            /// <summary>
            /// Property Indexer for OFXTransactionID 
            /// </summary>
            public const int OFXTransactionID = 51;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 52;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 53;

            /// <summary>
            /// Property Indexer for SourceDocumentNumber 
            /// </summary>
            public const int SourceDocumentNumber = 54;

            /// <summary>
            /// Property Indexer for CanReverseInvoice 
            /// </summary>
            public const int CanReverseInvoice = 55;

            /// <summary>
            /// Property Indexer for ReverseInvoice 
            /// </summary>
            public const int ReverseInvoice = 56;

            /// <summary>
            /// Property Indexer for DistributionCodeDescription 
            /// </summary>
            public const int DistributionCodeDescription = 57;

            /// <summary>
            /// Property Indexer for GOrLAccountDescription 
            /// </summary>
            public const int GLAccountDescription = 58;

            /// <summary>
            /// Property Indexer for ReconciliationPostingDate 
            /// </summary>
            public const int ReconciliationPostingDate = 59;

            /// <summary>
            /// Property Indexer for ReconciliationPostingYear 
            /// </summary>
            public const int ReconciliationPostingYear = 60;

            /// <summary>
            /// Property Indexer for ReconciliationPostingPeriod 
            /// </summary>
            public const int ReconciliationPostingPeriod = 61;

            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 62;

            /// <summary>
            /// Property Indexer for StatementCurrency 
            /// </summary>
            public const int StatementCurrency = 63;

            /// <summary>
            /// Property Indexer for ReconciledandJournaledTransac 
            /// </summary>
            public const int ReconciledAndJournaledTransaction = 64;

            /// <summary>
            /// Property Indexer for PostingSequence 
            /// </summary>
            public const int PostingSequence = 65;

            /// <summary>
            /// Property Indexer for Reconciled 
            /// </summary>
            public const int Reconciled = 66;

            /// <summary>
            /// Property Indexer for DocumentPostedDate 
            /// </summary>
            public const int DocumentPostedDate = 67;

            /// <summary>
            /// Property Indexer for SummatedTransactionAmount 
            /// </summary>
            public const int SummatedTransactionAmount = 68;

            /// <summary>
            /// Property Indexer for SourceCurrencyDescription 
            /// </summary>
            public const int SourceCurrencyDescription = 69;

            /// <summary>
            /// Property Indexer for ProcessResultCode 
            /// </summary>
            public const int ProcessResultCode = 70;

            #endregion
        }
    }
}
	