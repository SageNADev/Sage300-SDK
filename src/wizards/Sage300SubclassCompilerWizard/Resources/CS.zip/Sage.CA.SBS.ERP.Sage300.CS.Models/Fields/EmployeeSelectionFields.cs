﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of EmployeeSelection Constants
    /// </summary>
    public partial class EmployeeSelection
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "HQ0003";

        #region Properties

        /// <summary>
        /// Contains list of EmployeeSelection Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for RecordNumber
            /// </summary>
            public const string RecordNumber = "RECNUM";

            /// <summary>
            /// Property for SelectedForSyncing
            /// </summary>
            public const string SelectedForSyncing = "SELECTED";

            /// <summary>
            /// Property for OriginApplication
            /// </summary>
            public const string OriginApplication = "ORIGINAPP";

            /// <summary>
            /// Property for EmployeeIDERP
            /// </summary>
            public const string EmployeeIDERP = "EMPLOYEE";

            /// <summary>
            /// Property for FullName
            /// </summary>
            public const string FullName = "FULLNAME";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for SageIDEmail
            /// </summary>
            public const string SageIDEmail = "SAGEID";

            /// <summary>
            /// Property for InviteToSageHR
            /// </summary>
            public const string InviteToSageHR = "INVITE";

            /// <summary>
            /// Property for EmployeeIDSageHR
            /// </summary>
            public const string EmployeeIDSageHR = "EMPLOYEEID";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for IncludeInactiveAndTerminated
            /// </summary>
            public const string IncludeInactiveAndTerminated = "SHOWALL";

            /// <summary>
            /// Property for SearchText
            /// </summary>
            public const string SearchText = "SEARCHTEXT";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of EmployeeSelection Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for RecordNumber
            /// </summary>
            public const int RecordNumber = 1;

            /// <summary>
            /// Property Indexer for SelectedForSyncing
            /// </summary>
            public const int SelectedForSyncing = 2;

            /// <summary>
            /// Property Indexer for OriginApplication
            /// </summary>
            public const int OriginApplication = 3;

            /// <summary>
            /// Property Indexer for EmployeeIDERP
            /// </summary>
            public const int EmployeeIDERP = 4;

            /// <summary>
            /// Property Indexer for FullName
            /// </summary>
            public const int FullName = 5;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 6;

            /// <summary>
            /// Property Indexer for SageIDEmail
            /// </summary>
            public const int SageIDEmail = 7;

            /// <summary>
            /// Property Indexer for InviteToSageHR
            /// </summary>
            public const int InviteToSageHR = 8;

            /// <summary>
            /// Property Indexer for EmployeeIDSageHR
            /// </summary>
            public const int EmployeeIDSageHR = 9;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 49;

            /// <summary>
            /// Property Indexer for IncludeInactiveAndTerminated
            /// </summary>
            public const int IncludeInactiveAndTerminated = 50;

            /// <summary>
            /// Property Indexer for SearchText
            /// </summary>
            public const int SearchText = 51;

        }

        #endregion

    }
}