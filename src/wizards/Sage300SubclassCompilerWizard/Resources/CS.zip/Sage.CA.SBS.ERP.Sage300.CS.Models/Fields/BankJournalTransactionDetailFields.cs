// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankJournalTransactionDetails Constants 
    /// </summary>
	public partial class BankJournalTransactionDetail
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "BK0650";

        /// <summary>
        /// Contains list of BankJournalTransactionDetails Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for PostingSequence 
            /// </summary>
            public const string PostingSequence = "PSTSEQ";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for TransactionHeaderSerial 
            /// </summary>
            public const string TransactionHeaderSerial = "SERIAL";

            /// <summary>
            /// Property for TransactionDetailLine 
            /// </summary>
            public const string TransactionDetailLine = "LINE";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";

            /// <summary>
            /// Property for TransactionDetailStatus 
            /// </summary>
            public const string TransactionDetailStatus = "STATUS";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for DetailTransactionType 
            /// </summary>
            public const string DetailTransactionType = "TYPE";

            /// <summary>
            /// Property for RemittanceID 
            /// </summary>
            public const string RemittanceID = "IDREMIT";

            /// <summary>
            /// Property for TransactionDate 
            /// </summary>
            public const string TransactionDate = "DATEREMIT";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "BTCHNBR";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "ENTRYNBR";

            /// <summary>
            /// Property for PostingSequenceNumber 
            /// </summary>
            public const string PostingSequenceNumber = "POSTSEQ";

            /// <summary>
            /// Property for TransactionReference 
            /// </summary>
            public const string TransactionReference = "REFERENCE";

            /// <summary>
            /// Property for TransactionDescription 
            /// </summary>
            public const string TransactionDescription = "COMMENT";

            /// <summary>
            /// Property for PayerCode 
            /// </summary>
            public const string PayerCode = "PAYORID";

            /// <summary>
            /// Property for PayeeName 
            /// </summary>
            public const string PayeeName = "PAYORNAME";

            /// <summary>
            /// Property for VendorName 
            /// </summary>
            public const string VendorName = "VENDORNAME";

            /// <summary>
            /// Property for SourceTransactionAmount 
            /// </summary>
            public const string SourceTransactionAmount = "SRCEAMOUNT";

            /// <summary>
            /// Property for FunctionalTransactionAmount 
            /// </summary>
            public const string FunctionalTransactionAmount = "FUNCAMOUNT";

            /// <summary>
            /// Property for ExchangeRateType 
            /// </summary>
            public const string ExchangeRateType = "RATETYPE";

            /// <summary>
            /// Property for ReceiptCurrency 
            /// </summary>
            public const string ReceiptCurrency = "SRCECURN";

            /// <summary>
            /// Property for ExchangeRateDate 
            /// </summary>
            public const string ExchangeRateDate = "RATEDATE";

            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateSpread 
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for RateOperation 
            /// </summary>
            public const string RateOperation = "RATEOP";

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for GOrLAccount 
            /// </summary>
            public const string GOrLAccount = "GLACCOUNT";

            /// <summary>
            /// Property for GLAccountOverride 
            /// </summary>
            public const string GLAccountOverride = "GLACCTOVR";

            /// <summary>
            /// Property for DrilldownType 
            /// </summary>
            public const string DrilldownType = "DDTYPE";

            /// <summary>
            /// Property for DrilldownLink 
            /// </summary>
            public const string DrilldownLink = "DDLINK";

            /// <summary>
            /// Property for ReconciliationStatus 
            /// </summary>
            public const string ReconciliationStatus = "RECSTATUS";

            /// <summary>
            /// Property for StatusChangeDate 
            /// </summary>
            public const string StatusChangeDate = "RECSTATCHG";

            /// <summary>
            /// Property for ReconciliationDescription 
            /// </summary>
            public const string ReconciliationDescription = "RECCOMMENT";

            /// <summary>
            /// Property for ClearedAmount 
            /// </summary>
            public const string ClearedAmount = "RECCLEARED";

            /// <summary>
            /// Property for ReconciliationPostingDate 
            /// </summary>
            public const string ReconciliationPostingDate = "POSTDATE";

            /// <summary>
            /// Property for ReconciliationPostingYear 
            /// </summary>
            public const string ReconciliationPostingYear = "POSTYEAR";

            /// <summary>
            /// Property for ReconciliationPostingPeriod 
            /// </summary>
            public const string ReconciliationPostingPeriod = "POSTPERIOD";

            /// <summary>
            /// Property for Reconciled 
            /// </summary>
            public const string Reconciled = "RECONCILED";

            /// <summary>
            /// Property for RemainingInTransitAmount 
            /// </summary>
            public const string RemainingInTransitAmount = "RECPENDING";

            /// <summary>
            /// Property for ReconciliationError 
            /// </summary>
            public const string ReconciliationError = "RECERR";

            /// <summary>
            /// Property for ReconciliationErrorPending 
            /// </summary>
            public const string ReconciliationErrorPending = "RECERRPEND";

            /// <summary>
            /// Property for ReconciliationExchangeGain 
            /// </summary>
            public const string ReconciliationExchangeGain = "RECEXGAIN";

            /// <summary>
            /// Property for ReconciliationExchangeLoss 
            /// </summary>
            public const string ReconciliationExchangeLoss = "RECEXLOSS";

            /// <summary>
            /// Property for ReconciliationSuggestion 
            /// </summary>
            public const string ReconciliationSuggestion = "RECSUGGEST";

            /// <summary>
            /// Property for TransactionAmount 
            /// </summary>
            public const string TransactionAmount = "RECAMOUNT";

            /// <summary>
            /// Property for OutstandingAmount 
            /// </summary>
            public const string OutstandingAmount = "RECOUTSTND";

            /// <summary>
            /// Property for ReconciliationTarget 
            /// </summary>
            public const string ReconciliationTarget = "RECTARGET";

            /// <summary>
            /// Property for ReconciliationCreditCardCharg 
            /// </summary>
            public const string ReconciliationCreditCardCharg = "RECCCC";

            /// <summary>
            /// Property for WriteOffAmount 
            /// </summary>
            public const string WriteOffAmount = "RECWOSUM";

            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "CURFUNC";

            /// <summary>
            /// Property for StatementCurrency 
            /// </summary>
            public const string StatementCurrency = "CURSTMT";

            /// <summary>
            /// Property for SummatedTransactionAmount 
            /// </summary>
            public const string SummatedTransactionAmount = "SUMAMOUNT";

            /// <summary>
            /// Property for ReconciliationSpread 
            /// </summary>
            public const string ReconciliationSpread = "RECSPREAD";

            /// <summary>
            /// Property for FiscalTransactionRemainingIn 
            /// </summary>
            public const string FiscalTransactionRemainingIn = "RECPAMOUNT";

            /// <summary>
            /// Property for FiscalOutstandingAmount 
            /// </summary>
            public const string FiscalOutstandingAmount = "RECPOUTSTD";

            /// <summary>
            /// Property for FiscalWriteOffs 
            /// </summary>
            public const string FiscalWriteOffs = "RECPWO";

            /// <summary>
            /// Property for FiscalBankErrors 
            /// </summary>
            public const string FiscalBankErrors = "RECPERR";

            /// <summary>
            /// Property for FiscalExchangeGain 
            /// </summary>
            public const string FiscalExchangeGain = "RECPGAIN";

            /// <summary>
            /// Property for FiscalExchangeLoss 
            /// </summary>
            public const string FiscalExchangeLoss = "RECPLOSS";

            /// <summary>
            /// Property for FiscalCreditCardCharge 
            /// </summary>
            public const string FiscalCreditCardCharge = "RECPCCC";

            /// <summary>
            /// Property for FiscalCleared 
            /// </summary>
            public const string FiscalCleared = "RECPCLR";

            /// <summary>
            /// Property for FiscalFunctionalAmount 
            /// </summary>
            public const string FiscalFunctionalAmount = "RECPFUNAM";

            /// <summary>
            /// Property for FiscalOriginalTransactionAmou 
            /// </summary>
            public const string FiscalOriginalTransactionAmou = "RECPORIG";

            /// <summary>
            /// Property for TotalBookAmount 
            /// </summary>
            public const string TotalBookAmount = "RECTBOOK";

            /// <summary>
            /// Property for FiscalBookAmount 
            /// </summary>
            public const string FiscalBookAmount = "RECPBOOK";

            /// <summary>
            /// Property for TotalRemainingAmount 
            /// </summary>
            public const string TotalRemainingAmount = "RECTREMAIN";

            /// <summary>
            /// Property for FiscalRemainingAmount 
            /// </summary>
            public const string FiscalRemainingAmount = "RECPREMAIN";

            /// <summary>
            /// Property for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const string FiscalWriteOffToThisPeriod = "RECRWOSUM";

            /// <summary>
            /// Property for FiscalClearedToFuture 
            /// </summary>
            public const string FiscalClearedToFuture = "RECFCLR";

            /// <summary>
            /// Property for FiscalClearedToCurrent 
            /// </summary>
            public const string FiscalClearedToCurrent = "RECRCLR";

            /// <summary>
            /// Property for CurrentPeriodsWriteOff 
            /// </summary>
            public const string CurrentPeriodsWriteOff = "RECWOSUMR";

            /// <summary>
            /// Property for PostedFiscalClearedToFuture 
            /// </summary>
            public const string PostedFiscalClearedToFuture = "RECFCLRR";

            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for CheckStockCode 
            /// </summary>
            public const string CheckStockCode = "CHKFORM";

            /// <summary>
            /// Property for OFXTransactionID 
            /// </summary>
            public const string OFXTransactionID = "OFXTID";

            /// <summary>
            /// Property for FutureReconciliationDelta 
            /// </summary>
            public const string FutureReconciliationDelta = "RECDELTAF";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCPERIOD";

            /// <summary>
            /// Property for ReversalOrReturnDate 
            /// </summary>
            public const string ReversalOrReturnDate = "REVDATE";

            /// <summary>
            /// Property for SourceDocumentNumber 
            /// </summary>
            public const string SourceDocumentNumber = "SRCEDOCNUM";

            /// <summary>
            /// Property for CanReverseInvoice 
            /// </summary>
            public const string CanReverseInvoice = "CANREVINVC";

            /// <summary>
            /// Property for ReverseInvoice 
            /// </summary>
            public const string ReverseInvoice = "REVINVC";

            /// <summary>
            /// Property for ReconciledandJournaledTransac 
            /// </summary>
            public const string ReconciledandJournaledTransac = "COMPLETED";

            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryType = "ENTRYTYPE";

            /// <summary>
            /// Property for ReconciliationAmountDelta 
            /// </summary>
            public const string ReconciliationAmountDelta = "RECDELTA";

            /// <summary>
            /// Property for DocumentPostedDate 
            /// </summary>
            public const string DocumentPostedDate = "POSTED";

            /// <summary>
            /// Property for ReconciledBy 
            /// </summary>
            public const string ReconciledBy = "RECLEVEL";

            #endregion
        }


        /// <summary>
        /// Contains list of BankJournalTransactionDetails Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for PostingSequence 
            /// </summary>
            public const int PostingSequence = 1;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 2;

            /// <summary>
            /// Property Indexer for TransactionHeaderSerial 
            /// </summary>
            public const int TransactionHeaderSerial = 3;

            /// <summary>
            /// Property Indexer for TransactionDetailLine 
            /// </summary>
            public const int TransactionDetailLine = 4;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 5;

            /// <summary>
            /// Property Indexer for TransactionDetailStatus 
            /// </summary>
            public const int TransactionDetailStatus = 6;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 7;

            /// <summary>
            /// Property Indexer for DetailTransactionType 
            /// </summary>
            public const int DetailTransactionType = 8;

            /// <summary>
            /// Property Indexer for RemittanceID 
            /// </summary>
            public const int RemittanceID = 9;

            /// <summary>
            /// Property Indexer for TransactionDate 
            /// </summary>
            public const int TransactionDate = 10;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 11;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 12;

            /// <summary>
            /// Property Indexer for PostingSequenceNumber 
            /// </summary>
            public const int PostingSequenceNumber = 13;

            /// <summary>
            /// Property Indexer for TransactionReference 
            /// </summary>
            public const int TransactionReference = 14;

            /// <summary>
            /// Property Indexer for TransactionDescription 
            /// </summary>
            public const int TransactionDescription = 15;

            /// <summary>
            /// Property Indexer for PayerCode 
            /// </summary>
            public const int PayerCode = 16;

            /// <summary>
            /// Property Indexer for PayeeName 
            /// </summary>
            public const int PayeeName = 17;

            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
            public const int VendorName = 18;

            /// <summary>
            /// Property Indexer for SourceTransactionAmount 
            /// </summary>
            public const int SourceTransactionAmount = 19;

            /// <summary>
            /// Property Indexer for FunctionalTransactionAmount 
            /// </summary>
            public const int FunctionalTransactionAmount = 20;

            /// <summary>
            /// Property Indexer for ExchangeRateType 
            /// </summary>
            public const int ExchangeRateType = 21;

            /// <summary>
            /// Property Indexer for ReceiptCurrency 
            /// </summary>
            public const int ReceiptCurrency = 22;

            /// <summary>
            /// Property Indexer for ExchangeRateDate 
            /// </summary>
            public const int ExchangeRateDate = 23;

            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 24;

            /// <summary>
            /// Property Indexer for RateSpread 
            /// </summary>
            public const int RateSpread = 25;

            /// <summary>
            /// Property Indexer for RateOperation 
            /// </summary>
            public const int RateOperation = 26;

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 27;

            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
            public const int GLAccount = 28;

            /// <summary>
            /// Property Indexer for GLAccountOverride 
            /// </summary>
            public const int GLAccountOverride = 29;

            /// <summary>
            /// Property Indexer for DrilldownType 
            /// </summary>
            public const int DrilldownType = 35;

            /// <summary>
            /// Property Indexer for DrilldownLink 
            /// </summary>
            public const int DrilldownLink = 36;

            /// <summary>
            /// Property Indexer for ReconciliationStatus 
            /// </summary>
            public const int ReconciliationStatus = 37;

            /// <summary>
            /// Property Indexer for StatusChangeDate 
            /// </summary>
            public const int StatusChangeDate = 38;

            /// <summary>
            /// Property Indexer for ReconciliationDescription 
            /// </summary>
            public const int ReconciliationDescription = 39;

            /// <summary>
            /// Property Indexer for ClearedAmount 
            /// </summary>
            public const int ClearedAmount = 40;

            /// <summary>
            /// Property Indexer for ReconciliationPostingDate 
            /// </summary>
            public const int ReconciliationPostingDate = 41;

            /// <summary>
            /// Property Indexer for ReconciliationPostingYear 
            /// </summary>
            public const int ReconciliationPostingYear = 42;

            /// <summary>
            /// Property Indexer for ReconciliationPostingPeriod 
            /// </summary>
            public const int ReconciliationPostingPeriod = 43;

            /// <summary>
            /// Property Indexer for Reconciled 
            /// </summary>
            public const int Reconciled = 44;

            /// <summary>
            /// Property Indexer for RemainingInTransitAmount 
            /// </summary>
            public const int RemainingInTransitAmount = 45;

            /// <summary>
            /// Property Indexer for ReconciliationError 
            /// </summary>
            public const int ReconciliationError = 46;

            /// <summary>
            /// Property Indexer for ReconciliationErrorPending 
            /// </summary>
            public const int ReconciliationErrorPending = 47;

            /// <summary>
            /// Property Indexer for ReconciliationExchangeGain 
            /// </summary>
            public const int ReconciliationExchangeGain = 48;

            /// <summary>
            /// Property Indexer for ReconciliationExchangeLoss 
            /// </summary>
            public const int ReconciliationExchangeLoss = 49;

            /// <summary>
            /// Property Indexer for ReconciliationSuggestion 
            /// </summary>
            public const int ReconciliationSuggestion = 50;

            /// <summary>
            /// Property Indexer for TransactionAmount 
            /// </summary>
            public const int TransactionAmount = 51;

            /// <summary>
            /// Property Indexer for OutstandingAmount 
            /// </summary>
            public const int OutstandingAmount = 52;

            /// <summary>
            /// Property Indexer for ReconciliationTarget 
            /// </summary>
            public const int ReconciliationTarget = 53;

            /// <summary>
            /// Property Indexer for ReconciliationCreditCardCharg 
            /// </summary>
            public const int ReconciliationCreditCardCharg = 54;

            /// <summary>
            /// Property Indexer for WriteOffAmount 
            /// </summary>
            public const int WriteOffAmount = 55;

            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 56;

            /// <summary>
            /// Property Indexer for StatementCurrency 
            /// </summary>
            public const int StatementCurrency = 57;

            /// <summary>
            /// Property Indexer for SummatedTransactionAmount 
            /// </summary>
            public const int SummatedTransactionAmount = 58;

            /// <summary>
            /// Property Indexer for ReconciliationSpread 
            /// </summary>
            public const int ReconciliationSpread = 59;

            /// <summary>
            /// Property Indexer for FiscalTransactionRemainingIn 
            /// </summary>
            public const int FiscalTransactionRemainingIn = 60;

            /// <summary>
            /// Property Indexer for FiscalOutstandingAmount 
            /// </summary>
            public const int FiscalOutstandingAmount = 61;

            /// <summary>
            /// Property Indexer for FiscalWriteOffs 
            /// </summary>
            public const int FiscalWriteOffs = 62;

            /// <summary>
            /// Property Indexer for FiscalBankErrors 
            /// </summary>
            public const int FiscalBankErrors = 63;

            /// <summary>
            /// Property Indexer for FiscalExchangeGain 
            /// </summary>
            public const int FiscalExchangeGain = 64;

            /// <summary>
            /// Property Indexer for FiscalExchangeLoss 
            /// </summary>
            public const int FiscalExchangeLoss = 65;

            /// <summary>
            /// Property Indexer for FiscalCreditCardCharge 
            /// </summary>
            public const int FiscalCreditCardCharge = 66;

            /// <summary>
            /// Property Indexer for FiscalCleared 
            /// </summary>
            public const int FiscalCleared = 67;

            /// <summary>
            /// Property Indexer for FiscalFunctionalAmount 
            /// </summary>
            public const int FiscalFunctionalAmount = 68;

            /// <summary>
            /// Property Indexer for FiscalOriginalTransactionAmou 
            /// </summary>
            public const int FiscalOriginalTransactionAmou = 69;

            /// <summary>
            /// Property Indexer for TotalBookAmount 
            /// </summary>
            public const int TotalBookAmount = 70;

            /// <summary>
            /// Property Indexer for FiscalBookAmount 
            /// </summary>
            public const int FiscalBookAmount = 71;

            /// <summary>
            /// Property Indexer for TotalRemainingAmount 
            /// </summary>
            public const int TotalRemainingAmount = 72;

            /// <summary>
            /// Property Indexer for FiscalRemainingAmount 
            /// </summary>
            public const int FiscalRemainingAmount = 73;

            /// <summary>
            /// Property Indexer for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const int FiscalWriteOffToThisPeriod = 74;

            /// <summary>
            /// Property Indexer for FiscalClearedToFuture 
            /// </summary>
            public const int FiscalClearedToFuture = 75;

            /// <summary>
            /// Property Indexer for FiscalClearedToCurrent 
            /// </summary>
            public const int FiscalClearedToCurrent = 76;

            /// <summary>
            /// Property Indexer for CurrentPeriodsWriteOff 
            /// </summary>
            public const int CurrentPeriodsWriteOff = 77;

            /// <summary>
            /// Property Indexer for PostedFiscalClearedToFuture 
            /// </summary>
            public const int PostedFiscalClearedToFuture = 78;

            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 79;

            /// <summary>
            /// Property Indexer for CheckStockCode 
            /// </summary>
            public const int CheckStockCode = 80;

            /// <summary>
            /// Property Indexer for OFXTransactionID 
            /// </summary>
            public const int OFXTransactionID = 81;

            /// <summary>
            /// Property Indexer for FutureReconciliationDelta 
            /// </summary>
            public const int FutureReconciliationDelta = 82;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 83;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 84;

            /// <summary>
            /// Property Indexer for ReversalOrReturnDate 
            /// </summary>
            public const int ReversalOrReturnDate = 85;

            /// <summary>
            /// Property Indexer for SourceDocumentNumber 
            /// </summary>
            public const int SourceDocumentNumber = 86;

            /// <summary>
            /// Property Indexer for CanReverseInvoice 
            /// </summary>
            public const int CanReverseInvoice = 87;

            /// <summary>
            /// Property Indexer for ReverseInvoice 
            /// </summary>
            public const int ReverseInvoice = 88;

            /// <summary>
            /// Property Indexer for ReconciledandJournaledTransac 
            /// </summary>
            public const int ReconciledandJournaledTransac = 89;

            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryType = 90;

            /// <summary>
            /// Property Indexer for ReconciliationAmountDelta 
            /// </summary>
            public const int ReconciliationAmountDelta = 91;

            /// <summary>
            /// Property Indexer for DocumentPostedDate 
            /// </summary>
            public const int DocumentPostedDate = 92;

            /// <summary>
            /// Property Indexer for ReconciledBy 
            /// </summary>
            public const int ReconciledBy = 93;

            #endregion
        }


	}
}
	