﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankTransactionReversalDetail Constants 
    /// </summary>
    public partial class BankTransactionReversalDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0855";

        /// <summary>
        /// Contains list of BankTransactionReversal Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for DetailSequence 
            /// </summary>
            public const string DetailSequence = "SEQUENCE";

            /// <summary>
            /// Property for ReverseDocument 
            /// </summary>
            public const string ReverseDocument = "SWREVDOC";

            /// <summary>
            /// Property for ReverseInvoice 
            /// </summary>
            public const string ReverseInvoice = "SWREVINVC";

            /// <summary>
            /// Property for ReversalDate 
            /// </summary>
            public const string ReversalDate = "REVDATE";

            /// <summary>
            /// Property for ReversalFiscalYear 
            /// </summary>
            public const string ReversalFiscalYear = "REVFISCYR";

            /// <summary>
            /// Property for ReversalFiscalPeriod 
            /// </summary>
            public const string ReversalFiscalPeriod = "REVFISCPER";

            /// <summary>
            /// Property for ReversalReason 
            /// </summary>
            public const string ReversalReason = "REASON";

            /// <summary>
            /// Property for TransactionHeaderSerial 
            /// </summary>
            public const string TransactionHeaderSerial = "SERIAL";

            /// <summary>
            /// Property for TransactionDetailLine 
            /// </summary>
            public const string TransactionDetailLine = "LINE";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for HeaderType 
            /// </summary>
            public const string HeaderType = "ENTRYTYPE";

            /// <summary>
            /// Property for DetailType 
            /// </summary>
            public const string DetailType = "DETAILTYPE";

            /// <summary>
            /// Property for RemittanceID 
            /// </summary>
            public const string RemittanceId = "IDREMIT";

            /// <summary>
            /// Property for DrilldownType 
            /// </summary>
            public const string DrilldownType = "DDTYPE";

            /// <summary>
            /// Property for DrilldownLink 
            /// </summary>
            public const string DrilldownLink = "DDLINK";

            /// <summary>
            /// Property for RemittanceDate 
            /// </summary>
            public const string RemittanceDate = "DATEREMIT";

            /// <summary>
            /// Property for TransactionFunctionalAmount 
            /// </summary>
            public const string TransactionFunctionalAmount = "FUNCAMOUNT";

            /// <summary>
            /// Property for TransactionSourceAmount 
            /// </summary>
            public const string TransactionSourceAmount = "SRCEAMOUNT";

            /// <summary>
            /// Property for TransactionSourceCurrency 
            /// </summary>
            public const string TransactionSourceCurrency = "SRCECURN";

            /// <summary>
            /// Property for PayorCode 
            /// </summary>
            public const string PayorCode = "PAYORID";

            /// <summary>
            /// Property for PayorName 
            /// </summary>
            public const string PayorName = "PAYORNAME";

            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for ProcessBankCode 
            /// </summary>
            public const string ProcessBankCode = "PBANK";

            /// <summary>
            /// Property for ProcessSourceApplication 
            /// </summary>
            public const string ProcessSourceApplication = "PSRCEAPP";

            /// <summary>
            /// Property for ReverseMultipleTransactions 
            /// </summary>
            public const string ReverseMultipleTransactions = "SWMULTTRAN";

            /// <summary>
            /// Property for ReverseTransactionType 
            /// </summary>
            public const string ReverseTransactionType = "DOCTYPE";

            /// <summary>
            /// Property for RemittanceIDFrom 
            /// </summary>
            public const string RemittanceIdFrom = "IDREMITFR";

            /// <summary>
            /// Property for RemittanceIDTo 
            /// </summary>
            public const string RemittanceIdTo = "IDREMITTO";

            /// <summary>
            /// Property for RemittanceDateFrom 
            /// </summary>
            public const string RemittanceDateFrom = "DATREMITFR";

            /// <summary>
            /// Property for RemittanceDateTo 
            /// </summary>
            public const string RemittanceDateTo = "DATREMITTO";

            /// <summary>
            /// Property for FuncTransactionAmountFrom 
            /// </summary>
            public const string FuncTransactionAmountFrom = "FUNCAMTFR";

            /// <summary>
            /// Property for FuncTransactionAmountTo 
            /// </summary>
            public const string FuncTransactionAmountTo = "FUNCAMTTO";

            /// <summary>
            /// Property for SrceTransactionAmountFrom 
            /// </summary>
            public const string SrceTransactionAmountFrom = "SRCEAMTFR";

            /// <summary>
            /// Property for SrceTransactionAmountTo 
            /// </summary>
            public const string SrceTransactionAmountTo = "SRCEAMTTO";

            /// <summary>
            /// Property for SrceCurrencyFrom 
            /// </summary>
            public const string SrceCurrencyFrom = "SRCECURNFR";

            /// <summary>
            /// Property for SrceCurrencyTo 
            /// </summary>
            public const string SrceCurrencyTo = "SRCECURNTO";

            /// <summary>
            /// Property for PayerCodeFrom 
            /// </summary>
            public const string PayerCodeFrom = "PAYORIDFR";

            /// <summary>
            /// Property for PayerCodeTo 
            /// </summary>
            public const string PayerCodeTo = "PAYORIDTO";

            /// <summary>
            /// Property for ProcessBankAccountNumber 
            /// </summary>
            public const string ProcessBankAccountNumber = "BKACCT";

            /// <summary>
            /// Property for ProcessBankAccount 
            /// </summary>
            public const string ProcessBankAccount = "IDACCT";

            /// <summary>
            /// Property for ProcessStatementCurrency 
            /// </summary>
            public const string ProcessStatementCurrency = "CURNSTMT";

            /// <summary>
            /// Property for DuplicateRemittanceID 
            /// </summary>
            public const string DuplicateRemittanceId = "SWDUPRMIT";

            /// <summary>
            /// Property for NumberofReversals 
            /// </summary>
            public const string NumberofReversals = "CNTREVERSE";

            /// <summary>
            /// Property for RestartRunID 
            /// </summary>
            public const string RestartRunId = "RUNID";

            /// <summary>
            /// Property for Hasrestartrecord 
            /// </summary>
            public const string Hasrestartrecord = "HASRESTART";

            #endregion
        }

        /// <summary>
        /// Contains list of BankTransactionReversal Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;

            /// <summary>
            /// Property Indexer for DetailSequence 
            /// </summary>
            public const int DetailSequence = 2;

            /// <summary>
            /// Property Indexer for ReverseDocument 
            /// </summary>
            public const int ReverseDocument = 3;

            /// <summary>
            /// Property Indexer for ReverseInvoice 
            /// </summary>
            public const int ReverseInvoice = 4;

            /// <summary>
            /// Property Indexer for ReversalDate 
            /// </summary>
            public const int ReversalDate = 5;

            /// <summary>
            /// Property Indexer for ReversalFiscalYear 
            /// </summary>
            public const int ReversalFiscalYear = 6;

            /// <summary>
            /// Property Indexer for ReversalFiscalPeriod 
            /// </summary>
            public const int ReversalFiscalPeriod = 7;

            /// <summary>
            /// Property Indexer for ReversalReason 
            /// </summary>
            public const int ReversalReason = 8;

            /// <summary>
            /// Property Indexer for TransactionHeaderSerial 
            /// </summary>
            public const int TransactionHeaderSerial = 9;

            /// <summary>
            /// Property Indexer for TransactionDetailLine 
            /// </summary>
            public const int TransactionDetailLine = 10;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 11;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 12;

            /// <summary>
            /// Property Indexer for HeaderType 
            /// </summary>
            public const int HeaderType = 13;

            /// <summary>
            /// Property Indexer for DetailType 
            /// </summary>
            public const int DetailType = 14;

            /// <summary>
            /// Property Indexer for RemittanceID 
            /// </summary>
            public const int RemittanceId = 15;

            /// <summary>
            /// Property Indexer for DrilldownType 
            /// </summary>
            public const int DrilldownType = 16;

            /// <summary>
            /// Property Indexer for DrilldownLink 
            /// </summary>
            public const int DrilldownLink = 17;

            /// <summary>
            /// Property Indexer for RemittanceDate 
            /// </summary>
            public const int RemittanceDate = 18;

            /// <summary>
            /// Property Indexer for TransactionFunctionalAmount 
            /// </summary>
            public const int TransactionFunctionalAmount = 19;

            /// <summary>
            /// Property Indexer for TransactionSourceAmount 
            /// </summary>
            public const int TransactionSourceAmount = 20;

            /// <summary>
            /// Property Indexer for TransactionSourceCurrency 
            /// </summary>
            public const int TransactionSourceCurrency = 21;

            /// <summary>
            /// Property Indexer for PayorCode 
            /// </summary>
            public const int PayorCode = 22;

            /// <summary>
            /// Property Indexer for PayorName 
            /// </summary>
            public const int PayorName = 23;

            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 100;

            /// <summary>
            /// Property Indexer for ProcessBankCode 
            /// </summary>
            public const int ProcessBankCode = 101;

            /// <summary>
            /// Property Indexer for ProcessSourceApplication 
            /// </summary>
            public const int ProcessSourceApplication = 102;

            /// <summary>
            /// Property Indexer for ReverseMultipleTransactions 
            /// </summary>
            public const int ReverseMultipleTransactions = 103;

            /// <summary>
            /// Property Indexer for ReverseTransactionType 
            /// </summary>
            public const int ReverseTransactionType = 104;

            /// <summary>
            /// Property Indexer for RemittanceIDFrom 
            /// </summary>
            public const int RemittanceIdFrom = 105;

            /// <summary>
            /// Property Indexer for RemittanceIDTo 
            /// </summary>
            public const int RemittanceIdTo = 106;

            /// <summary>
            /// Property Indexer for RemittanceDateFrom 
            /// </summary>
            public const int RemittanceDateFrom = 107;

            /// <summary>
            /// Property Indexer for RemittanceDateTo 
            /// </summary>
            public const int RemittanceDateTo = 108;

            /// <summary>
            /// Property Indexer for FuncTransactionAmountFrom 
            /// </summary>
            public const int FuncTransactionAmountFrom = 109;

            /// <summary>
            /// Property Indexer for FuncTransactionAmountTo 
            /// </summary>
            public const int FuncTransactionAmountTo = 110;

            /// <summary>
            /// Property Indexer for SrceTransactionAmountFrom 
            /// </summary>
            public const int SrceTransactionAmountFrom = 111;

            /// <summary>
            /// Property Indexer for SrceTransactionAmountTo 
            /// </summary>
            public const int SrceTransactionAmountTo = 112;

            /// <summary>
            /// Property Indexer for SrceCurrencyFrom 
            /// </summary>
            public const int SrceCurrencyFrom = 113;

            /// <summary>
            /// Property Indexer for SrceCurrencyTo 
            /// </summary>
            public const int SrceCurrencyTo = 114;

            /// <summary>
            /// Property Indexer for PayerCodeFrom 
            /// </summary>
            public const int PayerCodeFrom = 115;

            /// <summary>
            /// Property Indexer for PayerCodeTo 
            /// </summary>
            public const int PayerCodeTo = 116;

            /// <summary>
            /// Property Indexer for ProcessBankAccountNumber 
            /// </summary>
            public const int ProcessBankAccountNumber = 117;

            /// <summary>
            /// Property Indexer for ProcessBankAccount 
            /// </summary>
            public const int ProcessBankAccount = 118;

            /// <summary>
            /// Property Indexer for ProcessStatementCurrency 
            /// </summary>
            public const int ProcessStatementCurrency = 119;

            /// <summary>
            /// Property Indexer for DuplicateRemittanceID 
            /// </summary>
            public const int DuplicateRemittanceId = 120;

            /// <summary>
            /// Property Indexer for NumberofReversals 
            /// </summary>
            public const int NumberofReversals = 121;

            /// <summary>
            /// Property Indexer for RestartRunID 
            /// </summary>
            public const int RestartRunId = 122;

            /// <summary>
            /// Property Indexer for Hasrestartrecord 
            /// </summary>
            public const int Hasrestartrecord = 123;

            #endregion
        }
    }
}
