// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankServicesIntegrityCheck Constants 
    /// </summary>
    public partial class BankServicesIntegrityCheck
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "BK0100";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of BankServicesIntegrityCheck Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for IntegrityCheckOptionNumber 
            /// </summary>
            public const string IntegrityCheckOptionNumber = "CHECKNBR";

            /// <summary>
            /// Property for Date 
            /// </summary>
            public const string Date = "DATECHK";

            /// <summary>
            /// Property for FromBank 
            /// </summary>
            public const string FromBank = "FROMBANK";

            /// <summary>
            /// Property for ToBank 
            /// </summary>
            public const string ToBank = "TOBANK";

            /// <summary>
            /// Property for DataCheck 
            /// </summary>
            public const string DataCheck = "DATACHK";

            /// <summary>
            /// Property for OrphanCheck 
            /// </summary>
            public const string OrphanCheck = "ORPHANCHK";

            /// <summary>
            /// Property for RestartRecovery 
            /// </summary>
            public const string RestartRecovery = "RESTART";

            /// <summary>
            /// Property for Logerror 
            /// </summary>
            public const string Logerror = "LOGTOFILE";

            /// <summary>
            /// Property for JournalControl 
            /// </summary>
            public const string JournalControl = "CONTROL";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of BankServicesIntegrityCheck Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for IntegrityCheckOptionNumber 
            /// </summary>
            public const int IntegrityCheckOptionNumber = 1;

            /// <summary>
            /// Property Indexer for Date 
            /// </summary>
            public const int Date = 2;

            /// <summary>
            /// Property Indexer for FromBank 
            /// </summary>
            public const int FromBank = 3;

            /// <summary>
            /// Property Indexer for ToBank 
            /// </summary>
            public const int ToBank = 4;

            /// <summary>
            /// Property Indexer for DataCheck 
            /// </summary>
            public const int DataCheck = 5;

            /// <summary>
            /// Property Indexer for OrphanCheck 
            /// </summary>
            public const int OrphanCheck = 6;

            /// <summary>
            /// Property Indexer for RestartRecovery 
            /// </summary>
            public const int RestartRecovery = 7;

            /// <summary>
            /// Property Indexer for Logerror 
            /// </summary>
            public const int Logerror = 8;

            /// <summary>
            /// Property Indexer for JournalControl 
            /// </summary>
            public const int JournalControl = 9;

            #endregion
        }

        #endregion
    }
}