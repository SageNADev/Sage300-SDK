// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CreditCardType Constants 
    /// </summary>
	public partial class CreditCardType 
	{
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "BK0240";

        /// <summary>
        /// Contains list of CreditCardTypes Fields Constants
        /// </summary>
	    public class Fields
        {
            #region Properties
	        /// <summary>
            /// Property for CreditCardType 
            /// </summary>
	        public const string CreditCardTypeName  = "CCTYPE";
	        /// <summary>
            /// Property for Description 
            /// </summary>
	        public const string Description  = "DESC";
	        /// <summary>
            /// Property for Status 
            /// </summary>
	        public const string Status  = "INACTIVE";
	        /// <summary>
            /// Property for LastMaintained 
            /// </summary>
	        public const string LastMaintained  = "LASTMAINT";
	        /// <summary>
            /// Property for InactiveDate 
            /// </summary>
	        public const string InactiveDate  = "INACTDATE";
	     
            #endregion
	    }


		/// <summary>
        /// Contains list of CreditCardTypes Index Constants
        /// </summary>
	    public class Index
        {
            #region Properties
	        /// <summary>
            /// Property Indexer for CreditCardType 
            /// </summary>
	        public const int CreditCardTypeName  = 1;
	        /// <summary>
            /// Property Indexer for Description 
            /// </summary>
	        public const int Description  = 2;
	        /// <summary>
            /// Property Indexer for Status 
            /// </summary>
	        public const int Status  = 3;
	        /// <summary>
            /// Property Indexer for LastMaintained 
            /// </summary>
	        public const int LastMaintained  = 4;
	        /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
	        public const int InactiveDate  = 5;
	     
            #endregion
	    }
	}
}
	