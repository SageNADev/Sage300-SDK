﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of TaxAuditClearing Constants 
    /// </summary>
    public partial class TaxAuditClearing
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "TX0903";

        /// <summary>
        /// Contains list of TaxAuditClearing Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for AuthorityFrom 
            /// </summary>
            public const string AuthorityFrom = "AUTHFROM";

            /// <summary>
            /// Property for AuthorityTo 
            /// </summary>
            public const string AuthorityTo = "AUTHTO";

            /// <summary>
            /// Property for ClearRecordsBy 
            /// </summary>
            public const string ClearRecordsBy = "CLEARBY";

            /// <summary>
            /// Property for ReportAsOfYear 
            /// </summary>
            public const string ReportAsOfYear = "ASOFYEAR";

            /// <summary>
            /// Property for ReportAsOfPeriod 
            /// </summary>
            public const string ReportAsOfPeriod = "ASOFPERIOD";

            /// <summary>
            /// Property for ReportAsOfDate 
            /// </summary>
            public const string ReportAsOfDate = "ASOFDATE";

            /// <summary>
            /// Property for TypeofRecordtoClear 
            /// </summary>
            public const string TypeofRecordtoClear = "CLEARTYPE";

            /// <summary>
            /// Property for MethodofClearingClasses 
            /// </summary>
            public const string MethodofClearingClasses = "BYITEMCLAS";

            /// <summary>
            /// Property for FromItemClass 
            /// </summary>
            public const string FromItemClass = "FROMICLASS";

            /// <summary>
            /// Property for ToItemClass 
            /// </summary>
            public const string ToItemClass = "TOICLASS";

            /// <summary>
            /// Property for FromFiscalYear 
            /// </summary>
            public const string FromFiscalYear = "FROMYEAR";

            /// <summary>
            /// Property for FromFiscalPeriod 
            /// </summary>
            public const string FromFiscalPeriod = "FROMPRD";

            /// <summary>
            /// Property for ToFiscalYear 
            /// </summary>
            public const string ToFiscalYear = "TOYEAR";

            /// <summary>
            /// Property for ToFiscalPeriod 
            /// </summary>
            public const string ToFiscalPeriod = "TOPRD";

            #endregion
        }


        /// <summary>
        /// Contains list of TaxAuditClearing Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for AuthorityFrom 
            /// </summary>
            public const int AuthorityFrom = 1;

            /// <summary>
            /// Property Indexer for AuthorityTo 
            /// </summary>
            public const int AuthorityTo = 2;

            /// <summary>
            /// Property Indexer for ClearRecordsBy 
            /// </summary>
            public const int ClearRecordsBy = 3;

            /// <summary>
            /// Property Indexer for ReportAsOfYear 
            /// </summary>
            public const int ReportAsOfYear = 4;

            /// <summary>
            /// Property Indexer for ReportAsOfPeriod 
            /// </summary>
            public const int ReportAsOfPeriod = 5;

            /// <summary>
            /// Property Indexer for ReportAsOfDate 
            /// </summary>
            public const int ReportAsOfDate = 6;

            /// <summary>
            /// Property Indexer for TypeofRecordtoClear 
            /// </summary>
            public const int TypeofRecordtoClear = 7;

            /// <summary>
            /// Property Indexer for MethodofClearingClasses 
            /// </summary>
            public const int MethodofClearingClasses = 8;

            /// <summary>
            /// Property Indexer for FromItemClass 
            /// </summary>
            public const int FromItemClass = 9;

            /// <summary>
            /// Property Indexer for ToItemClass 
            /// </summary>
            public const int ToItemClass = 10;

            /// <summary>
            /// Property Indexer for FromFiscalYear 
            /// </summary>
            public const int FromFiscalYear = 11;

            /// <summary>
            /// Property Indexer for FromFiscalPeriod 
            /// </summary>
            public const int FromFiscalPeriod = 12;

            /// <summary>
            /// Property Indexer for ToFiscalYear 
            /// </summary>
            public const int ToFiscalYear = 13;

            /// <summary>
            /// Property Indexer for ToFiscalPeriod 
            /// </summary>
            public const int ToFiscalPeriod = 14;

            #endregion
        }


    }
}