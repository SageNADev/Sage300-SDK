﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of Employee Constants
    /// </summary>
    public partial class Employee
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "HQ0002";

        #region Properties

        /// <summary>
        /// Contains list of Employee Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for RecordNumber
            /// </summary>
            public const string RecordNumber = "RECNUM";

            /// <summary>
            /// Property for OriginalModule
            /// </summary>
            public const string OriginalModule = "ORIGINAPP";

            /// <summary>
            /// Property for EmployeeIDERP
            /// </summary>
            public const string EmployeeIDERP = "EMPLOYEE";

            /// <summary>
            /// Property for EmployeeIDSageHR
            /// </summary>
            public const string EmployeeIDSageHR = "EMPLOYEEID";

            /// <summary>
            /// Property for SageIDEmail
            /// </summary>
            public const string SageIDEmail = "SAGEID";

            /// <summary>
            /// Property for InviteToSageHR
            /// </summary>
            public const string InviteToSageHR = "INVITE";

            /// <summary>
            /// Property for SyncStatus
            /// </summary>
            public const string SyncStatus = "SYNCSTATUS";

            /// <summary>
            /// Property for SelectedForUnsyncing
            /// </summary>
            public const string SelectedForUnsyncing = "SELECTED";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for FullName
            /// </summary>
            public const string FullName = "FULLNAME";

            /// <summary>
            /// Property for HireDate
            /// </summary>
            public const string HireDate = "HIREDATE";

            /// <summary>
            /// Property for TerminationDate
            /// </summary>
            public const string TerminationDate = "FIREDATE";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for Position
            /// </summary>
            public const string Position = "POSITION";

            /// <summary>
            /// Property for FirstName
            /// </summary>
            public const string FirstName = "FIRSTNAME";

            /// <summary>
            /// Property for MiddleName
            /// </summary>
            public const string MiddleName = "MIDDLENAME";

            /// <summary>
            /// Property for LastName
            /// </summary>
            public const string LastName = "LASTNAME";

            /// <summary>
            /// Property for BirthDate
            /// </summary>
            public const string BirthDate = "BIRTHDATE";

            /// <summary>
            /// Property for AddressLine1
            /// </summary>
            public const string AddressLine1 = "ADDRESS1";

            /// <summary>
            /// Property for AddressLine2
            /// </summary>
            public const string AddressLine2 = "ADDRESS2";

            /// <summary>
            /// Property for StateProvince
            /// </summary>
            public const string StateProvince = "STATE";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "CITY";

            /// <summary>
            /// Property for ZIPCode
            /// </summary>
            public const string ZIPCode = "ZIP";

            /// <summary>
            /// Property for CountryCode
            /// </summary>
            public const string CountryCode = "CNTRYCODE";

            /// <summary>
            /// Property for Phone
            /// </summary>
            public const string Phone = "PHONE";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "EMAIL";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of Employee Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for RecordNumber
            /// </summary>
            public const int RecordNumber = 1;

            /// <summary>
            /// Property Indexer for OriginalModule
            /// </summary>
            public const int OriginalModule = 2;

            /// <summary>
            /// Property Indexer for EmployeeIDERP
            /// </summary>
            public const int EmployeeIDERP = 3;

            /// <summary>
            /// Property Indexer for EmployeeIDSageHR
            /// </summary>
            public const int EmployeeIDSageHR = 4;

            /// <summary>
            /// Property Indexer for SageIDEmail
            /// </summary>
            public const int SageIDEmail = 5;

            /// <summary>
            /// Property Indexer for InviteToSageHR
            /// </summary>
            public const int InviteToSageHR = 6;

            /// <summary>
            /// Property Indexer for SyncStatus
            /// </summary>
            public const int SyncStatus = 7;

            /// <summary>
            /// Property Indexer for SelectedForUnsyncing
            /// </summary>
            public const int SelectedForUnsyncing = 8;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 49;

            /// <summary>
            /// Property Indexer for FullName
            /// </summary>
            public const int FullName = 50;

            /// <summary>
            /// Property Indexer for HireDate
            /// </summary>
            public const int HireDate = 51;

            /// <summary>
            /// Property Indexer for TerminationDate
            /// </summary>
            public const int TerminationDate = 52;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 53;

            /// <summary>
            /// Property Indexer for Position
            /// </summary>
            public const int Position = 54;

            /// <summary>
            /// Property Indexer for FirstName
            /// </summary>
            public const int FirstName = 55;

            /// <summary>
            /// Property Indexer for MiddleName
            /// </summary>
            public const int MiddleName = 56;

            /// <summary>
            /// Property Indexer for LastName
            /// </summary>
            public const int LastName = 57;

            /// <summary>
            /// Property Indexer for BirthDate
            /// </summary>
            public const int BirthDate = 58;

            /// <summary>
            /// Property Indexer for AddressLine1
            /// </summary>
            public const int AddressLine1 = 59;

            /// <summary>
            /// Property Indexer for AddressLine2
            /// </summary>
            public const int AddressLine2 = 60;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 61;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 62;

            /// <summary>
            /// Property Indexer for ZIPCode
            /// </summary>
            public const int ZIPCode = 63;

            /// <summary>
            /// Property Indexer for CountryCode
            /// </summary>
            public const int CountryCode = 64;

            /// <summary>
            /// Property Indexer for Phone
            /// </summary>
            public const int Phone = 65;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 66;

        }

        #endregion

    }
}
