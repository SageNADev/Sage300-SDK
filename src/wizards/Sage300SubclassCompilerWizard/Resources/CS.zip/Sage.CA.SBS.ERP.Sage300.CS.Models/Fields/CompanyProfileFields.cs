﻿// /* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of Company Profile Constants 
    /// </summary>
    public partial class CompanyProfile
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "CS0001";

        /// <summary>
        /// Contains list of CompanyProfile Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for DatabaseID 
            /// </summary>
            public const string DatabaseId = "ORGID";

            /// <summary>
            /// Property for Name 
            /// </summary>
            public const string Name = "CONAME";

            /// <summary>
            /// Property for Address 
            /// </summary>
            public const string AddressLine1 = "ADDR01";

            /// <summary>
            /// Property for AddressLine2 
            /// </summary>
            public const string AddressLine2 = "ADDR02";

            /// <summary>
            /// Property for AddressLine3 
            /// </summary>
            public const string AddressLine3 = "ADDR03";

            /// <summary>
            /// Property for AddressLine4 
            /// </summary>
            public const string AddressLine4 = "ADDR04";

            /// <summary>
            /// Property for City 
            /// </summary>
            public const string City = "CITY";

            /// <summary>
            /// Property for StateOrProvince 
            /// </summary>
            /// NOTE: The StateOrProvince property changed to State for compatibility to GL Screens
            public const string State = "STATE";

            /// <summary>
            /// Property for ZipOrPostalCode 
            /// </summary>
            /// NOTE: The ZipOrPostalCode property changed to ZipCode for compatibility to GL Screens
            public const string ZipCode = "POSTAL";

            /// <summary>
            /// Property for Country 
            /// </summary>
            public const string Country = "COUNTRY";

            /// <summary>
            /// Property for LocationType 
            /// </summary>
            public const string LocationType = "LOCTYPE";

            /// <summary>
            /// Property for LocationCode 
            /// </summary>
            public const string LocationCode = "LOCCODE";

            /// <summary>
            /// Property for FormatPhoneNumber 
            /// </summary>
            public const string FormatPhoneNumber = "PHONEFMT";

            /// <summary>
            /// Property for PhoneNumber 
            /// </summary>
            public const string PhoneNumber = "PHONE";

            /// <summary>
            /// Property for FaxNumber 
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for Contact 
            /// </summary>
            public const string Contact = "CONTACT";

            /// <summary>
            /// Property for CountryCode 
            /// </summary>
            public const string CountryCode = "CNTRYCODE";

            /// <summary>
            /// Property for Branch 
            /// </summary>
            public const string Branch = "BRANCH";

            ///<summary>
            ///Property for NumberofFiscalPeriods 
            ///</summary>
            public const string NumberofFiscalPeriods = "PERDFSC";

            /// <summary>
            /// Property for Quarterwith4Periods 
            /// </summary>
            public const string Quarterwith4Periods = "QTR4PERD";

            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "HOMECUR";

            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "MULTICURSW";

            /// <summary>
            /// Property for DefaultRateTypeCode 
            /// </summary>
            public const string DefaultRateTypeCode = "RATETYPE";

            /// <summary>
            /// Property for WarningDateRange 
            /// </summary>
            public const string WarningDateRange = "WARNDAYS";

            /// <summary>
            /// Property for LockedFiscalPeriod 
            /// </summary>
            public const string LockedFiscalPeriod = "HNDLCKFSC";

            /// <summary>
            /// Property for InactiveGOrLAccount 
            /// </summary>
            public const string InactiveGorLAccount = "HNDINAACCT";

            /// <summary>
            /// Property for NonexistentGOrLAccount 
            /// </summary>
            public const string NonexistentGorLAccount = "HNDNEXACCT";

            /// <summary>
            /// Property for GainOrLossAccountingMethod 
            /// </summary>
            public const string GainOrLossAccountingMethod = "GNLSSMTHD";

            /// <summary>
            /// Property for TaxNumber 
            /// </summary>
            public const string TaxNumber = "TAXNBR";

            /// <summary>
            /// Property for BusinessRegistrationNumber 
            /// </summary>
            public const string BusinessRegistrationNumber = "BRN";

            /// <summary>
            /// Property for LegalName 
            /// </summary>
            public const string LegalName = "LEGALNAME";

            /// <summary>
            /// Property for EmailHost
            /// </summary>
            public const string ServerName = "EMAILHOST";
            /// <summary>
            /// Property for EMAILPORT
            /// </summary>

            public const string ServerPort = "EMAILPORT";
            /// <summary>
            /// Property for EmailUsername
            /// </summary>
            public const string Username = "EMAILUSER";
            /// <summary>
            /// Property for EmailPassword
            /// </summary>
            public const string Password = "EMAILPSWD";
            /// <summary>
            /// Property for Email send to address
            /// </summary>
            public const string SendTo = "EMAILADDR";
            /// <summary>
            /// Property for Email use Ssl
            /// </summary>
            public const string UseSSL = "EMAILSSL";

            /// <summary>
            /// Property for Payments Acceptance Organization Information
            /// </summary>
            public const string PaymentsAcceptanceOrgInfo = "SFPAORG";

            /// <summary>
            /// Property for Payments Acceptance Company
            /// </summary>
            public const string PaymentsAcceptanceCompany = "SFPACOMP";

            /// <summary>
            /// Property for Payments Acceptance Country
            /// </summary>
            public const string PaymentsAcceptanceCountry = "SFPACNTRY";

            /// <summary>
            /// Property for E-mail Send Method
            /// </summary>
            public const string EmailMethod = "EMAILMTHD";

            /// <summary>
            /// Property for User Email Input Password
            /// </summary>
            public const string UserPassword = "USEREPSWD";

            /// <summary>
            /// Property for Payments Acceptance Country Code
            /// </summary>
            public const string PaymentsAcceptanceCountryCode = "CNTRY";

            /// <summary>
            /// Property for SD&A Subdomain
            /// </summary>
            public const string SDASubdomain = "SUBDOMAIN";


            #endregion
        }

        /// <summary>
        /// Company Profile Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Property Indexer for DatabaseID 
            /// </summary>
            public const int DatabaseId = 1;

            /// <summary>
            /// Property Indexer for Name 
            /// </summary>
            public const int Name = 2;

            /// <summary>
            /// Property Indexer for Address 
            /// </summary>
            public const int AddressLine1 = 3;

            /// <summary>
            /// Property Indexer for AddressLine2 
            /// </summary>
            public const int AddressLine2 = 4;

            /// <summary>
            /// Property Indexer for AddressLine3 
            /// </summary>
            public const int AddressLine3 = 5;

            /// <summary>
            /// Property Indexer for AddressLine4 
            /// </summary>
            public const int AddressLine4 = 6;

            /// <summary>
            /// Property Indexer for City 
            /// </summary>
            public const int City = 7;

            /// <summary>
            /// Property Indexer for StateOrProvince
            /// </summary>
            /// NOTE: The StateOrProvince property changed to State for compatibility to GL Screens
            public const int State = 8;

            /// <summary>
            /// Property Indexer for ZipOrPostalCode 
            /// </summary>
            /// NOTE: The ZipOrPostalCode property changed to ZipCode for compatibility to GL Screens
            public const int ZipCode = 9;

            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
            public const int Country = 10;

            /// <summary>
            /// Property Indexer for LocationType 
            /// </summary>
            public const int LocationType = 11;

            /// <summary>
            /// Property Indexer for LocationCode 
            /// </summary>
            public const int LocationCode = 12;

            /// <summary>
            /// Property Indexer for FormatPhoneNumber 
            /// </summary>
            public const int FormatPhoneNumber = 13;

            /// <summary>
            /// Property Indexer for PhoneNumber 
            /// </summary>
            public const int PhoneNumber = 14;

            /// <summary>
            /// Property Indexer for FaxNumber 
            /// </summary>
            public const int FaxNumber = 15;

            /// <summary>
            /// Property Indexer for Contact 
            /// </summary>
            public const int Contact = 16;

            /// <summary>
            /// Property Indexer for CountryCode 
            /// </summary>
            public const int CountryCode = 17;

            /// <summary>
            /// Property Indexer for Branch 
            /// </summary>
            public const int Branch = 18;

            /// <summary>
            /// Property Indexer for NumberofFiscalPeriods 
            /// </summary>
            public const int NumberofFiscalPeriods = 19;

            /// <summary>
            /// Property Indexer for Quarterwith4Periods 
            /// </summary>
            public const int Quarterwith4Periods = 20;

            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 21;

            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 22;

            /// <summary>
            /// Property Indexer for DefaultRateTypeCode 
            /// </summary>
            public const int DefaultRateTypeCode = 23;

            /// <summary>
            /// Property Indexer for WarningDateRange 
            /// </summary>
            public const int WarningDateRange = 24;

            /// <summary>
            /// Property Indexer for LockedFiscalPeriod 
            /// </summary>
            public const int LockedFiscalPeriod = 52;

            /// <summary>
            /// Property Indexer for InactiveGOrLAccount 
            /// </summary>
            public const int InactiveGorLAccount = 53;

            /// <summary>
            /// Property Indexer for NonexistentGOrLAccount 
            /// </summary>
            public const int NonexistentGorLAccount = 54;

            /// <summary>
            /// Property Indexer for GainOrLossAccountingMethod 
            /// </summary>
            public const int GainOrLossAccountingMethod = 55;

            /// <summary>
            /// Property Indexer for TaxNumber 
            /// </summary>
            public const int TaxNumber = 56;

            /// <summary>
            /// Property Indexer for LegalName 
            /// </summary>
            public const int LegalName = 57;

            /// <summary>
            /// Property Indexer for BusinessRegistrationNumber
            /// </summary>
            public const int BusinessRegistrationNumber = 58;

            /// <summary>
            /// Property Indexer for EmailHost
            /// </summary>
            public const int EmailHost = 59;

            /// <summary>
            /// Property Indexer for EmailUsername
            /// </summary>
            public const int EmailUsername = 60;

            /// <summary>
            /// Property Indexer for EmailPassword
            /// </summary>
            public const int EmailPassword = 61;

            /// <summary>
            /// Property Indexer for EmailPort
            /// </summary>
            public const int EmailPort = 62;

            /// <summary>
            /// Property Indexer for EmailSSLFlag
            /// </summary>
            public const int EmailSslFlag = 63;

            /// <summary>
            /// Property Indexer for EmailFromAddress
            /// </summary>
            public const int EmailFromAddress = 64;

            /// <summary>
            /// Property Indexer for BccEmailAddress
            /// </summary>
            public const int BccEmailAddress = 67;

            /// <summary>
            /// Property Indexer for Payments Acceptance Organization Information
            /// </summary>
            public const int PaymentsAcceptanceOrgInfo = 68;

            /// <summary>
            /// Property Indexer for Payments Acceptance Company
            /// </summary>
            public const int PaymentsAcceptanceCompany = 69;

            /// <summary>
            /// Property Indexer for Payments Acceptance Country
            /// </summary>
            public const int PaymentsAcceptanceCountry = 70;

            /// <summary>
            /// Property Indexer for E-mail Send Method
            /// </summary>
            public const int EmailMethod = 71;

            /// <summary>
            /// Property Indexer for User Email Input Password
            /// </summary>
            public const int UserInputEmailPassword = 100;

            /// <summary>
            /// Property Indexer for Payments Acceptance Company Code
            /// </summary>
            public const int PaymentsAcceptanceCountryCode = 102;

            /// <summary>
            /// Property Indexer for SD&A Subdomain
            /// </summary>
            public const int SDASubdomain = 103;
            #endregion
        }
    }
}