// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankReconciliationClearing Constants 
    /// </summary>
    public partial class BankReconciliationClearing
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0103";

        /// <summary>
        /// Contains list of BankReconciliationClearing Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Operation 
            /// </summary>
            public const string Operation = "OPERATION";
            /// <summary>
            /// Property for BeginningPostingSequence 
            /// </summary>
            public const string BeginningPostingSequence = "SEQFROM";
            /// <summary>
            /// Property for EndingPostingSequence 
            /// </summary>
            public const string EndingPostingSequence = "SEQTO";
            /// <summary>
            /// Property for ReportTempFile 
            /// </summary>
            public const string ReportTempFile = "FILENAME";
            /// <summary>
            /// Property for BeginningBankCode 
            /// </summary>
            public const string BeginningBankCode = "BANKFROM";
            /// <summary>
            /// Property for EndingBankCode 
            /// </summary>
            public const string EndingBankCode = "BANKTO";
            /// <summary>
            /// Property for ThroughDate 
            /// </summary>
            public const string ThroughDate = "THRUDATE";

            #endregion
        }

        /// <summary>
        /// Contains list of BankReconciliationClearing Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Operation 
            /// </summary>
            public const int Operation = 1;
            /// <summary>
            /// Property Indexer for BeginningPostingSequence 
            /// </summary>
            public const int BeginningPostingSequence = 2;
            /// <summary>
            /// Property Indexer for EndingPostingSequence 
            /// </summary>
            public const int EndingPostingSequence = 3;
            /// <summary>
            /// Property Indexer for ReportTempFile 
            /// </summary>
            public const int ReportTempFile = 4;
            /// <summary>
            /// Property Indexer for BeginningBankCode 
            /// </summary>
            public const int BeginningBankCode = 5;
            /// <summary>
            /// Property Indexer for EndingBankCode 
            /// </summary>
            public const int EndingBankCode = 6;
            /// <summary>
            /// Property Indexer for ThroughDate 
            /// </summary>
            public const int ThroughDate = 7;

            #endregion
        }
    }
}
