// Copyright (c) 2024 Sage Software, Inc. All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of ConnectedBridgeOnboarding Constants
    /// </summary>
    public partial class ConnectedBridgeOnboarding
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "CS0070";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of ConnectedBridgeOnboarding Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for RecordNumber
            /// </summary>
            public const string RecordNumber = "RECNUM";

            /// <summary>
            /// Property for Payload
            /// </summary>
            public const string Payload = "PAYLOAD";

            /// <summary>
            /// Property for OrganisationID
            /// </summary>
            public const string OrganisationID = "ORGID";

            /// <summary>
            /// Property for CompanyID
            /// </summary>
            public const string CompanyID = "COMPID";

            /// <summary>
            /// Property for SigningKey
            /// </summary>
            public const string SigningKey = "SIGNKEY";

            /// <summary>
            /// Property for AccountID
            /// </summary>
            public const string AccountID = "ACCTID";

            /// <summary>
            /// Property for ProductSubscriptionID
            /// </summary>
            public const string ProductSubscriptionID = "PRODSUBID";

            /// <summary>
            /// Property for ApplicationID
            /// </summary>
            public const string ApplicationID = "APPLICID";

            /// <summary>
            /// Property for ClientID
            /// </summary>
            public const string ClientID = "CLIENTID";

            /// <summary>
            /// Property for SerialNumber
            /// </summary>
            public const string SerialNumber = "SERIAL";

            /// <summary>
            /// Property for SageIDUser
            /// </summary>
            public const string SageIDUser = "SAGEID";

            /// <summary>
            /// Property for RefreshToken
            /// </summary>
            public const string RefreshToken = "REFTOKEN";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ConnectedBridgeOnboarding Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for RecordNumber
            /// </summary>
            public const int RecordNumber = 1;

            /// <summary>
            /// Property Indexer for Payload
            /// </summary>
            public const int Payload = 2;

            /// <summary>
            /// Property Indexer for OrganisationID
            /// </summary>
            public const int OrganisationID = 100;

            /// <summary>
            /// Property Indexer for CompanyID
            /// </summary>
            public const int CompanyID = 101;

            /// <summary>
            /// Property Indexer for SigningKey
            /// </summary>
            public const int SigningKey = 102;

            /// <summary>
            /// Property Indexer for AccountID
            /// </summary>
            public const int AccountID = 103;

            /// <summary>
            /// Property Indexer for ProductSubscriptionID
            /// </summary>
            public const int ProductSubscriptionID = 104;

            /// <summary>
            /// Property Indexer for ApplicationID
            /// </summary>
            public const int ApplicationID = 105;

            /// <summary>
            /// Property Indexer for ClientID
            /// </summary>
            public const int ClientID = 106;

            /// <summary>
            /// Property Indexer for SerialNumber
            /// </summary>
            public const int SerialNumber = 107;

            /// <summary>
            /// Property Indexer for SageIDUser
            /// </summary>
            public const int SageIDUser = 108;

            /// <summary>
            /// Property Indexer for RefreshToken
            /// </summary>
            public const int RefreshToken = 109;


        }

        #endregion

    }
}