// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of Bank G/L Integration Constants 
    /// </summary>
	public partial class BankGLIntegration 
	{
	     /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "BK0470";

        /// <summary>
        /// Contains list of Bank GL Integration Fields Constants
        /// </summary>
        public class Fields : BaseFields
        {

            /// <summary>
            /// Property for GLTransactionField 
            /// </summary>
            public new const string GLTransactionField = "GLDIST";

            /// <summary>
            /// Property for SegmentCounter 
            /// </summary>
            public const string SegmentCounter = "SEGCOUNT";

        }
        
		/// <summary>
        /// Contains list of Bank G/L Integration Index Constants
        /// </summary>
        public class Index 
        {
            #region Properties

            /// <summary>
            /// Property Indexer for SourceTransactionType 
            /// </summary>
            public const int SourceTransactionType = 1;

            /// <summary>
            /// Property Indexer for GOrLTransactionfield 
            /// </summary>
            public const int GLTransactionField = 2;

            /// <summary>
            /// Property Index for Example 
            /// </summary>
            public const int Example = 3;
            
            /// <summary>
            /// Property Indexer for Separator 
            /// </summary>
            public const int Separator = 4;

            /// <summary>
            /// Property Indexer for IncludedSegment1 
            /// </summary>
            public const int IncludedSegment1 = 5;

            /// <summary>
            /// Property Indexer for IncludedSegment2 
            /// </summary>
            public const int IncludedSegment2 = 6;

            /// <summary>
            /// Property Indexer for IncludedSegment3 
            /// </summary>
            public const int IncludedSegment3 = 7;

            /// <summary>
            /// Property Indexer for IncludedSegment4 
            /// </summary>
            public const int IncludedSegment4 = 8;

            /// <summary>
            /// Property Indexer for IncludedSegment5 
            /// </summary>
            public const int IncludedSegment5 = 9;

            /// <summary>
            /// Property Indexer for SegmentCounter 
            /// </summary>
            public const int SegmentCounter = 10;

            #endregion
        }
	}
}
	