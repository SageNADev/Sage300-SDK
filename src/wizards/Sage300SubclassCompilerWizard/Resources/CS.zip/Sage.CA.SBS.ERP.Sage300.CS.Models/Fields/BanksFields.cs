// /* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of Banks Constants 
    /// </summary>
    public partial class Banks
    {
        /// <summary>
        /// Banks
        /// </summary>
        public const string EntityName = "BK0001";

        /// <summary>
        /// Contains list of Banks Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "NAME";

            /// <summary>
            /// Property for AddressLine1 
            /// </summary>
            public const string AddressLine1 = "ADDR1";

            /// <summary>
            /// Property for AddressLine2 
            /// </summary>
            public const string AddressLine2 = "ADDR2";

            /// <summary>
            /// Property for AddressLine3 
            /// </summary>
            public const string AddressLine3 = "ADDR3";

            /// <summary>
            /// Property for AddressLine4 
            /// </summary>
            public const string AddressLine4 = "ADDR4";

            /// <summary>
            /// Property for City 
            /// </summary>
            public const string City = "CITY";

            /// <summary>
            /// Property for StateOrProvince 
            /// </summary>
            public const string StateOrProvince = "STATE";

            /// <summary>
            /// Property for Country 
            /// </summary>
            public const string Country = "COUNTRY";

            /// <summary>
            /// Property for ZipOrPostalCode 
            /// </summary>
            public const string ZipOrPostalCode = "POSTAL";

            /// <summary>
            /// Property for Contact 
            /// </summary>
            public const string Contact = "CONTACT";

            /// <summary>
            /// Property for PhoneNumber 
            /// </summary>
            public const string PhoneNumber = "PHONE";

            /// <summary>
            /// Property for FaxNumber 
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for TransitNumber 
            /// </summary>
            public const string TransitNumber = "TRANSIT";

            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "MULTICUR";

            /// <summary>
            /// Property for StatementCurrency 
            /// </summary>
            public const string StatementCurrency = "CURNSTMT";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "INACTDATE";

            /// <summary>
            /// Property for BankAccountNumber 
            /// </summary>
            public const string BankAccountNumber = "BKACCT";

            /// <summary>
            /// Property for BankAccount 
            /// </summary>
            public const string BankAccount = "IDACCT";

            /// <summary>
            /// Property for WriteOffAccount 
            /// </summary>
            public const string WriteOffAccount = "IDACCTERR";

            /// <summary>
            /// Property for ErrorSpread 
            /// </summary>
            public const string ErrorSpread = "ERRSPREAD";

            /// <summary>
            /// Property for LastMaintained 
            /// </summary>
            public const string LastMaintained = "LSTMNTND";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "RECFY";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "RECFP";

            /// <summary>
            /// Property for LastReconciliationYear 
            /// </summary>
            public const string LastReconciliationYear = "RECLSTFY";

            /// <summary>
            /// Property for LastReconciliationPeriod 
            /// </summary>
            public const string LastReconciliationPeriod = "RECLSTFP";

            //TODO: The naming convention of this property has to be relooked         /// <summary>
            /// Property for RECLSTDATE 
            /// 
            public const string RECLSTDATE = "RECLSTDATE";

            /// <summary>
            /// Property for LastClosingStatementBalance 
            /// </summary>
            public const string LastClosingStatementBalance = "RECLSTBAL";

            //TODO: The naming convention of this property has to be relooked        
            /// <summary>
            /// Property for RECDATE 
            /// </summary>
            public const string RECDATE = "RECDATE";

            /// <summary>
            /// Property for StatementDate 
            /// </summary>
            public const string StatementDate = "RECSTMTDAT";

            /// <summary>
            /// Property for StatementBalance 
            /// </summary>
            public const string StatementBalance = "RECSTMTBAL";

            /// <summary>
            /// Property for DepositsinTransit 
            /// </summary>
            public const string DepositsinTransit = "RECINTRANS";

            /// <summary>
            /// Property for ChecksOutstanding 
            /// </summary>
            public const string ChecksOutstanding = "RECOUTSTND";

            /// <summary>
            /// Property for BankErrors 
            /// </summary>
            public const string BankErrors = "RECBKERRPN";

            /// <summary>
            /// Property for TotalNotPostedBankEntries 
            /// </summary>
            public const string TotalNotPostedBankEntries = "RECBKENT";

            /// <summary>
            /// Property for WriteOffs 
            /// </summary>
            public const string WriteOffs = "RECBKERR";

            /// <summary>
            /// Property for ExchangeGain 
            /// </summary>
            public const string ExchangeGain = "RECEXGAIN";

            /// <summary>
            /// Property for ExchangeLoss 
            /// </summary>
            public const string ExchangeLoss = "RECEXLOSS";

            /// <summary>
            /// Property for TotalDeposits 
            /// </summary>
            public const string TotalDeposits = "RECDEPOSIT";

            /// <summary>
            /// Property for TotalChecks 
            /// </summary>
            public const string TotalChecks = "RECCHECK";

            /// <summary>
            /// Property for DepositsToFiscalPeriod 
            /// </summary>
            public const string DepositsToFiscalPeriod = "RECFCDEP";

            /// <summary>
            /// Property for ChecksToFiscalPeriod 
            /// </summary>
            public const string ChecksToFiscalPeriod = "RECFCCHK";

            /// <summary>
            /// Property for DepositsInTransitToFiscPer 
            /// </summary>
            public const string DepositsInTransitToFiscPer = "RECFCDEPIT";

            /// <summary>
            /// Property for ChecksOutstandingToFiscPer 
            /// </summary>
            public const string ChecksOutstandingToFiscPer = "RECFCCHKOS";

            /// <summary>
            /// Property for CalculateFiscalPeriodData 
            /// </summary>
            public const string CalculateFiscalPeriodData = "RECRECALC";

            /// <summary>
            /// Property for LastStatementDate 
            /// </summary>
            public const string LastStatementDate = "RECLSMDATE";

            /// <summary>
            /// </summary>
            /// Property for ExchangeGainToFiscalPeriod 
            /// <summary>
            /// </summary>
            public const string ExchangeGainToFiscalPeriod = "RECFCGAIN";

            /// <summary>
            /// Property for ExchangeLossToFiscalPeriod 
            /// </summary>
            public const string ExchangeLossToFiscalPeriod = "RECFCLOSS";

            /// <summary>
            /// Property for BankErrorPendingToFiscalPer 
            /// </summary>
            public const string BankErrorPendingToFiscalPer = "RECFCERRPN";

            /// <summary>
            /// Property for BankErrorToFiscalPeriod 
            /// </summary>
            public const string BankErrorToFiscalPeriod = "RECFCERR";

            /// <summary>
            /// Property for TotalNotPostedBankEntriesTo 
            /// </summary>
            public const string TotalNotPostedBankEntriesTo = "RECFCENTRE";

            /// <summary>
            /// Property for CreditCardChargesAccount 
            /// </summary>
            public const string CreditCardChargesAccount = "IDACCTCCC";

            /// <summary>
            /// Property for CreditCardChargeSpread 
            /// </summary>
            public const string CreditCardChargeSpread = "CCCSPREAD";

            /// <summary>
            /// Property for ExchangeRateDifferenceSpread 
            /// </summary>
            public const string ExchangeRateDifferenceSpread = "EXSPREAD";

            /// <summary>
            /// Property for AdjustedBookBalance 
            /// </summary>
            public const string AdjustedBookBalance = "ADJBOOKBAL";

            /// <summary>
            /// Property for AdjustedStatementBalance 
            /// </summary>
            public const string AdjustedStatementBalance = "ADJSTMTBAL";

            /// <summary>
            /// Property for BankReconciliationBalanced 
            /// </summary>
            public const string BankReconciliationBalanced = "BALANCES";


            /// <summary>
            /// Property for BankReconciliationBalanced String
            /// </summary>
            public const string BankReconciliationBalancedString = "BALANCES";

            /// <summary>
            /// Property for OutOfBalanceBy 
            /// </summary>
            public const string OutOfBalanceBy = "ADJBALDIFF";

            /// <summary>
            /// Property for NextCheckSerialNumber 
            /// </summary>
            public const string NextCheckSerialNumber = "CHKSERIAL";

            /// <summary>
            /// Property for NextDepositSlipNumber 
            /// </summary>
            public const string NextDepositSlipNumber = "NXTDEPOSIT";

            /// <summary>
            /// Property for NextDepositUniquifier 
            /// </summary>
            public const string NextDepositUniquifier = "DEPSERIAL";

            /// <summary>
            /// Property for CurrentBalance 
            /// </summary>
            public const string CurrentBalance = "RECAVAIL";

            /// <summary>
            /// Property for BookBalance 
            /// </summary>
            public const string BookBalance = "RECBOOKBAL";

            /// <summary>
            /// Property for BankStatementType 
            /// </summary>
            public const string BankStatementType = "CURRTYPE";

            /// <summary>
            /// Property for TotalWriteOffs 
            /// </summary>
            public const string TotalWriteOffs = "RECTWO";

            /// <summary>
            /// Property for TotalCreditCardCharges 
            /// </summary>
            public const string TotalCreditCardCharges = "RECTCCC";

            /// <summary>
            /// Property for FiscalPeriodWriteOff 
            /// </summary>
            public const string FiscalPeriodWriteOff = "RECPWO";

            /// <summary>
            /// Property for FiscalPeriodCreditCardCharge 
            /// </summary>
            public const string FiscalPeriodCreditCardCharge = "RECPCCC";

            /// <summary>
            /// Property for SumofWithdrawalTotalWriteOf 
            /// </summary>
            public const string SumofWithdrawalTotalWriteOf = "RECWTWOSUM";

            /// <summary>
            /// Property for SumofDepositTotalWriteOffs 
            /// </summary>
            public const string SumofDepositTotalWriteOffs = "RECDTWOSUM";

            /// <summary>
            /// Property for SumofWithdrawalFiscalWriteO 
            /// </summary>
            public const string SumofWithdrawalFiscalWriteO = "RECWPWOSUM";

            /// <summary>
            /// Property for SumofDepositFiscalWriteOffs 
            /// </summary>
            public const string SumofDepositFiscalWriteOffs = "RECDPWOSUM";

            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "CURFUNC";

            /// <summary>
            /// Property for TotalRemainingOutStanding 
            /// </summary>
            public const string TotalRemainingOutStanding = "RECWTREM";

            /// <summary>
            /// Property for FiscalRemainingOutStanding 
            /// </summary>
            public const string FiscalRemainingOutStanding = "RECWPREM";

            /// <summary>
            /// Property for TotalRemainingInTransit 
            /// </summary>
            public const string TotalRemainingInTransit = "RECDTREM";

            /// <summary>
            /// Property for FiscalRemainingInTransit 
            /// </summary>
            public const string FiscalRemainingInTransit = "RECDPREM";

            /// <summary>
            /// Property for FiscalWithdrawalClearedToCur 
            /// </summary>
            public const string FiscalWithdrawalClearedToCur = "RECWRCLR";

            /// <summary>
            /// Property for FiscalDepositClearedToCurren 
            /// </summary>
            public const string FiscalDepositClearedToCurren = "RECDRCLR";

            /// <summary>
            /// Property for TaxGroupDescription 
            /// </summary>
            public const string TaxGroupDescription = "TXGRPDESC";

            /// <summary>
            /// Property for TaxAuthorizationDescription1 
            /// </summary>
            public const string TaxAuthorizationDescription1 = "TXAUTDESC1";

            /// <summary>
            /// Property for TaxAuthorizationDescription2 
            /// </summary>
            public const string TaxAuthorizationDescription2 = "TXAUTDESC2";

            /// <summary>
            /// Property for TaxAuthorizationDescription3 
            /// </summary>
            public const string TaxAuthorizationDescription3 = "TXAUTDESC3";

            /// <summary>
            /// Property for TaxAuthorizationDescription4 
            /// </summary>
            public const string TaxAuthorizationDescription4 = "TXAUTDESC4";

            /// <summary>
            /// Property for TaxAuthorizationDescription5 
            /// </summary>
            public const string TaxAuthorizationDescription5 = "TXAUTDESC5";

            /// <summary>
            /// Property for VendorTaxClassDescription1 
            /// </summary>
            public const string VendorTaxClassDescription1 = "TXCLSDESC1";

            /// <summary>
            /// Property for VendorTaxClassDescription2 
            /// </summary>
            public const string VendorTaxClassDescription2 = "TXCLSDESC2";

            /// <summary>
            /// Property for VendorTaxClassDescription3 
            /// </summary>
            public const string VendorTaxClassDescription3 = "TXCLSDESC3";

            /// <summary>
            /// Property for VendorTaxClassDescription4 
            /// </summary>
            public const string VendorTaxClassDescription4 = "TXCLSDESC4";

            /// <summary>
            /// Property for VendorTaxClassDescription5 
            /// </summary>
            public const string VendorTaxClassDescription5 = "TXCLSDESC5";

            /// <summary>
            /// Property for NextSerialNumber 
            /// </summary>
            public const string NextSerialNumber = "NEXTSERIAL";

            /// <summary>
            /// Property for DepositClearedwithExchangeRa 
            /// </summary>
            public const string DepositClearedwithExchangeRa = "RECDEXDIFF";

            /// <summary>
            /// Property for WithdrawalsClearedwithExchR 
            /// </summary>
            public const string WithdrawalsClearedwithExchR = "RECWEXDIFF";

            /// <summary>
            /// Property for TotalWithdrawalBankErrors 
            /// </summary>
            public const string TotalWithdrawalBankErrors = "RECWTERR";

            /// <summary>
            /// Property for TotalWithdrawalWriteOffs 
            /// </summary>
            public const string TotalWithdrawalWriteOffs = "RECWTWO";

            /// <summary>
            /// Property for TotalWithdrawalExchangeGain 
            /// </summary>
            public const string TotalWithdrawalExchangeGain = "RECWTGAIN";

            /// <summary>
            /// Property for TotalWithdrawalExchangeLoss 
            /// </summary>
            public const string TotalWithdrawalExchangeLoss = "RECWTLOSS";

            /// <summary>
            /// Property for TotalWithdrawalCreditCardCha 
            /// </summary>
            public const string TotalWithdrawalCreditCardCha = "RECWTCCC";

            /// <summary>
            /// Property for TotalWithdrawalCleared 
            /// </summary>
            public const string TotalWithdrawalCleared = "RECWTCLR";

            /// <summary>
            /// Property for WithdrawalTotal 
            /// </summary>
            public const string WithdrawalTotal = "RECWTFUNAM";

            /// <summary>
            /// Property for FiscalWithdrawalBankErrors 
            /// </summary>
            public const string FiscalWithdrawalBankErrors = "RECWPERR";

            /// <summary>
            /// Property for FiscalWithdrawalWriteOffs 
            /// </summary>
            public const string FiscalWithdrawalWriteOffs = "RECWPWO";

            /// <summary>
            /// Property for FiscalWithdrawalExchangeGain 
            /// </summary>
            public const string FiscalWithdrawalExchangeGain = "RECWPGAIN";

            /// <summary>
            /// Property for FiscalWithdrawalExchangeLoss 
            /// </summary>
            public const string FiscalWithdrawalExchangeLoss = "RECWPLOSS";

            /// <summary>
            /// Property for FiscalWithdrawalCreditCardCh 
            /// </summary>
            public const string FiscalWithdrawalCreditCardCh = "RECWPCCC";

            /// <summary>
            /// Property for FiscalWithdrawalCleared 
            /// </summary>
            public const string FiscalWithdrawalCleared = "RECWPCLR";

            /// <summary>
            /// Property for FiscalWithdrawalTotal 
            /// </summary>
            public const string FiscalWithdrawalTotal = "RECWPFUNAM";

            /// <summary>
            /// Property for TotalDepositBankErrors 
            /// </summary>
            public const string TotalDepositBankErrors = "RECDTERR";

            /// <summary>
            /// Property for TotalDepositWriteOffs 
            /// </summary>
            public const string TotalDepositWriteOffs = "RECDTWO";

            /// <summary>
            /// Property for TotalDepositExchangeGain 
            /// </summary>
            public const string TotalDepositExchangeGain = "RECDTGAIN";

            /// <summary>
            /// Property for TotalDepositExchangeLoss 
            /// </summary>
            public const string TotalDepositExchangeLoss = "RECDTLOSS";

            /// <summary>
            /// Property for TotalDepositCreditCardCharge 
            /// </summary>
            public const string TotalDepositCreditCardCharge = "RECDTCCC";

            /// <summary>
            /// Property for TotalDepositCleared 
            /// </summary>
            public const string TotalDepositCleared = "RECDTCLR";

            /// <summary>
            /// Property for DepositTotal 
            /// </summary>
            public const string DepositTotal = "RECDTFUNAM";

            /// <summary>
            /// Property for FiscalDepositBankErrors 
            /// </summary>
            public const string FiscalDepositBankErrors = "RECDPERR";

            /// <summary>
            /// Property for FiscalDepositWriteOffs 
            /// </summary>
            public const string FiscalDepositWriteOffs = "RECDPWO";

            /// <summary>
            /// Property for FiscalDepositExchangeGain 
            /// </summary>
            public const string FiscalDepositExchangeGain = "RECDPGAIN";

            /// <summary>
            /// Property for FiscalDepositExchangeLoss 
            /// </summary>
            public const string FiscalDepositExchangeLoss = "RECDPLOSS";

            /// <summary>
            /// Property for FiscalDepositCreditCardCharg 
            /// </summary>
            public const string FiscalDepositCreditCardCharg = "RECDPCCC";

            /// <summary>
            /// Property for FiscalDepositCleared 
            /// </summary>
            public const string FiscalDepositCleared = "RECDPCLR";

            /// <summary>
            /// Property for FiscalDepositTotal 
            /// </summary>
            public const string FiscalDepositTotal = "RECDPFUNAM";

            /// <summary>
            /// Property for FiscalWithdrawalClearedToFut 
            /// </summary>
            public const string FiscalWithdrawalClearedToFut = "RECWFCLR";

            /// <summary>
            /// Property for FiscalDepositClearedToFuture 
            /// </summary>
            public const string FiscalDepositClearedToFuture = "RECDFCLR";

            /// <summary>
            /// Property for WithdrawalFunctionalTotal 
            /// </summary>
            public const string WithdrawalFunctionalTotal = "FUNWTAMT";

            /// <summary>
            /// Property for FiscalWithdrawalFunctionalTot 
            /// </summary>
            public const string FiscalWithdrawalFunctionalTot = "FUNWPAMT";

            /// <summary>
            /// Property for DepositFunctionalTotal 
            /// </summary>
            public const string DepositFunctionalTotal = "FUNDTAMT";

            /// <summary>
            /// Property for FiscalDepositFunctionalTotal 
            /// </summary>
            public const string FiscalDepositFunctionalTotal = "FUNDPAMT";

            /// <summary>
            /// Property for TaxGroupCode 
            /// </summary>
            public const string TaxGroupCode = "CODETXGRP";

            /// <summary>
            /// Property for TaxAuthorization1 
            /// </summary>
            public const string TaxAuthorization1 = "TAXAUTH1";

            /// <summary>
            /// Property for TaxAuthorization2 
            /// </summary>
            public const string TaxAuthorization2 = "TAXAUTH2";

            /// <summary>
            /// Property for TaxAuthorization3 
            /// </summary>
            public const string TaxAuthorization3 = "TAXAUTH3";

            /// <summary>
            /// Property for TaxAuthorization4 
            /// </summary>
            public const string TaxAuthorization4 = "TAXAUTH4";

            /// <summary>
            /// Property for TaxAuthorization5 
            /// </summary>
            public const string TaxAuthorization5 = "TAXAUTH5";

            /// <summary>
            /// Property for VendorTaxClass1 
            /// </summary>
            public const string VendorTaxClass1 = "TXVCLSS1";

            /// <summary>
            /// Property for VendorTaxClass2 
            /// </summary>
            public const string VendorTaxClass2 = "TXVCLSS2";

            /// <summary>
            /// Property for VendorTaxClass3 
            /// </summary>
            public const string VendorTaxClass3 = "TXVCLSS3";

            /// <summary>
            /// Property for VendorTaxClass4 
            /// </summary>
            public const string VendorTaxClass4 = "TXVCLSS4";

            /// <summary>
            /// Property for VendorTaxClass5 
            /// </summary>
            public const string VendorTaxClass5 = "TXVCLSS5";

            /// <summary>
            /// Property for DaysBeforeEligibleforClearin 
            /// </summary>
            public const string DaysBeforeEligibleforClearin = "AGEPURGE";

            //TODO: The naming convention of this property has to be relooked         /// <summary>
            /// Property for POSTDATE 
            ///
            public const string POSTDATE = "POSTDATE";

            //TODO: The naming convention of this property has to be relooked         /// <summary>
            /// Property for LSTPOSTDAT 
            /// 
            public const string LSTPOSTDAT = "LSTPOSTDAT";

            /// <summary>
            /// Property for LastAvailableStatementBalance 
            /// </summary>
            public const string LastAvailableStatementBalance = "LSTSTMTBAL";

            /// <summary>
            /// Property for DefaultReconciliationDescripti 
            /// </summary>
            public const string DefaultReconciliationDescripti = "RECCOMMENT";

            /// <summary>
            /// Property for Status string value 
            /// </summary>
            public const string StatusString = "INACTIVE";

            /// <summary>
            /// Property for Multicurrencystring string value 
            /// </summary>
            public const string MulticurrencyString = "MULTICUR";

            /// <summary>
            /// Property for CalculateFiscalPeriodData string value 
            /// </summary>
            public const string CalculateFiscalPeriodDataString = "RECRECALC";

            /// <summary>
            /// Property for DifferenceofBankEntriesToFi
            /// </summary>
            public const string DifferenceofBankEntriesToFi = "RECFCBKENT";

            /// <summary>
            /// Property for BankingCloudAccount
            /// </summary>
            public const string BankingCloudAccount = "BCACCT";

            /// <summary>
            /// Property for Banking Cloud IsConnected boolean
            /// </summary>
            public const string BankingCloudConnected = "BCCONNECT";

            /// <summary>
            /// Property for BankingCloudLastIndex
            /// </summary>
            public const string BankingCloudLastIndex = "BCLSTIDX";

            #endregion
        }

        /// <summary>
        /// Contains list of Banks Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for AddressLine1 
            /// </summary>
            public const int AddressLine1 = 3;

            /// <summary>
            /// Property Indexer for AddressLine2 
            /// </summary>
            public const int AddressLine2 = 4;

            /// <summary>
            /// Property Indexer for AddressLine3 
            /// </summary>
            public const int AddressLine3 = 5;

            /// <summary>
            /// Property Indexer for AddressLine4 
            /// </summary>
            public const int AddressLine4 = 6;

            /// <summary>
            /// Property Indexer for City 
            /// </summary>
            public const int City = 7;

            /// <summary>
            /// Property Indexer for StateOrProvince 
            /// </summary>
            public const int StateOrProvince = 8;

            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
            public const int Country = 9;

            /// <summary>
            /// Property Indexer for ZipOrPostalCode 
            /// </summary>
            public const int ZipOrPostalCode = 10;

            /// <summary>
            /// Property Indexer for Contact 
            /// </summary>
            public const int Contact = 11;

            /// <summary>
            /// Property Indexer for PhoneNumber 
            /// </summary>
            public const int PhoneNumber = 14;

            /// <summary>
            /// Property Indexer for FaxNumber 
            /// </summary>
            public const int FaxNumber = 15;

            /// <summary>
            /// Property Indexer for TransitNumber 
            /// </summary>
            public const int TransitNumber = 16;

            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 17;

            /// <summary>
            /// Property Indexer for StatementCurrency 
            /// </summary>
            public const int StatementCurrency = 18;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 19;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 20;

            /// <summary>
            /// Property Indexer for BankAccountNumber 
            /// </summary>
            public const int BankAccountNumber = 21;

            /// <summary>
            /// Property Indexer for BankAccount 
            /// </summary>
            public const int BankAccount = 23;

            /// <summary>
            /// Property Indexer for WriteOffAccount 
            /// </summary>
            public const int WriteOffAccount = 24;

            /// <summary>
            /// Property Indexer for ErrorSpread 
            /// </summary>
            public const int ErrorSpread = 25;

            /// <summary>
            /// Property Indexer for LastMaintained 
            /// </summary>
            public const int LastMaintained = 26;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 27;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 28;

            /// <summary>
            /// Property Indexer for LastReconciliationYear 
            /// </summary>
            public const int LastReconciliationYear = 29;

            /// <summary>
            /// Property Indexer for LastReconciliationPeriod 
            /// </summary>
            public const int LastReconciliationPeriod = 30;

            //TODO: The naming convention of this property has to be relooked        
            /// <summary>
            /// Property Indexer for RECLSTDATE 
            /// </summary>
            public const int RECLSTDATE = 31;

            /// <summary>
            /// Property Indexer for LastClosingStatementBalance 
            /// </summary>
            public const int LastClosingStatementBalance = 32;

            //TODO: The naming convention of this property has to be relooked       
            /// <summary>
            /// Property Indexer for RECDATE 
            /// </summary>
            public const int RECDATE = 33;

            /// <summary>
            /// Property Indexer for StatementDate 
            /// </summary>
            public const int StatementDate = 34;

            /// <summary>
            /// Property Indexer for StatementBalance 
            /// </summary>
            public const int StatementBalance = 35;

            /// <summary>
            /// Property Indexer for DepositsinTransit 
            /// </summary>
            public const int DepositsinTransit = 36;

            /// <summary>
            /// Property Indexer for ChecksOutstanding 
            /// </summary>
            public const int ChecksOutstanding = 37;

            /// <summary>
            /// Property Indexer for BankErrors 
            /// </summary>
            public const int BankErrors = 38;

            /// <summary>
            /// Property Indexer for TotalNotPostedBankEntries 
            /// </summary>
            public const int TotalNotPostedBankEntries = 39;

            /// <summary>
            /// Property Indexer for WriteOffs 
            /// </summary>
            public const int WriteOffs = 40;

            /// <summary>
            /// Property Indexer for ExchangeGain 
            /// </summary>
            public const int ExchangeGain = 41;

            /// <summary>
            /// Property Indexer for ExchangeLoss 
            /// </summary>
            public const int ExchangeLoss = 42;

            /// <summary>
            /// Property Indexer for TotalDeposits 
            /// </summary>
            public const int TotalDeposits = 43;

            /// <summary>
            /// Property Indexer for TotalChecks 
            /// </summary>
            public const int TotalChecks = 44;

            /// <summary>
            /// Property Indexer for DepositsToFiscalPeriod 
            /// </summary>
            public const int DepositsToFiscalPeriod = 45;

            /// <summary>
            /// Property Indexer for ChecksToFiscalPeriod 
            /// </summary>
            public const int ChecksToFiscalPeriod = 46;

            /// <summary>
            /// Property Indexer for DepositsInTransitToFiscPer 
            /// </summary>
            public const int DepositsInTransitToFiscPer = 47;

            /// <summary>
            /// Property Indexer for ChecksOutstandingToFiscPer 
            /// </summary>
            public const int ChecksOutstandingToFiscPer = 48;

            /// <summary>
            /// Property Indexer for CalculateFiscalPeriodData 
            /// </summary>
            public const int CalculateFiscalPeriodData = 49;

            /// <summary>
            /// Property Indexer for LastStatementDate 
            /// </summary>
            public const int LastStatementDate = 50;

            /// <summary>
            /// Property Indexer for DifferenceofBankEntriesToFi 
            /// </summary>
            public const int DifferenceofBankEntriesToFi = 51;

            /// <summary>
            /// Property Indexer for ExchangeGainToFiscalPeriod 
            /// </summary>
            public const int ExchangeGainToFiscalPeriod = 52;

            /// <summary>
            /// Property Indexer for ExchangeLossToFiscalPeriod 
            /// </summary>
            public const int ExchangeLossToFiscalPeriod = 53;

            /// <summary>
            /// Property Indexer for BankErrorPendingToFiscalPer 
            /// </summary>
            public const int BankErrorPendingToFiscalPer = 54;

            /// <summary>
            /// Property Indexer for BankErrorToFiscalPeriod 
            /// </summary>
            public const int BankErrorToFiscalPeriod = 55;

            /// <summary>
            /// Property Indexer for TotalNotPostedBankEntriesTo 
            /// </summary>
            public const int TotalNotPostedBankEntriesTo = 56;

            /// <summary>
            /// Property Indexer for CreditCardChargesAccount 
            /// </summary>
            public const int CreditCardChargesAccount = 57;

            /// <summary>
            /// Property Indexer for CreditCardChargeSpread 
            /// </summary>
            public const int CreditCardChargeSpread = 58;

            /// <summary>
            /// Property Indexer for ExchangeRateDifferenceSpread 
            /// </summary>
            public const int ExchangeRateDifferenceSpread = 59;

            /// <summary>
            /// Property Indexer for AdjustedBookBalance 
            /// </summary>
            public const int AdjustedBookBalance = 70;

            /// <summary>
            /// Property Indexer for AdjustedStatementBalance 
            /// </summary>
            public const int AdjustedStatementBalance = 71;

            /// <summary>
            /// Property Indexer for BankReconciliationBalanced 
            /// </summary>
            public const int BankReconciliationBalanced = 72;

            /// <summary>
            /// Property Indexer for OutOfBalanceBy 
            /// </summary>
            public const int OutOfBalanceBy = 73;

            /// <summary>
            /// Property Indexer for NextCheckSerialNumber 
            /// </summary>
            public const int NextCheckSerialNumber = 74;

            /// <summary>
            /// Property Indexer for NextDepositSlipNumber 
            /// </summary>
            public const int NextDepositSlipNumber = 75;

            /// <summary>
            /// Property Indexer for NextDepositUniquifier 
            /// </summary>
            public const int NextDepositUniquifier = 76;

            /// <summary>
            /// Property Indexer for CurrentBalance 
            /// </summary>
            public const int CurrentBalance = 77;

            /// <summary>
            /// Property Indexer for BookBalance 
            /// </summary>
            public const int BookBalance = 78;

            /// <summary>
            /// Property Indexer for BankStatementType 
            /// </summary>
            public const int BankStatementType = 79;

            /// <summary>
            /// Property Indexer for TotalWriteOffs 
            /// </summary>
            public const int TotalWriteOffs = 80;

            /// <summary>
            /// Property Indexer for TotalCreditCardCharges 
            /// </summary>
            public const int TotalCreditCardCharges = 81;

            /// <summary>
            /// Property Indexer for FiscalPeriodWriteOff 
            /// </summary>
            public const int FiscalPeriodWriteOff = 82;

            /// <summary>
            /// Property Indexer for FiscalPeriodCreditCardCharge 
            /// </summary>
            public const int FiscalPeriodCreditCardCharge = 83;

            /// <summary>
            /// Property Indexer for SumofWithdrawalTotalWriteOf 
            /// </summary>
            public const int SumofWithdrawalTotalWriteOf = 84;

            /// <summary>
            /// Property Indexer for SumofDepositTotalWriteOffs 
            /// </summary>
            public const int SumofDepositTotalWriteOffs = 85;

            /// <summary>
            /// Property Indexer for SumofWithdrawalFiscalWriteO 
            /// </summary>
            public const int SumofWithdrawalFiscalWriteO = 86;

            /// <summary>
            /// Property Indexer for SumofDepositFiscalWriteOffs 
            /// </summary>
            public const int SumofDepositFiscalWriteOffs = 87;

            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 88;

            /// <summary>
            /// Property Indexer for TotalRemainingOutStanding 
            /// </summary>
            public const int TotalRemainingOutStanding = 89;

            /// <summary>
            /// Property Indexer for FiscalRemainingOutStanding 
            /// </summary>
            public const int FiscalRemainingOutStanding = 90;

            /// <summary>
            /// Property Indexer for TotalRemainingInTransit 
            /// </summary>
            public const int TotalRemainingInTransit = 91;

            /// <summary>
            /// Property Indexer for FiscalRemainingInTransit 
            /// </summary>
            public const int FiscalRemainingInTransit = 92;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalClearedToCur 
            /// </summary>
            public const int FiscalWithdrawalClearedToCur = 93;

            /// <summary>
            /// Property Indexer for FiscalDepositClearedToCurren 
            /// </summary>
            public const int FiscalDepositClearedToCurren = 94;

            /// <summary>
            /// Property Indexer for TaxGroupDescription 
            /// </summary>
            public const int TaxGroupDescription = 95;

            /// <summary>
            /// Property Indexer for TaxAuthorizationDescription1 
            /// </summary>
            public const int TaxAuthorizationDescription1 = 96;

            /// <summary>
            /// Property Indexer for TaxAuthorizationDescription2 
            /// </summary>
            public const int TaxAuthorizationDescription2 = 97;

            /// <summary>
            /// Property Indexer for TaxAuthorizationDescription3 
            /// </summary>
            public const int TaxAuthorizationDescription3 = 98;

            /// <summary>
            /// Property Indexer for TaxAuthorizationDescription4 
            /// </summary>
            public const int TaxAuthorizationDescription4 = 99;

            /// <summary>
            /// Property Indexer for TaxAuthorizationDescription5 
            /// </summary>
            public const int TaxAuthorizationDescription5 = 100;

            /// <summary>
            /// Property Indexer for VendorTaxClassDescription1 
            /// </summary>
            public const int VendorTaxClassDescription1 = 101;

            /// <summary>
            /// Property Indexer for VendorTaxClassDescription2 
            /// </summary>
            public const int VendorTaxClassDescription2 = 102;

            /// <summary>
            /// Property Indexer for VendorTaxClassDescription3 
            /// </summary>
            public const int VendorTaxClassDescription3 = 103;

            /// <summary>
            /// Property Indexer for VendorTaxClassDescription4 
            /// </summary>
            public const int VendorTaxClassDescription4 = 104;

            /// <summary>
            /// Property Indexer for VendorTaxClassDescription5 
            /// </summary>
            public const int VendorTaxClassDescription5 = 105;

            /// <summary>
            /// Property Indexer for NextSerialNumber 
            /// </summary>
            public const int NextSerialNumber = 106;

            /// <summary>
            /// Property Indexer for DepositClearedwithExchangeRa 
            /// </summary>
            public const int DepositClearedwithExchangeRa = 107;

            /// <summary>
            /// Property Indexer for WithdrawalsClearedwithExchR 
            /// </summary>
            public const int WithdrawalsClearedwithExchR = 108;

            /// <summary>
            /// Property Indexer for TotalWithdrawalBankErrors 
            /// </summary>
            public const int TotalWithdrawalBankErrors = 150;

            /// <summary>
            /// Property Indexer for TotalWithdrawalWriteOffs 
            /// </summary>
            public const int TotalWithdrawalWriteOffs = 151;

            /// <summary>
            /// Property Indexer for TotalWithdrawalExchangeGain 
            /// </summary>
            public const int TotalWithdrawalExchangeGain = 152;

            /// <summary>
            /// Property Indexer for TotalWithdrawalExchangeLoss 
            /// </summary>
            public const int TotalWithdrawalExchangeLoss = 153;

            /// <summary>
            /// Property Indexer for TotalWithdrawalCreditCardCha 
            /// </summary>
            public const int TotalWithdrawalCreditCardCha = 154;

            /// <summary>
            /// Property Indexer for TotalWithdrawalCleared 
            /// </summary>
            public const int TotalWithdrawalCleared = 155;

            /// <summary>
            /// Property Indexer for WithdrawalTotal 
            /// </summary>
            public const int WithdrawalTotal = 156;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalBankErrors 
            /// </summary>
            public const int FiscalWithdrawalBankErrors = 157;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalWriteOffs 
            /// </summary>
            public const int FiscalWithdrawalWriteOffs = 158;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalExchangeGain 
            /// </summary>
            public const int FiscalWithdrawalExchangeGain = 159;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalExchangeLoss 
            /// </summary>
            public const int FiscalWithdrawalExchangeLoss = 160;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalCreditCardCh 
            /// </summary>
            public const int FiscalWithdrawalCreditCardCh = 161;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalCleared 
            /// </summary>
            public const int FiscalWithdrawalCleared = 162;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalTotal 
            /// </summary>
            public const int FiscalWithdrawalTotal = 163;

            /// <summary>
            /// Property Indexer for TotalDepositBankErrors 
            /// </summary>
            public const int TotalDepositBankErrors = 164;

            /// <summary>
            /// Property Indexer for TotalDepositWriteOffs 
            /// </summary>
            public const int TotalDepositWriteOffs = 165;

            /// <summary>
            /// Property Indexer for TotalDepositExchangeGain 
            /// </summary>
            public const int TotalDepositExchangeGain = 166;

            /// <summary>
            /// Property Indexer for TotalDepositExchangeLoss 
            /// </summary>
            public const int TotalDepositExchangeLoss = 167;

            /// <summary>
            /// Property Indexer for TotalDepositCreditCardCharge 
            /// </summary>
            public const int TotalDepositCreditCardCharge = 168;

            /// <summary>
            /// Property Indexer for TotalDepositCleared 
            /// </summary>
            public const int TotalDepositCleared = 169;

            /// <summary>
            /// Property Indexer for DepositTotal 
            /// </summary>
            public const int DepositTotal = 170;

            /// <summary>
            /// Property Indexer for FiscalDepositBankErrors 
            /// </summary>
            public const int FiscalDepositBankErrors = 171;

            /// <summary>
            /// Property Indexer for FiscalDepositWriteOffs 
            /// </summary>
            public const int FiscalDepositWriteOffs = 172;

            /// <summary>
            /// Property Indexer for FiscalDepositExchangeGain 
            /// </summary>
            public const int FiscalDepositExchangeGain = 173;

            /// <summary>
            /// Property Indexer for FiscalDepositExchangeLoss 
            /// </summary>
            public const int FiscalDepositExchangeLoss = 174;

            /// <summary>
            /// Property Indexer for FiscalDepositCreditCardCharg 
            /// </summary>
            public const int FiscalDepositCreditCardCharg = 175;

            /// <summary>
            /// Property Indexer for FiscalDepositCleared 
            /// </summary>
            public const int FiscalDepositCleared = 176;

            /// <summary>
            /// Property Indexer for FiscalDepositTotal 
            /// </summary>
            public const int FiscalDepositTotal = 177;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalClearedToFut 
            /// </summary>
            public const int FiscalWithdrawalClearedToFut = 178;

            /// <summary>
            /// Property Indexer for FiscalDepositClearedToFuture 
            /// </summary>
            public const int FiscalDepositClearedToFuture = 179;

            /// <summary>
            /// Property Indexer for WithdrawalFunctionalTotal 
            /// </summary>
            public const int WithdrawalFunctionalTotal = 180;

            /// <summary>
            /// Property Indexer for FiscalWithdrawalFunctionalTot 
            /// </summary>
            public const int FiscalWithdrawalFunctionalTot = 181;

            /// <summary>
            /// Property Indexer for DepositFunctionalTotal 
            /// </summary>
            public const int DepositFunctionalTotal = 182;

            /// <summary>
            /// Property Indexer for FiscalDepositFunctionalTotal 
            /// </summary>
            public const int FiscalDepositFunctionalTotal = 183;

            /// <summary>
            /// Property Indexer for TaxGroupCode 
            /// </summary>
            public const int TaxGroupCode = 184;

            /// <summary>
            /// Property Indexer for TaxAuthorization1 
            /// </summary>
            public const int TaxAuthorization1 = 185;

            /// <summary>
            /// Property Indexer for TaxAuthorization2 
            /// </summary>
            public const int TaxAuthorization2 = 186;

            /// <summary>
            /// Property Indexer for TaxAuthorization3 
            /// </summary>
            public const int TaxAuthorization3 = 187;

            /// <summary>
            /// Property Indexer for TaxAuthorization4 
            /// </summary>
            public const int TaxAuthorization4 = 188;

            /// <summary>
            /// Property Indexer for TaxAuthorization5 
            /// </summary>
            public const int TaxAuthorization5 = 189;

            /// <summary>
            /// Property Indexer for VendorTaxClass1 
            /// </summary>
            public const int VendorTaxClass1 = 190;

            /// <summary>
            /// Property Indexer for VendorTaxClass2 
            /// </summary>
            public const int VendorTaxClass2 = 191;

            /// <summary>
            /// Property Indexer for VendorTaxClass3 
            /// </summary>
            public const int VendorTaxClass3 = 192;

            /// <summary>
            /// Property Indexer for VendorTaxClass4 
            /// </summary>
            public const int VendorTaxClass4 = 193;

            /// <summary>
            /// Property Indexer for VendorTaxClass5 
            /// </summary>
            public const int VendorTaxClass5 = 194;

            /// <summary>
            /// Property Indexer for DaysBeforeEligibleforClearin 
            /// </summary>
            public const int DaysBeforeEligibleforClearin = 195;

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property Indexer for POSTDATE 
            /// </summary>
            public const int POSTDATE = 196;

            //TODO: The naming convention of this property has to be relooked         
            /// <summary>
            /// Property Indexer for LSTPOSTDAT 
            /// </summary>
            public const int LSTPOSTDAT = 197;

            /// <summary>
            /// Property Indexer for LastAvailableStatementBalance 
            /// </summary>
            public const int LastAvailableStatementBalance = 198;

            /// <summary>
            /// Property Indexer for DefaultReconciliationDescripti 
            /// </summary>
            public const int DefaultReconciliationDescripti = 199;

            /// <summary>
            /// Property for BankingCloudAccount
            /// </summary>
            public const int BankingCloudAccount= 200;

            /// <summary>
            /// Property for Banking Cloud IsConnected boolean
            /// </summary>
            public const int BankingCloudConnected = 201;

            /// <summary>
            /// Property Indexer for BankingCloudLastIndex
            /// </summary>
            public const int BankingCloudLastIndex = 202;

            #endregion
        }
    }
}