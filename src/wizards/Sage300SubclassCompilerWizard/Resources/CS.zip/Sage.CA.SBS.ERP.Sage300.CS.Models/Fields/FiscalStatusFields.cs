﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Class FiscalStatus
    /// </summary>
    public partial class FiscalStatus
    {
        #region Public Field

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "CS0060";

        #endregion

        /// <summary>
        /// Contains list of Fiscal Statuses Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Fiscal Year 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";

            /// <summary>
            /// Property for Application 
            /// </summary>
            public const string Application = "PGMID";

            /// <summary>
            /// Property for Period 1 Status 
            /// </summary>
            public const string Period1Status = "STATUS1";

            /// <summary>
            /// Property for Period 2 Status 
            /// </summary>
            public const string Period2Status = "STATUS2";

            /// <summary>
            /// Property for Period 3 Status 
            /// </summary>
            public const string Period3Status = "STATUS3";

            /// <summary>
            /// Property for Period 4 Status 
            /// </summary>
            public const string Period4Status = "STATUS4";

            /// <summary>
            /// Property for Period 5 Status 
            /// </summary>
            public const string Period5Status = "STATUS5";

            /// <summary>
            /// Property for Period 6 Status 
            /// </summary>
            public const string Period6Status = "STATUS6";

            /// <summary>
            /// Property for Period 7 Status 
            /// </summary>
            public const string Period7Status = "STATUS7";

            /// <summary>
            /// Property for Period 8 Status 
            /// </summary>
            public const string Period8Status = "STATUS8";

            /// <summary>
            /// Property for Period 9 Status 
            /// </summary>
            public const string Period9Status = "STATUS9";

            /// <summary>
            /// Property for Period 10 Status 
            /// </summary>
            public const string Period10Status = "STATUS10";

            /// <summary>
            /// Property for Period 11 Status 
            /// </summary>
            public const string Period11Status = "STATUS11";

            /// <summary>
            /// Property for Period 12 Status 
            /// </summary>
            public const string Period12Status = "STATUS12";

            /// <summary>
            /// Property for Period 13 Status 
            /// </summary>
            public const string Period13Status = "STATUS13";

            #endregion
        }

        /// <summary>
        /// Contains list of FiscalStatuses Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Fiscal Year 
            /// </summary>
            public const int FiscalYear = 1;

            /// <summary>
            /// Property Indexer for Application 
            /// </summary>
            public const int Application = 2;

            /// <summary>
            /// Property Indexer for Period 1 Status 
            /// </summary>
            public const int Period1Status = 3;

            /// <summary>
            /// Property Indexer for Period 2 Status 
            /// </summary>
            public const int Period2Status = 4;

            /// <summary>
            /// Property Indexer for Period 3 Status 
            /// </summary>
            public const int Period3Status = 5;

            /// <summary>
            /// Property Indexer for Period 4 Status 
            /// </summary>
            public const int Period4Status = 6;

            /// <summary>
            /// Property Indexer for Period 5 Status 
            /// </summary>
            public const int Period5Status = 7;

            /// <summary>
            /// Property Indexer for Period 6 Status 
            /// </summary>
            public const int Period6Status = 8;

            /// <summary>
            /// Property Indexer for Period 7 Status 
            /// </summary>
            public const int Period7Status = 9;

            /// <summary>
            /// Property Indexer for Period 8 Status 
            /// </summary>
            public const int Period8Status = 10;

            /// <summary>
            /// Property Indexer for Period 9 Status 
            /// </summary>
            public const int Period9Status = 11;

            /// <summary>
            /// Property Indexer for Period 10 Status 
            /// </summary>
            public const int Period10Status = 12;

            /// <summary>
            /// Property Indexer for Period 11 Status 
            /// </summary>
            public const int Period11Status = 13;

            /// <summary>
            /// Property Indexer for Period 12 Status 
            /// </summary>
            public const int Period12Status = 14;

            /// <summary>
            /// Property Indexer for Period 13 Status 
            /// </summary>
            public const int Period13Status = 15;

            #endregion
        }
    }
}