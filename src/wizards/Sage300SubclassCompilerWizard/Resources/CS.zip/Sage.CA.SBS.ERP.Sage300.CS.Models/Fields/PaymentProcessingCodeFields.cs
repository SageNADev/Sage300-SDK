﻿
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of ProcessingCodes Constants 
    /// </summary>
    public partial class PaymentProcessingCode
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "YP0500";

        /// <summary>
        /// Contains list of ProcessingCodes Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for ProcessingCode 
            /// </summary>
            public const string ProcessingCode = "PROCESSCOD";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Bank 
            /// </summary>
            public const string Bank = "BANK";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CURRENCY";
            /// <summary>
            /// Property for MerchantID 
            /// </summary>
            public const string MerchantID = "MERCHID";
            /// <summary>
            /// Property for MerchantInformation 
            /// </summary>
            public const string MerchantInformation = "MERCHINFO";
            /// <summary>
            /// Property for CurrencyDescription 
            /// </summary>
            public const string CurrencyDescription = "CURRENCYD";
            /// <summary>
            /// Property for BankDescription 
            /// </summary>
            public const string BankDescription = "BANKD";
            /// <summary>
            /// Property for MerchantKey 
            /// </summary>
            public const string MerchantKey = "MERCHKEY";

            #endregion
        }


        /// <summary>
        /// Contains list of ProcessingCodes Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ProcessingCode 
            /// </summary>
            public const int ProcessingCode = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Bank 
            /// </summary>
            public const int Bank = 3;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 4;
            /// <summary>
            /// Property Indexer for MerchantID 
            /// </summary>
            public const int MerchantID = 5;
            /// <summary>
            /// Property Indexer for MerchantInformation 
            /// </summary>
            public const int MerchantInformation = 6;
            /// <summary>
            /// Property Indexer for CurrencyDescription 
            /// </summary>
            public const int CurrencyDescription = 20;
            /// <summary>
            /// Property Indexer for BankDescription 
            /// </summary>
            public const int BankDescription = 22;
            /// <summary>
            /// Property Indexer for MerchantKey 
            /// </summary>
            public const int MerchantKey = 23;

            #endregion
        }


    }
}
	
