// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
     /// <summary>
     /// Contains list of SPSXML Constants
     /// </summary>
     public partial class SPSXML
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "YP0501";

          #region Properties
          /// <summary>
          /// Contains list of SPSXML Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Bank
               /// </summary>
               public const string Bank = "BANK";

               /// <summary>
               /// Property for CurrencyCode
               /// </summary>
               public const string CurrencyCode = "CODECURN";

               /// <summary>
               /// Property for Action
               /// </summary>
               public const string Action = "ACTION";

               /// <summary>
               /// Property for TransactionID
               /// </summary>
               public const string TransactionID = "TRANSID";

               /// <summary>
               /// Property for ResponseIndicator
               /// </summary>
               public const string ResponseIndicator = "RESPIND";

               /// <summary>
               /// Property for ResponseCode
               /// </summary>
               public const string ResponseCode = "RESPCD";

               /// <summary>
               /// Property for ResponseMessage
               /// </summary>
               public const string ResponseMessage = "RESPMSG";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for GUID
               /// </summary>
               public const string GUID = "GUID";

               /// <summary>
               /// Property for ExpireDate
               /// </summary>
               public const string ExpireDate = "Expdate";

               /// <summary>
               /// Property for Last4
               /// </summary>
               public const string Last4 = "LAST4";

               /// <summary>
               /// Property for PaymentDescription
               /// </summary>
               public const string PaymentDescription = "PMTDESC";

               /// <summary>
               /// Property for PaymentTypeID
               /// </summary>
               public const string PaymentTypeID = "PMTTYPEID";

               /// <summary>
               /// Property for Reference1
               /// </summary>
               public const string Reference1 = "REF1";

               /// <summary>
               /// Property for Reference2
               /// </summary>
               public const string Reference2 = "REF2";

               /// <summary>
               /// Property for Amount
               /// </summary>
               public const string Amount = "AMOUNT";

               /// <summary>
               /// Property for AuthorizationCode
               /// </summary>
               public const string AuthorizationCode = "AUTHCODE";

               /// <summary>
               /// Property for VANReference
               /// </summary>
               public const string VANReference = "VANREF";

               /// <summary>
               /// Property for Name
               /// </summary>
               public const string Name = "NAME";

               /// <summary>
               /// Property for AddressLine1
               /// </summary>
               public const string AddressLine1 = "ADDR1";

               /// <summary>
               /// Property for AddressLine2
               /// </summary>
               public const string AddressLine2 = "ADDR2";

               /// <summary>
               /// Property for City
               /// </summary>
               public const string City = "CITY";

               /// <summary>
               /// Property for State
               /// </summary>
               public const string State = "STATE";

               /// <summary>
               /// Property for ZipCode
               /// </summary>
               public const string ZipCode = "ZIPCODE";

               /// <summary>
               /// Property for Country
               /// </summary>
               public const string Country = "COUNTRY";

               /// <summary>
               /// Property for Email
               /// </summary>
               public const string Email = "EMAIL";

               /// <summary>
               /// Property for Telephone
               /// </summary>
               public const string Telephone = "TEL";

               /// <summary>
               /// Property for Fax
               /// </summary>
               public const string Fax = "FAX";

               /// <summary>
               /// Property for AVSResult
               /// </summary>
               public const string AVSResult = "AVSRESULT";

               /// <summary>
               /// Property for CVVResult
               /// </summary>
               public const string CVVResult = "CVVRESULT";

               /// <summary>
               /// Property for TransactionDate
               /// </summary>
               public const string TransactionDate = "TRANSDATE";

               /// <summary>
               /// Property for BatchReference
               /// </summary>
               public const string BatchReference = "BATCHREF";

               /// <summary>
               /// Property for SettlementType
               /// </summary>
               public const string SettlementType = "SETLTYPE";

               /// <summary>
               /// Property for SettlementDate
               /// </summary>
               public const string SettlementDate = "SETLDATE";

               /// <summary>
               /// Property for TransactionType
               /// </summary>
               public const string TransactionType = "TRANSTYPE";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for CUSTNMB
               /// </summary>
               public const string CUSTNMB = "CUSTNMB";

               /// <summary>
               /// Property for TaxAmount
               /// </summary>
               public const string TaxAmount = "TAXAMOUNT";

               /// <summary>
               /// Property for ProcessingCode
               /// </summary>
               public const string ProcessingCode = "PROCESSCOD";

               /// <summary>
               /// Property for MerchantID
               /// </summary>
               public const string MerchantID = "MERCHID";

               /// <summary>
               /// Property for MerchantInfo
               /// </summary>
               public const string MerchantInfo = "MERCHINFO";

               /// <summary>
               /// Property for Active
               /// </summary>
               public const string Active = "ACTIVE";

               /// <summary>
               /// Property for XMLString
               /// </summary>
               public const string XMLString = "XMLSTRING";

               /// <summary>
               /// Property for ResponseIslogged
               /// </summary>
               public const string ResponseIslogged = "ISLOGGED";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for IDCUST
               /// </summary>
               public const string IDCUST = "IDCUST";

               /// <summary>
               /// Property for CardID
               /// </summary>
               public const string CardID = "IDCARD";

               /// <summary>
               /// Property for DocumentNumber
               /// </summary>
               public const string DocumentNumber = "DOCNUMBER";

               /// <summary>
               /// Property for CardDescription
               /// </summary>
               public const string CardDescription = "CARDDESC";

               /// <summary>
               /// Property for CardComment
               /// </summary>
               public const string CardComment = "CARDCMNT";

               /// <summary>
               /// Property for SPSRequestProcessCompletedFl
               /// </summary>
               public const string SPSRequestProcessCompletedFl = "ISCOMPLETE";

               /// <summary>
               /// Property for Application
               /// </summary>
               public const string Application = "APP";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of SPSXML Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Bank
               /// </summary>
               public const int Bank = 1;

               /// <summary>
               /// Property Indexer for CurrencyCode
               /// </summary>
               public const int CurrencyCode = 2;

               /// <summary>
               /// Property Indexer for Action
               /// </summary>
               public const int Action = 3;

               /// <summary>
               /// Property Indexer for TransactionID
               /// </summary>
               public const int TransactionID = 4;

               /// <summary>
               /// Property Indexer for ResponseIndicator
               /// </summary>
               public const int ResponseIndicator = 5;

               /// <summary>
               /// Property Indexer for ResponseCode
               /// </summary>
               public const int ResponseCode = 6;

               /// <summary>
               /// Property Indexer for ResponseMessage
               /// </summary>
               public const int ResponseMessage = 7;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for GUID
               /// </summary>
               public const int GUID = 8;

               /// <summary>
               /// Property Indexer for ExpireDate
               /// </summary>
               public const int ExpireDate = 9;

               /// <summary>
               /// Property Indexer for Last4
               /// </summary>
               public const int Last4 = 10;

               /// <summary>
               /// Property Indexer for PaymentDescription
               /// </summary>
               public const int PaymentDescription = 11;

               /// <summary>
               /// Property Indexer for PaymentTypeID
               /// </summary>
               public const int PaymentTypeID = 12;

               /// <summary>
               /// Property Indexer for Reference1
               /// </summary>
               public const int Reference1 = 13;

               /// <summary>
               /// Property Indexer for Reference2
               /// </summary>
               public const int Reference2 = 14;

               /// <summary>
               /// Property Indexer for Amount
               /// </summary>
               public const int Amount = 15;

               /// <summary>
               /// Property Indexer for AuthorizationCode
               /// </summary>
               public const int AuthorizationCode = 16;

               /// <summary>
               /// Property Indexer for VANReference
               /// </summary>
               public const int VANReference = 17;

               /// <summary>
               /// Property Indexer for Name
               /// </summary>
               public const int Name = 18;

               /// <summary>
               /// Property Indexer for AddressLine1
               /// </summary>
               public const int AddressLine1 = 19;

               /// <summary>
               /// Property Indexer for AddressLine2
               /// </summary>
               public const int AddressLine2 = 20;

               /// <summary>
               /// Property Indexer for City
               /// </summary>
               public const int City = 21;

               /// <summary>
               /// Property Indexer for State
               /// </summary>
               public const int State = 22;

               /// <summary>
               /// Property Indexer for ZipCode
               /// </summary>
               public const int ZipCode = 23;

               /// <summary>
               /// Property Indexer for Country
               /// </summary>
               public const int Country = 24;

               /// <summary>
               /// Property Indexer for Email
               /// </summary>
               public const int Email = 25;

               /// <summary>
               /// Property Indexer for Telephone
               /// </summary>
               public const int Telephone = 26;

               /// <summary>
               /// Property Indexer for Fax
               /// </summary>
               public const int Fax = 27;

               /// <summary>
               /// Property Indexer for AVSResult
               /// </summary>
               public const int AVSResult = 28;

               /// <summary>
               /// Property Indexer for CVVResult
               /// </summary>
               public const int CVVResult = 29;

               /// <summary>
               /// Property Indexer for TransactionDate
               /// </summary>
               public const int TransactionDate = 30;

               /// <summary>
               /// Property Indexer for BatchReference
               /// </summary>
               public const int BatchReference = 31;

               /// <summary>
               /// Property Indexer for SettlementType
               /// </summary>
               public const int SettlementType = 32;

               /// <summary>
               /// Property Indexer for SettlementDate
               /// </summary>
               public const int SettlementDate = 33;

               /// <summary>
               /// Property Indexer for TransactionType
               /// </summary>
               public const int TransactionType = 34;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for CUSTNMB
               /// </summary>
               public const int CUSTNMB = 35;

               /// <summary>
               /// Property Indexer for TaxAmount
               /// </summary>
               public const int TaxAmount = 36;

               /// <summary>
               /// Property Indexer for ProcessingCode
               /// </summary>
               public const int ProcessingCode = 37;

               /// <summary>
               /// Property Indexer for MerchantID
               /// </summary>
               public const int MerchantID = 38;

               /// <summary>
               /// Property Indexer for MerchantInfo
               /// </summary>
               public const int MerchantInfo = 39;

               /// <summary>
               /// Property Indexer for Active
               /// </summary>
               public const int Active = 40;

               /// <summary>
               /// Property Indexer for XMLString
               /// </summary>
               public const int XMLString = 41;

               /// <summary>
               /// Property Indexer for ResponseIslogged
               /// </summary>
               public const int ResponseIslogged = 51;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for IDCUST
               /// </summary>
               public const int IDCUST = 52;

               /// <summary>
               /// Property Indexer for CardID
               /// </summary>
               public const int CardID = 53;

               /// <summary>
               /// Property Indexer for DocumentNumber
               /// </summary>
               public const int DocumentNumber = 54;

               /// <summary>
               /// Property Indexer for CardDescription
               /// </summary>
               public const int CardDescription = 55;

               /// <summary>
               /// Property Indexer for CardComment
               /// </summary>
               public const int CardComment = 56;

               /// <summary>
               /// Property Indexer for SPSRequestProcessCompletedFl
               /// </summary>
               public const int SPSRequestProcessCompletedFl = 57;

               /// <summary>
               /// Property Indexer for Application
               /// </summary>
               public const int Application = 58;

          }
          #endregion

     }
}
