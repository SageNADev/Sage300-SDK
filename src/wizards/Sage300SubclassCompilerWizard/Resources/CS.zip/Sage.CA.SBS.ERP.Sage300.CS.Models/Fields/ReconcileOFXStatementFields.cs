// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of OFXTransactionMatching Constants 
    /// </summary>
    public partial class ReconcileOFXStatement
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "BK0680";

        /// <summary>
        /// Contains list of OFXTransactionMatching Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for Operation 
            /// </summary>
            public const string Operation = "OPERATION";
            
            /// <summary>
            /// Property for Mode 
            /// </summary>
            public const string Mode = "MODE";
            
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";
            
            /// <summary>
            /// Property for Number 
            /// </summary>
            public const string Number = "NUMBER";
            
            /// <summary>
            /// Property for SerialNumber 
            /// </summary>
            public const string SerialNumber = "SERIAL";
            
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "LINE";

            /// <summary>
            /// Property for OFXID 
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string OFXID = "OFXTID";
            
            /// <summary>
            /// Property for UnmatUniqueID 
            /// </summary>
            public const string UnmatUniqueID = "UNIQUE";
            
            /// <summary>
            /// Property for FromBank 
            /// </summary>
            public const string FromBank = "FROMBANK";
            
            /// <summary>
            /// Property for ToBank 
            /// </summary>
            public const string ToBank = "TOBANK";
            
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "YEAR";
            
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "PERIOD";
            
            /// <summary>
            /// Property for ReconciliationDate 
            /// </summary>
            public const string ReconciliationDate = "RECDATE";
            
            /// <summary>
            /// Property for ReconciliationCutoffDate 
            /// </summary>
            public const string ReconciliationCutoffDate = "CUTDATE";
            
            /// <summary>
            /// Property for TransactionsMatched 
            /// </summary>
            public const string TransactionsMatched = "RECMATCH";
            
            /// <summary>
            /// Property for TotalTransactionsProcessed 
            /// </summary>
            public const string TotalTransactionsProcessed = "TRXNUM";
            
            /// <summary>
            /// Property for TotalTransactionsCleared 
            /// </summary>
            public const string TotalTransactionsCleared = "TRXCLR";
            
            /// <summary>
            /// Property for Autodeletematchedtransactions 
            /// </summary>
            public const string Autodeletematchedtransactions = "AUTODEL";
            
            /// <summary>
            /// Property for SuggestedReconciliationStatus 
            /// </summary>
            public const string SuggestedReconciliationStatus = "RECSUGGEST";
            
            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "POSTDATE";
            
            /// <summary>
            /// Property for MatchDepositsBy 
            /// </summary>
            public const string MatchDepositsBy = "DEPMODE";
            #endregion
        }

        /// <summary>
        /// Contains list of OFXTransactionMatching Index Constants
        /// </summary>
        public class Index
        {
            #region Properties            
            /// <summary>
            /// Property Indexer for Operation 
            /// </summary>
            public const int Operation = 1;
            
            /// <summary>
            /// Property Indexer for Mode 
            /// </summary>
            public const int Mode = 2;
            
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 3;
            
            /// <summary>
            /// Property Indexer for Number 
            /// </summary>
            public const int Number = 4;
            
            /// <summary>
            /// Property Indexer for SerialNumber 
            /// </summary>
            public const int SerialNumber = 5;
            
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 6;

            /// <summary>
            /// Property Indexer for OFXID 
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int OFXID = 7;
            
            /// <summary>
            /// Property Indexer for UnmatUniqueID 
            /// </summary>
            public const int UnmatUniqueID = 8;
            
            /// <summary>
            /// Property Indexer for FromBank 
            /// </summary>
            public const int FromBank = 9;
            
            /// <summary>
            /// Property Indexer for ToBank 
            /// </summary>
            public const int ToBank = 10;
            
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 11;
            
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 12;
            
            /// <summary>
            /// Property Indexer for ReconciliationDate 
            /// </summary>
            public const int ReconciliationDate = 13;
            
            /// <summary>
            /// Property Indexer for ReconciliationCutoffDate 
            /// </summary>
            public const int ReconciliationCutoffDate = 14;
            
            /// <summary>
            /// Property Indexer for TransactionsMatched 
            /// </summary>
            public const int TransactionsMatched = 15;
            
            /// <summary>
            /// Property Indexer for TotalTransactionsProcessed 
            /// </summary>
            public const int TotalTransactionsProcessed = 16;
            
            /// <summary>
            /// Property Indexer for TotalTransactionsCleared 
            /// </summary>
            public const int TotalTransactionsCleared = 17;
            
            /// <summary>
            /// Property Indexer for Autodeletematchedtransactions 
            /// </summary>
            public const int Autodeletematchedtransactions = 18;
            
            /// <summary>
            /// Property Indexer for SuggestedReconciliationStatus 
            /// </summary>
            public const int SuggestedReconciliationStatus = 19;
            
            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 20;
            
            /// <summary>
            /// Property Indexer for MatchDepositsBy 
            /// </summary>
            public const int MatchDepositsBy = 21;
            #endregion
        }
    }
}
