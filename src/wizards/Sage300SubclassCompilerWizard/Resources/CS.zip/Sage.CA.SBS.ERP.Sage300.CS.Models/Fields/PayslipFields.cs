// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of Payslip Constants
    /// </summary>
    public partial class Payslip
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "HQ0004";


        #region Fields Properties

        /// <summary>
        /// Contains list of Payslip Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for PaymentDate
            /// </summary>
            public const string PaymentDate = "TRANSDATE";

            /// <summary>
            /// Property for RecordNumber
            /// </summary>
            public const string RecordNumber = "RECNUM";

            /// <summary>
            /// Property for OriginalModule
            /// </summary>
            public const string OriginalModule = "ORIGINAPP";

            /// <summary>
            /// Property for Employee
            /// </summary>
            public const string Employee = "EMPLOYEE";

            /// <summary>
            /// Property for SelectedForPublishing
            /// </summary>
            public const string SelectedForPublishing = "SELECTED";

            /// <summary>
            /// Property for PublishSetting
            /// </summary>
            public const string PublishSetting = "PUBSETTING";

            /// <summary>
            /// Property for PayslipUploadStatus
            /// </summary>
            public const string PayslipUploadStatus = "PAYSTATUS";

            /// <summary>
            /// Property for SageHRPayslipID
            /// </summary>
            public const string SageHRPayslipID = "PAYSLIPID";

            /// <summary>
            /// Property for CheckPDFUploadStatus
            /// </summary>
            public const string CheckPDFUploadStatus = "PDFSTATUS";

            /// <summary>
            /// Property for CheckPDFFilePath
            /// </summary>
            public const string CheckPDFFilePath = "PDFPATH";

            /// <summary>
            /// Property for PeriodStartDate
            /// </summary>
            public const string PeriodStartDate = "PERSTART";

            /// <summary>
            /// Property for PeriodEndDate
            /// </summary>
            public const string PeriodEndDate = "PEREND";

            /// <summary>
            /// Property for EmployeeLastName
            /// </summary>
            public const string EmployeeLastName = "LASTNAME";

            /// <summary>
            /// Property for EmployeeFirstName
            /// </summary>
            public const string EmployeeFirstName = "FIRSTNAME";

            /// <summary>
            /// Property for EmployeeMiddleName
            /// </summary>
            public const string EmployeeMiddleName = "MIDDLENAME";

            /// <summary>
            /// Property for TotalHours
            /// </summary>
            public const string TotalHours = "TOTHOURS";

            /// <summary>
            /// Property for TotalDeductions
            /// </summary>
            public const string TotalDeductions = "TOTDEDCUR";

            /// <summary>
            /// Property for TotalDeductionsYTD
            /// </summary>
            public const string TotalDeductionsYTD = "TOTDEDYTD";

            /// <summary>
            /// Property for TotalTaxes
            /// </summary>
            public const string TotalTaxes = "TOTTAXCUR";

            /// <summary>
            /// Property for TotalTaxesYTD
            /// </summary>
            public const string TotalTaxesYTD = "TOTTAXYTD";

            /// <summary>
            /// Property for TotalCashBenefits
            /// </summary>
            public const string TotalCashBenefits = "TOTCBCUR";

            /// <summary>
            /// Property for TotalCashBenefitsYTD
            /// </summary>
            public const string TotalCashBenefitsYTD = "TOTCBYTD";

            /// <summary>
            /// Property for TotalNonCashBenefits
            /// </summary>
            public const string TotalNonCashBenefits = "TOTNCCUR";

            /// <summary>
            /// Property for TotalNonCashBenefitsYTD
            /// </summary>
            public const string TotalNonCashBenefitsYTD = "TOTNCYTD";

            /// <summary>
            /// Property for TotalGross
            /// </summary>
            public const string TotalGross = "TOTEARNCUR";

            /// <summary>
            /// Property for TotalGrossYTD
            /// </summary>
            public const string TotalGrossYTD = "TOTEARNYTD";

            /// <summary>
            /// Property for NetPay
            /// </summary>
            public const string NetPay = "NETPAYCUR";

            /// <summary>
            /// Property for NetPayYTD
            /// </summary>
            public const string NetPayYTD = "NETPAYYTD";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SSNSIN
            /// </summary>
            public const string SSNSIN = "SSN";

            /// <summary>
            /// Property for EmployeeAddress1
            /// </summary>
            public const string EmployeeAddress1 = "ADDRESS1";

            /// <summary>
            /// Property for EmployeeAddress2
            /// </summary>
            public const string EmployeeAddress2 = "ADDRESS2";

            /// <summary>
            /// Property for EmployeeAddress3
            /// </summary>
            public const string EmployeeAddress3 = "ADDRESS3";

            /// <summary>
            /// Property for EmployeeAddress4
            /// </summary>
            public const string EmployeeAddress4 = "ADDRESS4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "CITY";

            /// <summary>
            /// Property for State
            /// </summary>
            public const string State = "STATE";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "COUNTRY";

            /// <summary>
            /// Property for ZipPostalCode
            /// </summary>
            public const string ZipPostalCode = "ZIP";

            /// <summary>
            /// Property for EmployeeFullName
            /// </summary>
            public const string EmployeeFullName = "FULLNAME";

            /// <summary>
            /// Property for CheckNumber
            /// </summary>
            public const string CheckNumber = "CHECK";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for ProcessDate
            /// </summary>
            public const string ProcessDate = "POSTED";

            /// <summary>
            /// Property for PaymentCurrency
            /// </summary>
            public const string PaymentCurrency = "SRCECURN";

            /// <summary>
            /// Property for PayFrequency
            /// </summary>
            public const string PayFrequency = "PAYFREQ";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Payslip Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for PaymentDate
            /// </summary>
            public const int PaymentDate = 1;

            /// <summary>
            /// Property Indexer for RecordNumber
            /// </summary>
            public const int RecordNumber = 2;

            /// <summary>
            /// Property Indexer for OriginalModule
            /// </summary>
            public const int OriginalModule = 3;

            /// <summary>
            /// Property Indexer for Employee
            /// </summary>
            public const int Employee = 4;

            /// <summary>
            /// Property Indexer for SelectedForPublishing
            /// </summary>
            public const int SelectedForPublishing = 5;

            /// <summary>
            /// Property Indexer for PublishSetting
            /// </summary>
            public const int PublishSetting = 6;

            /// <summary>
            /// Property Indexer for PayslipUploadStatus
            /// </summary>
            public const int PayslipUploadStatus = 7;

            /// <summary>
            /// Property Indexer for SageHRPayslipID
            /// </summary>
            public const int SageHRPayslipID = 8;

            /// <summary>
            /// Property Indexer for CheckPDFUploadStatus
            /// </summary>
            public const int CheckPDFUploadStatus = 9;

            /// <summary>
            /// Property Indexer for CheckPDFFilePath
            /// </summary>
            public const int CheckPDFFilePath = 10;

            /// <summary>
            /// Property Indexer for PeriodStartDate
            /// </summary>
            public const int PeriodStartDate = 11;

            /// <summary>
            /// Property Indexer for PeriodEndDate
            /// </summary>
            public const int PeriodEndDate = 12;

            /// <summary>
            /// Property Indexer for EmployeeLastName
            /// </summary>
            public const int EmployeeLastName = 13;

            /// <summary>
            /// Property Indexer for EmployeeFirstName
            /// </summary>
            public const int EmployeeFirstName = 14;

            /// <summary>
            /// Property Indexer for EmployeeMiddleName
            /// </summary>
            public const int EmployeeMiddleName = 15;

            /// <summary>
            /// Property Indexer for TotalHours
            /// </summary>
            public const int TotalHours = 16;

            /// <summary>
            /// Property Indexer for TotalDeductions
            /// </summary>
            public const int TotalDeductions = 17;

            /// <summary>
            /// Property Indexer for TotalDeductionsYTD
            /// </summary>
            public const int TotalDeductionsYTD = 18;

            /// <summary>
            /// Property Indexer for TotalTaxes
            /// </summary>
            public const int TotalTaxes = 19;

            /// <summary>
            /// Property Indexer for TotalTaxesYTD
            /// </summary>
            public const int TotalTaxesYTD = 20;

            /// <summary>
            /// Property Indexer for TotalCashBenefits
            /// </summary>
            public const int TotalCashBenefits = 21;

            /// <summary>
            /// Property Indexer for TotalCashBenefitsYTD
            /// </summary>
            public const int TotalCashBenefitsYTD = 22;

            /// <summary>
            /// Property Indexer for TotalNonCashBenefits
            /// </summary>
            public const int TotalNonCashBenefits = 23;

            /// <summary>
            /// Property Indexer for TotalNonCashBenefitsYTD
            /// </summary>
            public const int TotalNonCashBenefitsYTD = 24;

            /// <summary>
            /// Property Indexer for TotalGross
            /// </summary>
            public const int TotalGross = 25;

            /// <summary>
            /// Property Indexer for TotalGrossYTD
            /// </summary>
            public const int TotalGrossYTD = 26;

            /// <summary>
            /// Property Indexer for NetPay
            /// </summary>
            public const int NetPay = 27;

            /// <summary>
            /// Property Indexer for NetPayYTD
            /// </summary>
            public const int NetPayYTD = 28;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SSNSIN
            /// </summary>
            public const int SSNSIN = 29;

            /// <summary>
            /// Property Indexer for EmployeeAddress1
            /// </summary>
            public const int EmployeeAddress1 = 30;

            /// <summary>
            /// Property Indexer for EmployeeAddress2
            /// </summary>
            public const int EmployeeAddress2 = 31;

            /// <summary>
            /// Property Indexer for EmployeeAddress3
            /// </summary>
            public const int EmployeeAddress3 = 32;

            /// <summary>
            /// Property Indexer for EmployeeAddress4
            /// </summary>
            public const int EmployeeAddress4 = 33;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 34;

            /// <summary>
            /// Property Indexer for State
            /// </summary>
            public const int State = 35;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 36;

            /// <summary>
            /// Property Indexer for ZipPostalCode
            /// </summary>
            public const int ZipPostalCode = 37;

            /// <summary>
            /// Property Indexer for EmployeeFullName
            /// </summary>
            public const int EmployeeFullName = 38;

            /// <summary>
            /// Property Indexer for CheckNumber
            /// </summary>
            public const int CheckNumber = 39;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 40;

            /// <summary>
            /// Property Indexer for ProcessDate
            /// </summary>
            public const int ProcessDate = 41;

            /// <summary>
            /// Property Indexer for PaymentCurrency
            /// </summary>
            public const int PaymentCurrency = 42;

            /// <summary>
            /// Property Indexer for PayFrequency
            /// </summary>
            public const int PayFrequency = 43;


        }

        #endregion

    }
}