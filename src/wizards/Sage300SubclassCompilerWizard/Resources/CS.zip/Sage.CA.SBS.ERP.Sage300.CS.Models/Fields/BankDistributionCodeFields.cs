// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankDistributionCode Constants 
    /// </summary>
    public partial class BankDistributionCode
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "BK0003";

        /// <summary>
        /// Contains list of BankDistributionCode Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "TYPE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for GLAccount 
            /// </summary>
            public const string GLAccount = "ACCT";

            /// <summary>
            /// Property for LastMaintained 
            /// </summary>
            public const string LastMaintained = "LSTMNTND";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "INACTDATE";

            /// <summary>
            /// Property for Status string value 
            /// </summary>
            public const string StatusString = "INACTIVE";

            #endregion
        }

        /// <summary>
        /// Contains list of BankDistributionCode Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for GLAccount 
            /// </summary>
            public const int GLAccount = 3;

            /// <summary>
            /// Property Indexer for LastMaintained 
            /// </summary>
            public const int LastMaintained = 4;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 5;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 6;

            #endregion
        }
    }
}