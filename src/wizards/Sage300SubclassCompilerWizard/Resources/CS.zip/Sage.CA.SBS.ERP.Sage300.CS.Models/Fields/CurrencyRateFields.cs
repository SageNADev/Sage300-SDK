﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CurrencyRate Constants 
    /// </summary>
    public partial class CurrencyRate
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0006";

        /// <summary>
        /// Contains list of CurrencyRates Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for ToCurrency 
            /// </summary>
            public const string ToCurrency = "HOMECUR";
            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "RATETYPE";
            /// <summary>
            /// Property for FromCurrency 
            /// </summary>
            public const string FromCurrency = "SOURCECUR";
            /// <summary>
            /// Property for RateDate 
            /// </summary>
            public const string RateDate = "RATEDATE";
            /// <summary>
            /// Property for Rate 
            /// </summary>
            public const string Rate = "RATE";
            /// <summary>
            /// Property for Spread 
            /// </summary>
            public const string Spread = "SPREAD";
            /// <summary>
            /// Property for DateMatching 
            /// </summary>
            public const string DateMatching = "DATEMATCH";
           
            /// <summary>
            /// Property for RateOperation 
            /// </summary>
            public const string RateOperation = "RATEOPER";
            /// <summary>
            /// Property for PropagateChangesImmediately 
            /// </summary>
            public const string PropagateChangesImmediately = "PRGTNOW";

            #endregion
        }


        /// <summary>
        /// Contains list of CurrencyRates Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ToCurrency 
            /// </summary>
            public const int ToCurrency = 1;
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 2;
            /// <summary>
            /// Property Indexer for FromCurrency 
            /// </summary>
            public const int FromCurrency = 3;
            /// <summary>
            /// Property Indexer for RateDate 
            /// </summary>
            public const int RateDate = 4;
            /// <summary>
            /// Property Indexer for Rate 
            /// </summary>
            public const int Rate = 5;
            /// <summary>
            /// Property Indexer for Spread 
            /// </summary>
            public const int Spread = 6;
            /// <summary>
            /// Property Indexer for DateMatching 
            /// </summary>
            public const int DateMatching = 7;
            /// <summary>
            /// Property Indexer for RateOperation 
            /// </summary>
            public const int RateOperation = 8;
            /// <summary>
            /// Property Indexer for PropagateChangesImmediately 
            /// </summary>
            public const int PropagateChangesImmediately = 30;

            #endregion
        }


    }
}
