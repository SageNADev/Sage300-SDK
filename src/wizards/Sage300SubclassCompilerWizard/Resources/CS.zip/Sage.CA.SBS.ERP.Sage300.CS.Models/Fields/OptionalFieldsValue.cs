﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
    // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Class OptionalFieldValue.
    /// </summary>
    public partial class OptionalFieldsValue
    {
        /// <summary>
        /// The entity name
        /// </summary>
        public const string EntityName = "CS0012";

        /// <summary>
        /// Class Fields.
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for OptionalField 
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for Value 
            /// </summary>
            public const string Value = "VALUE";

            /// <summary>
            /// Property for SortedValue 
            /// </summary>
            public const string SortedValue = "SORTEDVAL";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string ValueDescription = "VDESC";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for AllowBlank 
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for Validate 
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for ValueStringToConvert 
            /// </summary>
            public const string ValueStringToConvert = "VALCONVERT";

            /// <summary>
            /// Property for TypedValueFieldIndex 
            /// </summary>
            public const string TypeValueFieldIndex = "VALINDEX";

            /// <summary>
            /// Property for TextValue 
            /// </summary>
            public const string TextValue = "VALIFTEXT";

            /// <summary>
            /// Property for AmountValue 
            /// </summary>
            public const string AmountValue = "VALIFMONEY";

            /// <summary>
            /// Property for NumberValue 
            /// </summary>
            public const string NumberValue = "VALIFNUM";

            /// <summary>
            /// Property for IntegerValue 
            /// </summary>
            public const string IntegerValue = "VALIFLONG";

            /// <summary>
            /// Property for YesOrNoValue 
            /// </summary>
            public const string YesOrNoValue = "VALIFBOOL";

            /// <summary>
            /// Property for DateValue 
            /// </summary>
            public const string DateValue = "VALIFDATE";

            /// <summary>
            /// Property for TimeValue 
            /// </summary>
            public const string TimeValue = "VALIFTIME";

            /// <summary>
            /// Convert Value Index - VALCONVERT
            /// </summary>
            public const string ConvertValue = "VALCONVERT";
          
            /// <summary>
            /// Convert Value Index - TextValue
            /// </summary>
            public const string BooleanValue = "VALIFBOOL";


            
        }

        /// <summary>
        /// OptionalFieldValue Index Constants
        /// </summary>
        public class Index
        {
            #region Field Index

            /// <summary>
            /// Optional Field Index - OPTFIELD
            /// </summary>
            public const int OptionalField = 1;

            /// <summary>
            /// Value Index - VALUE
            /// </summary>
            public const int Value = 2;

            /// <summary>
            /// Sorted Value Index - SORTEDVAL
            /// </summary>
            public const int SortedValue = 3;

            /// <summary>
            /// Value Description Index - VDESC
            /// </summary>
            public const int ValueDescription = 4;

            /// <summary>
            /// Type Index - TYPE
            /// </summary>
            public const int Type = 5;

            /// <summary>
            /// Length Index - LENGTH
            /// </summary>
            public const int Length = 6;

            /// <summary>
            /// Decimals Index - DECIMALS
            /// </summary>
            public const int Decimals = 7;

            /// <summary>
            /// Allow Null Index - ALLOWNULL
            /// </summary>
            public const int AllowBlank = 8;

            /// <summary>
            /// Validate Index - VALIDATE
            /// </summary>
            public const int Validate = 9;

            /// <summary>
            /// Convert Value Index - VALCONVERT
            /// </summary>
            public const int ConvertValue = 20;

            /// <summary>
            /// Type Value Field Index - VALINDEX
            /// </summary>
            public const int TypeValueFieldIndex = 21;

            /// <summary>
            /// Text Value Index - VALIFTEXT
            /// </summary>
            public const int TextValue = 22;

            /// <summary>
            /// Amount Value Index - VALIFMONEY
            /// </summary>
            public const int AmountValue = 23;

            /// <summary>
            /// Number Value Index - VALIFNUM
            /// </summary>
            public const int NumberValue = 24;

            /// <summary>
            /// Integer Value Index - VALIFLONG
            /// </summary>
            public const int IntegerValue = 25;

            /// <summary>
            /// Boolean Value Index - VALIFBOOL
            /// </summary>
            public const int BooleanValue = 26;

            /// <summary>
            /// Date Value Index - VALIFDATE
            /// </summary>
            public const int DateValue = 27;

            /// <summary>
            /// Time Value Index - VALIFTIME
            /// </summary>
            public const int TimeValue = 28;

            #endregion
        }
    }
}