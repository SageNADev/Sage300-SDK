﻿//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 
// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of OptionalFields Constants 
    /// </summary>
    public partial class OptionalFields
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0011";

        /// <summary>
        /// Contains list of OptionalFields Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for OptionalField 
            /// </summary>
            public const string OptionalFieldKey = "OPTFIELD";



            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "FDESC";



            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string TypeString = "TYPE";



            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";



            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";



            /// <summary>
            /// Property for AllowBlank 
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";



            /// <summary>
            /// Property for Validate 
            /// </summary>
            public const string IsValidate = "VALIDATE";



            /// <summary>
            /// Property for Values 
            /// </summary>
            public const string Values = "VALUES";

            /// <summary>

            /// Property for AllowBlank

            /// </summary>

            public const string AllowBlankString = "ALLOWNULL";



            #endregion
        }

        /// <summary>
        /// 
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for OptionalField 
            /// </summary>
            public const int OptionalFieldKey = 1;



            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;


            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 3;



            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 4;



            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 5;



            /// <summary>
            /// Property Indexer for AllowBlank 
            /// </summary>
            public const int AllowBlank = 6;



            /// <summary>
            /// Property Indexer for Validate 
            /// </summary>
            public const int IsValidate = 7;



            /// <summary>
            /// Property Indexer for Values 
            /// </summary>
            public const int Values = 8;

        }
    }
}