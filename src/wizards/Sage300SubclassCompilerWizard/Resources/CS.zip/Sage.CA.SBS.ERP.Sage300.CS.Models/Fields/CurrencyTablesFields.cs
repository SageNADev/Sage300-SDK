// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CurrencyTables Constants 
    /// </summary>
    public partial class CurrencyTable
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0005";

        /// <summary>
        /// Contains list of CurrencyTables Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for ToCurrency 
            /// </summary>
            public const string ToCurrency = "HOMECUR";
            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "RATETYPE";
            /// <summary>
            /// Property for TableDescription 
            /// </summary>
            public const string TableDescription = "TABLEDESC";
            /// <summary>
            /// Property for DateMatching 
            /// </summary>
            public const string DateMatching = "DATEMATCH";
            /// <summary>
            /// Property for RateOperation 
            /// </summary>
            public const string RateOperation = "RATEOPER";
            /// <summary>
            /// Property for SourceofRates 
            /// </summary>
            public const string SourceofRates = "RATESRCE";
            /// <summary>
            /// Property for PropagateChangesImmediately 
            /// </summary>
            public const string PropagateChangesImmediately = "PRGTNOW";
            /// <summary>
            /// Property for Command 
            /// </summary>
            public const string Command = "PROCESSCMD";
            /// <summary>
            /// Property for FromDate 
            /// </summary>
            public const string FromDate = "FROMDATE";
            /// <summary>
            /// Property for ToDate 
            /// </summary>
            public const string ToDate = "TODATE";

            #endregion
        }


        /// <summary>
        /// Contains list of CurrencyTables Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ToCurrency 
            /// </summary>
            public const int ToCurrency = 1;
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 2;
            /// <summary>
            /// Property Indexer for TableDescription 
            /// </summary>
            public const int TableDescription = 3;
            /// <summary>
            /// Property Indexer for DateMatching 
            /// </summary>
            public const int DateMatching = 4;
            /// <summary>
            /// Property Indexer for RateOperation 
            /// </summary>
            public const int RateOperation = 5;
            /// <summary>
            /// Property Indexer for SourceofRates 
            /// </summary>
            public const int SourceofRates = 6;
            /// <summary>
            /// Property Indexer for PropagateChangesImmediately 
            /// </summary>
            public const int PropagateChangesImmediately = 30;
            /// <summary>
            /// Property Indexer for Command 
            /// </summary>
            public const int Command = 31;
            /// <summary>
            /// Property Indexer for FromDate 
            /// </summary>
            public const int FromDate = 32;
            /// <summary>
            /// Property Indexer for ToDate 
            /// </summary>
            public const int ToDate = 33;

            #endregion
        }


    }
}
