// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
     /// <summary>
     /// Contains list of TransferAuditCharge Constants
     /// </summary>
     public partial class TransferAuditCharge
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "BK0645";

          #region Properties
          /// <summary>
          /// Contains list of TransferAuditCharge Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for PostingSequence
               /// </summary>
               public const string PostingSequence = "PSTSEQ";

               /// <summary>
               /// Property for KeySequence
               /// </summary>
               public const string KeySequence = "KEYSEQ";

               /// <summary>
               /// Property for ChargeLine
               /// </summary>
               public const string ChargeLine = "LINE";

               /// <summary>
               /// Property for ChargeBank
               /// </summary>
               public const string ChargeBank = "BANK";

               /// <summary>
               /// Property for TransferChargeDistribCode
               /// </summary>
               public const string TransferChargeDistribCode = "TYPE";

               /// <summary>
               /// Property for TransferChargeGLAccount
               /// </summary>
               public const string TransferChargeGLAccount = "GLACCOUNT";

               /// <summary>
               /// Property for TransferChargeSourceCurrency
               /// </summary>
               public const string TransferChargeSourceCurrency = "SRCECURN";

               /// <summary>
               /// Property for TransferChargeSourceAmount
               /// </summary>
               public const string TransferChargeSourceAmount = "SRCEAMT";

               /// <summary>
               /// Property for ExchangeRateType
               /// </summary>
               public const string ExchangeRateType = "RATETYPE";

               /// <summary>
               /// Property for ExchangeRateDate
               /// </summary>
               public const string ExchangeRateDate = "RATEDATE";

               /// <summary>
               /// Property for ExchangeRate
               /// </summary>
               public const string ExchangeRate = "RATE";

               /// <summary>
               /// Property for RateOperation
               /// </summary>
               public const string RateOperation = "RATEOP";

               /// <summary>
               /// Property for TransferChargeFunctionalAmt
               /// </summary>
               public const string TransferChargeFunctionalAmt = "FAMOUNT";

               /// <summary>
               /// Property for TransferChargeGLOverride
               /// </summary>
               public const string TransferChargeGLOverride = "GLACCHG";

               /// <summary>
               /// Property for ChargeGLDescription
               /// </summary>
               public const string ChargeGLDescription = "GLACCOUNTD";

               /// <summary>
               /// Property for Taxable
               /// </summary>
               public const string Taxable = "SWTAXBL";

               /// <summary>
               /// Property for TaxAmountCalculation
               /// </summary>
               public const string TaxAmountCalculation = "TXAMTCALC";

               /// <summary>
               /// Property for TaxGroup
               /// </summary>
               public const string TaxGroup = "CODETAXGRP";

               /// <summary>
               /// Property for TaxAuthority1
               /// </summary>
               public const string TaxAuthority1 = "TAXAUTH1";

               /// <summary>
               /// Property for TaxAuthority2
               /// </summary>
               public const string TaxAuthority2 = "TAXAUTH2";

               /// <summary>
               /// Property for TaxAuthority3
               /// </summary>
               public const string TaxAuthority3 = "TAXAUTH3";

               /// <summary>
               /// Property for TaxAuthority4
               /// </summary>
               public const string TaxAuthority4 = "TAXAUTH4";

               /// <summary>
               /// Property for TaxAuthority5
               /// </summary>
               public const string TaxAuthority5 = "TAXAUTH5";

               /// <summary>
               /// Property for TaxVendorClass1
               /// </summary>
               public const string TaxVendorClass1 = "TAXVCLSS1";

               /// <summary>
               /// Property for TaxVendorClass2
               /// </summary>
               public const string TaxVendorClass2 = "TAXVCLSS2";

               /// <summary>
               /// Property for TaxVendorClass3
               /// </summary>
               public const string TaxVendorClass3 = "TAXVCLSS3";

               /// <summary>
               /// Property for TaxVendorClass4
               /// </summary>
               public const string TaxVendorClass4 = "TAXVCLSS4";

               /// <summary>
               /// Property for TaxVendorClass5
               /// </summary>
               public const string TaxVendorClass5 = "TAXVCLSS5";

               /// <summary>
               /// Property for TaxItemClass1
               /// </summary>
               public const string TaxItemClass1 = "TAXICLSS1";

               /// <summary>
               /// Property for TaxItemClass2
               /// </summary>
               public const string TaxItemClass2 = "TAXICLSS2";

               /// <summary>
               /// Property for TaxItemClass3
               /// </summary>
               public const string TaxItemClass3 = "TAXICLSS3";

               /// <summary>
               /// Property for TaxItemClass4
               /// </summary>
               public const string TaxItemClass4 = "TAXICLSS4";

               /// <summary>
               /// Property for TaxItemClass5
               /// </summary>
               public const string TaxItemClass5 = "TAXICLSS5";

               /// <summary>
               /// Property for TaxInclude1
               /// </summary>
               public const string TaxInclude1 = "TAXINCL1";

               /// <summary>
               /// Property for TaxInclude2
               /// </summary>
               public const string TaxInclude2 = "TAXINCL2";

               /// <summary>
               /// Property for TaxInclude3
               /// </summary>
               public const string TaxInclude3 = "TAXINCL3";

               /// <summary>
               /// Property for TaxInclude4
               /// </summary>
               public const string TaxInclude4 = "TAXINCL4";

               /// <summary>
               /// Property for TaxInclude5
               /// </summary>
               public const string TaxInclude5 = "TAXINCL5";

               /// <summary>
               /// Property for TaxBaseAmount1
               /// </summary>
               public const string TaxBaseAmount1 = "BASETAX1";

               /// <summary>
               /// Property for TaxBaseAmount2
               /// </summary>
               public const string TaxBaseAmount2 = "BASETAX2";

               /// <summary>
               /// Property for TaxBaseAmount3
               /// </summary>
               public const string TaxBaseAmount3 = "BASETAX3";

               /// <summary>
               /// Property for TaxBaseAmount4
               /// </summary>
               public const string TaxBaseAmount4 = "BASETAX4";

               /// <summary>
               /// Property for TaxBaseAmount5
               /// </summary>
               public const string TaxBaseAmount5 = "BASETAX5";

               /// <summary>
               /// Property for TaxBaseRetainageamount1
               /// </summary>
               public const string TaxBaseRetainageamount1 = "BASETAXRC1";

               /// <summary>
               /// Property for TaxBaseRetainageamount2
               /// </summary>
               public const string TaxBaseRetainageamount2 = "BASETAXRC2";

               /// <summary>
               /// Property for TaxBaseRetainageamount3
               /// </summary>
               public const string TaxBaseRetainageamount3 = "BASETAXRC3";

               /// <summary>
               /// Property for TaxBaseRetainageamount4
               /// </summary>
               public const string TaxBaseRetainageamount4 = "BASETAXRC4";

               /// <summary>
               /// Property for TaxBaseRetainageamount5
               /// </summary>
               public const string TaxBaseRetainageamount5 = "BASETAXRC5";

               /// <summary>
               /// Property for TaxBaseCalculationMethod
               /// </summary>
               public const string TaxBaseCalculationMethod = "TXCALCBASE";

               /// <summary>
               /// Property for TaxAmount1
               /// </summary>
               public const string TaxAmount1 = "AMTTAX1";

               /// <summary>
               /// Property for TaxAmount2
               /// </summary>
               public const string TaxAmount2 = "AMTTAX2";

               /// <summary>
               /// Property for TaxAmount3
               /// </summary>
               public const string TaxAmount3 = "AMTTAX3";

               /// <summary>
               /// Property for TaxAmount4
               /// </summary>
               public const string TaxAmount4 = "AMTTAX4";

               /// <summary>
               /// Property for TaxAmount5
               /// </summary>
               public const string TaxAmount5 = "AMTTAX5";

               /// <summary>
               /// Property for TaxableAMount
               /// </summary>
               public const string TaxableAMount = "AMTTXBL";

               /// <summary>
               /// Property for NonTaxableAmount
               /// </summary>
               public const string NonTaxableAmount = "AMTNOTTXBL";

               /// <summary>
               /// Property for TaxTotal
               /// </summary>
               public const string TaxTotal = "AMTTAXTOT";

               /// <summary>
               /// Property for DocumentTotalBeforeTax
               /// </summary>
               public const string DocumentTotalBeforeTax = "AMTDOCTOT";

               /// <summary>
               /// Property for DocumentTotalIncludingTax
               /// </summary>
               public const string DocumentTotalIncludingTax = "AMTNETTOT";

               /// <summary>
               /// Property for TaxDistributionamount
               /// </summary>
               public const string TaxDistributionamount = "AMTDIST";

               /// <summary>
               /// Property for TotalIncludedAmount
               /// </summary>
               public const string TotalIncludedAmount = "AMTINCLUDE";

               /// <summary>
               /// Property for TotalExcludedAmount
               /// </summary>
               public const string TotalExcludedAmount = "AMTEXCLUDE";

               /// <summary>
               /// Property for TaxNetDistributionAmount
               /// </summary>
               public const string TaxNetDistributionAmount = "AMTNETDIST";

               /// <summary>
               /// Property for TaxGrossDistributionAmount
               /// </summary>
               public const string TaxGrossDistributionAmount = "AMTGRODIST";

               /// <summary>
               /// Property for TaxExpenseAmount1
               /// </summary>
               public const string TaxExpenseAmount1 = "AMTEXPENS1";

               /// <summary>
               /// Property for TaxExpenseAmount2
               /// </summary>
               public const string TaxExpenseAmount2 = "AMTEXPENS2";

               /// <summary>
               /// Property for TaxExpenseAmount3
               /// </summary>
               public const string TaxExpenseAmount3 = "AMTEXPENS3";

               /// <summary>
               /// Property for TaxExpenseAmount4
               /// </summary>
               public const string TaxExpenseAmount4 = "AMTEXPENS4";

               /// <summary>
               /// Property for TaxExpenseAmount5
               /// </summary>
               public const string TaxExpenseAmount5 = "AMTEXPENS5";

               /// <summary>
               /// Property for TaxRecoverableAMount1
               /// </summary>
               public const string TaxRecoverableAMount1 = "AMTRECVRB1";

               /// <summary>
               /// Property for TaxRecoverableAMount2
               /// </summary>
               public const string TaxRecoverableAMount2 = "AMTRECVRB2";

               /// <summary>
               /// Property for TaxRecoverableAMount3
               /// </summary>
               public const string TaxRecoverableAMount3 = "AMTRECVRB3";

               /// <summary>
               /// Property for TaxRecoverableAMount4
               /// </summary>
               public const string TaxRecoverableAMount4 = "AMTRECVRB4";

               /// <summary>
               /// Property for TaxRecoverableAMount5
               /// </summary>
               public const string TaxRecoverableAMount5 = "AMTRECVRB5";

               /// <summary>
               /// Property for TotalTaxAllocatedAmount
               /// </summary>
               public const string TotalTaxAllocatedAmount = "TOTAMTALOC";

               /// <summary>
               /// Property for TaxReportingAmount1
               /// </summary>
               public const string TaxReportingAmount1 = "TXAMT1RC";

               /// <summary>
               /// Property for TaxReportingAmount2
               /// </summary>
               public const string TaxReportingAmount2 = "TXAMT2RC";

               /// <summary>
               /// Property for TaxReportingAmount3
               /// </summary>
               public const string TaxReportingAmount3 = "TXAMT3RC";

               /// <summary>
               /// Property for TaxReportingAmount4
               /// </summary>
               public const string TaxReportingAmount4 = "TXAMT4RC";

               /// <summary>
               /// Property for TaxReportingAmount5
               /// </summary>
               public const string TaxReportingAmount5 = "TXAMT5RC";

               /// <summary>
               /// Property for TotalTaxReportingAllocAmt
               /// </summary>
               public const string TotalTaxReportingAllocAmt = "TXALOCRC";

               /// <summary>
               /// Property for TaxReportingExpensedAmount
               /// </summary>
               public const string TaxReportingExpensedAmount = "TXEXPNSRC";

               /// <summary>
               /// Property for TaxReportingRecoverableAmount
               /// </summary>
               public const string TaxReportingRecoverableAmount = "TXRECVBRC";

               /// <summary>
               /// Property for TotalTaxReportingAmount
               /// </summary>
               public const string TotalTaxReportingAmount = "TXTOTRC";

               /// <summary>
               /// Property for TaxVersion
               /// </summary>
               public const string TaxVersion = "TAXVERSION";

               /// <summary>
               /// Property for TaxCalculationReportingMethod
               /// </summary>
               public const string TaxCalculationReportingMethod = "TXCALCRMET";

               /// <summary>
               /// Property for TaxExpenseAccount1
               /// </summary>
               public const string TaxExpenseAccount1 = "EXPNSACNT1";

               /// <summary>
               /// Property for TaxExpenseAccount2
               /// </summary>
               public const string TaxExpenseAccount2 = "EXPNSACNT2";

               /// <summary>
               /// Property for TaxExpenseAccount3
               /// </summary>
               public const string TaxExpenseAccount3 = "EXPNSACNT3";

               /// <summary>
               /// Property for TaxExpenseAccount4
               /// </summary>
               public const string TaxExpenseAccount4 = "EXPNSACNT4";

               /// <summary>
               /// Property for TaxExpenseAccount5
               /// </summary>
               public const string TaxExpenseAccount5 = "EXPNSACNT5";

               /// <summary>
               /// Property for TaxRecoverableAccount1
               /// </summary>
               public const string TaxRecoverableAccount1 = "RECBLACNT1";

               /// <summary>
               /// Property for TaxRecoverableAccount2
               /// </summary>
               public const string TaxRecoverableAccount2 = "RECBLACNT2";

               /// <summary>
               /// Property for TaxRecoverableAccount3
               /// </summary>
               public const string TaxRecoverableAccount3 = "RECBLACNT3";

               /// <summary>
               /// Property for TaxRecoverableAccount4
               /// </summary>
               public const string TaxRecoverableAccount4 = "RECBLACNT4";

               /// <summary>
               /// Property for TaxRecoverableAccount5
               /// </summary>
               public const string TaxRecoverableAccount5 = "RECBLACNT5";

               /// <summary>
               /// Property for TaxReportingCurrencyCode
               /// </summary>
               public const string TaxReportingCurrencyCode = "CODECURNRC";

               /// <summary>
               /// Property for TaxGroupDescription
               /// </summary>
               public const string TaxGroupDescription = "TXGRPDESC";

               /// <summary>
               /// Property for TaxAuthorityDescription1
               /// </summary>
               public const string TaxAuthorityDescription1 = "TXAU1DESC";

               /// <summary>
               /// Property for TaxAuthorityDescription2
               /// </summary>
               public const string TaxAuthorityDescription2 = "TXAU2DESC";

               /// <summary>
               /// Property for TaxAuthorityDescription3
               /// </summary>
               public const string TaxAuthorityDescription3 = "TXAU3DESC";

               /// <summary>
               /// Property for TaxAuthorityDescription4
               /// </summary>
               public const string TaxAuthorityDescription4 = "TXAU4DESC";

               /// <summary>
               /// Property for TaxAuthorityDescription5
               /// </summary>
               public const string TaxAuthorityDescription5 = "TXAU5DESC";

               /// <summary>
               /// Property for VendorTaxClassDescription1
               /// </summary>
               public const string VendorTaxClassDescription1 = "VCLS1DESC";

               /// <summary>
               /// Property for VendorTaxClassDescription2
               /// </summary>
               public const string VendorTaxClassDescription2 = "VCLS2DESC";

               /// <summary>
               /// Property for VendorTaxClassDescription3
               /// </summary>
               public const string VendorTaxClassDescription3 = "VCLS3DESC";

               /// <summary>
               /// Property for VendorTaxClassDescription4
               /// </summary>
               public const string VendorTaxClassDescription4 = "VCLS4DESC";

               /// <summary>
               /// Property for VendorTaxClassDescription5
               /// </summary>
               public const string VendorTaxClassDescription5 = "VCLS5DESC";

               /// <summary>
               /// Property for ItemTaxClassDescription1
               /// </summary>
               public const string ItemTaxClassDescription1 = "ICLS1DESC";

               /// <summary>
               /// Property for ItemTaxClassDescription2
               /// </summary>
               public const string ItemTaxClassDescription2 = "ICLS2DESC";

               /// <summary>
               /// Property for ItemTaxClassDescription3
               /// </summary>
               public const string ItemTaxClassDescription3 = "ICLS3DESC";

               /// <summary>
               /// Property for ItemTaxClassDescription4
               /// </summary>
               public const string ItemTaxClassDescription4 = "ICLS4DESC";

               /// <summary>
               /// Property for ItemTaxClassDescription5
               /// </summary>
               public const string ItemTaxClassDescription5 = "ICLS5DESC";

               /// <summary>
               /// Property for FuncGrossDistributionAmount
               /// </summary>
               public const string FuncGrossDistributionAmount = "FUNGRODIS";

               /// <summary>
               /// Property for FunctionalExpensedAmount1
               /// </summary>
               public const string FunctionalExpensedAmount1 = "FUNTXEXP1";

               /// <summary>
               /// Property for FunctionalExpensedAmount2
               /// </summary>
               public const string FunctionalExpensedAmount2 = "FUNTXEXP2";

               /// <summary>
               /// Property for FunctionalExpensedAmount3
               /// </summary>
               public const string FunctionalExpensedAmount3 = "FUNTXEXP3";

               /// <summary>
               /// Property for FunctionalExpensedAmount4
               /// </summary>
               public const string FunctionalExpensedAmount4 = "FUNTXEXP4";

               /// <summary>
               /// Property for FunctionalExpensedAmount5
               /// </summary>
               public const string FunctionalExpensedAmount5 = "FUNTXEXP5";

               /// <summary>
               /// Property for FunctionalRecoverableAmount1
               /// </summary>
               public const string FunctionalRecoverableAmount1 = "FUNTXRCB1";

               /// <summary>
               /// Property for FunctionalRecoverableAmount2
               /// </summary>
               public const string FunctionalRecoverableAmount2 = "FUNTXRCB2";

               /// <summary>
               /// Property for FunctionalRecoverableAmount3
               /// </summary>
               public const string FunctionalRecoverableAmount3 = "FUNTXRCB3";

               /// <summary>
               /// Property for FunctionalRecoverableAmount4
               /// </summary>
               public const string FunctionalRecoverableAmount4 = "FUNTXRCB4";

               /// <summary>
               /// Property for FunctionalRecoverableAmount5
               /// </summary>
               public const string FunctionalRecoverableAmount5 = "FUNTXRCB5";

               /// <summary>
               /// Property for TaxReportingRate
               /// </summary>
               public const string TaxReportingRate = "RATERC";

               /// <summary>
               /// Property for TaxReportingRateType
               /// </summary>
               public const string TaxReportingRateType = "RATETYPERC";

               /// <summary>
               /// Property for TaxReportingRateDate
               /// </summary>
               public const string TaxReportingRateDate = "RATEDATERC";

               /// <summary>
               /// Property for TaxReportingRateOperation
               /// </summary>
               public const string TaxReportingRateOperation = "RATEOPRC";

               /// <summary>
               /// Property for TaxReportingCurrencyDesc
               /// </summary>
               public const string TaxReportingCurrencyDesc = "CURNRCDESC";

               /// <summary>
               /// Property for TaxReportingRateTypeDesc
               /// </summary>
               public const string TaxReportingRateTypeDesc = "RATERCDESC";

               /// <summary>
               /// Property for TaxRate1
               /// </summary>
               public const string TaxRate1 = "TAXRATE1";

               /// <summary>
               /// Property for TaxRate2
               /// </summary>
               public const string TaxRate2 = "TAXRATE2";

               /// <summary>
               /// Property for TaxRate3
               /// </summary>
               public const string TaxRate3 = "TAXRATE3";

               /// <summary>
               /// Property for TaxRate4
               /// </summary>
               public const string TaxRate4 = "TAXRATE4";

               /// <summary>
               /// Property for TaxRate5
               /// </summary>
               public const string TaxRate5 = "TAXRATE5";

               /// <summary>
               /// Property for FunctionalNetOfTax
               /// </summary>
               public const string FunctionalNetOfTax = "FUNNETTAX";

               /// <summary>
               /// Property for FunctionalTotalTaxAllocated
               /// </summary>
               public const string FunctionalTotalTaxAllocated = "FUNAMTALOC";

               /// <summary>
               /// Property for FunctionalTaxTotal
               /// </summary>
               public const string FunctionalTaxTotal = "FUNTOTTAX";

               /// <summary>
               /// Property for TaxAllocatedAmount1
               /// </summary>
               public const string TaxAllocatedAmount1 = "AMTALLOC1";

               /// <summary>
               /// Property for TaxAllocatedAmount2
               /// </summary>
               public const string TaxAllocatedAmount2 = "AMTALLOC2";

               /// <summary>
               /// Property for TaxAllocatedAmount3
               /// </summary>
               public const string TaxAllocatedAmount3 = "AMTALLOC3";

               /// <summary>
               /// Property for TaxAllocatedAmount4
               /// </summary>
               public const string TaxAllocatedAmount4 = "AMTALLOC4";

               /// <summary>
               /// Property for TaxAllocatedAmount5
               /// </summary>
               public const string TaxAllocatedAmount5 = "AMTALLOC5";

               /// <summary>
               /// Property for TaxReportingExpensed1
               /// </summary>
               public const string TaxReportingExpensed1 = "TXEXPNS1RC";

               /// <summary>
               /// Property for TaxReportingExpensed2
               /// </summary>
               public const string TaxReportingExpensed2 = "TXEXPNS2RC";

               /// <summary>
               /// Property for TaxReportingExpensed3
               /// </summary>
               public const string TaxReportingExpensed3 = "TXEXPNS3RC";

               /// <summary>
               /// Property for TaxReportingExpensed4
               /// </summary>
               public const string TaxReportingExpensed4 = "TXEXPNS4RC";

               /// <summary>
               /// Property for TaxReportingExpensed5
               /// </summary>
               public const string TaxReportingExpensed5 = "TXEXPNS5RC";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt1
               /// </summary>
               public const string TaxReportingRecoverableAmt1 = "TXRECVB1RC";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt2
               /// </summary>
               public const string TaxReportingRecoverableAmt2 = "TXRECVB2RC";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt3
               /// </summary>
               public const string TaxReportingRecoverableAmt3 = "TXRECVB3RC";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt4
               /// </summary>
               public const string TaxReportingRecoverableAmt4 = "TXRECVB4RC";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt5
               /// </summary>
               public const string TaxReportingRecoverableAmt5 = "TXRECVB5RC";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount1
               /// </summary>
               public const string TaxReportingAllocatedAmount1 = "TXALLOC1RC";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount2
               /// </summary>
               public const string TaxReportingAllocatedAmount2 = "TXALLOC2RC";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount3
               /// </summary>
               public const string TaxReportingAllocatedAmount3 = "TXALLOC3RC";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount4
               /// </summary>
               public const string TaxReportingAllocatedAmount4 = "TXALLOC4RC";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount5
               /// </summary>
               public const string TaxReportingAllocatedAmount5 = "TXALLOC5RC";

               /// <summary>
               /// Property for FunctionalAllocatedAmount1
               /// </summary>
               public const string FunctionalAllocatedAmount1 = "FUNTXALOC1";

               /// <summary>
               /// Property for FunctionalAllocatedAmount2
               /// </summary>
               public const string FunctionalAllocatedAmount2 = "FUNTXALOC2";

               /// <summary>
               /// Property for FunctionalAllocatedAmount3
               /// </summary>
               public const string FunctionalAllocatedAmount3 = "FUNTXALOC3";

               /// <summary>
               /// Property for FunctionalAllocatedAmount4
               /// </summary>
               public const string FunctionalAllocatedAmount4 = "FUNTXALOC4";

               /// <summary>
               /// Property for FunctionalAllocatedAmount5
               /// </summary>
               public const string FunctionalAllocatedAmount5 = "FUNTXALOC5";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of TransferAuditCharge Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for PostingSequence
               /// </summary>
               public const int PostingSequence = 1;

               /// <summary>
               /// Property Indexer for KeySequence
               /// </summary>
               public const int KeySequence = 2;

               /// <summary>
               /// Property Indexer for ChargeLine
               /// </summary>
               public const int ChargeLine = 3;

               /// <summary>
               /// Property Indexer for ChargeBank
               /// </summary>
               public const int ChargeBank = 4;

               /// <summary>
               /// Property Indexer for TransferChargeDistribCode
               /// </summary>
               public const int TransferChargeDistribCode = 5;

               /// <summary>
               /// Property Indexer for TransferChargeGLAccount
               /// </summary>
               public const int TransferChargeGLAccount = 6;

               /// <summary>
               /// Property Indexer for TransferChargeSourceCurrency
               /// </summary>
               public const int TransferChargeSourceCurrency = 7;

               /// <summary>
               /// Property Indexer for TransferChargeSourceAmount
               /// </summary>
               public const int TransferChargeSourceAmount = 8;

               /// <summary>
               /// Property Indexer for ExchangeRateType
               /// </summary>
               public const int ExchangeRateType = 9;

               /// <summary>
               /// Property Indexer for ExchangeRateDate
               /// </summary>
               public const int ExchangeRateDate = 10;

               /// <summary>
               /// Property Indexer for ExchangeRate
               /// </summary>
               public const int ExchangeRate = 11;

               /// <summary>
               /// Property Indexer for RateOperation
               /// </summary>
               public const int RateOperation = 12;

               /// <summary>
               /// Property Indexer for TransferChargeFunctionalAmt
               /// </summary>
               public const int TransferChargeFunctionalAmt = 13;

               /// <summary>
               /// Property Indexer for TransferChargeGLOverride
               /// </summary>
               public const int TransferChargeGLOverride = 14;

               /// <summary>
               /// Property Indexer for ChargeGLDescription
               /// </summary>
               public const int ChargeGLDescription = 15;

               /// <summary>
               /// Property Indexer for Taxable
               /// </summary>
               public const int Taxable = 16;

               /// <summary>
               /// Property Indexer for TaxAmountCalculation
               /// </summary>
               public const int TaxAmountCalculation = 17;

               /// <summary>
               /// Property Indexer for TaxGroup
               /// </summary>
               public const int TaxGroup = 18;

               /// <summary>
               /// Property Indexer for TaxAuthority1
               /// </summary>
               public const int TaxAuthority1 = 19;

               /// <summary>
               /// Property Indexer for TaxAuthority2
               /// </summary>
               public const int TaxAuthority2 = 20;

               /// <summary>
               /// Property Indexer for TaxAuthority3
               /// </summary>
               public const int TaxAuthority3 = 21;

               /// <summary>
               /// Property Indexer for TaxAuthority4
               /// </summary>
               public const int TaxAuthority4 = 22;

               /// <summary>
               /// Property Indexer for TaxAuthority5
               /// </summary>
               public const int TaxAuthority5 = 23;

               /// <summary>
               /// Property Indexer for TaxVendorClass1
               /// </summary>
               public const int TaxVendorClass1 = 24;

               /// <summary>
               /// Property Indexer for TaxVendorClass2
               /// </summary>
               public const int TaxVendorClass2 = 25;

               /// <summary>
               /// Property Indexer for TaxVendorClass3
               /// </summary>
               public const int TaxVendorClass3 = 26;

               /// <summary>
               /// Property Indexer for TaxVendorClass4
               /// </summary>
               public const int TaxVendorClass4 = 27;

               /// <summary>
               /// Property Indexer for TaxVendorClass5
               /// </summary>
               public const int TaxVendorClass5 = 28;

               /// <summary>
               /// Property Indexer for TaxItemClass1
               /// </summary>
               public const int TaxItemClass1 = 29;

               /// <summary>
               /// Property Indexer for TaxItemClass2
               /// </summary>
               public const int TaxItemClass2 = 30;

               /// <summary>
               /// Property Indexer for TaxItemClass3
               /// </summary>
               public const int TaxItemClass3 = 31;

               /// <summary>
               /// Property Indexer for TaxItemClass4
               /// </summary>
               public const int TaxItemClass4 = 32;

               /// <summary>
               /// Property Indexer for TaxItemClass5
               /// </summary>
               public const int TaxItemClass5 = 33;

               /// <summary>
               /// Property Indexer for TaxInclude1
               /// </summary>
               public const int TaxInclude1 = 34;

               /// <summary>
               /// Property Indexer for TaxInclude2
               /// </summary>
               public const int TaxInclude2 = 35;

               /// <summary>
               /// Property Indexer for TaxInclude3
               /// </summary>
               public const int TaxInclude3 = 36;

               /// <summary>
               /// Property Indexer for TaxInclude4
               /// </summary>
               public const int TaxInclude4 = 37;

               /// <summary>
               /// Property Indexer for TaxInclude5
               /// </summary>
               public const int TaxInclude5 = 38;

               /// <summary>
               /// Property Indexer for TaxBaseAmount1
               /// </summary>
               public const int TaxBaseAmount1 = 39;

               /// <summary>
               /// Property Indexer for TaxBaseAmount2
               /// </summary>
               public const int TaxBaseAmount2 = 40;

               /// <summary>
               /// Property Indexer for TaxBaseAmount3
               /// </summary>
               public const int TaxBaseAmount3 = 41;

               /// <summary>
               /// Property Indexer for TaxBaseAmount4
               /// </summary>
               public const int TaxBaseAmount4 = 42;

               /// <summary>
               /// Property Indexer for TaxBaseAmount5
               /// </summary>
               public const int TaxBaseAmount5 = 43;

               /// <summary>
               /// Property Indexer for TaxBaseRetainageamount1
               /// </summary>
               public const int TaxBaseRetainageamount1 = 44;

               /// <summary>
               /// Property Indexer for TaxBaseRetainageamount2
               /// </summary>
               public const int TaxBaseRetainageamount2 = 45;

               /// <summary>
               /// Property Indexer for TaxBaseRetainageamount3
               /// </summary>
               public const int TaxBaseRetainageamount3 = 46;

               /// <summary>
               /// Property Indexer for TaxBaseRetainageamount4
               /// </summary>
               public const int TaxBaseRetainageamount4 = 47;

               /// <summary>
               /// Property Indexer for TaxBaseRetainageamount5
               /// </summary>
               public const int TaxBaseRetainageamount5 = 48;

               /// <summary>
               /// Property Indexer for TaxBaseCalculationMethod
               /// </summary>
               public const int TaxBaseCalculationMethod = 49;

               /// <summary>
               /// Property Indexer for TaxAmount1
               /// </summary>
               public const int TaxAmount1 = 50;

               /// <summary>
               /// Property Indexer for TaxAmount2
               /// </summary>
               public const int TaxAmount2 = 51;

               /// <summary>
               /// Property Indexer for TaxAmount3
               /// </summary>
               public const int TaxAmount3 = 52;

               /// <summary>
               /// Property Indexer for TaxAmount4
               /// </summary>
               public const int TaxAmount4 = 53;

               /// <summary>
               /// Property Indexer for TaxAmount5
               /// </summary>
               public const int TaxAmount5 = 54;

               /// <summary>
               /// Property Indexer for TaxableAMount
               /// </summary>
               public const int TaxableAMount = 55;

               /// <summary>
               /// Property Indexer for NonTaxableAmount
               /// </summary>
               public const int NonTaxableAmount = 56;

               /// <summary>
               /// Property Indexer for TaxTotal
               /// </summary>
               public const int TaxTotal = 57;

               /// <summary>
               /// Property Indexer for DocumentTotalBeforeTax
               /// </summary>
               public const int DocumentTotalBeforeTax = 58;

               /// <summary>
               /// Property Indexer for DocumentTotalIncludingTax
               /// </summary>
               public const int DocumentTotalIncludingTax = 59;

               /// <summary>
               /// Property Indexer for TaxDistributionamount
               /// </summary>
               public const int TaxDistributionamount = 60;

               /// <summary>
               /// Property Indexer for TotalIncludedAmount
               /// </summary>
               public const int TotalIncludedAmount = 61;

               /// <summary>
               /// Property Indexer for TotalExcludedAmount
               /// </summary>
               public const int TotalExcludedAmount = 62;

               /// <summary>
               /// Property Indexer for TaxNetDistributionAmount
               /// </summary>
               public const int TaxNetDistributionAmount = 63;

               /// <summary>
               /// Property Indexer for TaxGrossDistributionAmount
               /// </summary>
               public const int TaxGrossDistributionAmount = 64;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount1
               /// </summary>
               public const int TaxExpenseAmount1 = 65;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount2
               /// </summary>
               public const int TaxExpenseAmount2 = 66;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount3
               /// </summary>
               public const int TaxExpenseAmount3 = 67;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount4
               /// </summary>
               public const int TaxExpenseAmount4 = 68;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount5
               /// </summary>
               public const int TaxExpenseAmount5 = 69;

               /// <summary>
               /// Property Indexer for TaxRecoverableAMount1
               /// </summary>
               public const int TaxRecoverableAMount1 = 70;

               /// <summary>
               /// Property Indexer for TaxRecoverableAMount2
               /// </summary>
               public const int TaxRecoverableAMount2 = 71;

               /// <summary>
               /// Property Indexer for TaxRecoverableAMount3
               /// </summary>
               public const int TaxRecoverableAMount3 = 72;

               /// <summary>
               /// Property Indexer for TaxRecoverableAMount4
               /// </summary>
               public const int TaxRecoverableAMount4 = 73;

               /// <summary>
               /// Property Indexer for TaxRecoverableAMount5
               /// </summary>
               public const int TaxRecoverableAMount5 = 74;

               /// <summary>
               /// Property Indexer for TotalTaxAllocatedAmount
               /// </summary>
               public const int TotalTaxAllocatedAmount = 75;

               /// <summary>
               /// Property Indexer for TaxReportingAmount1
               /// </summary>
               public const int TaxReportingAmount1 = 76;

               /// <summary>
               /// Property Indexer for TaxReportingAmount2
               /// </summary>
               public const int TaxReportingAmount2 = 77;

               /// <summary>
               /// Property Indexer for TaxReportingAmount3
               /// </summary>
               public const int TaxReportingAmount3 = 78;

               /// <summary>
               /// Property Indexer for TaxReportingAmount4
               /// </summary>
               public const int TaxReportingAmount4 = 79;

               /// <summary>
               /// Property Indexer for TaxReportingAmount5
               /// </summary>
               public const int TaxReportingAmount5 = 80;

               /// <summary>
               /// Property Indexer for TotalTaxReportingAllocAmt
               /// </summary>
               public const int TotalTaxReportingAllocAmt = 81;

               /// <summary>
               /// Property Indexer for TaxReportingExpensedAmount
               /// </summary>
               public const int TaxReportingExpensedAmount = 82;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmount
               /// </summary>
               public const int TaxReportingRecoverableAmount = 83;

               /// <summary>
               /// Property Indexer for TotalTaxReportingAmount
               /// </summary>
               public const int TotalTaxReportingAmount = 84;

               /// <summary>
               /// Property Indexer for TaxVersion
               /// </summary>
               public const int TaxVersion = 85;

               /// <summary>
               /// Property Indexer for TaxCalculationReportingMethod
               /// </summary>
               public const int TaxCalculationReportingMethod = 86;

               /// <summary>
               /// Property Indexer for TaxExpenseAccount1
               /// </summary>
               public const int TaxExpenseAccount1 = 87;

               /// <summary>
               /// Property Indexer for TaxExpenseAccount2
               /// </summary>
               public const int TaxExpenseAccount2 = 88;

               /// <summary>
               /// Property Indexer for TaxExpenseAccount3
               /// </summary>
               public const int TaxExpenseAccount3 = 89;

               /// <summary>
               /// Property Indexer for TaxExpenseAccount4
               /// </summary>
               public const int TaxExpenseAccount4 = 90;

               /// <summary>
               /// Property Indexer for TaxExpenseAccount5
               /// </summary>
               public const int TaxExpenseAccount5 = 91;

               /// <summary>
               /// Property Indexer for TaxRecoverableAccount1
               /// </summary>
               public const int TaxRecoverableAccount1 = 92;

               /// <summary>
               /// Property Indexer for TaxRecoverableAccount2
               /// </summary>
               public const int TaxRecoverableAccount2 = 93;

               /// <summary>
               /// Property Indexer for TaxRecoverableAccount3
               /// </summary>
               public const int TaxRecoverableAccount3 = 94;

               /// <summary>
               /// Property Indexer for TaxRecoverableAccount4
               /// </summary>
               public const int TaxRecoverableAccount4 = 95;

               /// <summary>
               /// Property Indexer for TaxRecoverableAccount5
               /// </summary>
               public const int TaxRecoverableAccount5 = 96;

               /// <summary>
               /// Property Indexer for TaxReportingCurrencyCode
               /// </summary>
               public const int TaxReportingCurrencyCode = 97;

               /// <summary>
               /// Property Indexer for TaxGroupDescription
               /// </summary>
               public const int TaxGroupDescription = 98;

               /// <summary>
               /// Property Indexer for TaxAuthorityDescription1
               /// </summary>
               public const int TaxAuthorityDescription1 = 99;

               /// <summary>
               /// Property Indexer for TaxAuthorityDescription2
               /// </summary>
               public const int TaxAuthorityDescription2 = 100;

               /// <summary>
               /// Property Indexer for TaxAuthorityDescription3
               /// </summary>
               public const int TaxAuthorityDescription3 = 101;

               /// <summary>
               /// Property Indexer for TaxAuthorityDescription4
               /// </summary>
               public const int TaxAuthorityDescription4 = 102;

               /// <summary>
               /// Property Indexer for TaxAuthorityDescription5
               /// </summary>
               public const int TaxAuthorityDescription5 = 103;

               /// <summary>
               /// Property Indexer for VendorTaxClassDescription1
               /// </summary>
               public const int VendorTaxClassDescription1 = 104;

               /// <summary>
               /// Property Indexer for VendorTaxClassDescription2
               /// </summary>
               public const int VendorTaxClassDescription2 = 105;

               /// <summary>
               /// Property Indexer for VendorTaxClassDescription3
               /// </summary>
               public const int VendorTaxClassDescription3 = 106;

               /// <summary>
               /// Property Indexer for VendorTaxClassDescription4
               /// </summary>
               public const int VendorTaxClassDescription4 = 107;

               /// <summary>
               /// Property Indexer for VendorTaxClassDescription5
               /// </summary>
               public const int VendorTaxClassDescription5 = 108;

               /// <summary>
               /// Property Indexer for ItemTaxClassDescription1
               /// </summary>
               public const int ItemTaxClassDescription1 = 109;

               /// <summary>
               /// Property Indexer for ItemTaxClassDescription2
               /// </summary>
               public const int ItemTaxClassDescription2 = 110;

               /// <summary>
               /// Property Indexer for ItemTaxClassDescription3
               /// </summary>
               public const int ItemTaxClassDescription3 = 111;

               /// <summary>
               /// Property Indexer for ItemTaxClassDescription4
               /// </summary>
               public const int ItemTaxClassDescription4 = 112;

               /// <summary>
               /// Property Indexer for ItemTaxClassDescription5
               /// </summary>
               public const int ItemTaxClassDescription5 = 113;

               /// <summary>
               /// Property Indexer for FuncGrossDistributionAmount
               /// </summary>
               public const int FuncGrossDistributionAmount = 114;

               /// <summary>
               /// Property Indexer for FunctionalExpensedAmount1
               /// </summary>
               public const int FunctionalExpensedAmount1 = 115;

               /// <summary>
               /// Property Indexer for FunctionalExpensedAmount2
               /// </summary>
               public const int FunctionalExpensedAmount2 = 116;

               /// <summary>
               /// Property Indexer for FunctionalExpensedAmount3
               /// </summary>
               public const int FunctionalExpensedAmount3 = 117;

               /// <summary>
               /// Property Indexer for FunctionalExpensedAmount4
               /// </summary>
               public const int FunctionalExpensedAmount4 = 118;

               /// <summary>
               /// Property Indexer for FunctionalExpensedAmount5
               /// </summary>
               public const int FunctionalExpensedAmount5 = 119;

               /// <summary>
               /// Property Indexer for FunctionalRecoverableAmount1
               /// </summary>
               public const int FunctionalRecoverableAmount1 = 120;

               /// <summary>
               /// Property Indexer for FunctionalRecoverableAmount2
               /// </summary>
               public const int FunctionalRecoverableAmount2 = 121;

               /// <summary>
               /// Property Indexer for FunctionalRecoverableAmount3
               /// </summary>
               public const int FunctionalRecoverableAmount3 = 122;

               /// <summary>
               /// Property Indexer for FunctionalRecoverableAmount4
               /// </summary>
               public const int FunctionalRecoverableAmount4 = 123;

               /// <summary>
               /// Property Indexer for FunctionalRecoverableAmount5
               /// </summary>
               public const int FunctionalRecoverableAmount5 = 124;

               /// <summary>
               /// Property Indexer for TaxReportingRate
               /// </summary>
               public const int TaxReportingRate = 125;

               /// <summary>
               /// Property Indexer for TaxReportingRateType
               /// </summary>
               public const int TaxReportingRateType = 126;

               /// <summary>
               /// Property Indexer for TaxReportingRateDate
               /// </summary>
               public const int TaxReportingRateDate = 127;

               /// <summary>
               /// Property Indexer for TaxReportingRateOperation
               /// </summary>
               public const int TaxReportingRateOperation = 128;

               /// <summary>
               /// Property Indexer for TaxReportingCurrencyDesc
               /// </summary>
               public const int TaxReportingCurrencyDesc = 129;

               /// <summary>
               /// Property Indexer for TaxReportingRateTypeDesc
               /// </summary>
               public const int TaxReportingRateTypeDesc = 130;

               /// <summary>
               /// Property Indexer for TaxRate1
               /// </summary>
               public const int TaxRate1 = 131;

               /// <summary>
               /// Property Indexer for TaxRate2
               /// </summary>
               public const int TaxRate2 = 132;

               /// <summary>
               /// Property Indexer for TaxRate3
               /// </summary>
               public const int TaxRate3 = 133;

               /// <summary>
               /// Property Indexer for TaxRate4
               /// </summary>
               public const int TaxRate4 = 134;

               /// <summary>
               /// Property Indexer for TaxRate5
               /// </summary>
               public const int TaxRate5 = 135;

               /// <summary>
               /// Property Indexer for FunctionalNetOfTax
               /// </summary>
               public const int FunctionalNetOfTax = 136;

               /// <summary>
               /// Property Indexer for FunctionalTotalTaxAllocated
               /// </summary>
               public const int FunctionalTotalTaxAllocated = 137;

               /// <summary>
               /// Property Indexer for FunctionalTaxTotal
               /// </summary>
               public const int FunctionalTaxTotal = 138;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount1
               /// </summary>
               public const int TaxAllocatedAmount1 = 139;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount2
               /// </summary>
               public const int TaxAllocatedAmount2 = 140;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount3
               /// </summary>
               public const int TaxAllocatedAmount3 = 141;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount4
               /// </summary>
               public const int TaxAllocatedAmount4 = 142;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount5
               /// </summary>
               public const int TaxAllocatedAmount5 = 143;

               /// <summary>
               /// Property Indexer for TaxReportingExpensed1
               /// </summary>
               public const int TaxReportingExpensed1 = 144;

               /// <summary>
               /// Property Indexer for TaxReportingExpensed2
               /// </summary>
               public const int TaxReportingExpensed2 = 145;

               /// <summary>
               /// Property Indexer for TaxReportingExpensed3
               /// </summary>
               public const int TaxReportingExpensed3 = 146;

               /// <summary>
               /// Property Indexer for TaxReportingExpensed4
               /// </summary>
               public const int TaxReportingExpensed4 = 147;

               /// <summary>
               /// Property Indexer for TaxReportingExpensed5
               /// </summary>
               public const int TaxReportingExpensed5 = 148;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt1
               /// </summary>
               public const int TaxReportingRecoverableAmt1 = 149;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt2
               /// </summary>
               public const int TaxReportingRecoverableAmt2 = 150;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt3
               /// </summary>
               public const int TaxReportingRecoverableAmt3 = 151;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt4
               /// </summary>
               public const int TaxReportingRecoverableAmt4 = 152;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt5
               /// </summary>
               public const int TaxReportingRecoverableAmt5 = 153;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount1
               /// </summary>
               public const int TaxReportingAllocatedAmount1 = 154;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount2
               /// </summary>
               public const int TaxReportingAllocatedAmount2 = 155;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount3
               /// </summary>
               public const int TaxReportingAllocatedAmount3 = 156;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount4
               /// </summary>
               public const int TaxReportingAllocatedAmount4 = 157;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount5
               /// </summary>
               public const int TaxReportingAllocatedAmount5 = 158;

               /// <summary>
               /// Property Indexer for FunctionalAllocatedAmount1
               /// </summary>
               public const int FunctionalAllocatedAmount1 = 159;

               /// <summary>
               /// Property Indexer for FunctionalAllocatedAmount2
               /// </summary>
               public const int FunctionalAllocatedAmount2 = 160;

               /// <summary>
               /// Property Indexer for FunctionalAllocatedAmount3
               /// </summary>
               public const int FunctionalAllocatedAmount3 = 161;

               /// <summary>
               /// Property Indexer for FunctionalAllocatedAmount4
               /// </summary>
               public const int FunctionalAllocatedAmount4 = 162;

               /// <summary>
               /// Property Indexer for FunctionalAllocatedAmount5
               /// </summary>
               public const int FunctionalAllocatedAmount5 = 163;

          }
          #endregion

     }
}
