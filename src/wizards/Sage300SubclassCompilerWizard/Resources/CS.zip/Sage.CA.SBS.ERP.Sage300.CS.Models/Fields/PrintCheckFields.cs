/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PrintCheck Constants 
    /// </summary>
    public partial class PrintCheck
    {
        /// <summary>
        /// Contains list of PrintCheck Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field Property for Request 
            /// </summary>
            public const string Request = "SWREQTYPE";

            /// <summary>
            /// Field Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBATCHNO";

            /// <summary>
            /// Field Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTENTRYNO";

            /// <summary>
            /// Field Property for ReturnedStatus 
            /// </summary>
            public const string ReturnedStatus = "SWRTRNSTTS";

            /// <summary>
            /// Field Property for RestartState 
            /// </summary>
            public const string RestartState = "STATE";

            /// <summary>
            /// Field Property for Bank 
            /// </summary>
            public const string Bank = "IDBANK";

            /// <summary>
            /// Field Property for DecimalsinBankCurrency 
            /// </summary>
            public const string DecimalsinBankCurrency = "DECIMALS";

            /// <summary>
            /// STARTSERIAL
            /// </summary>
            public const string StartSerial = "STARTSERIAL";

            /// <summary>
            /// ENDSERIAL
            /// </summary>
            public const string EndSerial = "ENDSERIAL";

            /// <summary>
            /// APPRUNNUM
            /// </summary>
            public const string AppRunNum = "APPRUNNUM";

            /// <summary>
            /// EXTPARAM1
            /// </summary>
            public const string ExtParam1 = "EXTPARAM1";

            /// <summary>
            /// EXTPARAM2
            /// </summary>
            public const string ExtParam2 = "EXTPARAM2";

            /// <summary>
            /// EXTPARAM3
            /// </summary>
            public const string ExtParam3 = "EXTPARAM3";

            #endregion
        }

        /// <summary>
        /// Contains list of PrintCheck Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Request 
            /// </summary>
            public const int Request = 1;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;

            /// <summary>
            /// Property Indexer for ReturnedStatus 
            /// </summary>
            public const int ReturnedStatus = 4;

            /// <summary>
            /// Property Indexer for RestartState 
            /// </summary>
            public const int RestartState = 5;

            /// <summary>
            /// Property Indexer for Bank 
            /// </summary>
            public const int Bank = 6;

            /// <summary>
            /// Property Indexer for DecimalsinBankCurrency 
            /// </summary>
            public const int DecimalsinBankCurrency = 7;

            #endregion
        }
    }
}