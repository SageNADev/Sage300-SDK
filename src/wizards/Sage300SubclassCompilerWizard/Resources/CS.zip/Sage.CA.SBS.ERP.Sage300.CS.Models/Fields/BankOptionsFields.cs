// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankOptions Constants 
    /// </summary>
    public partial class BankOptions
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0010";

        /// <summary>
        /// Contains list of BankOptions Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BankOption 
            /// </summary>
            public const string BankOption = "OPTIONNBR";

            /// <summary>
            /// Property for NextPostingSequence 
            /// </summary>
            public const string NextPostingSequence = "NXTSEQ";

            /// <summary>
            /// Property for CreateGLBatches 
            /// </summary>
            public const string CreateGLBatches = "GLDEFER";

            /// <summary>
            /// Property for Consolidate GL Batches 
            /// </summary>
            public const string ConsolidateGLBatches = "GLCONSOL";

            /// <summary>
            /// Property for CreateGLTransactionsBy 
            /// </summary>
            public const string CreateGLTransactionsBy = "GLAPPEND";

            /// <summary>
            /// Property for TransferAdjustmentGLAccount 
            /// </summary>
            public const string TransferAdjustmentGLAccount = "TFRACCT";

            /// <summary>
            /// Property for NextBankTransferNumber 
            /// </summary>
            public const string NextBankTransferNumber = "TFRNUMBER";

            /// <summary>
            /// Property for SuppressUnmatchedOFXPosting 
            /// </summary>
            public const string SuppressUnmatchedOFXPosting = "OFXNOPOST";

            /// <summary>
            /// Property for ContactName 
            /// </summary>
            public const string ContactName = "CONTACT";

            /// <summary>
            /// Property for Telephone 
            /// </summary>
            public const string Telephone = "PHONE";

            /// <summary>
            /// Property for FaxNumber 
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for DefaultBankCode 
            /// </summary>
            public const string DefaultBankCode = "BANK";

            /// <summary>
            /// Property for ClearinFuturePeriodlist 
            /// </summary>
            public const string ClearinFuturePeriodlist = "SWRDATE";

            /// <summary>
            /// Property for DepositWriteOffMethod 
            /// </summary>
            public const string DepositWriteOffMethod = "SWDMETH";

            /// <summary>
            /// Property for DefaultDistributionCode 
            /// </summary>
            public const string DefaultDistributionCode = "TFRDISTCOD";

            /// <summary>
            /// Property for Banking Cloud Company GUID
            /// </summary>
            public const string BankingCloudCompany = "BCCOMP";

            /// <summary>
            /// Property for DefaultGLAccount 
            /// </summary>
            public const string DefaultGLAccount = "TFRSRVCACT";

            /// <summary>
            /// Property for BankTransferPrefix 
            /// </summary>
            public const string BankTransferPrefix = "TFRPFX";

            /// <summary>
            /// Property for BankTransferLength 
            /// </summary>
            public const string BankTransferLength = "TFRDOCLEN";

            /// <summary>
            /// Property for BankEntryPrefix 
            /// </summary>
            public const string BankEntryPrefix = "ENTRYPFX";

            /// <summary>
            /// Property for BankEntryLength 
            /// </summary>
            public const string BankEntryLength = "ENTDOCLEN";

            /// <summary>
            /// Property for NextBankEntryNumber 
            /// </summary>
            public const string NextBankEntryNumber = "ENTRYNUM";

            /// <summary>
            /// Property for NextBankTransferDocSeq 
            /// </summary>
            public const string NextBankTransferDocSeq = "SEQTFR";

            /// <summary>
            /// Property for NextBankEntryDocSeq 
            /// </summary>
            public const string NextBankEntryDocSeq = "SEQENTRY";

            /// <summary>
            /// Property for ReconcileList 
            /// </summary>
            public const string ReconcileList = "SWRECONCIL";

            /// <summary>
            /// Property for NextRunId 
            /// </summary>
            public const string NextRunId = "NEXTRUNID";

            /// <summary>
            /// Property for DefaultReconcileDetailSortBy 
            /// </summary>
            public const string DefaultReconcileDetailSortBy = "DTLSORTBY";

            /// <summary>
            /// Property for TransferAdjAccountDesc 
            /// </summary>
            public const string TransferAdjAccountDesc = "TFRACCTD";

            /// <summary>
            /// Property for DefaultDistributionCodeDesc 
            /// </summary>
            public const string DefaultDistributionCodeDesc = "DISTCODED";

            /// <summary>
            /// Property for DefaultGLAccountDescription 
            /// </summary>
            public const string DefaultGLAccountDescription = "SRVCACCTD";

            /// <summary>
            /// Property for DefaultBankCodeDesc 
            /// </summary>
            public const string DefaultBankCodeDesc = "BANKD";

            /// <summary>
            /// Property for DefaultGLDistributionAccount 
            /// </summary>
            public const string DefaultGLDistributionAccount = "DISTACCT";

            /// <summary>
            /// Property for DefaultDistCodeError 
            /// </summary>
            public const string DefaultDistCodeError = "VDISTCODE";

            /// <summary>
            /// Property for DefaultAccountError 
            /// </summary>
            public const string DefaultAccountError = "VSRVCACCNT";

            #endregion
        }

        /// <summary>
        /// Contains list of BankOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BankOption 
            /// </summary>
            public const int BankOption = 1;

            /// <summary>
            /// Property Indexer for NextPostingSequence 
            /// </summary>
            public const int NextPostingSequence = 2;

            /// <summary>
            /// Property Indexer for Create GL Batches 
            /// </summary>
            public const int CreateGLBatches = 3;

            /// <summary>
            /// Property Indexer for Consolidate GL Batches 
            /// </summary>
            public const int ConsolidateGLBatches = 4;

            /// <summary>
            /// Property Indexer for CreateGLTransactionsBy 
            /// </summary>
            public const int CreateGLTransactionsBy = 5;

            /// <summary>
            /// Property Indexer for TransferAdjustmentGLAccount 
            /// </summary>
            public const int TransferAdjustmentGLAccount = 6;

            /// <summary>
            /// Property Indexer for NextBankTransferNumber 
            /// </summary>
            public const int NextBankTransferNumber = 7;

            /// <summary>
            /// Property Indexer for SuppressUnmatchedOFXPosting 
            /// </summary>
            public const int SuppressUnmatchedOFXPosting = 12;

            /// <summary>
            /// Property Indexer for ContactName 
            /// </summary>
            public const int ContactName = 13;

            /// <summary>
            /// Property Indexer for Telephone 
            /// </summary>
            public const int Telephone = 14;

            /// <summary>
            /// Property Indexer for FaxNumber 
            /// </summary>
            public const int FaxNumber = 15;

            /// <summary>
            /// Property Indexer for DefaultBankCode 
            /// </summary>
            public const int DefaultBankCode = 16;

            /// <summary>
            /// Property Indexer for ClearinFuturePeriodlist 
            /// </summary>
            public const int ClearinFuturePeriodlist = 17;

            /// <summary>
            /// Property Indexer for DepositWriteOffMethod 
            /// </summary>
            public const int DepositWriteOffMethod = 18;

            /// <summary>
            /// Property Indexer for DefaultDistributionCode 
            /// </summary>
            public const int DefaultDistributionCode = 19;

            /// <summary>
            /// Property Indexer for DefaultGLAccount 
            /// </summary>
            public const int DefaultGLAccount = 20;

            /// <summary>
            /// Property Indexer for BankTransferPrefix 
            /// </summary>
            public const int BankTransferPrefix = 21;

            /// <summary>
            /// Property Indexer for BankTransferLength 
            /// </summary>
            public const int BankTransferLength = 22;

            /// <summary>
            /// Property Indexer for BankEntryPrefix 
            /// </summary>
            public const int BankEntryPrefix = 23;

            /// <summary>
            /// Property Indexer for BankEntryLength 
            /// </summary>
            public const int BankEntryLength = 24;

            /// <summary>
            /// Property Indexer for NextBankEntryNumber 
            /// </summary>
            public const int NextBankEntryNumber = 25;

            /// <summary>
            /// Property Indexer for NextBankTransferDocSeq 
            /// </summary>
            public const int NextBankTransferDocSeq = 26;

            /// <summary>
            /// Property Indexer for NextBankEntryDocSeq 
            /// </summary>
            public const int NextBankEntryDocSeq = 27;

            /// <summary>
            /// Property Indexer for ReconcileList 
            /// </summary>
            public const int ReconcileList = 28;

            /// <summary>
            /// Property Indexer for NextRunId 
            /// </summary>
            public const int NextRunId = 29;

            /// <summary>
            /// Property Indexer for DefaultReconcileDetailSortBy 
            /// </summary>
            public const int DefaultReconcileDetailSortBy = 30;

            /// <summary>
            /// Property Indexer for Banking Cloud Company GUID
            /// </summary>
            public const int BankingCloudCompany = 31;

            /// <summary>
            /// Property Indexer for TransferAdjAccountDesc 
            /// </summary>
            public const int TransferAdjAccountDesc = 70;

            /// <summary>
            /// Property Indexer for DefaultDistributionCodeDesc 
            /// </summary>
            public const int DefaultDistributionCodeDesc = 71;

            /// <summary>
            /// Property Indexer for DefaultGLAccountDescription 
            /// </summary>
            public const int DefaultGLAccountDescription = 72;

            /// <summary>
            /// Property Indexer for DefaultBankCodeDesc 
            /// </summary>
            public const int DefaultBankCodeDesc = 73;

            /// <summary>
            /// Property Indexer for DefaultGLDistributionAccount 
            /// </summary>
            public const int DefaultGLDistributionAccount = 74;

            /// <summary>
            /// Property Indexer for DefaultDistCodeError 
            /// </summary>
            public const int DefaultDistCodeError = 75;

            /// <summary>
            /// Property Indexer for DefaultAccountError 
            /// </summary>
            public const int DefaultAccountError = 76;

            #endregion
        }
    }
}