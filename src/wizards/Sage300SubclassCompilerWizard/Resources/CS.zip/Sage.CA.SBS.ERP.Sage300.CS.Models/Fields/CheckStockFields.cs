/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of CheckStocks Constants 
    /// </summary>
    public partial class CheckStock
    {
        /// <summary>
        /// Check Stocks
        /// </summary>
        public const string EntityName = "BK0008";

        /// <summary>
        /// Contains list of CheckStocks Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";
            /// <summary>
            /// Property for CheckStockCode 
            /// </summary>
            public const string CheckStockCode = "FORMID";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";
            /// <summary>
            /// Property for NextCheckNumber 
            /// </summary>
            public const string NextCheckNumber = "CHECK";
            /// <summary>
            /// Property for StockType 
            /// </summary>
            public const string StockType = "STKTYPE";
            /// <summary>
            /// Property for CheckForm 
            /// </summary>
            public const string CheckForm = "FORMSPEC1";
            /// <summary>
            /// Property for AdviceForm 
            /// </summary>
            public const string AdviceForm = "FORMSPEC2";
            /// <summary>
            /// Property for AdviceLinesPerPage 
            /// </summary>
            public const string AdviceLinesPerPage = "ADVICE";
            /// <summary>
            /// Property for Language 
            /// </summary>
            public const string Language = "LANGUAGE";

            #endregion
        }

        /// <summary>
        /// Contains list of CheckStocks Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;
            /// <summary>
            /// Property Indexer for CheckStockCode 
            /// </summary>
            public const int CheckStockCode = 2;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;
            /// <summary>
            /// Property Indexer for NextCheckNumber 
            /// </summary>
            public const int NextCheckNumber = 4;
            /// <summary>
            /// Property Indexer for StockType 
            /// </summary>
            public const int StockType = 5;
            /// <summary>
            /// Property Indexer for CheckForm 
            /// </summary>
            public const int CheckForm = 6;
            /// <summary>
            /// Property Indexer for AdviceForm 
            /// </summary>
            public const int AdviceForm = 7;
            /// <summary>
            /// Property Indexer for AdviceLinesPerPage 
            /// </summary>
            public const int AdviceLinesPerPage = 8;
            /// <summary>
            /// Property Indexer for Language 
            /// </summary>
            public const int Language = 9;

            #endregion
        }
    }
}
