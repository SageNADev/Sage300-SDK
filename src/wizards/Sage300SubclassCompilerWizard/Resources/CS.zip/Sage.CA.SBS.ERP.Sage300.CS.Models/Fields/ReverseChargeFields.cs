// Copyright (c) 2018 Sage  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of ReverseCharge Constants
    /// </summary>
    public partial class ReverseCharge
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "TX0017";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of ReverseCharge Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for TaxAuthority
            /// </summary>
            public const string TaxAuthority = "AUTHORITY";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TTYPE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            /// <summary>
            /// Property for ThresholdAmount
            /// </summary>
            public const string ThresholdAmount = "THRESHOLD";

            /// <summary>
            /// Property for REVCHG0101
            /// </summary>
            public const string REVCHG0101 = "REVCHG0101";

            /// <summary>
            /// Property for REVCHG0102
            /// </summary>
            public const string REVCHG0102 = "REVCHG0102";

            /// <summary>
            /// Property for REVCHG0103
            /// </summary>
            public const string REVCHG0103 = "REVCHG0103";

            /// <summary>
            /// Property for REVCHG0104
            /// </summary>
            public const string REVCHG0104 = "REVCHG0104";

            /// <summary>
            /// Property for REVCHG0105
            /// </summary>
            public const string REVCHG0105 = "REVCHG0105";

            /// <summary>
            /// Property for REVCHG0106
            /// </summary>
            public const string REVCHG0106 = "REVCHG0106";

            /// <summary>
            /// Property for REVCHG0107
            /// </summary>
            public const string REVCHG0107 = "REVCHG0107";

            /// <summary>
            /// Property for REVCHG0108
            /// </summary>
            public const string REVCHG0108 = "REVCHG0108";

            /// <summary>
            /// Property for REVCHG0109
            /// </summary>
            public const string REVCHG0109 = "REVCHG0109";

            /// <summary>
            /// Property for REVCHG0110
            /// </summary>
            public const string REVCHG0110 = "REVCHG0110";

            /// <summary>
            /// Property for REVCHG0201
            /// </summary>
            public const string REVCHG0201 = "REVCHG0201";

            /// <summary>
            /// Property for REVCHG0202
            /// </summary>
            public const string REVCHG0202 = "REVCHG0202";

            /// <summary>
            /// Property for REVCHG0203
            /// </summary>
            public const string REVCHG0203 = "REVCHG0203";

            /// <summary>
            /// Property for REVCHG0204
            /// </summary>
            public const string REVCHG0204 = "REVCHG0204";

            /// <summary>
            /// Property for REVCHG0205
            /// </summary>
            public const string REVCHG0205 = "REVCHG0205";

            /// <summary>
            /// Property for REVCHG0206
            /// </summary>
            public const string REVCHG0206 = "REVCHG0206";

            /// <summary>
            /// Property for REVCHG0207
            /// </summary>
            public const string REVCHG0207 = "REVCHG0207";

            /// <summary>
            /// Property for REVCHG0208
            /// </summary>
            public const string REVCHG0208 = "REVCHG0208";

            /// <summary>
            /// Property for REVCHG0209
            /// </summary>
            public const string REVCHG0209 = "REVCHG0209";

            /// <summary>
            /// Property for REVCHG0210
            /// </summary>
            public const string REVCHG0210 = "REVCHG0210";

            /// <summary>
            /// Property for REVCHG0301
            /// </summary>
            public const string REVCHG0301 = "REVCHG0301";

            /// <summary>
            /// Property for REVCHG0302
            /// </summary>
            public const string REVCHG0302 = "REVCHG0302";

            /// <summary>
            /// Property for REVCHG0303
            /// </summary>
            public const string REVCHG0303 = "REVCHG0303";

            /// <summary>
            /// Property for REVCHG0304
            /// </summary>
            public const string REVCHG0304 = "REVCHG0304";

            /// <summary>
            /// Property for REVCHG0305
            /// </summary>
            public const string REVCHG0305 = "REVCHG0305";

            /// <summary>
            /// Property for REVCHG0306
            /// </summary>
            public const string REVCHG0306 = "REVCHG0306";

            /// <summary>
            /// Property for REVCHG0307
            /// </summary>
            public const string REVCHG0307 = "REVCHG0307";

            /// <summary>
            /// Property for REVCHG0308
            /// </summary>
            public const string REVCHG0308 = "REVCHG0308";

            /// <summary>
            /// Property for REVCHG0309
            /// </summary>
            public const string REVCHG0309 = "REVCHG0309";

            /// <summary>
            /// Property for REVCHG0310
            /// </summary>
            public const string REVCHG0310 = "REVCHG0310";

            /// <summary>
            /// Property for REVCHG0401
            /// </summary>
            public const string REVCHG0401 = "REVCHG0401";

            /// <summary>
            /// Property for REVCHG0402
            /// </summary>
            public const string REVCHG0402 = "REVCHG0402";

            /// <summary>
            /// Property for REVCHG0403
            /// </summary>
            public const string REVCHG0403 = "REVCHG0403";

            /// <summary>
            /// Property for REVCHG0404
            /// </summary>
            public const string REVCHG0404 = "REVCHG0404";

            /// <summary>
            /// Property for REVCHG0405
            /// </summary>
            public const string REVCHG0405 = "REVCHG0405";

            /// <summary>
            /// Property for REVCHG0406
            /// </summary>
            public const string REVCHG0406 = "REVCHG0406";

            /// <summary>
            /// Property for REVCHG0407
            /// </summary>
            public const string REVCHG0407 = "REVCHG0407";

            /// <summary>
            /// Property for REVCHG0408
            /// </summary>
            public const string REVCHG0408 = "REVCHG0408";

            /// <summary>
            /// Property for REVCHG0409
            /// </summary>
            public const string REVCHG0409 = "REVCHG0409";

            /// <summary>
            /// Property for REVCHG0410
            /// </summary>
            public const string REVCHG0410 = "REVCHG0410";

            /// <summary>
            /// Property for REVCHG0501
            /// </summary>
            public const string REVCHG0501 = "REVCHG0501";

            /// <summary>
            /// Property for REVCHG0502
            /// </summary>
            public const string REVCHG0502 = "REVCHG0502";

            /// <summary>
            /// Property for REVCHG0503
            /// </summary>
            public const string REVCHG0503 = "REVCHG0503";

            /// <summary>
            /// Property for REVCHG0504
            /// </summary>
            public const string REVCHG0504 = "REVCHG0504";

            /// <summary>
            /// Property for REVCHG0505
            /// </summary>
            public const string REVCHG0505 = "REVCHG0505";

            /// <summary>
            /// Property for REVCHG0506
            /// </summary>
            public const string REVCHG0506 = "REVCHG0506";

            /// <summary>
            /// Property for REVCHG0507
            /// </summary>
            public const string REVCHG0507 = "REVCHG0507";

            /// <summary>
            /// Property for REVCHG0508
            /// </summary>
            public const string REVCHG0508 = "REVCHG0508";

            /// <summary>
            /// Property for REVCHG0509
            /// </summary>
            public const string REVCHG0509 = "REVCHG0509";

            /// <summary>
            /// Property for REVCHG0510
            /// </summary>
            public const string REVCHG0510 = "REVCHG0510";

            /// <summary>
            /// Property for REVCHG0601
            /// </summary>
            public const string REVCHG0601 = "REVCHG0601";

            /// <summary>
            /// Property for REVCHG0602
            /// </summary>
            public const string REVCHG0602 = "REVCHG0602";

            /// <summary>
            /// Property for REVCHG0603
            /// </summary>
            public const string REVCHG0603 = "REVCHG0603";

            /// <summary>
            /// Property for REVCHG0604
            /// </summary>
            public const string REVCHG0604 = "REVCHG0604";

            /// <summary>
            /// Property for REVCHG0605
            /// </summary>
            public const string REVCHG0605 = "REVCHG0605";

            /// <summary>
            /// Property for REVCHG0606
            /// </summary>
            public const string REVCHG0606 = "REVCHG0606";

            /// <summary>
            /// Property for REVCHG0607
            /// </summary>
            public const string REVCHG0607 = "REVCHG0607";

            /// <summary>
            /// Property for REVCHG0608
            /// </summary>
            public const string REVCHG0608 = "REVCHG0608";

            /// <summary>
            /// Property for REVCHG0609
            /// </summary>
            public const string REVCHG0609 = "REVCHG0609";

            /// <summary>
            /// Property for REVCHG0610
            /// </summary>
            public const string REVCHG0610 = "REVCHG0610";

            /// <summary>
            /// Property for REVCHG0701
            /// </summary>
            public const string REVCHG0701 = "REVCHG0701";

            /// <summary>
            /// Property for REVCHG0702
            /// </summary>
            public const string REVCHG0702 = "REVCHG0702";

            /// <summary>
            /// Property for REVCHG0703
            /// </summary>
            public const string REVCHG0703 = "REVCHG0703";

            /// <summary>
            /// Property for REVCHG0704
            /// </summary>
            public const string REVCHG0704 = "REVCHG0704";

            /// <summary>
            /// Property for REVCHG0705
            /// </summary>
            public const string REVCHG0705 = "REVCHG0705";

            /// <summary>
            /// Property for REVCHG0706
            /// </summary>
            public const string REVCHG0706 = "REVCHG0706";

            /// <summary>
            /// Property for REVCHG0707
            /// </summary>
            public const string REVCHG0707 = "REVCHG0707";

            /// <summary>
            /// Property for REVCHG0708
            /// </summary>
            public const string REVCHG0708 = "REVCHG0708";

            /// <summary>
            /// Property for REVCHG0709
            /// </summary>
            public const string REVCHG0709 = "REVCHG0709";

            /// <summary>
            /// Property for REVCHG0710
            /// </summary>
            public const string REVCHG0710 = "REVCHG0710";

            /// <summary>
            /// Property for REVCHG0801
            /// </summary>
            public const string REVCHG0801 = "REVCHG0801";

            /// <summary>
            /// Property for REVCHG0802
            /// </summary>
            public const string REVCHG0802 = "REVCHG0802";

            /// <summary>
            /// Property for REVCHG0803
            /// </summary>
            public const string REVCHG0803 = "REVCHG0803";

            /// <summary>
            /// Property for REVCHG0804
            /// </summary>
            public const string REVCHG0804 = "REVCHG0804";

            /// <summary>
            /// Property for REVCHG0805
            /// </summary>
            public const string REVCHG0805 = "REVCHG0805";

            /// <summary>
            /// Property for REVCHG0806
            /// </summary>
            public const string REVCHG0806 = "REVCHG0806";

            /// <summary>
            /// Property for REVCHG0807
            /// </summary>
            public const string REVCHG0807 = "REVCHG0807";

            /// <summary>
            /// Property for REVCHG0808
            /// </summary>
            public const string REVCHG0808 = "REVCHG0808";

            /// <summary>
            /// Property for REVCHG0809
            /// </summary>
            public const string REVCHG0809 = "REVCHG0809";

            /// <summary>
            /// Property for REVCHG0810
            /// </summary>
            public const string REVCHG0810 = "REVCHG0810";

            /// <summary>
            /// Property for REVCHG0901
            /// </summary>
            public const string REVCHG0901 = "REVCHG0901";

            /// <summary>
            /// Property for REVCHG0902
            /// </summary>
            public const string REVCHG0902 = "REVCHG0902";

            /// <summary>
            /// Property for REVCHG0903
            /// </summary>
            public const string REVCHG0903 = "REVCHG0903";

            /// <summary>
            /// Property for REVCHG0904
            /// </summary>
            public const string REVCHG0904 = "REVCHG0904";

            /// <summary>
            /// Property for REVCHG0905
            /// </summary>
            public const string REVCHG0905 = "REVCHG0905";

            /// <summary>
            /// Property for REVCHG0906
            /// </summary>
            public const string REVCHG0906 = "REVCHG0906";

            /// <summary>
            /// Property for REVCHG0907
            /// </summary>
            public const string REVCHG0907 = "REVCHG0907";

            /// <summary>
            /// Property for REVCHG0908
            /// </summary>
            public const string REVCHG0908 = "REVCHG0908";

            /// <summary>
            /// Property for REVCHG0909
            /// </summary>
            public const string REVCHG0909 = "REVCHG0909";

            /// <summary>
            /// Property for REVCHG0910
            /// </summary>
            public const string REVCHG0910 = "REVCHG0910";

            /// <summary>
            /// Property for REVCHG1001
            /// </summary>
            public const string REVCHG1001 = "REVCHG1001";

            /// <summary>
            /// Property for REVCHG1002
            /// </summary>
            public const string REVCHG1002 = "REVCHG1002";

            /// <summary>
            /// Property for REVCHG1003
            /// </summary>
            public const string REVCHG1003 = "REVCHG1003";

            /// <summary>
            /// Property for REVCHG1004
            /// </summary>
            public const string REVCHG1004 = "REVCHG1004";

            /// <summary>
            /// Property for REVCHG1005
            /// </summary>
            public const string REVCHG1005 = "REVCHG1005";

            /// <summary>
            /// Property for REVCHG1006
            /// </summary>
            public const string REVCHG1006 = "REVCHG1006";

            /// <summary>
            /// Property for REVCHG1007
            /// </summary>
            public const string REVCHG1007 = "REVCHG1007";

            /// <summary>
            /// Property for REVCHG1008
            /// </summary>
            public const string REVCHG1008 = "REVCHG1008";

            /// <summary>
            /// Property for REVCHG1009
            /// </summary>
            public const string REVCHG1009 = "REVCHG1009";

            /// <summary>
            /// Property for REVCHG1010
            /// </summary>
            public const string REVCHG1010 = "REVCHG1010";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ReverseCharge Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for TaxAuthority
            /// </summary>
            public const int TaxAuthority = 1;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 2;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 3;

            /// <summary>
            /// Property Indexer for ThresholdAmount
            /// </summary>
            public const int ThresholdAmount = 4;

            /// <summary>
            /// Property Indexer for REVCHG0101
            /// </summary>
            public const int REVCHG0101 = 5;

            /// <summary>
            /// Property Indexer for REVCHG0102
            /// </summary>
            public const int REVCHG0102 = 6;

            /// <summary>
            /// Property Indexer for REVCHG0103
            /// </summary>
            public const int REVCHG0103 = 7;

            /// <summary>
            /// Property Indexer for REVCHG0104
            /// </summary>
            public const int REVCHG0104 = 8;

            /// <summary>
            /// Property Indexer for REVCHG0105
            /// </summary>
            public const int REVCHG0105 = 9;

            /// <summary>
            /// Property Indexer for REVCHG0106
            /// </summary>
            public const int REVCHG0106 = 10;

            /// <summary>
            /// Property Indexer for REVCHG0107
            /// </summary>
            public const int REVCHG0107 = 11;

            /// <summary>
            /// Property Indexer for REVCHG0108
            /// </summary>
            public const int REVCHG0108 = 12;

            /// <summary>
            /// Property Indexer for REVCHG0109
            /// </summary>
            public const int REVCHG0109 = 13;

            /// <summary>
            /// Property Indexer for REVCHG0110
            /// </summary>
            public const int REVCHG0110 = 14;

            /// <summary>
            /// Property Indexer for REVCHG0201
            /// </summary>
            public const int REVCHG0201 = 15;

            /// <summary>
            /// Property Indexer for REVCHG0202
            /// </summary>
            public const int REVCHG0202 = 16;

            /// <summary>
            /// Property Indexer for REVCHG0203
            /// </summary>
            public const int REVCHG0203 = 17;

            /// <summary>
            /// Property Indexer for REVCHG0204
            /// </summary>
            public const int REVCHG0204 = 18;

            /// <summary>
            /// Property Indexer for REVCHG0205
            /// </summary>
            public const int REVCHG0205 = 19;

            /// <summary>
            /// Property Indexer for REVCHG0206
            /// </summary>
            public const int REVCHG0206 = 20;

            /// <summary>
            /// Property Indexer for REVCHG0207
            /// </summary>
            public const int REVCHG0207 = 21;

            /// <summary>
            /// Property Indexer for REVCHG0208
            /// </summary>
            public const int REVCHG0208 = 22;

            /// <summary>
            /// Property Indexer for REVCHG0209
            /// </summary>
            public const int REVCHG0209 = 23;

            /// <summary>
            /// Property Indexer for REVCHG0210
            /// </summary>
            public const int REVCHG0210 = 24;

            /// <summary>
            /// Property Indexer for REVCHG0301
            /// </summary>
            public const int REVCHG0301 = 25;

            /// <summary>
            /// Property Indexer for REVCHG0302
            /// </summary>
            public const int REVCHG0302 = 26;

            /// <summary>
            /// Property Indexer for REVCHG0303
            /// </summary>
            public const int REVCHG0303 = 27;

            /// <summary>
            /// Property Indexer for REVCHG0304
            /// </summary>
            public const int REVCHG0304 = 28;

            /// <summary>
            /// Property Indexer for REVCHG0305
            /// </summary>
            public const int REVCHG0305 = 29;

            /// <summary>
            /// Property Indexer for REVCHG0306
            /// </summary>
            public const int REVCHG0306 = 30;

            /// <summary>
            /// Property Indexer for REVCHG0307
            /// </summary>
            public const int REVCHG0307 = 31;

            /// <summary>
            /// Property Indexer for REVCHG0308
            /// </summary>
            public const int REVCHG0308 = 32;

            /// <summary>
            /// Property Indexer for REVCHG0309
            /// </summary>
            public const int REVCHG0309 = 33;

            /// <summary>
            /// Property Indexer for REVCHG0310
            /// </summary>
            public const int REVCHG0310 = 34;

            /// <summary>
            /// Property Indexer for REVCHG0401
            /// </summary>
            public const int REVCHG0401 = 35;

            /// <summary>
            /// Property Indexer for REVCHG0402
            /// </summary>
            public const int REVCHG0402 = 36;

            /// <summary>
            /// Property Indexer for REVCHG0403
            /// </summary>
            public const int REVCHG0403 = 37;

            /// <summary>
            /// Property Indexer for REVCHG0404
            /// </summary>
            public const int REVCHG0404 = 38;

            /// <summary>
            /// Property Indexer for REVCHG0405
            /// </summary>
            public const int REVCHG0405 = 39;

            /// <summary>
            /// Property Indexer for REVCHG0406
            /// </summary>
            public const int REVCHG0406 = 40;

            /// <summary>
            /// Property Indexer for REVCHG0407
            /// </summary>
            public const int REVCHG0407 = 41;

            /// <summary>
            /// Property Indexer for REVCHG0408
            /// </summary>
            public const int REVCHG0408 = 42;

            /// <summary>
            /// Property Indexer for REVCHG0409
            /// </summary>
            public const int REVCHG0409 = 43;

            /// <summary>
            /// Property Indexer for REVCHG0410
            /// </summary>
            public const int REVCHG0410 = 44;

            /// <summary>
            /// Property Indexer for REVCHG0501
            /// </summary>
            public const int REVCHG0501 = 45;

            /// <summary>
            /// Property Indexer for REVCHG0502
            /// </summary>
            public const int REVCHG0502 = 46;

            /// <summary>
            /// Property Indexer for REVCHG0503
            /// </summary>
            public const int REVCHG0503 = 47;

            /// <summary>
            /// Property Indexer for REVCHG0504
            /// </summary>
            public const int REVCHG0504 = 48;

            /// <summary>
            /// Property Indexer for REVCHG0505
            /// </summary>
            public const int REVCHG0505 = 49;

            /// <summary>
            /// Property Indexer for REVCHG0506
            /// </summary>
            public const int REVCHG0506 = 50;

            /// <summary>
            /// Property Indexer for REVCHG0507
            /// </summary>
            public const int REVCHG0507 = 51;

            /// <summary>
            /// Property Indexer for REVCHG0508
            /// </summary>
            public const int REVCHG0508 = 52;

            /// <summary>
            /// Property Indexer for REVCHG0509
            /// </summary>
            public const int REVCHG0509 = 53;

            /// <summary>
            /// Property Indexer for REVCHG0510
            /// </summary>
            public const int REVCHG0510 = 54;

            /// <summary>
            /// Property Indexer for REVCHG0601
            /// </summary>
            public const int REVCHG0601 = 55;

            /// <summary>
            /// Property Indexer for REVCHG0602
            /// </summary>
            public const int REVCHG0602 = 56;

            /// <summary>
            /// Property Indexer for REVCHG0603
            /// </summary>
            public const int REVCHG0603 = 57;

            /// <summary>
            /// Property Indexer for REVCHG0604
            /// </summary>
            public const int REVCHG0604 = 58;

            /// <summary>
            /// Property Indexer for REVCHG0605
            /// </summary>
            public const int REVCHG0605 = 59;

            /// <summary>
            /// Property Indexer for REVCHG0606
            /// </summary>
            public const int REVCHG0606 = 60;

            /// <summary>
            /// Property Indexer for REVCHG0607
            /// </summary>
            public const int REVCHG0607 = 61;

            /// <summary>
            /// Property Indexer for REVCHG0608
            /// </summary>
            public const int REVCHG0608 = 62;

            /// <summary>
            /// Property Indexer for REVCHG0609
            /// </summary>
            public const int REVCHG0609 = 63;

            /// <summary>
            /// Property Indexer for REVCHG0610
            /// </summary>
            public const int REVCHG0610 = 64;

            /// <summary>
            /// Property Indexer for REVCHG0701
            /// </summary>
            public const int REVCHG0701 = 65;

            /// <summary>
            /// Property Indexer for REVCHG0702
            /// </summary>
            public const int REVCHG0702 = 66;

            /// <summary>
            /// Property Indexer for REVCHG0703
            /// </summary>
            public const int REVCHG0703 = 67;

            /// <summary>
            /// Property Indexer for REVCHG0704
            /// </summary>
            public const int REVCHG0704 = 68;

            /// <summary>
            /// Property Indexer for REVCHG0705
            /// </summary>
            public const int REVCHG0705 = 69;

            /// <summary>
            /// Property Indexer for REVCHG0706
            /// </summary>
            public const int REVCHG0706 = 70;

            /// <summary>
            /// Property Indexer for REVCHG0707
            /// </summary>
            public const int REVCHG0707 = 71;

            /// <summary>
            /// Property Indexer for REVCHG0708
            /// </summary>
            public const int REVCHG0708 = 72;

            /// <summary>
            /// Property Indexer for REVCHG0709
            /// </summary>
            public const int REVCHG0709 = 73;

            /// <summary>
            /// Property Indexer for REVCHG0710
            /// </summary>
            public const int REVCHG0710 = 74;

            /// <summary>
            /// Property Indexer for REVCHG0801
            /// </summary>
            public const int REVCHG0801 = 75;

            /// <summary>
            /// Property Indexer for REVCHG0802
            /// </summary>
            public const int REVCHG0802 = 76;

            /// <summary>
            /// Property Indexer for REVCHG0803
            /// </summary>
            public const int REVCHG0803 = 77;

            /// <summary>
            /// Property Indexer for REVCHG0804
            /// </summary>
            public const int REVCHG0804 = 78;

            /// <summary>
            /// Property Indexer for REVCHG0805
            /// </summary>
            public const int REVCHG0805 = 79;

            /// <summary>
            /// Property Indexer for REVCHG0806
            /// </summary>
            public const int REVCHG0806 = 80;

            /// <summary>
            /// Property Indexer for REVCHG0807
            /// </summary>
            public const int REVCHG0807 = 81;

            /// <summary>
            /// Property Indexer for REVCHG0808
            /// </summary>
            public const int REVCHG0808 = 82;

            /// <summary>
            /// Property Indexer for REVCHG0809
            /// </summary>
            public const int REVCHG0809 = 83;

            /// <summary>
            /// Property Indexer for REVCHG0810
            /// </summary>
            public const int REVCHG0810 = 84;

            /// <summary>
            /// Property Indexer for REVCHG0901
            /// </summary>
            public const int REVCHG0901 = 85;

            /// <summary>
            /// Property Indexer for REVCHG0902
            /// </summary>
            public const int REVCHG0902 = 86;

            /// <summary>
            /// Property Indexer for REVCHG0903
            /// </summary>
            public const int REVCHG0903 = 87;

            /// <summary>
            /// Property Indexer for REVCHG0904
            /// </summary>
            public const int REVCHG0904 = 88;

            /// <summary>
            /// Property Indexer for REVCHG0905
            /// </summary>
            public const int REVCHG0905 = 89;

            /// <summary>
            /// Property Indexer for REVCHG0906
            /// </summary>
            public const int REVCHG0906 = 90;

            /// <summary>
            /// Property Indexer for REVCHG0907
            /// </summary>
            public const int REVCHG0907 = 91;

            /// <summary>
            /// Property Indexer for REVCHG0908
            /// </summary>
            public const int REVCHG0908 = 92;

            /// <summary>
            /// Property Indexer for REVCHG0909
            /// </summary>
            public const int REVCHG0909 = 93;

            /// <summary>
            /// Property Indexer for REVCHG0910
            /// </summary>
            public const int REVCHG0910 = 94;

            /// <summary>
            /// Property Indexer for REVCHG1001
            /// </summary>
            public const int REVCHG1001 = 95;

            /// <summary>
            /// Property Indexer for REVCHG1002
            /// </summary>
            public const int REVCHG1002 = 96;

            /// <summary>
            /// Property Indexer for REVCHG1003
            /// </summary>
            public const int REVCHG1003 = 97;

            /// <summary>
            /// Property Indexer for REVCHG1004
            /// </summary>
            public const int REVCHG1004 = 98;

            /// <summary>
            /// Property Indexer for REVCHG1005
            /// </summary>
            public const int REVCHG1005 = 99;

            /// <summary>
            /// Property Indexer for REVCHG1006
            /// </summary>
            public const int REVCHG1006 = 100;

            /// <summary>
            /// Property Indexer for REVCHG1007
            /// </summary>
            public const int REVCHG1007 = 101;

            /// <summary>
            /// Property Indexer for REVCHG1008
            /// </summary>
            public const int REVCHG1008 = 102;

            /// <summary>
            /// Property Indexer for REVCHG1009
            /// </summary>
            public const int REVCHG1009 = 103;

            /// <summary>
            /// Property Indexer for REVCHG1010
            /// </summary>
            public const int REVCHG1010 = 104;

            /// <summary>
            /// Property Indexer for InputTaxAccount
            /// </summary>
            public const int InputTaxAccount = 200;
            
            /// <summary>
            /// Property Indexer for OutputTaxAccount
            /// </summary>
            public const int OutputTaxAccount = 201;

        }

        #endregion

    }
}