// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
	/// <summary>
	/// Contains list of ScheduleApplicationLink Constants
	/// </summary>
	public partial class ScheduleApplicationLink
    {

        #region Entity Name

        /// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "CS0032";

        #endregion

        #region Properties

        /// <summary>
		/// Contains list of ScheduleApplicationLink Field Constants
		/// </summary>
		public class Fields
        {

            #region Properties

            /// <summary>
			/// Property for ScheduleCode
			/// </summary>
			public const string ScheduleCode = "SCHEDKEY";

			/// <summary>
			/// Property for ScheduleLink
			/// </summary>
			public const string ScheduleLink = "SCHEDLINK";

			/// <summary>
			/// Property for APPLICATIO
			/// </summary>
			public const string Application = "APPLICATIO";

			/// <summary>
			/// Property for ApplicationType
			/// </summary>
			public const string ApplicationType = "AOPCODE";

			/// <summary>
			/// Property for JobTypes
			/// </summary>
			public const string JobTypes = "AOPERATION";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "ADESCRIPTI";

			/// <summary>
			/// Property for APPLICATID
			/// </summary>
			public const string ApplicationID = "APPLICATID";

			/// <summary>
			/// Property for LastRunDate
			/// </summary>
			public const string LastRunDate = "LASTRUNDAT";

			/// <summary>
			/// Property for NextRunDate
			/// </summary>
			public const string NextRunDate = "ACTIVEDATE";

            #endregion
        }

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ScheduleApplicationLink Index Constants
		/// </summary>
		public class Index
        {

            #region Properties

            /// <summary>
			/// Property Indexer for ScheduleCode
			/// </summary>
			public const int ScheduleCode = 1;

			/// <summary>
			/// Property Indexer for ScheduleLink
			/// </summary>
			public const int ScheduleLink = 2;

			/// <summary>
			/// Property Indexer for APPLICATIO
			/// </summary>
			public const int Application = 3;

			/// <summary>
			/// Property Indexer for ApplicationType
			/// </summary>
			public const int ApplicationType = 4;

			/// <summary>
			/// Property Indexer for JobTypes
			/// </summary>
			public const int JobTypes = 5;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 6;

			/// <summary>
			/// Property Indexer for APPLICATID
			/// </summary>
            public const int ApplicationID = 51;

			/// <summary>
			/// Property Indexer for LastRunDate
			/// </summary>
			public const int LastRunDate = 52;

			/// <summary>
			/// Property Indexer for NextRunDate
			/// </summary>
			public const int NextRunDate = 53;

            #endregion

        }

		#endregion

	}
}
