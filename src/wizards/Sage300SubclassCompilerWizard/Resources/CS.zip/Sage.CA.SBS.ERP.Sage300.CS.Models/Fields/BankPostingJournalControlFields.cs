﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankPostingJournalControl Constants 
    /// </summary>
    public partial class BankPostingJournalControl
    {
        /// <summary>
        /// Bank Posting Journal Control
        /// </summary>
        public const string EntityName = "BK0020";

        /// <summary>
        /// Contains list of BankPostingJournalControl Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for PostingSequence 
            /// </summary>
            public const string PostingSequence = "PSTSEQ";
            /// <summary>
            /// Property for FromBank 
            /// </summary>
            public const string FromBank = "FROMBANK";
            /// <summary>
            /// Property for ToBank 
            /// </summary>
            public const string ToBank = "TOBANK";
            /// <summary>
            /// Property for DatePostedtoGL 
            /// </summary>
            public const string DatePostedtoGL = "POSTDATE";
            /// <summary>
            /// Property for PostingUser 
            /// </summary>
            public const string PostingUser = "POSTUSER";
            /// <summary>
            /// Property for PostingStatus 
            /// </summary>
            public const string PostingStatus = "POSTSTAT";
            /// <summary>
            /// Property for PostingStatus 
            /// </summary>
            public const string TypePostingStatus = "POSTSTAT";
            /// <summary>
            /// Property for LastDateJournalPrinted 
            /// </summary>
            public const string LastDateJournalPrinted = "PRINTDATE";
            /// <summary>
            /// Property for CreateGOrLBatches 
            /// </summary>
            public const string CreateGorLBatches = "GLDEFER";
            /// <summary>
            /// Property for CreateGOrLBatches 
            /// </summary>
            public const string TypeCreateGorLBatches = "GLDEFER";
            /// <summary>
            /// Property for ConsolidateGOrLBatches 
            /// </summary>
            public const string ConsolidateGorLBatches = "GLCONSOL";
            /// <summary>
            /// Property for ConsolidateGOrLBatches 
            /// </summary>
            public const string TypeConsolidateGorLBatches = "GLCONSOL";
            /// <summary>
            /// Property for CreateGOrLTransactionsBy 
            /// </summary>
            public const string CreateGorLTransactionsBy = "GLAPPEND";
            /// <summary>
            /// Property for CreateGOrLTransactionsBy 
            /// </summary>
            public const string TypeCreateGorLTransactionsBy = "GLAPPEND";
            /// <summary>
            /// Property for GOrLBatchNumber 
            /// </summary>
            public const string GorLBatchNumber = "GLBATCH";
            /// <summary>
            /// Property for GOrLBatchTransferred 
            /// </summary>
            public const string GorLBatchTransferred = "GLTRANS";
            /// <summary>
            /// Property for GOrLBatchTransferred 
            /// </summary>
            public const string TypeGorLBatchTransferred = "GLTRANS";
            /// <summary>
            /// Property for PostingType 
            /// </summary>
            public const string PostingType = "POSTTYPE";
            /// <summary>
            /// Property for PostingType 
            /// </summary>
            public const string TypePosting = "POSTTYPE";
            /// <summary>
            /// Property for BankSequence 
            /// </summary>
            public const string BankSequence = "BANKSEQ";
            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "PRINTED";
            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string TypePrinted = "PRINTED";

            #endregion
        }

        /// <summary>
        /// Contains list of BankPostingJournalControl Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for PostingSequence 
            /// </summary>
            public const int PostingSequence = 1;
            /// <summary>
            /// Property Indexer for FromBank 
            /// </summary>
            public const int FromBank = 2;
            /// <summary>
            /// Property Indexer for ToBank 
            /// </summary>
            public const int ToBank = 3;
            /// <summary>
            /// Property Indexer for DatePostedtoGL 
            /// </summary>
            public const int DatePostedtoGL = 4;
            /// <summary>
            /// Property Indexer for PostingUser 
            /// </summary>
            public const int PostingUser = 5;
            /// <summary>
            /// Property Indexer for PostingStatus 
            /// </summary>
            public const int PostingStatus = 6;
            /// <summary>
            /// Property Indexer for LastDateJournalPrinted 
            /// </summary>
            public const int LastDateJournalPrinted = 7;
            /// <summary>
            /// Property Indexer for CreateGOrLBatches 
            /// </summary>
            public const int CreateGorLBatches = 8;
            /// <summary>
            /// Property Indexer for ConsolidateGOrLBatches 
            /// </summary>
            public const int ConsolidateGorLBatches = 9;
            /// <summary>
            /// Property Indexer for CreateGOrLTransactionsBy 
            /// </summary>
            public const int CreateGorLTransactionsBy = 10;
            /// <summary>
            /// Property Indexer for GOrLBatchNumber 
            /// </summary>
            public const int GorLBatchNumber = 11;
            /// <summary>
            /// Property Indexer for GOrLBatchTransferred 
            /// </summary>
            public const int GorLBatchTransferred = 12;
            /// <summary>
            /// Property Indexer for PostingType 
            /// </summary>
            public const int PostingType = 13;
            /// <summary>
            /// Property Indexer for BankSequence 
            /// </summary>
            public const int BankSequence = 14;
            /// <summary>
            /// Property Indexer for Printed 
            /// </summary>
            public const int Printed = 30;

            #endregion
        }
    }
}