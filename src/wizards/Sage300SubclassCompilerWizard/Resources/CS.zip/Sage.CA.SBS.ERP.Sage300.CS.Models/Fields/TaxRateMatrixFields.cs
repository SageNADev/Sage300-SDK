/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of TaxRateMatrix Constants 
    /// </summary>
	public partial class TaxRateMatrix 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TX0902";

        /// <summary>
        /// Contains list of TaxRateMatrix Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for Authority 
        /// </summary>
	    public const string Authority  = "AUTHORITY";
	            /// <summary>
        /// Property for Type 
        /// </summary>
	    public const string Type  = "TYPE";
	            /// <summary>
        /// Property for LastMaintained 
        /// </summary>
	    public const string LastMaintained  = "LASTMAINT";
	            /// <summary>
        /// Property for Buyerclass1Itemclass1 
        /// </summary>
	    public const string Buyerclass1Itemclass1  = "BUY01ITM01";
	            /// <summary>
        /// Property for Buyerclass1Itemclass2 
        /// </summary>
	    public const string Buyerclass1Itemclass2  = "BUY01ITM02";
	            /// <summary>
        /// Property for Buyerclass1Itemclass3 
        /// </summary>
	    public const string Buyerclass1Itemclass3  = "BUY01ITM03";
	            /// <summary>
        /// Property for Buyerclass1Itemclass4 
        /// </summary>
	    public const string Buyerclass1Itemclass4  = "BUY01ITM04";
	            /// <summary>
        /// Property for Buyerclass1Itemclass5 
        /// </summary>
	    public const string Buyerclass1Itemclass5  = "BUY01ITM05";
	            /// <summary>
        /// Property for Buyerclass1Itemclass6 
        /// </summary>
	    public const string Buyerclass1Itemclass6  = "BUY01ITM06";
	            /// <summary>
        /// Property for Buyerclass1Itemclass7 
        /// </summary>
	    public const string Buyerclass1Itemclass7  = "BUY01ITM07";
	            /// <summary>
        /// Property for Buyerclass1Itemclass8 
        /// </summary>
	    public const string Buyerclass1Itemclass8  = "BUY01ITM08";
	            /// <summary>
        /// Property for Buyerclass1Itemclass9 
        /// </summary>
	    public const string Buyerclass1Itemclass9  = "BUY01ITM09";
	            /// <summary>
        /// Property for Buyerclass1Itemclass10 
        /// </summary>
	    public const string Buyerclass1Itemclass10  = "BUY01ITM10";
	            /// <summary>
        /// Property for Buyerclass2Itemclass1 
        /// </summary>
	    public const string Buyerclass2Itemclass1  = "BUY02ITM01";
	            /// <summary>
        /// Property for Buyerclass2Itemclass2 
        /// </summary>
	    public const string Buyerclass2Itemclass2  = "BUY02ITM02";
	            /// <summary>
        /// Property for Buyerclass2Itemclass3 
        /// </summary>
	    public const string Buyerclass2Itemclass3  = "BUY02ITM03";
	            /// <summary>
        /// Property for Buyerclass2Itemclass4 
        /// </summary>
	    public const string Buyerclass2Itemclass4  = "BUY02ITM04";
	            /// <summary>
        /// Property for Buyerclass2Itemclass5 
        /// </summary>
	    public const string Buyerclass2Itemclass5  = "BUY02ITM05";
	            /// <summary>
        /// Property for Buyerclass2Itemclass6 
        /// </summary>
	    public const string Buyerclass2Itemclass6  = "BUY02ITM06";
	            /// <summary>
        /// Property for Buyerclass2Itemclass7 
        /// </summary>
	    public const string Buyerclass2Itemclass7  = "BUY02ITM07";
	            /// <summary>
        /// Property for Buyerclass2Itemclass8 
        /// </summary>
	    public const string Buyerclass2Itemclass8  = "BUY02ITM08";
	            /// <summary>
        /// Property for Buyerclass2Itemclass9 
        /// </summary>
	    public const string Buyerclass2Itemclass9  = "BUY02ITM09";
	            /// <summary>
        /// Property for Buyerclass2Itemclass10 
        /// </summary>
	    public const string Buyerclass2Itemclass10  = "BUY02ITM10";
	            /// <summary>
        /// Property for Buyerclass3Itemclass1 
        /// </summary>
	    public const string Buyerclass3Itemclass1  = "BUY03ITM01";
	            /// <summary>
        /// Property for Buyerclass3Itemclass2 
        /// </summary>
	    public const string Buyerclass3Itemclass2  = "BUY03ITM02";
	            /// <summary>
        /// Property for Buyerclass3Itemclass3 
        /// </summary>
	    public const string Buyerclass3Itemclass3  = "BUY03ITM03";
	            /// <summary>
        /// Property for Buyerclass3Itemclass4 
        /// </summary>
	    public const string Buyerclass3Itemclass4  = "BUY03ITM04";
	            /// <summary>
        /// Property for Buyerclass3Itemclass5 
        /// </summary>
	    public const string Buyerclass3Itemclass5  = "BUY03ITM05";
	            /// <summary>
        /// Property for Buyerclass3Itemclass6 
        /// </summary>
	    public const string Buyerclass3Itemclass6  = "BUY03ITM06";
	            /// <summary>
        /// Property for Buyerclass3Itemclass7 
        /// </summary>
	    public const string Buyerclass3Itemclass7  = "BUY03ITM07";
	            /// <summary>
        /// Property for Buyerclass3Itemclass8 
        /// </summary>
	    public const string Buyerclass3Itemclass8  = "BUY03ITM08";
	            /// <summary>
        /// Property for Buyerclass3Itemclass9 
        /// </summary>
	    public const string Buyerclass3Itemclass9  = "BUY03ITM09";
	            /// <summary>
        /// Property for Buyerclass3Itemclass10 
        /// </summary>
	    public const string Buyerclass3Itemclass10  = "BUY03ITM10";
	            /// <summary>
        /// Property for Buyerclass4Itemclass1 
        /// </summary>
	    public const string Buyerclass4Itemclass1  = "BUY04ITM01";
	            /// <summary>
        /// Property for Buyerclass4Itemclass2 
        /// </summary>
	    public const string Buyerclass4Itemclass2  = "BUY04ITM02";
	            /// <summary>
        /// Property for Buyerclass4Itemclass3 
        /// </summary>
	    public const string Buyerclass4Itemclass3  = "BUY04ITM03";
	            /// <summary>
        /// Property for Buyerclass4Itemclass4 
        /// </summary>
	    public const string Buyerclass4Itemclass4  = "BUY04ITM04";
	            /// <summary>
        /// Property for Buyerclass4Itemclass5 
        /// </summary>
	    public const string Buyerclass4Itemclass5  = "BUY04ITM05";
	            /// <summary>
        /// Property for Buyerclass4Itemclass6 
        /// </summary>
	    public const string Buyerclass4Itemclass6  = "BUY04ITM06";
	            /// <summary>
        /// Property for Buyerclass4Itemclass7 
        /// </summary>
	    public const string Buyerclass4Itemclass7  = "BUY04ITM07";
	            /// <summary>
        /// Property for Buyerclass4Itemclass8 
        /// </summary>
	    public const string Buyerclass4Itemclass8  = "BUY04ITM08";
	            /// <summary>
        /// Property for Buyerclass4Itemclass9 
        /// </summary>
	    public const string Buyerclass4Itemclass9  = "BUY04ITM09";
	            /// <summary>
        /// Property for Buyerclass4Itemclass10 
        /// </summary>
	    public const string Buyerclass4Itemclass10  = "BUY04ITM10";
	            /// <summary>
        /// Property for Buyerclass5Itemclass1 
        /// </summary>
	    public const string Buyerclass5Itemclass1  = "BUY05ITM01";
	            /// <summary>
        /// Property for Buyerclass5Itemclass2 
        /// </summary>
	    public const string Buyerclass5Itemclass2  = "BUY05ITM02";
	            /// <summary>
        /// Property for Buyerclass5Itemclass3 
        /// </summary>
	    public const string Buyerclass5Itemclass3  = "BUY05ITM03";
	            /// <summary>
        /// Property for Buyerclass5Itemclass4 
        /// </summary>
	    public const string Buyerclass5Itemclass4  = "BUY05ITM04";
	            /// <summary>
        /// Property for Buyerclass5Itemclass5 
        /// </summary>
	    public const string Buyerclass5Itemclass5  = "BUY05ITM05";
	            /// <summary>
        /// Property for Buyerclass5Itemclass6 
        /// </summary>
	    public const string Buyerclass5Itemclass6  = "BUY05ITM06";
	            /// <summary>
        /// Property for Buyerclass5Itemclass7 
        /// </summary>
	    public const string Buyerclass5Itemclass7  = "BUY05ITM07";
	            /// <summary>
        /// Property for Buyerclass5Itemclass8 
        /// </summary>
	    public const string Buyerclass5Itemclass8  = "BUY05ITM08";
	            /// <summary>
        /// Property for Buyerclass5Itemclass9 
        /// </summary>
	    public const string Buyerclass5Itemclass9  = "BUY05ITM09";
	            /// <summary>
        /// Property for Buyerclass5Itemclass10 
        /// </summary>
	    public const string Buyerclass5Itemclass10  = "BUY05ITM10";
	            /// <summary>
        /// Property for Buyerclass6Itemclass1 
        /// </summary>
	    public const string Buyerclass6Itemclass1  = "BUY06ITM01";
	            /// <summary>
        /// Property for Buyerclass6Itemclass2 
        /// </summary>
	    public const string Buyerclass6Itemclass2  = "BUY06ITM02";
	            /// <summary>
        /// Property for Buyerclass6Itemclass3 
        /// </summary>
	    public const string Buyerclass6Itemclass3  = "BUY06ITM03";
	            /// <summary>
        /// Property for Buyerclass6Itemclass4 
        /// </summary>
	    public const string Buyerclass6Itemclass4  = "BUY06ITM04";
	            /// <summary>
        /// Property for Buyerclass6Itemclass5 
        /// </summary>
	    public const string Buyerclass6Itemclass5  = "BUY06ITM05";
	            /// <summary>
        /// Property for Buyerclass6Itemclass6 
        /// </summary>
	    public const string Buyerclass6Itemclass6  = "BUY06ITM06";
	            /// <summary>
        /// Property for Buyerclass6Itemclass7 
        /// </summary>
	    public const string Buyerclass6Itemclass7  = "BUY06ITM07";
	            /// <summary>
        /// Property for Buyerclass6Itemclass8 
        /// </summary>
	    public const string Buyerclass6Itemclass8  = "BUY06ITM08";
	            /// <summary>
        /// Property for Buyerclass6Itemclass9 
        /// </summary>
	    public const string Buyerclass6Itemclass9  = "BUY06ITM09";
	            /// <summary>
        /// Property for Buyerclass6Itemclass10 
        /// </summary>
	    public const string Buyerclass6Itemclass10  = "BUY06ITM10";
	            /// <summary>
        /// Property for Buyerclass7Itemclass1 
        /// </summary>
	    public const string Buyerclass7Itemclass1  = "BUY07ITM01";
	            /// <summary>
        /// Property for Buyerclass7Itemclass2 
        /// </summary>
	    public const string Buyerclass7Itemclass2  = "BUY07ITM02";
	            /// <summary>
        /// Property for Buyerclass7Itemclass3 
        /// </summary>
	    public const string Buyerclass7Itemclass3  = "BUY07ITM03";
	            /// <summary>
        /// Property for Buyerclass7Itemclass4 
        /// </summary>
	    public const string Buyerclass7Itemclass4  = "BUY07ITM04";
	            /// <summary>
        /// Property for Buyerclass7Itemclass5 
        /// </summary>
	    public const string Buyerclass7Itemclass5  = "BUY07ITM05";
	            /// <summary>
        /// Property for Buyerclass7Itemclass6 
        /// </summary>
	    public const string Buyerclass7Itemclass6  = "BUY07ITM06";
	            /// <summary>
        /// Property for Buyerclass7Itemclass7 
        /// </summary>
	    public const string Buyerclass7Itemclass7  = "BUY07ITM07";
	            /// <summary>
        /// Property for Buyerclass7Itemclass8 
        /// </summary>
	    public const string Buyerclass7Itemclass8  = "BUY07ITM08";
	            /// <summary>
        /// Property for Buyerclass7Itemclass9 
        /// </summary>
	    public const string Buyerclass7Itemclass9  = "BUY07ITM09";
	            /// <summary>
        /// Property for Buyerclass7Itemclass10 
        /// </summary>
	    public const string Buyerclass7Itemclass10  = "BUY07ITM10";
	            /// <summary>
        /// Property for Buyerclass8Itemclass1 
        /// </summary>
	    public const string Buyerclass8Itemclass1  = "BUY08ITM01";
	            /// <summary>
        /// Property for Buyerclass8Itemclass2 
        /// </summary>
	    public const string Buyerclass8Itemclass2  = "BUY08ITM02";
	            /// <summary>
        /// Property for Buyerclass8Itemclass3 
        /// </summary>
	    public const string Buyerclass8Itemclass3  = "BUY08ITM03";
	            /// <summary>
        /// Property for Buyerclass8Itemclass4 
        /// </summary>
	    public const string Buyerclass8Itemclass4  = "BUY08ITM04";
	            /// <summary>
        /// Property for Buyerclass8Itemclass5 
        /// </summary>
	    public const string Buyerclass8Itemclass5  = "BUY08ITM05";
	            /// <summary>
        /// Property for Buyerclass8Itemclass6 
        /// </summary>
	    public const string Buyerclass8Itemclass6  = "BUY08ITM06";
	            /// <summary>
        /// Property for Buyerclass8Itemclass7 
        /// </summary>
	    public const string Buyerclass8Itemclass7  = "BUY08ITM07";
	            /// <summary>
        /// Property for Buyerclass8Itemclass8 
        /// </summary>
	    public const string Buyerclass8Itemclass8  = "BUY08ITM08";
	            /// <summary>
        /// Property for Buyerclass8Itemclass9 
        /// </summary>
	    public const string Buyerclass8Itemclass9  = "BUY08ITM09";
	            /// <summary>
        /// Property for Buyerclass8Itemclass10 
        /// </summary>
	    public const string Buyerclass8Itemclass10  = "BUY08ITM10";
	            /// <summary>
        /// Property for Buyerclass9Itemclass1 
        /// </summary>
	    public const string Buyerclass9Itemclass1  = "BUY09ITM01";
	            /// <summary>
        /// Property for Buyerclass9Itemclass2 
        /// </summary>
	    public const string Buyerclass9Itemclass2  = "BUY09ITM02";
	            /// <summary>
        /// Property for Buyerclass9Itemclass3 
        /// </summary>
	    public const string Buyerclass9Itemclass3  = "BUY09ITM03";
	            /// <summary>
        /// Property for Buyerclass9Itemclass4 
        /// </summary>
	    public const string Buyerclass9Itemclass4  = "BUY09ITM04";
	            /// <summary>
        /// Property for Buyerclass9Itemclass5 
        /// </summary>
	    public const string Buyerclass9Itemclass5  = "BUY09ITM05";
	            /// <summary>
        /// Property for Buyerclass9Itemclass6 
        /// </summary>
	    public const string Buyerclass9Itemclass6  = "BUY09ITM06";
	            /// <summary>
        /// Property for Buyerclass9Itemclass7 
        /// </summary>
	    public const string Buyerclass9Itemclass7  = "BUY09ITM07";
	            /// <summary>
        /// Property for Buyerclass9Itemclass8 
        /// </summary>
	    public const string Buyerclass9Itemclass8  = "BUY09ITM08";
	            /// <summary>
        /// Property for Buyerclass9Itemclass9 
        /// </summary>
	    public const string Buyerclass9Itemclass9  = "BUY09ITM09";
	            /// <summary>
        /// Property for Buyerclass9Itemclass10 
        /// </summary>
	    public const string Buyerclass9Itemclass10  = "BUY09ITM10";
	            /// <summary>
        /// Property for Buyerclass10Itemclass1 
        /// </summary>
	    public const string Buyerclass10Itemclass1  = "BUY10ITM01";
	            /// <summary>
        /// Property for Buyerclass10Itemclass2 
        /// </summary>
	    public const string Buyerclass10Itemclass2  = "BUY10ITM02";
	            /// <summary>
        /// Property for Buyerclass10Itemclass3 
        /// </summary>
	    public const string Buyerclass10Itemclass3  = "BUY10ITM03";
	            /// <summary>
        /// Property for Buyerclass10Itemclass4 
        /// </summary>
	    public const string Buyerclass10Itemclass4  = "BUY10ITM04";
	            /// <summary>
        /// Property for Buyerclass10Itemclass5 
        /// </summary>
	    public const string Buyerclass10Itemclass5  = "BUY10ITM05";
	            /// <summary>
        /// Property for Buyerclass10Itemclass6 
        /// </summary>
	    public const string Buyerclass10Itemclass6  = "BUY10ITM06";
	            /// <summary>
        /// Property for Buyerclass10Itemclass7 
        /// </summary>
	    public const string Buyerclass10Itemclass7  = "BUY10ITM07";
	            /// <summary>
        /// Property for Buyerclass10Itemclass8 
        /// </summary>
	    public const string Buyerclass10Itemclass8  = "BUY10ITM08";
	            /// <summary>
        /// Property for Buyerclass10Itemclass9 
        /// </summary>
	    public const string Buyerclass10Itemclass9  = "BUY10ITM09";
	            /// <summary>
        /// Property for Buyerclass10Itemclass10 
        /// </summary>
	    public const string Buyerclass10Itemclass10  = "BUY10ITM10";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of TaxRateMatrix Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for Authority 
        /// </summary>
	    public const int Authority  = 1;
	             /// <summary>
        /// Property Indexer for Type 
        /// </summary>
	    public const int Type  = 2;
	             /// <summary>
        /// Property Indexer for LastMaintained 
        /// </summary>
	    public const int LastMaintained  = 3;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass1 
        /// </summary>
	    public const int Buyerclass1Itemclass1  = 101;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass2 
        /// </summary>
	    public const int Buyerclass1Itemclass2  = 102;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass3 
        /// </summary>
	    public const int Buyerclass1Itemclass3  = 103;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass4 
        /// </summary>
	    public const int Buyerclass1Itemclass4  = 104;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass5 
        /// </summary>
	    public const int Buyerclass1Itemclass5  = 105;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass6 
        /// </summary>
	    public const int Buyerclass1Itemclass6  = 106;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass7 
        /// </summary>
	    public const int Buyerclass1Itemclass7  = 107;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass8 
        /// </summary>
	    public const int Buyerclass1Itemclass8  = 108;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass9 
        /// </summary>
	    public const int Buyerclass1Itemclass9  = 109;
	             /// <summary>
        /// Property Indexer for Buyerclass1Itemclass10 
        /// </summary>
	    public const int Buyerclass1Itemclass10  = 110;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass1 
        /// </summary>
	    public const int Buyerclass2Itemclass1  = 201;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass2 
        /// </summary>
	    public const int Buyerclass2Itemclass2  = 202;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass3 
        /// </summary>
	    public const int Buyerclass2Itemclass3  = 203;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass4 
        /// </summary>
	    public const int Buyerclass2Itemclass4  = 204;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass5 
        /// </summary>
	    public const int Buyerclass2Itemclass5  = 205;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass6 
        /// </summary>
	    public const int Buyerclass2Itemclass6  = 206;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass7 
        /// </summary>
	    public const int Buyerclass2Itemclass7  = 207;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass8 
        /// </summary>
	    public const int Buyerclass2Itemclass8  = 208;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass9 
        /// </summary>
	    public const int Buyerclass2Itemclass9  = 209;
	             /// <summary>
        /// Property Indexer for Buyerclass2Itemclass10 
        /// </summary>
	    public const int Buyerclass2Itemclass10  = 210;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass1 
        /// </summary>
	    public const int Buyerclass3Itemclass1  = 301;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass2 
        /// </summary>
	    public const int Buyerclass3Itemclass2  = 302;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass3 
        /// </summary>
	    public const int Buyerclass3Itemclass3  = 303;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass4 
        /// </summary>
	    public const int Buyerclass3Itemclass4  = 304;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass5 
        /// </summary>
	    public const int Buyerclass3Itemclass5  = 305;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass6 
        /// </summary>
	    public const int Buyerclass3Itemclass6  = 306;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass7 
        /// </summary>
	    public const int Buyerclass3Itemclass7  = 307;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass8 
        /// </summary>
	    public const int Buyerclass3Itemclass8  = 308;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass9 
        /// </summary>
	    public const int Buyerclass3Itemclass9  = 309;
	             /// <summary>
        /// Property Indexer for Buyerclass3Itemclass10 
        /// </summary>
	    public const int Buyerclass3Itemclass10  = 310;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass1 
        /// </summary>
	    public const int Buyerclass4Itemclass1  = 401;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass2 
        /// </summary>
	    public const int Buyerclass4Itemclass2  = 402;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass3 
        /// </summary>
	    public const int Buyerclass4Itemclass3  = 403;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass4 
        /// </summary>
	    public const int Buyerclass4Itemclass4  = 404;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass5 
        /// </summary>
	    public const int Buyerclass4Itemclass5  = 405;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass6 
        /// </summary>
	    public const int Buyerclass4Itemclass6  = 406;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass7 
        /// </summary>
	    public const int Buyerclass4Itemclass7  = 407;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass8 
        /// </summary>
	    public const int Buyerclass4Itemclass8  = 408;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass9 
        /// </summary>
	    public const int Buyerclass4Itemclass9  = 409;
	             /// <summary>
        /// Property Indexer for Buyerclass4Itemclass10 
        /// </summary>
	    public const int Buyerclass4Itemclass10  = 410;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass1 
        /// </summary>
	    public const int Buyerclass5Itemclass1  = 501;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass2 
        /// </summary>
	    public const int Buyerclass5Itemclass2  = 502;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass3 
        /// </summary>
	    public const int Buyerclass5Itemclass3  = 503;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass4 
        /// </summary>
	    public const int Buyerclass5Itemclass4  = 504;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass5 
        /// </summary>
	    public const int Buyerclass5Itemclass5  = 505;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass6 
        /// </summary>
	    public const int Buyerclass5Itemclass6  = 506;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass7 
        /// </summary>
	    public const int Buyerclass5Itemclass7  = 507;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass8 
        /// </summary>
	    public const int Buyerclass5Itemclass8  = 508;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass9 
        /// </summary>
	    public const int Buyerclass5Itemclass9  = 509;
	             /// <summary>
        /// Property Indexer for Buyerclass5Itemclass10 
        /// </summary>
	    public const int Buyerclass5Itemclass10  = 510;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass1 
        /// </summary>
	    public const int Buyerclass6Itemclass1  = 601;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass2 
        /// </summary>
	    public const int Buyerclass6Itemclass2  = 602;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass3 
        /// </summary>
	    public const int Buyerclass6Itemclass3  = 603;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass4 
        /// </summary>
	    public const int Buyerclass6Itemclass4  = 604;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass5 
        /// </summary>
	    public const int Buyerclass6Itemclass5  = 605;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass6 
        /// </summary>
	    public const int Buyerclass6Itemclass6  = 606;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass7 
        /// </summary>
	    public const int Buyerclass6Itemclass7  = 607;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass8 
        /// </summary>
	    public const int Buyerclass6Itemclass8  = 608;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass9 
        /// </summary>
	    public const int Buyerclass6Itemclass9  = 609;
	             /// <summary>
        /// Property Indexer for Buyerclass6Itemclass10 
        /// </summary>
	    public const int Buyerclass6Itemclass10  = 610;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass1 
        /// </summary>
	    public const int Buyerclass7Itemclass1  = 701;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass2 
        /// </summary>
	    public const int Buyerclass7Itemclass2  = 702;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass3 
        /// </summary>
	    public const int Buyerclass7Itemclass3  = 703;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass4 
        /// </summary>
	    public const int Buyerclass7Itemclass4  = 704;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass5 
        /// </summary>
	    public const int Buyerclass7Itemclass5  = 705;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass6 
        /// </summary>
	    public const int Buyerclass7Itemclass6  = 706;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass7 
        /// </summary>
	    public const int Buyerclass7Itemclass7  = 707;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass8 
        /// </summary>
	    public const int Buyerclass7Itemclass8  = 708;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass9 
        /// </summary>
	    public const int Buyerclass7Itemclass9  = 709;
	             /// <summary>
        /// Property Indexer for Buyerclass7Itemclass10 
        /// </summary>
	    public const int Buyerclass7Itemclass10  = 710;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass1 
        /// </summary>
	    public const int Buyerclass8Itemclass1  = 801;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass2 
        /// </summary>
	    public const int Buyerclass8Itemclass2  = 802;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass3 
        /// </summary>
	    public const int Buyerclass8Itemclass3  = 803;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass4 
        /// </summary>
	    public const int Buyerclass8Itemclass4  = 804;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass5 
        /// </summary>
	    public const int Buyerclass8Itemclass5  = 805;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass6 
        /// </summary>
	    public const int Buyerclass8Itemclass6  = 806;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass7 
        /// </summary>
	    public const int Buyerclass8Itemclass7  = 807;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass8 
        /// </summary>
	    public const int Buyerclass8Itemclass8  = 808;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass9 
        /// </summary>
	    public const int Buyerclass8Itemclass9  = 809;
	             /// <summary>
        /// Property Indexer for Buyerclass8Itemclass10 
        /// </summary>
	    public const int Buyerclass8Itemclass10  = 810;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass1 
        /// </summary>
	    public const int Buyerclass9Itemclass1  = 901;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass2 
        /// </summary>
	    public const int Buyerclass9Itemclass2  = 902;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass3 
        /// </summary>
	    public const int Buyerclass9Itemclass3  = 903;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass4 
        /// </summary>
	    public const int Buyerclass9Itemclass4  = 904;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass5 
        /// </summary>
	    public const int Buyerclass9Itemclass5  = 905;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass6 
        /// </summary>
	    public const int Buyerclass9Itemclass6  = 906;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass7 
        /// </summary>
	    public const int Buyerclass9Itemclass7  = 907;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass8 
        /// </summary>
	    public const int Buyerclass9Itemclass8  = 908;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass9 
        /// </summary>
	    public const int Buyerclass9Itemclass9  = 909;
	             /// <summary>
        /// Property Indexer for Buyerclass9Itemclass10 
        /// </summary>
	    public const int Buyerclass9Itemclass10  = 910;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass1 
        /// </summary>
	    public const int Buyerclass10Itemclass1  = 1001;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass2 
        /// </summary>
	    public const int Buyerclass10Itemclass2  = 1002;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass3 
        /// </summary>
	    public const int Buyerclass10Itemclass3  = 1003;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass4 
        /// </summary>
	    public const int Buyerclass10Itemclass4  = 1004;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass5 
        /// </summary>
	    public const int Buyerclass10Itemclass5  = 1005;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass6 
        /// </summary>
	    public const int Buyerclass10Itemclass6  = 1006;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass7 
        /// </summary>
	    public const int Buyerclass10Itemclass7  = 1007;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass8 
        /// </summary>
	    public const int Buyerclass10Itemclass8  = 1008;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass9 
        /// </summary>
	    public const int Buyerclass10Itemclass9  = 1009;
	             /// <summary>
        /// Property Indexer for Buyerclass10Itemclass10 
        /// </summary>
	    public const int Buyerclass10Itemclass10  = 1010;
	     
        #endregion
	    }

	
	}
}
	