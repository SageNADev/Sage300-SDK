// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankCheckPrintingFunctions Constants 
    /// </summary>
    public partial class BankCheckPrintingFunction
    {
        /// <summary>
        /// Bank Check Printing Functions
        /// </summary>
        public const string EntityName = "BK0107";

        /// <summary>
        /// Contains list of BankCheckPrintingFunctions Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";

            /// <summary>
            /// Property for ApplicationRunNumber 
            /// </summary>
            public const string ApplicationRunNumber = "APPRUNNUM";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for CheckStockCode 
            /// </summary>
            public const string CheckStockCode = "FORMID";

            /// <summary>
            /// Property for NumberofPrintPhases 
            /// </summary>
            public const string NumberofPrintPhases = "PHASES";

            /// <summary>
            /// Property for AdviceLines 
            /// </summary>
            public const string AdviceLines = "ADVICE";

            /// <summary>
            /// Property for CheckRunPrepared? 
            /// </summary>
            public const string CheckRunPrepared = "PREPARED";

            /// <summary>
            /// Property for Language 
            /// </summary>
            public const string Language = "LANGUAGE";

            /// <summary>
            /// Property for LanguageCode 
            /// </summary>
            public const string LanguageCode = "LANGCODE";

            /// <summary>
            /// Property for UnprintedChecksForThisLangua 
            /// </summary>
            public const string UnprintedChecksForThisLangua = "LANUNPRCHK";

            /// <summary>
            /// Property for ChecksforthisLanguagePosted? 
            /// </summary>
            public const string ChecksforthisLanguagePosted = "LANGPOSTED";

            /// <summary>
            /// Property for StockType 
            /// </summary>
            public const string StockType = "STKTYPE";

            /// <summary>
            /// Property for Function 
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for CurrentPrintPhase 
            /// </summary>
            public const string CurrentPrintPhase = "PHASE";

            /// <summary>
            /// Property for NumberofChecks 
            /// </summary>
            public const string NumberofChecks = "CHECKS";

            /// <summary>
            /// Property for FromCheckNumber 
            /// </summary>
            public const string FromCheckNumber = "CHECKFROM";

            /// <summary>
            /// Property for ToCheckNumber 
            /// </summary>
            public const string ToCheckNumber = "CHECKTO";

            /// <summary>
            /// Property for FromSerialNumber 
            /// </summary>
            public const string FromSerialNumber = "SERIALFROM";

            /// <summary>
            /// Property for ToSerialNumber 
            /// </summary>
            public const string ToSerialNumber = "SERIALTO";

            /// <summary>
            /// Property for Criteria 
            /// </summary>
            public const string Criteria = "CRITERIA";

            /// <summary>
            /// Property for CheckStatus 
            /// </summary>
            public const string CheckStatus = "STATUS";

            /// <summary>
            /// Property for Reprinting 
            /// </summary>
            public const string Reprinting = "REPRINT";

            /// <summary>
            /// Property for CurrentLanguageForThisBank 
            /// </summary>
            public const string CurrentLanguageForThisBank = "LANGCOOKIE";

            /// <summary>
            /// Property for LanguagesForThisBank 
            /// </summary>
            public const string LanguagesForThisBank = "LANGS";

            /// <summary>
            /// Property for UnpostedLanguagesForThisBank 
            /// </summary>
            public const string UnpostedLanguagesForThisBank = "UNPOSLANGS";

            /// <summary>
            /// Property for UnprintedChecksForThisBank 
            /// </summary>
            public const string UnprintedChecksForThisBank = "BANUNPRCHK";

            /// <summary>
            /// Property for BankName 
            /// </summary>
            public const string BankName = "BANKNAME";

            /// <summary>
            /// Property for StatementCurrency 
            /// </summary>
            public const string StatementCurrency = "BANKCUR";

            /// <summary>
            /// Property for StatementCurrencyName 
            /// </summary>
            public const string StatementCurrencyName = "BANKCURDES";

            /// <summary>
            /// Property for ChecksforthisBankPosted? 
            /// </summary>
            public const string ChecksforthisBankPosted = "BANKPOSTED";

            /// <summary>
            /// Property for ModeofOperation 
            /// </summary>
            public const string ModeofOperation = "MODE";

            /// <summary>
            /// Property for HidePrintedChecks 
            /// </summary>
            public const string HidePrintedChecks = "HIDEPRINT";

            /// <summary>
            /// Property for Banks 
            /// </summary>
            public const string Banks = "BANKCOOKIE";

            /// <summary>
            /// Property for BanksForThisRun 
            /// </summary>
            public const string BanksForThisRun = "BANKS";

            /// <summary>
            /// Property for UnpostedBanksForThisRun 
            /// </summary>
            public const string UnpostedBanksForThisRun = "UNPOSBANKS";

            /// <summary>
            /// Property for UnprintedCheckCountTotal 
            /// </summary>
            public const string UnprintedCheckCountTotal = "TOTUNPRCHK";

            /// <summary>
            /// Property for CheckForm 
            /// </summary>
            public const string CheckForm = "CHECKFORM";

            /// <summary>
            /// Property for AdviceForm 
            /// </summary>
            public const string AdviceForm = "ADVISEFORM";

            #endregion
        }

        /// <summary>
        /// Contains list of BankCheckPrintingFunctions Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 1;

            /// <summary>
            /// Property Indexer for ApplicationRunNumber 
            /// </summary>
            public const int ApplicationRunNumber = 2;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 3;

            /// <summary>
            /// Property Indexer for CheckStockCode 
            /// </summary>
            public const int CheckStockCode = 4;

            /// <summary>
            /// Property Indexer for NumberofPrintPhases 
            /// </summary>
            public const int NumberofPrintPhases = 10;

            /// <summary>
            /// Property Indexer for AdviceLines 
            /// </summary>
            public const int AdviceLines = 11;

            /// <summary>
            /// Property Indexer for CheckRunPrepared? 
            /// </summary>
            public const int CheckRunPrepared = 12;

            /// <summary>
            /// Property Indexer for Language 
            /// </summary>
            public const int Language = 13;

            /// <summary>
            /// Property Indexer for LanguageCode 
            /// </summary>
            public const int LanguageCode = 14;

            /// <summary>
            /// Property Indexer for UnprintedChecksForThisLangua 
            /// </summary>
            public const int UnprintedChecksForThisLanguage = 15;

            /// <summary>
            /// Property Indexer for ChecksforthisLanguagePosted? 
            /// </summary>
            public const int ChecksforthisLanguagePosted = 16;

            /// <summary>
            /// Property Indexer for StockType 
            /// </summary>
            public const int StockType = 17;

            /// <summary>
            /// Property Indexer for Function 
            /// </summary>
            public const int Function = 20;

            /// <summary>
            /// Property Indexer for CurrentPrintPhase 
            /// </summary>
            public const int CurrentPrintPhase = 21;

            /// <summary>
            /// Property Indexer for NumberofChecks 
            /// </summary>
            public const int NumberofChecks = 22;

            /// <summary>
            /// Property Indexer for FromCheckNumber 
            /// </summary>
            public const int FromCheckNumber = 23;

            /// <summary>
            /// Property Indexer for ToCheckNumber 
            /// </summary>
            public const int ToCheckNumber = 24;

            /// <summary>
            /// Property Indexer for FromSerialNumber 
            /// </summary>
            public const int FromSerialNumber = 25;

            /// <summary>
            /// Property Indexer for ToSerialNumber 
            /// </summary>
            public const int ToSerialNumber = 26;

            /// <summary>
            /// Property Indexer for Criteria 
            /// </summary>
            public const int Criteria = 27;

            /// <summary>
            /// Property Indexer for CheckStatus 
            /// </summary>
            public const int CheckStatus = 28;

            /// <summary>
            /// Property Indexer for Reprinting 
            /// </summary>
            public const int Reprinting = 29;

            /// <summary>
            /// Property Indexer for CurrentLanguageForThisBank 
            /// </summary>
            public const int CurrentLanguageForThisBank = 75;

            /// <summary>
            /// Property Indexer for LanguagesForThisBank 
            /// </summary>
            public const int LanguagesForThisBank = 76;

            /// <summary>
            /// Property Indexer for UnpostedLanguagesForThisBank 
            /// </summary>
            public const int UnpostedLanguagesForThisBank = 77;

            /// <summary>
            /// Property Indexer for UnprintedChecksForThisBank 
            /// </summary>
            public const int UnprintedChecksForThisBank = 78;

            /// <summary>
            /// Property Indexer for BankName 
            /// </summary>
            public const int BankName = 79;

            /// <summary>
            /// Property Indexer for StatementCurrency 
            /// </summary>
            public const int StatementCurrency = 80;

            /// <summary>
            /// Property Indexer for StatementCurrencyName 
            /// </summary>
            public const int StatementCurrencyName = 81;

            /// <summary>
            /// Property Indexer for ChecksforthisBankPosted? 
            /// </summary>
            public const int ChecksforthisBankPosted = 82;

            /// <summary>
            /// Property Indexer for ModeofOperation 
            /// </summary>
            public const int ModeofOperation = 90;

            /// <summary>
            /// Property Indexer for HidePrintedChecks 
            /// </summary>
            public const int HidePrintedChecks = 91;

            /// <summary>
            /// Property Indexer for Banks 
            /// </summary>
            public const int Banks = 92;

            /// <summary>
            /// Property Indexer for BanksForThisRun 
            /// </summary>
            public const int BanksForThisRun = 93;

            /// <summary>
            /// Property Indexer for UnpostedBanksForThisRun 
            /// </summary>
            public const int UnpostedBanksForThisRun = 94;

            /// <summary>
            /// Property Indexer for UnprintedCheckCountTotal 
            /// </summary>
            public const int UnprintedCheckCountTotal = 95;

            /// <summary>
            /// Property Indexer for CheckForm 
            /// </summary>
            public const int CheckForm = 96;

            /// <summary>
            /// Property Indexer for AdviceForm 
            /// </summary>
            public const int AdviceForm = 97;

            #endregion
        }
    }
}
