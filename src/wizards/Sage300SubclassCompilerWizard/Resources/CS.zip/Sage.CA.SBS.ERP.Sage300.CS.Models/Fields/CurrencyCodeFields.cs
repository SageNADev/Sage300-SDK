﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of CurrencyCodes Constants 
    /// </summary>
    public partial class CurrencyCode
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0003";

        /// <summary>
        /// Contains list of CurrencyCodes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCodeId = "CURID";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "CURNAME";

            /// <summary>
            /// Property for Symbol 
            /// </summary>
            public const string Symbol = "SYMBOL";

            /// <summary>
            /// Property for DecimalPlaces 
            /// </summary>
            public const string DecimalPlaces = "DECIMALS";

            /// <summary>
            /// Property for DecimalPlacesString 
            /// </summary>
            [IsMvcSpecific]
            public const string DecimalPlacesString = "DECIMALS";

            /// <summary>
            /// Property for SymbolPosition 
            /// </summary>
            public const string SymbolPosition = "SYMBOLPOS";

            /// <summary>
            /// Property for SymbolPositionString 
            /// </summary>
            [IsMvcSpecific]
            public const string SymbolPositionString = "SYMBOLPOS";

            /// <summary>
            /// Property for ThousandsSeparator 
            /// </summary>
            public const string ThousandsSeparator = "THOUSSEP";

            /// <summary>
            /// Property Indexer for ThousandsSeparatorString 
            /// </summary>
            [IsMvcSpecific]
            public const string ThousandsSeparatorString = "THOUSSEP";

            /// <summary>
            /// Property for DecimalSeparator 
            /// </summary>
            public const string DecimalSeparator = "DECSEP";

            /// <summary>
            /// Property for DecimalSeparatorString 
            /// </summary>
            [IsMvcSpecific]
            public const string DecimalSeparatorString = "DECSEP";

            /// <summary>
            /// Property for NegativeDisplay 
            /// </summary>
            public const string NegativeDisplay = "NEGDISP";

            /// <summary>
            /// Property for NegativeDisplayString 
            /// </summary>
            [IsMvcSpecific]
            public const string NegativeDisplayString = "NEGDISP";

            #endregion
        }

        /// <summary>
        /// Contains list of CurrencyCodes Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCodeId = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Symbol 
            /// </summary>
            public const int Symbol = 3;

            /// <summary>
            /// Property Indexer for DecimalPlaces 
            /// </summary>
            public const int DecimalPlaces = 4;

            /// <summary>
            /// Property Indexer for DecimalPlacesString 
            /// </summary>
            public const int DecimalPlacesString = 4;

            /// <summary>
            /// Property Indexer for SymbolPosition 
            /// </summary>
            public const int SymbolPosition = 5;

            /// <summary>
            /// Property Indexer for SymbolPositionString 
            /// </summary>
            public const int SymbolPositionString = 5;

            /// <summary>
            /// Property Indexer for ThousandsSeparator 
            /// </summary>
            public const int ThousandsSeparator = 6;

            /// <summary>
            /// Property Indexer for ThousandsSeparatorString 
            /// </summary>
            public const int ThousandsSeparatorString = 6;

            /// <summary>
            /// Property Indexer for DecimalSeparator 
            /// </summary>
            public const int DecimalSeparator = 7;

            /// <summary>
            /// Property Indexer for DecimalSeparatorString 
            /// </summary>
            public const int DecimalSeparatorString = 7;

            /// <summary>
            /// Property Indexer for NegativeDisplay 
            /// </summary>
            public const int NegativeDisplay = 8;

            /// <summary>
            /// Property for NegativeDisplayString 
            /// </summary>
            public const int NegativeDisplayString = 8;

            #endregion
        }
    }
}