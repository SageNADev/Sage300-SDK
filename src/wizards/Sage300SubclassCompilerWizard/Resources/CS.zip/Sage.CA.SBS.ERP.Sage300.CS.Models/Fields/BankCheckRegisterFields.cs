/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankCheckRegister Constants 
    /// </summary>
    public partial class BankCheckRegister
    {
        /// <summary>
        /// Bank Check Register
        /// </summary>
        public const string EntityName = "BK0009";

        /// <summary>
        /// Contains list of BankCheckRegister Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";
            /// <summary>
            /// Property for ApplicationRunNumber 
            /// </summary>
            public const string ApplicationRunNumber = "APPRUNNUM";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";
            /// <summary>
            /// Property for SortCode 
            /// </summary>
            public const string SortCode = "SORTCODE";
            /// <summary>
            /// Property for PayeeCode 
            /// </summary>
            public const string PayeeCode = "PAYEEID";
            /// <summary>
            /// Property for SerialNumber 
            /// </summary>
            public const string SerialNumber = "SERIAL";
            /// <summary>
            /// Property for CheckNumber 
            /// </summary>
            public const string CheckNumber = "CHECK";
            /// <summary>
            /// Property for CheckStatus 
            /// </summary>
            public const string CheckStatus = "STATUS";
            /// <summary>
            /// Property for CheckType 
            /// </summary>
            public const string CheckType = "CHKTYPE";
            /// <summary>
            /// Property for CheckStockCode 
            /// </summary>
            public const string CheckStockCode = "CHKFORM";
            /// <summary>
            /// Property for PayeeName 
            /// </summary>
            public const string PayeeName = "PAYEENAME";
            /// <summary>
            /// Property for VendorName 
            /// </summary>
            public const string VendorName = "VENDORNAME";
            /// <summary>
            /// Property for CheckReference 
            /// </summary>
            public const string CheckReference = "REFERENCE";
            /// <summary>
            /// Property for CheckDescription 
            /// </summary>
            public const string CheckDescription = "COMMENT";
            /// <summary>
            /// Property for DateCheckPrinted 
            /// </summary>
            public const string DateCheckPrinted = "POSTED";
            /// <summary>
            /// Property for CheckDate 
            /// </summary>
            public const string CheckDate = "CHKDATE";
            /// <summary>
            /// Property for CheckAmount 
            /// </summary>
            public const string CheckAmount = "ISSUED";
            /// <summary>
            /// Property for CheckSourceAmount 
            /// </summary>
            public const string CheckSourceAmount = "SISSUED";
            /// <summary>
            /// Property for ExchangeRateType 
            /// </summary>
            public const string ExchangeRateType = "RATETYPE";
            /// <summary>
            /// Property for PaymentCurrency 
            /// </summary>
            public const string PaymentCurrency = "SRCECURN";
            /// <summary>
            /// Property for ExchangeRateDate 
            /// </summary>
            public const string ExchangeRateDate = "RATEDATE";
            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "RATE";
            /// <summary>
            /// Property for RateSpread 
            /// </summary>
            public const string RateSpread = "RATESPREAD";
            /// <summary>
            /// Property for RateOperation 
            /// </summary>
            public const string RateOperation = "RATEOP";
            /// <summary>
            /// Property for ExtraApplicationData 
            /// </summary>
            public const string ExtraApplicationData = "EXTRA";
            /// <summary>
            /// Property for LanguageCode 
            /// </summary>
            public const string LanguageCode = "LANGUAGE";
            /// <summary>
            /// Property for AdviceLines 
            /// </summary>
            public const string AdviceLines = "ADVICE";
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCPERIOD";
            /// <summary>
            /// Property for Language 
            /// </summary>
            public const string Language = "LANGCODE";
            /// <summary>
            /// Property for SourceCurrencyDecimals 
            /// </summary>
            public const string SourceCurrencyDecimals = "SDECIMALS";
            /// <summary>
            /// Property for DrilldownType 
            /// </summary>
            public const string DrilldownType = "DDTYPE";
            /// <summary>
            /// Property for DrilldownLink 
            /// </summary>
            public const string DrilldownLink = "DDLINK";
            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";
            /// <summary>
            /// Property for SourceDocumentNumber 
            /// </summary>
            public const string SourceDocumentNumber = "SRCEDOCNUM";
            /// <summary>
            /// Property for CanReverseInvoice 
            /// </summary>
            public const string CanReverseInvoice = "CANREVINVC";

            #endregion
        }

        /// <summary>
        /// Contains list of BankCheckRegister Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 1;
            /// <summary>
            /// Property Indexer for ApplicationRunNumber 
            /// </summary>
            public const int ApplicationRunNumber = 2;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 3;
            /// <summary>
            /// Property Indexer for SortCode 
            /// </summary>
            public const int SortCode = 4;
            /// <summary>
            /// Property Indexer for PayeeCode 
            /// </summary>
            public const int PayeeCode = 5;
            /// <summary>
            /// Property Indexer for SerialNumber 
            /// </summary>
            public const int SerialNumber = 7;
            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int CheckNumber = 8;
            /// <summary>
            /// Property Indexer for CheckStatus 
            /// </summary>
            public const int CheckStatus = 9;
            /// <summary>
            /// Property Indexer for CheckType 
            /// </summary>
            public const int CheckType = 10;
            /// <summary>
            /// Property Indexer for CheckStockCode 
            /// </summary>
            public const int CheckStockCode = 11;
            /// <summary>
            /// Property Indexer for PayeeName 
            /// </summary>
            public const int PayeeName = 12;
            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
            public const int VendorName = 13;
            /// <summary>
            /// Property Indexer for CheckReference 
            /// </summary>
            public const int CheckReference = 14;
            /// <summary>
            /// Property Indexer for CheckDescription 
            /// </summary>
            public const int CheckDescription = 15;
            /// <summary>
            /// Property Indexer for DateCheckPrinted 
            /// </summary>
            public const int DateCheckPrinted = 16;
            /// <summary>
            /// Property Indexer for CheckDate 
            /// </summary>
            public const int CheckDate = 17;
            /// <summary>
            /// Property Indexer for CheckAmount 
            /// </summary>
            public const int CheckAmount = 18;
            /// <summary>
            /// Property Indexer for CheckSourceAmount 
            /// </summary>
            public const int CheckSourceAmount = 19;
            /// <summary>
            /// Property Indexer for ExchangeRateType 
            /// </summary>
            public const int ExchangeRateType = 20;
            /// <summary>
            /// Property Indexer for PaymentCurrency 
            /// </summary>
            public const int PaymentCurrency = 21;
            /// <summary>
            /// Property Indexer for ExchangeRateDate 
            /// </summary>
            public const int ExchangeRateDate = 22;
            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 23;
            /// <summary>
            /// Property Indexer for RateSpread 
            /// </summary>
            public const int RateSpread = 24;
            /// <summary>
            /// Property Indexer for RateOperation 
            /// </summary>
            public const int RateOperation = 25;
            /// <summary>
            /// Property Indexer for ExtraApplicationData 
            /// </summary>
            public const int ExtraApplicationData = 26;
            /// <summary>
            /// Property Indexer for LanguageCode 
            /// </summary>
            public const int LanguageCode = 27;
            /// <summary>
            /// Property Indexer for AdviceLines 
            /// </summary>
            public const int AdviceLines = 28;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 29;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 30;
            /// <summary>
            /// Property Indexer for Language 
            /// </summary>
            public const int Language = 31;
            /// <summary>
            /// Property Indexer for SourceCurrencyDecimals 
            /// </summary>
            public const int SourceCurrencyDecimals = 32;
            /// <summary>
            /// Property Indexer for DrilldownType 
            /// </summary>
            public const int DrilldownType = 33;
            /// <summary>
            /// Property Indexer for DrilldownLink 
            /// </summary>
            public const int DrilldownLink = 34;
            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 35;
            /// <summary>
            /// Property Indexer for SourceDocumentNumber 
            /// </summary>
            public const int SourceDocumentNumber = 36;
            /// <summary>
            /// Property Indexer for CanReverseInvoice 
            /// </summary>
            public const int CanReverseInvoice = 37;

            #endregion
        }
    }
}
