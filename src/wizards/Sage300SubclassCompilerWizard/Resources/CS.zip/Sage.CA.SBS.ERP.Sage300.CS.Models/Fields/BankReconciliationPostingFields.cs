// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankReconciliationPosting Constants 
    /// </summary>
	public partial class BankReconciliationPosting 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "BK0101";

        /// <summary>
        /// Contains list of BankReconciliationPosting Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for PostingOperation 
        /// </summary>
	    public const string PostingOperation  = "OPERATION";
	            /// <summary>
        /// Property for BeginningBankCode 
        /// </summary>
	    public const string BeginningBankCode  = "BANKFROM";
	            /// <summary>
        /// Property for EndingBankCode 
        /// </summary>
	    public const string EndingBankCode  = "BANKTO";
	            /// <summary>
        /// Property for FiscalYear 
        /// </summary>
	    public const string FiscalYear  = "FISCYEAR";
	            /// <summary>
        /// Property for FiscalPeriod 
        /// </summary>
	    public const string FiscalPeriod  = "FISCPERIOD";
	            /// <summary>
        /// Property for ThroughDate 
        /// </summary>
	    public const string ThroughDate  = "THRUDATE";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of BankReconciliationPosting Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for PostingOperation 
        /// </summary>
	    public const int PostingOperation  = 1;
	             /// <summary>
        /// Property Indexer for BeginningBankCode 
        /// </summary>
	    public const int BeginningBankCode  = 2;
	             /// <summary>
        /// Property Indexer for EndingBankCode 
        /// </summary>
	    public const int EndingBankCode  = 3;
	             /// <summary>
        /// Property Indexer for FiscalYear 
        /// </summary>
	    public const int FiscalYear  = 10;
	             /// <summary>
        /// Property Indexer for FiscalPeriod 
        /// </summary>
	    public const int FiscalPeriod  = 11;
	             /// <summary>
        /// Property Indexer for ThroughDate 
        /// </summary>
	    public const int ThroughDate  = 12;
	     
        #endregion
	    }

	
	}
}
	