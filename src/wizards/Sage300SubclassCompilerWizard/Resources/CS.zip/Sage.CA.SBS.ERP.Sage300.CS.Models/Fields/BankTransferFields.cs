/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of Transfers Constants 
    /// </summary>
    public partial class BankTransfer
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0036";

        /// <summary>
        /// Contains list of Transfers Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for TransferNumber 
            /// </summary>
            public const string TransferNumber = "TRANSFERNR";
            /// <summary>
            /// Property for Date 
            /// </summary>
            public const string Date = "DATE";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";
            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "REFERENCE";
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FISCYEAR";
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";
            /// <summary>
            /// Property for TransferBank 
            /// </summary>
            public const string TransferBank = "OBANK";
            /// <summary>
            /// Property for TransferSourceCurrency 
            /// </summary>
            public const string TransferSourceCurrency = "OSRCECURN";
            /// <summary>
            /// Property for TransferRateDate 
            /// </summary>
            public const string TransferRateDate = "ORATEDATE";
            /// <summary>
            /// Property for TransferRateType 
            /// </summary>
            public const string TransferRateType = "ORATETYPE";
            /// <summary>
            /// Property for TransferRateFactor 
            /// </summary>
            public const string TransferRateFactor = "ORATE";
            /// <summary>
            /// Property for TransferRateSpread 
            /// </summary>
            public const string TransferRateSpread = "ORATESPREA";
            /// <summary>
            /// Property for TransferRateOperator 
            /// </summary>
            public const string TransferRateOperator = "ORATEOP";
            /// <summary>
            /// Property for TransferSourceAmount 
            /// </summary>
            public const string TransferSourceAmount = "OSAMOUNT";
            /// <summary>
            /// Property for TransferFunctionalAmount 
            /// </summary>
            public const string TransferFunctionalAmount = "OFAMOUNT";
            /// <summary>
            /// Property for DepositBank 
            /// </summary>
            public const string DepositBank = "DBANK";
            /// <summary>
            /// Property for DepositSourceCurrency 
            /// </summary>
            public const string DepositSourceCurrency = "DSRCECURN";
            /// <summary>
            /// Property for DepositRateDate 
            /// </summary>
            public const string DepositRateDate = "DRATEDATE";
            /// <summary>
            /// Property for DepositRateType 
            /// </summary>
            public const string DepositRateType = "DRATETYPE";
            /// <summary>
            /// Property for DepositRateFactor 
            /// </summary>
            public const string DepositRateFactor = "DRATE";
            /// <summary>
            /// Property for DepositRateSpread 
            /// </summary>
            public const string DepositRateSpread = "DRATESPREA";
            /// <summary>
            /// Property for DepositRateOperator 
            /// </summary>
            public const string DepositRateOperator = "DRATEOP";
            /// <summary>
            /// Property for DepositSourceAmount 
            /// </summary>
            public const string DepositSourceAmount = "DSAMOUNT";
            /// <summary>
            /// Property for DepositFunctionalAmount 
            /// </summary>
            public const string DepositFunctionalAmount = "DFAMOUNT";
            /// <summary>
            /// Property for PostDate 
            /// </summary>
            public const string PostDate = "POSTDATE";
            /// <summary>
            /// Property for TransferFunctionalFixed? 
            /// </summary>
            public const string TransferFunctionalFixed = "OFFIXREL";
            /// <summary>
            /// Property for DepositFunctionalFixed? 
            /// </summary>
            public const string DepositFunctionalFixed = "DFFIXREL";
            /// <summary>
            /// Property for TransferDepositFixed? 
            /// </summary>
            public const string TransferDepositFixed = "ODFIXREL";
            /// <summary>
            /// Property for TransferBankDescription 
            /// </summary>
            public const string TransferBankDescription = "OBANKD";
            /// <summary>
            /// Property for TransferBankCurrencyDescription 
            /// </summary>
            public const string TransferBankCurrencyDescription = "OSRCECURND";
            /// <summary>
            /// Property for TransferCurrencyStatement 
            /// </summary>
            public const string TransferCurrencyStatement = "OCURNSTMT";
            /// <summary>
            /// Property for TransferMulticurrency? 
            /// </summary>
            public const string TransferMulticurrency = "OMULTICUR";
            /// <summary>
            /// Property for DepositBankDescription 
            /// </summary>
            public const string DepositBankDescription = "DBANKD";
            /// <summary>
            /// Property for DepositBankCurrencyDescription 
            /// </summary>
            public const string DepositBankCurrencyDescription = "DSRCECURND";
            /// <summary>
            /// Property for DepositCurrencyStatement 
            /// </summary>
            public const string DepositCurrencyStatement = "DCURNSTMT";
            /// <summary>
            /// Property for DepositMulticurrency? 
            /// </summary>
            public const string DepositMulticurrency = "DMULTICUR";
            /// <summary>
            /// Property for TransferDepositConversion 
            /// </summary>
            public const string TransferDepositConversion = "TRATE";
            /// <summary>
            /// Property for TransferDepositRateOperation 
            /// </summary>
            public const string TransferDepositRateOperation = "TRATEOP";
            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "FUNCTCURN";
            /// <summary>
            /// Property for DepositFunctionalDefaultAmount 
            /// </summary>
            public const string DepositFunctionalDefaultAmount = "DFDEFAULT";
            /// <summary>
            /// Property for DepositSourceDefaultAmount 
            /// </summary>
            public const string DepositSourceDefaultAmount = "DSDEFAULT";
            /// <summary>
            /// Property for TransferRateTypeDescription 
            /// </summary>
            public const string TransferRateTypeDescription = "ORATETYPED";
            /// <summary>
            /// Property for DepositRateTypeDescription 
            /// </summary>
            public const string DepositRateTypeDescription = "DRATETYPED";
            /// <summary>
            /// Property for NumericTransferNumber 
            /// </summary>
            public const string NumericTransferNumber = "TRANSFERNN";
            /// <summary>
            /// Property for TransferTypeDescription 
            /// </summary>
            public const string TransferTypeDescription = "TTYPED";
            /// <summary>
            /// Property for GOrLAccountDescription 
            /// </summary>
            public const string GorLAccountDescription = "GLACCOUNTD";
            /// <summary>
            /// Property for TransferBankAccount 
            /// </summary>
            public const string TransferBankAccount = "OBANKACCT";
            /// <summary>
            /// Property for DepositBankAccount 
            /// </summary>
            public const string DepositBankAccount = "DBANKACCT";

            #endregion
        }

        /// <summary>
        /// Contains list of Transfers Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for TransferNumber 
            /// </summary>
            public const int TransferNumber = 1;
            /// <summary>
            /// Property Indexer for Date 
            /// </summary>
            public const int Date = 2;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;
            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 4;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 5;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 6;
            /// <summary>
            /// Property Indexer for TransferBank 
            /// </summary>
            public const int TransferBank = 7;
            /// <summary>
            /// Property Indexer for TransferSourceCurrency 
            /// </summary>
            public const int TransferSourceCurrency = 8;
            /// <summary>
            /// Property Indexer for TransferRateDate 
            /// </summary>
            public const int TransferRateDate = 9;
            /// <summary>
            /// Property Indexer for TransferRateType 
            /// </summary>
            public const int TransferRateType = 10;
            /// <summary>
            /// Property Indexer for TransferRateFactor 
            /// </summary>
            public const int TransferRateFactor = 11;
            /// <summary>
            /// Property Indexer for TransferRateSpread 
            /// </summary>
            public const int TransferRateSpread = 12;
            /// <summary>
            /// Property Indexer for TransferRateOperator 
            /// </summary>
            public const int TransferRateOperator = 13;
            /// <summary>
            /// Property Indexer for TransferSourceAmount 
            /// </summary>
            public const int TransferSourceAmount = 14;
            /// <summary>
            /// Property Indexer for TransferFunctionalAmount 
            /// </summary>
            public const int TransferFunctionalAmount = 15;
            /// <summary>
            /// Property Indexer for DepositBank 
            /// </summary>
            public const int DepositBank = 16;
            /// <summary>
            /// Property Indexer for DepositSourceCurrency 
            /// </summary>
            public const int DepositSourceCurrency = 17;
            /// <summary>
            /// Property Indexer for DepositRateDate 
            /// </summary>
            public const int DepositRateDate = 18;
            /// <summary>
            /// Property Indexer for DepositRateType 
            /// </summary>
            public const int DepositRateType = 19;
            /// <summary>
            /// Property Indexer for DepositRateFactor 
            /// </summary>
            public const int DepositRateFactor = 20;
            /// <summary>
            /// Property Indexer for DepositRateSpread 
            /// </summary>
            public const int DepositRateSpread = 21;
            /// <summary>
            /// Property Indexer for DepositRateOperator 
            /// </summary>
            public const int DepositRateOperator = 22;
            /// <summary>
            /// Property Indexer for DepositSourceAmount 
            /// </summary>
            public const int DepositSourceAmount = 23;
            /// <summary>
            /// Property Indexer for DepositFunctionalAmount 
            /// </summary>
            public const int DepositFunctionalAmount = 24;
            /// <summary>
            /// Property Indexer for PostDate 
            /// </summary>
            public const int PostDate = 25;
            /// <summary>
            /// Property Indexer for TransferFunctionalFixed? 
            /// </summary>
            public const int TransferFunctionalFixed = 101;
            /// <summary>
            /// Property Indexer for DepositFunctionalFixed? 
            /// </summary>
            public const int DepositFunctionalFixed = 102;
            /// <summary>
            /// Property Indexer for TransferDepositFixed? 
            /// </summary>
            public const int TransferDepositFixed = 103;
            /// <summary>
            /// Property Indexer for TransferBankDescription 
            /// </summary>
            public const int TransferBankDescription = 111;
            /// <summary>
            /// Property Indexer for TransferBankCurrencyDescription 
            /// </summary>
            public const int TransferBankCurrencyDescription = 112;
            /// <summary>
            /// Property Indexer for TransferCurrencyStatement 
            /// </summary>
            public const int TransferCurrencyStatement = 116;
            /// <summary>
            /// Property Indexer for TransferMulticurrency? 
            /// </summary>
            public const int TransferMulticurrency = 117;
            /// <summary>
            /// Property Indexer for DepositBankDescription 
            /// </summary>
            public const int DepositBankDescription = 121;
            /// <summary>
            /// Property Indexer for DepositBankCurrencyDescription 
            /// </summary>
            public const int DepositBankCurrencyDescription = 122;
            /// <summary>
            /// Property Indexer for DepositCurrencyStatement 
            /// </summary>
            public const int DepositCurrencyStatement = 126;
            /// <summary>
            /// Property Indexer for DepositMulticurrency? 
            /// </summary>
            public const int DepositMulticurrency = 127;
            /// <summary>
            /// Property Indexer for TransferDepositConversion 
            /// </summary>
            public const int TransferDepositConversion = 136;
            /// <summary>
            /// Property Indexer for TransferDepositRateOperation 
            /// </summary>
            public const int TransferDepositRateOperation = 137;
            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 138;
            /// <summary>
            /// Property Indexer for DepositFunctionalDefaultAmount 
            /// </summary>
            public const int DepositFunctionalDefaultAmount = 139;
            /// <summary>
            /// Property Indexer for DepositSourceDefaultAmount 
            /// </summary>
            public const int DepositSourceDefaultAmount = 140;
            /// <summary>
            /// Property Indexer for TransferRateTypeDescription 
            /// </summary>
            public const int TransferRateTypeDescription = 146;
            /// <summary>
            /// Property Indexer for DepositRateTypeDescription 
            /// </summary>
            public const int DepositRateTypeDescription = 147;
            /// <summary>
            /// Property Indexer for NumericTransferNumber 
            /// </summary>
            public const int NumericTransferNumber = 148;
            /// <summary>
            /// Property Indexer for TransferTypeDescription 
            /// </summary>
            public const int TransferTypeDescription = 149;
            /// <summary>
            /// Property Indexer for GOrLAccountDescription 
            /// </summary>
            public const int GorLAccountDescription = 150;
            /// <summary>
            /// Property Indexer for TransferBankAccount 
            /// </summary>
            public const int TransferBankAccount = 151;
            /// <summary>
            /// Property Indexer for DepositBankAccount 
            /// </summary>
            public const int DepositBankAccount = 152;

            #endregion
        }
    }
}
