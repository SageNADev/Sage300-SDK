﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class SageHROptions
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "HQ0001";


        #region Fields Properties

        /// <summary>
        /// Contains list of Sage HR Options Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for OptionId 
            /// </summary>
            public const string OptionId = "OPTIONID";

            /// <summary>
            /// Property for Onboarded 
            /// </summary>
            public const string Onboarded = "ONBOARDED";

            /// <summary>
            /// Property for Active 
            /// </summary>
            public const string HQActive = "HQACTIVE";

            /// <summary>
            /// Property for AutoSyncEmployee
            /// </summary>
            public const string AutoSyncEmployee = "AUTOSYNCEM";

            /// <summary>
            /// Property for AutoSyncPaySlip
            /// </summary>
            public const string AutoSyncPaySlip = "AUTOSYNCPS";

            /// <summary>
            /// Property for LicenseActive
            /// </summary>
            public const string LicenseActive = "LICACTIVE";

            /// <summary>
            /// Property for Readonly
            /// </summary>
            public const string HQReadOnly = "HQREADONLY";

            /// <summary>
            /// Property for CPMeetsMinimumRequirements
            /// </summary>
            public const string CPMeetsMinimumRequirements = "CPCOMPAT";

            /// <summary>
            /// Property for UPMeetsMinimumRequirements
            /// </summary>
            public const string UPMeetsMinimumRequirements = "UPCOMPAT";

            /// <summary>
            /// Property for HRSageId
            /// </summary>
            public const string HRSageId = "HRSAGEID";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Sage HR Options Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for OptionId 
            /// </summary>
            public const int OptionId = 1;

            /// <summary>
            /// Property Indexer for Onboarded 
            /// </summary>
            public const int Onboarded = 2;

            /// <summary>
            /// Property Indexer for HQActive 
            /// </summary>
            public const int HQActive = 3;

            /// <summary>
            /// Property Indexer for AutoSyncEmployee
            /// </summary>
            public const int AutoSyncEmployee = 4;

            /// <summary>
            /// Property Indexer for AutoSyncPaySlip
            /// </summary>
            public const int AutoSyncPaySlip = 5;

            /// <summary>
            /// Property Indexer for LicenseActive
            /// </summary>
            public const int LicenseActive = 46;

            /// <summary>
            /// Property Indexer for AutoSyncPaySlip
            /// </summary>
            public const int HQReadonly = 47;

            /// <summary>
            /// Property Indexer for CPMeetsMinimumRequirements
            /// </summary>
            public const int CPMeetsMinimumRequirements = 48;

            /// <summary>
            /// Property Indexer for UPMeetsMinimumRequirements
            /// </summary>
            public const int UPMeetsMinimumRequirements = 49;

            /// <summary>
            /// Property Indexer for HRSageId
            /// </summary>
            public const int HRSageId = 54;
        }

        #endregion
    }
}
