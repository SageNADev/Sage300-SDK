/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of FiscalSets Constants 
    /// </summary>
    public partial class FiscalSet
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "GL0003";

        /// <summary>
        /// Contains list of FiscalSets Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "ACCTID";
            /// <summary>
            /// Property for Fiscalsetyear 
            /// </summary>
            public const string Fiscalsetyear = "FSCSYR";
            /// <summary>
            /// Property for FiscalsetDesignator 
            /// </summary>
            public const string FiscalsetDesignator = "FSCSDSG";
            /// <summary>
            /// Property for Currencycode 
            /// </summary>
            public const string Currencycode = "FSCSCURN";
            /// <summary>
            /// Property for Currencytype 
            /// </summary>
            public const string Currencytype = "CURNTYPE";
            /// <summary>
            /// Property for Sourcecurrencydecimals 
            /// </summary>
            public const string Sourcecurrencydecimals = "SCURNDEC";
            /// <summary>
            /// Property for Beginningbalance 
            /// </summary>
            public const string Beginningbalance = "OPENBAL";
            /// <summary>
            /// Property for Period01netamount 
            /// </summary>
            public const string Period01Netamount = "NETPERD1";
            /// <summary>
            /// Property for Period02netamount 
            /// </summary>
            public const string Period02Netamount = "NETPERD2";
            /// <summary>
            /// Property for Period03netamount 
            /// </summary>
            public const string Period03Netamount = "NETPERD3";
            /// <summary>
            /// Property for Period04netamount 
            /// </summary>
            public const string Period04Netamount = "NETPERD4";
            /// <summary>
            /// Property for Period05netamount 
            /// </summary>
            public const string Period05Netamount = "NETPERD5";
            /// <summary>
            /// Property for Period06netamount 
            /// </summary>
            public const string Period06Netamount = "NETPERD6";
            /// <summary>
            /// Property for Period07netamount 
            /// </summary>
            public const string Period07Netamount = "NETPERD7";
            /// <summary>
            /// Property for Period08netamount 
            /// </summary>
            public const string Period08Netamount = "NETPERD8";
            /// <summary>
            /// Property for Period09netamount 
            /// </summary>
            public const string Period09Netamount = "NETPERD9";
            /// <summary>
            /// Property for Period10netamount 
            /// </summary>
            public const string Period10Netamount = "NETPERD10";
            /// <summary>
            /// Property for Period11netamount 
            /// </summary>
            public const string Period11Netamount = "NETPERD11";
            /// <summary>
            /// Property for Period12netamount 
            /// </summary>
            public const string Period12Netamount = "NETPERD12";
            /// <summary>
            /// Property for Period13netamount 
            /// </summary>
            public const string Period13Netamount = "NETPERD13";
            /// <summary>
            /// Property for Period14netamount 
            /// </summary>
            public const string Period14Netamount = "NETPERD14";
            /// <summary>
            /// Property for Period15netamount 
            /// </summary>
            public const string Period15Netamount = "NETPERD15";
            /// <summary>
            /// Property for Allowspecificcurrenciesswitch 
            /// </summary>
            public const string Allowspecificcurrenciesswitch = "SPECURNSW";
            /// <summary>
            /// Property for Processasytdbalancesswitch 
            /// </summary>
            public const string Processasytdbalancesswitch = "NETCHGSW";
            /// <summary>
            /// Property for Yeartodateamount 
            /// </summary>
            public const string Yeartodateamount = "TOTALAMT";
            /// <summary>
            /// Property for Period01balanceamount 
            /// </summary>
            public const string Period01Balanceamount = "PERD01BAL";
            /// <summary>
            /// Property for Period02balanceamount 
            /// </summary>
            public const string Period02Balanceamount = "PERD02BAL";
            /// <summary>
            /// Property for Period03balanceamount 
            /// </summary>
            public const string Period03Balanceamount = "PERD03BAL";
            /// <summary>
            /// Property for Period04balanceamount 
            /// </summary>
            public const string Period04Balanceamount = "PERD04BAL";
            /// <summary>
            /// Property for Period05balanceamount 
            /// </summary>
            public const string Period05Balanceamount = "PERD05BAL";
            /// <summary>
            /// Property for Period06balanceamount 
            /// </summary>
            public const string Period06Balanceamount = "PERD06BAL";
            /// <summary>
            /// Property for Period07balanceamount 
            /// </summary>
            public const string Period07Balanceamount = "PERD07BAL";
            /// <summary>
            /// Property for Period08balanceamount 
            /// </summary>
            public const string Period08Balanceamount = "PERD08BAL";
            /// <summary>
            /// Property for Period09balanceamount 
            /// </summary>
            public const string Period09Balanceamount = "PERD09BAL";
            /// <summary>
            /// Property for Period10balanceamount 
            /// </summary>
            public const string Period10Balanceamount = "PERD10BAL";
            /// <summary>
            /// Property for Period11balanceamount 
            /// </summary>
            public const string Period11Balanceamount = "PERD11BAL";
            /// <summary>
            /// Property for Period12balanceamount 
            /// </summary>
            public const string Period12Balanceamount = "PERD12BAL";
            /// <summary>
            /// Property for Period13balanceamount 
            /// </summary>
            public const string Period13Balanceamount = "PERD13BAL";
            /// <summary>
            /// Property for Period14balanceamount 
            /// </summary>
            public const string Period14Balanceamount = "PERD14BAL";
            /// <summary>
            /// Property for Period15balanceamount 
            /// </summary>
            public const string Period15Balanceamount = "PERD15BAL";
            /// <summary>
            /// Property for Replacementswitch 
            /// </summary>
            public const string Replacementswitch = "REPLACESW";
            /// <summary>
            /// Property for Overrideratetypecode 
            /// </summary>
            public const string Overrideratetypecode = "RATETYPE";
            /// <summary>
            /// Property for Overriderate 
            /// </summary>
            public const string Overriderate = "OVRDRATE";
            /// <summary>
            /// Property for Activityswitch 
            /// </summary>
            public const string Activityswitch = "ACTIVITYSW";
            /// <summary>
            /// Property for Rollupswitch 
            /// </summary>
            public const string Rollupswitch = "ROLLUPSW";

            #endregion
        }


        /// <summary>
        /// Contains list of FiscalSets Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 1;
            /// <summary>
            /// Property Indexer for Fiscalsetyear 
            /// </summary>
            public const int Fiscalsetyear = 2;
            /// <summary>
            /// Property Indexer for FiscalsetDesignator 
            /// </summary>
            public const int FiscalsetDesignator = 3;
            /// <summary>
            /// Property Indexer for Currencycode 
            /// </summary>
            public const int Currencycode = 4;
            /// <summary>
            /// Property Indexer for Currencytype 
            /// </summary>
            public const int Currencytype = 5;
            /// <summary>
            /// Property Indexer for Sourcecurrencydecimals 
            /// </summary>
            public const int Sourcecurrencydecimals = 8;
            /// <summary>
            /// Property Indexer for Beginningbalance 
            /// </summary>
            public const int Beginningbalance = 9;
            /// <summary>
            /// Property Indexer for Period01netamount 
            /// </summary>
            public const int Period01Netamount = 10;
            /// <summary>
            /// Property Indexer for Period02netamount 
            /// </summary>
            public const int Period02Netamount = 11;
            /// <summary>
            /// Property Indexer for Period03netamount 
            /// </summary>
            public const int Period03Netamount = 12;
            /// <summary>
            /// Property Indexer for Period04netamount 
            /// </summary>
            public const int Period04Netamount = 13;
            /// <summary>
            /// Property Indexer for Period05netamount 
            /// </summary>
            public const int Period05Netamount = 14;
            /// <summary>
            /// Property Indexer for Period06netamount 
            /// </summary>
            public const int Period06Netamount = 15;
            /// <summary>
            /// Property Indexer for Period07netamount 
            /// </summary>
            public const int Period07Netamount = 16;
            /// <summary>
            /// Property Indexer for Period08netamount 
            /// </summary>
            public const int Period08Netamount = 17;
            /// <summary>
            /// Property Indexer for Period09netamount 
            /// </summary>
            public const int Period09Netamount = 18;
            /// <summary>
            /// Property Indexer for Period10netamount 
            /// </summary>
            public const int Period10Netamount = 19;
            /// <summary>
            /// Property Indexer for Period11netamount 
            /// </summary>
            public const int Period11Netamount = 20;
            /// <summary>
            /// Property Indexer for Period12netamount 
            /// </summary>
            public const int Period12Netamount = 21;
            /// <summary>
            /// Property Indexer for Period13netamount 
            /// </summary>
            public const int Period13Netamount = 22;
            /// <summary>
            /// Property Indexer for Period14netamount 
            /// </summary>
            public const int Period14Netamount = 23;
            /// <summary>
            /// Property Indexer for Period15netamount 
            /// </summary>
            public const int Period15Netamount = 24;
            /// <summary>
            /// Property Indexer for Allowspecificcurrenciesswitch 
            /// </summary>
            public const int Allowspecificcurrenciesswitch = 26;
            /// <summary>
            /// Property Indexer for Processasytdbalancesswitch 
            /// </summary>
            public const int Processasytdbalancesswitch = 27;
            /// <summary>
            /// Property Indexer for Yeartodateamount 
            /// </summary>
            public const int Yeartodateamount = 29;
            /// <summary>
            /// Property Indexer for Period01balanceamount 
            /// </summary>
            public const int Period01Balanceamount = 30;
            /// <summary>
            /// Property Indexer for Period02balanceamount 
            /// </summary>
            public const int Period02Balanceamount = 31;
            /// <summary>
            /// Property Indexer for Period03balanceamount 
            /// </summary>
            public const int Period03Balanceamount = 32;
            /// <summary>
            /// Property Indexer for Period04balanceamount 
            /// </summary>
            public const int Period04Balanceamount = 33;
            /// <summary>
            /// Property Indexer for Period05balanceamount 
            /// </summary>
            public const int Period05Balanceamount = 34;
            /// <summary>
            /// Property Indexer for Period06balanceamount 
            /// </summary>
            public const int Period06Balanceamount = 35;
            /// <summary>
            /// Property Indexer for Period07balanceamount 
            /// </summary>
            public const int Period07Balanceamount = 36;
            /// <summary>
            /// Property Indexer for Period08balanceamount 
            /// </summary>
            public const int Period08Balanceamount = 37;
            /// <summary>
            /// Property Indexer for Period09balanceamount 
            /// </summary>
            public const int Period09Balanceamount = 38;
            /// <summary>
            /// Property Indexer for Period10balanceamount 
            /// </summary>
            public const int Period10Balanceamount = 39;
            /// <summary>
            /// Property Indexer for Period11balanceamount 
            /// </summary>
            public const int Period11Balanceamount = 40;
            /// <summary>
            /// Property Indexer for Period12balanceamount 
            /// </summary>
            public const int Period12Balanceamount = 41;
            /// <summary>
            /// Property Indexer for Period13balanceamount 
            /// </summary>
            public const int Period13Balanceamount = 42;
            /// <summary>
            /// Property Indexer for Period14balanceamount 
            /// </summary>
            public const int Period14Balanceamount = 43;
            /// <summary>
            /// Property Indexer for Period15balanceamount 
            /// </summary>
            public const int Period15Balanceamount = 44;
            /// <summary>
            /// Property Indexer for Replacementswitch 
            /// </summary>
            public const int Replacementswitch = 45;
            /// <summary>
            /// Property Indexer for Overrideratetypecode 
            /// </summary>
            public const int Overrideratetypecode = 46;
            /// <summary>
            /// Property Indexer for Overriderate 
            /// </summary>
            public const int Overriderate = 47;
            /// <summary>
            /// Property Indexer for Activityswitch 
            /// </summary>
            public const int Activityswitch = 48;
            /// <summary>
            /// Property Indexer for Rollupswitch 
            /// </summary>
            public const int Rollupswitch = 49;

            #endregion
        }


    }
}
