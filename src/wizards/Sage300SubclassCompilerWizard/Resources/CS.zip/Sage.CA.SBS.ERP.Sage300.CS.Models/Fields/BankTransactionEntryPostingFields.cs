/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankTransactionEntryPosting Constants 
    /// </summary>
    public partial class BankTransactionEntryPosting
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "BK0465";

        /// <summary>
        /// Contains list of BankTransactionEntryPosting Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for PostingOperation 
            /// </summary>
            public const string PostingOperation = "OPERATION";
            /// <summary>
            /// Property for FromSequenceNumber 
            /// </summary>
            public const string FromSequenceNumber = "FROMSEQ";
            /// <summary>
            /// Property for ToSequenceNumber 
            /// </summary>
            public const string ToSequenceNumber = "TOSEQ";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "FROMBANK";
            /// <summary>
            /// Property for ToBankCode 
            /// </summary>
            public const string ToBankCode = "TOBANK";
            /// <summary>
            /// Property for BankEntryDate 
            /// </summary>
            public const string BankEntryDate = "FROMDATE";
            /// <summary>
            /// Property for ToBankEntryDate 
            /// </summary>
            public const string ToBankEntryDate = "TODATE";
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FISCYEAR";
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";
            /// <summary>
            /// Property for BankEntryNumber 
            /// </summary>
            public const string BankEntryNumber = "FROMENTRNM";
            /// <summary>
            /// Property for ToBankEntryNumber 
            /// </summary>
            public const string ToBankEntryNumber = "TOENTRYNBR";

            #endregion
        }


        /// <summary>
        /// Contains list of BankTransactionEntryPosting Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for PostingOperation 
            /// </summary>
            public const int PostingOperation = 1;
            /// <summary>
            /// Property Indexer for FromSequenceNumber 
            /// </summary>
            public const int FromSequenceNumber = 2;
            /// <summary>
            /// Property Indexer for ToSequenceNumber 
            /// </summary>
            public const int ToSequenceNumber = 3;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 4;
            /// <summary>
            /// Property Indexer for ToBankCode 
            /// </summary>
            public const int ToBankCode = 5;
            /// <summary>
            /// Property Indexer for BankEntryDate 
            /// </summary>
            public const int BankEntryDate = 6;
            /// <summary>
            /// Property Indexer for ToBankEntryDate 
            /// </summary>
            public const int ToBankEntryDate = 7;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 8;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 9;
            /// <summary>
            /// Property Indexer for BankEntryNumber 
            /// </summary>
            public const int BankEntryNumber = 10;
            /// <summary>
            /// Property Indexer for ToBankEntryNumber 
            /// </summary>
            public const int ToBankEntryNumber = 11;

            #endregion
        }


    }
}
