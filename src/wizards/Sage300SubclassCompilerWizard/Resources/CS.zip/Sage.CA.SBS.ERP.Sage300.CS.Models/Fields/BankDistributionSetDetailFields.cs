// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankDistributionSetDetail Constants 
    /// </summary>
    public partial class BankDistributionSetDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0440";

        /// <summary>
        /// Contains list of BankDistributionSetDetail Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for DistributionSetCode 
            /// </summary>
            public const string DistributionSetCode = "DSETCODE";

            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "LINE";

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for GOrLAccount 
            /// </summary>
            public const string GLAccount = "ACCT";

            /// <summary>
            /// Property for Amount 
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for DistributionCodeDescription 
            /// </summary>
            public const string DistributionCodeDescription = "DISTCODED";

            /// <summary>
            /// Property for AccountDescription 
            /// </summary>
            public const string AccountDescription = "ACCOUNTD";

            /// <summary>
            /// Property for Line 
            /// </summary>
            public const string Line = "LINEONE";

            #endregion
        }

        /// <summary>
        /// Contains list of BankDistributionSetDetail Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for DistributionSetCode 
            /// </summary>
            public const int DistributionSetCode = 1;

            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 3;

            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
            public const int GLAccount = 4;

            /// <summary>
            /// Property Indexer for Amount 
            /// </summary>
            public const int Amount = 5;

            /// <summary>
            /// Property Indexer for DistributionCodeDescription 
            /// </summary>
            public const int DistributionCodeDescription = 10;

            /// <summary>
            /// Property Indexer for AccountDescription 
            /// </summary>
            public const int AccountDescription = 11;

            /// <summary>
            /// Property Indexer for Line 
            /// </summary>
            public const int Line = 12;

            #endregion
        }
    }
}