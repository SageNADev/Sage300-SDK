// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BKDrillDownDriver Constants 
    /// </summary>
    public partial class BankDrillDownDriver
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0370";

        /// <summary>
        /// Contains list of BKDrillDownDriver Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for DrilldownApplicationCode 
            /// </summary>
            public const string DrilldownApplicationCode = "DRILLAPP";

            /// <summary>
            /// Property for DrilldownDistributionCode 
            /// </summary>
            public const string DrilldownDistributionCode = "SRCETYPE";

            /// <summary>
            /// Property for DrilldownLink 
            /// </summary>
            public const string DrilldownLink = "DRILLDWNLK";

            /// <summary>
            /// Property for DrilldownType 
            /// </summary>
            public const string DrilldownType = "DRILLTYPE";

            /// <summary>
            /// Property for RotoIDofUIObject 
            /// </summary>
            public const string RotoIDofUiObject = "ROTOID";

            /// <summary>
            /// Property for Parameters 
            /// </summary>
            public const string Parameters = "PARAMETERS";

            /// <summary>
            /// Property for DocumentKey 
            /// </summary>
            public const string DocumentKey = "DRILLKEY";

            #endregion
        }

        /// <summary>
        /// Contains list of BKDrillDownDriver Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for DrilldownApplicationCode 
            /// </summary>
            public const int DrilldownApplicationCode = 1;

            /// <summary>
            /// Property Indexer for DrilldownDistributionCode 
            /// </summary>
            public const int DrilldownDistributionCode = 2;

            /// <summary>
            /// Property Indexer for DrilldownLink 
            /// </summary>
            public const int DrilldownLink = 3;

            /// <summary>
            /// Property Indexer for DrilldownType 
            /// </summary>
            public const int DrilldownType = 4;

            /// <summary>
            /// Property Indexer for RotoIDofUIObject 
            /// </summary>
            public const int RotoIDofUiObject = 5;

            /// <summary>
            /// Property Indexer for Parameters 
            /// </summary>
            public const int Parameters = 6;

            /// <summary>
            /// Property Indexer for DocumentKey 
            /// </summary>
            public const int DocumentKey = 7;

            #endregion
        }
    }
}
