// Copyright © 2017 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Process
{
    /// <summary>
    /// Contains list of TaxClearHistory Constants
    /// </summary>
    public partial class TaxClearHistory
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "TX0903";


        #region Properties

        /// <summary>
        /// Contains list of TaxClearHistory Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for AuthorityFrom
            /// </summary>
            public const string AuthorityFrom = "AUTHFROM";

            /// <summary>
            /// Property for AuthorityTo
            /// </summary>
            public const string AuthorityTo = "AUTHTO";

            /// <summary>
            /// Property for ClearRecordsBy
            /// </summary>
            public const string ClearRecordsBy = "CLEARBY";

            /// <summary>
            /// Property for TypeOfRecordToClear
            /// </summary>
            public const string TypeOfRecordToClear = "CLEARTYPE";

            /// <summary>
            /// Property for MethodOfClearingClasses
            /// </summary>
            public const string MethodOfClearingClasses = "BYITEMCLAS";

            /// <summary>
            /// Property for FromItemClass
            /// </summary>
            public const string FromItemClass = "FROMICLASS";

            /// <summary>
            /// Property for ToItemClass
            /// </summary>
            public const string ToItemClass = "TOICLASS";

            /// <summary>
            /// Property for FromYear
            /// </summary>
            public const string FromYear = "FROMYEAR";

            /// <summary>
            /// Property for FromPeriod
            /// </summary>
            public const string FromPeriod = "FROMPERIOD";

            /// <summary>
            /// Property for ToYear
            /// </summary>
            public const string ToYear = "TOYEAR";

            /// <summary>
            /// Property for ToPeriod
            /// </summary>
            public const string ToPeriod = "TOPERIOD";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TaxClearHistory Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for AuthorityFrom
            /// </summary>
            public const int AuthorityFrom = 1;

            /// <summary>
            /// Property Indexer for AuthorityTo
            /// </summary>
            public const int AuthorityTo = 2;

            /// <summary>
            /// Property Indexer for ClearRecordsBy
            /// </summary>
            public const int ClearRecordsBy = 3;

            /// <summary>
            /// Property Indexer for TypeOfRecordToClear
            /// </summary>
            public const int TypeOfRecordToClear = 7;

            /// <summary>
            /// Property Indexer for MethodOfClearingClasses
            /// </summary>
            public const int MethodOfClearingClasses = 8;

            /// <summary>
            /// Property Indexer for FromItemClass
            /// </summary>
            public const int FromItemClass = 9;

            /// <summary>
            /// Property Indexer for ToItemClass
            /// </summary>
            public const int ToItemClass = 10;

            /// <summary>
            /// Property Indexer for FromYear
            /// </summary>
            public const int FromYear = 11;

            /// <summary>
            /// Property Indexer for FromPeriod
            /// </summary>
            public const int FromPeriod = 12;

            /// <summary>
            /// Property Indexer for ToYear
            /// </summary>
            public const int ToYear = 13;

            /// <summary>
            /// Property Indexer for ToPeriod
            /// </summary>
            public const int ToPeriod = 14;

            /// <summary>
            /// Property Indexer for FromDate
            /// </summary>
            public const int FromDate = 15;

            /// <summary>
            /// Property Indexer for ToDate
            /// </summary>
            public const int ToDate = 16;
        }

        #endregion

    }
}