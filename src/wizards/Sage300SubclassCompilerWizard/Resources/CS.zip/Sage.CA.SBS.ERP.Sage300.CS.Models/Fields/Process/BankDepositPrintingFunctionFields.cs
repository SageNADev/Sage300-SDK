// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Process
{
    /// <summary>
    /// Contains list of BankDepositPrintingFunction Constants
    /// </summary>
    public partial class BankDepositPrintingFunction
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "BK0765";

        #region Properties
        /// <summary>
        /// Contains list of BankDepositPrintingFunction Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for SourceApplication
            /// </summary>
            public const string SourceApplication = "SRCEAPP";

            /// <summary>
            /// Property for BankCode
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for FromDepositNumber
            /// </summary>
            public const string FromDepositNumber = "DEPFROM";

            /// <summary>
            /// Property for ToDepositNumber
            /// </summary>
            public const string ToDepositNumber = "DEPTO";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of BankDepositPrintingFunction Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1;

            /// <summary>
            /// Property Indexer for SourceApplication
            /// </summary>
            public const int SourceApplication = 2;

            /// <summary>
            /// Property Indexer for BankCode
            /// </summary>
            public const int BankCode = 3;

            /// <summary>
            /// Property Indexer for FromDepositNumber
            /// </summary>
            public const int FromDepositNumber = 4;

            /// <summary>
            /// Property Indexer for ToDepositNumber
            /// </summary>
            public const int ToDepositNumber = 5;
        }
        #endregion
    }
}