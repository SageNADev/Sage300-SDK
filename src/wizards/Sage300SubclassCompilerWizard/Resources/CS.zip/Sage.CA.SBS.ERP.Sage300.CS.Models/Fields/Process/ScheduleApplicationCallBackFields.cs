// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Process
{
    /// <summary>
    /// Contains list of Schedule Constants
    /// </summary>
    public partial class ScheduleApplicationCallBack
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0034";

        #region Properties

        /// <summary>
        /// Contains list of Schedule Field Constants
        /// </summary>
        public class Fields
        {

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SCHEDKEY
            /// </summary>
            public const string SCHEDKEY = "SCHEDKEY";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RUNDATE
            /// </summary>
            public const string RUNDATE = "RUNDATE";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RUNNEXT
            /// </summary>
            public const string RUNNEXT = "RUNNEXT";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of Schedule Index Constants
        /// </summary>
        public class Index
        {

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SCHEDKEY
            /// </summary>
            public const int SCHEDKEY = 1;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RUNDATE
            /// </summary>
            public const int RUNDATE = 2;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RUNNEXT
            /// </summary>
            public const int RUNNEXT = 3;

        }

        #endregion

    }
}
