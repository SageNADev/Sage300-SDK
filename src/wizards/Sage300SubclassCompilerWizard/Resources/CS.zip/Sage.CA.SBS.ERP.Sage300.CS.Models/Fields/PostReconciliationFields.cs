// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Post Reconciliation Constants 
    /// </summary>
    public partial class PostReconciliation
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "BK0101";

        /// <summary>
        /// Contains list of Post Reconciliation Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Posting Operation 
            /// </summary>
            public const string PostingOperation = "OPERATION";

            /// <summary>
            /// Property for Beginning Bank Code 
            /// </summary>
            public const string BeginningBankCode = "BANKFROM";

            /// <summary>
            /// Property for Ending Bank Code 
            /// </summary>
            public const string EndingBankCode = "BANKTO";

            /// <summary>
            /// Property for Fiscal Year 
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for Fiscal Period 
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for Through Date 
            /// </summary>
            public const string ThroughDate = "THRUDATE";

            #endregion
        }

        /// <summary>
        /// Contains list of Post Reconciliation Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Posting Operation 
            /// </summary>
            public const int PostingOperation = 1;

            /// <summary>
            /// Property Indexer for Beginning Bank Code 
            /// </summary>
            public const int BeginningBankCode = 2;

            /// <summary>
            /// Property Indexer for Ending Bank Code 
            /// </summary>
            public const int EndingBankCode = 3;

            /// <summary>
            /// Property Indexer for Fiscal Year 
            /// </summary>
            public const int FiscalYear = 10;

            /// <summary>
            /// Property Indexer for Fiscal Period 
            /// </summary>
            public const int FiscalPeriod = 11;

            /// <summary>
            /// Property Indexer for Through Date 
            /// </summary>
            public const int ThroughDate = 12;

            #endregion
        }
    }
}