// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankJournalTransactionHeader Constants 
    /// </summary>
	public partial class BankJournalTransactionHeader 
	{	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "BK0655";

        /// <summary>
        /// Contains list of BankJournalTransactionHeader Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for PostingSequence 
            /// </summary>
            public const string PostingSequence = "PSTSEQ";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for TransactionHeaderSerial 
            /// </summary>
            public const string TransactionHeaderSerial = "SERIAL";

            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for OldSerialNumber 
            /// </summary>
            public const string OldSerialNumber = "OLDSERIAL";

            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryType = "ENTRYTYPE";

            /// <summary>
            /// Property for TransactionReference 
            /// </summary>
            public const string TransactionReference = "REFERENCE";

            /// <summary>
            /// Property for TransactionDescription 
            /// </summary>
            public const string TransactionDescription = "DESC";

            /// <summary>
            /// Property for TransactionDate 
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCPERIOD";

            /// <summary>
            /// Property for TransactionSlipPrinted 
            /// </summary>
            public const string TransactionSlipPrinted = "PRINTED";

            /// <summary>
            /// Property for TransactionTotal 
            /// </summary>
            public const string TransactionTotal = "TOTAMOUNT";

            /// <summary>
            /// Property for TransactionRemainingBalanceAmount 
            /// </summary>
            public const string TransactionRemainingBalanceAmt = "TOTBALAMT";

            /// <summary>
            /// Property for FiscalTransactionTotal 
            /// </summary>
            public const string FiscalTransactionTotal = "TOTCLEARED";

            /// <summary>
            /// Property for NextTransactionDetailLine 
            /// </summary>
            public const string NextTransactionDetailLine = "NXTLINE";

            /// <summary>
            /// Property for Lines 
            /// </summary>
            public const string Lines = "LINES";

            /// <summary>
            /// Property for LinesInTransit 
            /// </summary>
            public const string LinesInTransit = "LINESPOST";

            /// <summary>
            /// Property for LinesReconciled 
            /// </summary>
            public const string LinesReconciled = "LINESREC";

            /// <summary>
            /// Property for TransactionStatus 
            /// </summary>
            public const string TransactionStatus = "STATUS";

            /// <summary>
            /// Property for ReconciliationError 
            /// </summary>
            public const string ReconciliationError = "RECERR";

            /// <summary>
            /// Property for ReconciliationErrorPending 
            /// </summary>
            public const string ReconciliationErrorPending = "RECERRPEND";

            /// <summary>
            /// Property for ReconciliationExchangeGain 
            /// </summary>
            public const string ReconciliationExchangeGain = "RECEXGAIN";

            /// <summary>
            /// Property for ReconciliationExchangeLoss 
            /// </summary>
            public const string ReconciliationExchangeLoss = "RECEXLOSS";

            /// <summary>
            /// Property for ReconciliationDepositAmount 
            /// </summary>
            public const string ReconciliationDepositAmount = "RECAMOUNT";

            /// <summary>
            /// Property for ReconciliationInTransitAmt 
            /// </summary>
            public const string ReconciliationInTransitAmt = "RECOUTSTND";

            /// <summary>
            /// Property for TransactionRecordedInSummary 
            /// </summary>
            public const string TransactionRecordedInSummary = "SUMMARY";

            /// <summary>
            /// Property for ReconciliationCreditCardCharges 
            /// </summary>
            public const string ReconciliationCreditCardCharge = "RECCCC";

            /// <summary>
            /// Property for AmountCleared 
            /// </summary>
            public const string AmountCleared = "RECCLEARED";

            /// <summary>
            /// Property for FunctionalTransactionAmount 
            /// </summary>
            public const string FunctionalTransactionAmount = "RECFUNCAMT";

            /// <summary>
            /// Property for FunctionalTransactionTotal 
            /// </summary>
            public const string FunctionalTransactionTotal = "TOTFUNCAMT";

            /// <summary>
            /// Property for ReconciliationClearedAmount 
            /// </summary>
            public const string ReconciliationClearedAmount = "TOCLEAR";

            /// <summary>
            /// Property for WriteOffAmount 
            /// </summary>
            public const string WriteOffAmount = "TOWRITEOFF";

            /// <summary>
            /// Property for InTransitAmount 
            /// </summary>
            public const string InTransitAmount = "TOREMAIN";

            /// <summary>
            /// Property for VarianceType 
            /// </summary>
            public const string VarianceType = "VARIANCE";

            /// <summary>
            /// Property for LinesCanReverseInvoice 
            /// </summary>
            public const string LinesCanReverseInvoice = "LINESREVIN";

            /// <summary>
            /// Property for DefaultPostingDate 
            /// </summary>
            public const string DefaultPostingDate = "POSTDATE";

            /// <summary>
            /// Property for DefaultReconciliationStatus 
            /// </summary>
            public const string DefaultReconciliationStatus = "RECSTATUS";

            /// <summary>
            /// Property for DefaultReconciliationDesc 
            /// </summary>
            public const string DefaultReconciliationDesc = "RECCOMMENT";

            /// <summary>
            /// Property for LinesJournalled 
            /// </summary>
            public const string LinesJournalled = "LINESJOUR";

            /// <summary>
            /// Property for LinesPurged 
            /// </summary>
            public const string LinesPurged = "LINESPUR";

            /// <summary>
            /// Property for ClearToFuturePeriod 
            /// </summary>
            public const string ClearToFuturePeriod = "TOCLEARF";

            /// <summary>
            /// Property for FiscalClearedToFuture 
            /// </summary>
            public const string FiscalClearedToFuture = "RECFCLR";

            /// <summary>
            /// Property for FiscalClearedToCurrent 
            /// </summary>
            public const string FiscalClearedToCurrent = "RECRCLR";

            /// <summary>
            /// Property for ReconciledAndJournaledTransac 
            /// </summary>
            public const string ReconciledAndJournaledTransac = "COMPLETED";

            /// <summary>
            /// Property for CurrentPeriodsWriteOff 
            /// </summary>
            public const string CurrentPeriodsWriteOff = "RECWOSUMR";

            /// <summary>
            /// Property for ClearToReconciliationPeriod 
            /// </summary>
            public const string ClearToReconciliationPeriod = "TOCLEARR";

            /// <summary>
            /// Property for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const string FiscalWriteOffToThisPeriod = "RECRWOSUM";

            /// <summary>
            /// Property for FiscalRemainingOutstanding 
            /// </summary>
            public const string FiscalRemainingOutstanding = "RECPREM";

            /// <summary>
            /// Property for TotalDeltaWriteOffs 
            /// </summary>
            public const string TotalDeltaWriteOffs = "RECTWO";

            /// <summary>
            /// Property for TotalDeltaBankErrors 
            /// </summary>
            public const string TotalDeltaBankErrors = "RECTERR";

            /// <summary>
            /// Property for TotalDeltaExchangeGain 
            /// </summary>
            public const string TotalDeltaExchangeGain = "RECTGAIN";

            /// <summary>
            /// Property for TotalDeltaExchangeLoss 
            /// </summary>
            public const string TotalDeltaExchangeLoss = "RECTLOSS";

            /// <summary>
            /// Property for TotalDeltaCreditCardCharge 
            /// </summary>
            public const string TotalDeltaCreditCardCharge = "RECTCCC";

            /// <summary>
            /// Property for TotalDeltaCleared 
            /// </summary>
            public const string TotalDeltaCleared = "RECTCLR";

            /// <summary>
            /// Property for TotalDeltaFunctionalAmount 
            /// </summary>
            public const string TotalDeltaFunctionalAmount = "RECTFUNAM";

            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "CURFUNC";

            /// <summary>
            /// Property for StatementCurrency 
            /// </summary>
            public const string StatementCurrency = "CURSTMT";

            /// <summary>
            /// Property for ReconciliationWriteOffSum 
            /// </summary>
            public const string ReconciliationWriteOffSum = "RECWOSUM";

            /// <summary>
            /// Property for ReconciliationPostingYear 
            /// </summary>
            public const string ReconciliationPostingYear = "POSTYEAR";

            /// <summary>
            /// Property for ReconciliationPostingPeriod 
            /// </summary>
            public const string ReconciliationPostingPeriod = "POSTPERIOD";

            /// <summary>
            /// Property for ReconciliationDelta 
            /// </summary>
            public const string ReconciliationDelta = "RECDELTA";

            /// <summary>
            /// Property for FiscalMiscellaneousEntry 
            /// </summary>
            public const string FiscalMiscellaneousEntry = "RECFCMISC";

            /// <summary>
            /// Property for WithdrawalMiscellaneousEntriesToFisc 
            /// </summary>
            public const string WithdrawalMiscEntriesToFisc = "RECFCWMISC";

            /// <summary>
            /// Property for DepositMiscellaneousEntriesToFiscal 
            /// </summary>
            public const string DepositMiscEntriesToFiscal = "RECFCDMISC";

            /// <summary>
            /// Property for WithdrawalMiscellaneousEntriesToFutu 
            /// </summary>
            public const string WithdrawalMiscEntriesToFutu = "RECFWMISC";

            /// <summary>
            /// Property for DepositMiscellaneousEntriesToFuture 
            /// </summary>
            public const string DepositMiscEntriesToFuture = "RECFDMISC";

            /// <summary>
            /// Property for PaymentPayeeName 
            /// </summary>
            public const string PaymentPayeeName = "PAYORNAME";

            /// <summary>
            /// Property for PaymentVendorName 
            /// </summary>
            public const string PaymentVendorName = "VENDORNAME";

            /// <summary>
            /// Property for BankEntryOrTransferNumber 
            /// </summary>
            public const string BankEntryOrTransferNumber = "ENTRYNBR";

            /// <summary>
            /// Property for LinesProcessed 
            /// </summary>
            public const string LinesProcessed = "LINESPROC";

            /// <summary>
            /// Property for ReverseInvoice 
            /// </summary>
            public const string ReverseInvoice = "REVINVC";

            /// <summary>
            /// Property for GLAccountofDiscrepancy 
            /// </summary>
            public const string GLAccountofDiscrepancy = "GLACCOUNT";

            /// <summary>
            /// Property for ReconcilebyDetailReconciled 
            /// </summary>
            public const string ReconcilebyDetailReconciled = "AMTDTLREC";

            /// <summary>
            /// Property for ReconcilebyDetailOutstanding 
            /// </summary>
            public const string ReconcilebyDetailOutstanding = "AMTDTLOUT";

            #endregion
        }

        /// <summary>
        /// Contains list of BankJournalTransactionHeader Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for PostingSequence 
            /// </summary>
            public const int PostingSequence = 1;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 2;

            /// <summary>
            /// Property Indexer for TransactionHeaderSerial 
            /// </summary>
            public const int TransactionHeaderSerial = 3;

            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 4;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 5;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 6;

            /// <summary>
            /// Property Indexer for OldSerialNumber 
            /// </summary>
            public const int OldSerialNumber = 7;

            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryType = 8;

            /// <summary>
            /// Property Indexer for TransactionReference 
            /// </summary>
            public const int TransactionReference = 9;

            /// <summary>
            /// Property Indexer for TransactionDescription 
            /// </summary>
            public const int TransactionDescription = 10;

            /// <summary>
            /// Property Indexer for TransactionDate 
            /// </summary>
            public const int TransactionDate = 11;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 12;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 13;

            /// <summary>
            /// Property Indexer for TransactionSlipPrinted 
            /// </summary>
            public const int TransactionSlipPrinted = 14;

            /// <summary>
            /// Property Indexer for TransactionTotal 
            /// </summary>
            public const int TransactionTotal = 15;

            /// <summary>
            /// Property Indexer for TransactionRemainingBalanceAmount 
            /// </summary>
            public const int TransactionRemainingBalanceAmt = 16;

            /// <summary>
            /// Property Indexer for FiscalTransactionTotal 
            /// </summary>
            public const int FiscalTransactionTotal = 17;

            /// <summary>
            /// Property Indexer for NextTransactionDetailLine 
            /// </summary>
            public const int NextTransactionDetailLine = 18;

            /// <summary>
            /// Property Indexer for Lines 
            /// </summary>
            public const int Lines = 19;

            /// <summary>
            /// Property Indexer for LinesInTransit 
            /// </summary>
            public const int LinesInTransit = 20;

            /// <summary>
            /// Property Indexer for LinesReconciled 
            /// </summary>
            public const int LinesReconciled = 21;

            /// <summary>
            /// Property Indexer for TransactionStatus 
            /// </summary>
            public const int TransactionStatus = 22;

            /// <summary>
            /// Property Indexer for ReconciliationError 
            /// </summary>
            public const int ReconciliationError = 23;

            /// <summary>
            /// Property Indexer for ReconciliationErrorPending 
            /// </summary>
            public const int ReconciliationErrorPending = 24;

            /// <summary>
            /// Property Indexer for ReconciliationExchangeGain 
            /// </summary>
            public const int ReconciliationExchangeGain = 25;

            /// <summary>
            /// Property Indexer for ReconciliationExchangeLoss 
            /// </summary>
            public const int ReconciliationExchangeLoss = 26;

            /// <summary>
            /// Property Indexer for ReconciliationDepositAmount 
            /// </summary>
            public const int ReconciliationDepositAmount = 27;

            /// <summary>
            /// Property Indexer for ReconciliationInTransitAmt 
            /// </summary>
            public const int ReconciliationInTransitAmt = 28;

            /// <summary>
            /// Property Indexer for TransactionRecordedInSummary 
            /// </summary>
            public const int TransactionRecordedInSummary = 29;

            /// <summary>
            /// Property Indexer for ReconciliationCreditCardCharges 
            /// </summary>
            public const int ReconciliationCreditCardCharge = 30;

            /// <summary>
            /// Property Indexer for AmountCleared 
            /// </summary>
            public const int AmountCleared = 31;

            /// <summary>
            /// Property Indexer for FunctionalTransactionAmount 
            /// </summary>
            public const int FunctionalTransactionAmount = 32;

            /// <summary>
            /// Property Indexer for FunctionalTransactionTotal 
            /// </summary>
            public const int FunctionalTransactionTotal = 33;

            /// <summary>
            /// Property Indexer for ReconciliationClearedAmount 
            /// </summary>
            public const int ReconciliationClearedAmount = 34;

            /// <summary>
            /// Property Indexer for WriteOffAmount 
            /// </summary>
            public const int WriteOffAmount = 35;

            /// <summary>
            /// Property Indexer for InTransitAmount 
            /// </summary>
            public const int InTransitAmount = 36;

            /// <summary>
            /// Property Indexer for VarianceType 
            /// </summary>
            public const int VarianceType = 37;

            /// <summary>
            /// Property Indexer for LinesCanReverseInvoice 
            /// </summary>
            public const int LinesCanReverseInvoice = 38;

            /// <summary>
            /// Property Indexer for DefaultPostingDate 
            /// </summary>
            public const int DefaultPostingDate = 39;

            /// <summary>
            /// Property Indexer for DefaultReconciliationStatus 
            /// </summary>
            public const int DefaultReconciliationStatus = 40;

            /// <summary>
            /// Property Indexer for DefaultReconciliationDescription 
            /// </summary>
            public const int DefaultReconciliationDesc = 41;

            /// <summary>
            /// Property Indexer for LinesJournalled 
            /// </summary>
            public const int LinesJournal = 42;

            /// <summary>
            /// Property Indexer for LinesPurged 
            /// </summary>
            public const int LinesPurged = 43;

            /// <summary>
            /// Property Indexer for ClearToFuturePeriod 
            /// </summary>
            public const int ClearToFuturePeriod = 44;

            /// <summary>
            /// Property Indexer for FiscalClearedToFuture 
            /// </summary>
            public const int FiscalClearedToFuture = 45;

            /// <summary>
            /// Property Indexer for FiscalClearedToCurrent 
            /// </summary>
            public const int FiscalClearedToCurrent = 46;

            /// <summary>
            /// Property Indexer for ReconciledAndJournaledTransac 
            /// </summary>
            public const int ReconciledAndJournalTransac = 47;

            /// <summary>
            /// Property Indexer for CurrentPeriodsWriteOff 
            /// </summary>
            public const int CurrentPeriodsWriteOff = 48;

            /// <summary>
            /// Property Indexer for ClearToReconciliationPeriod 
            /// </summary>
            public const int ClearToReconciliationPeriod = 49;

            /// <summary>
            /// Property Indexer for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const int FiscalWriteOffToThisPeriod = 50;

            /// <summary>
            /// Property Indexer for FiscalRemainingOutstanding 
            /// </summary>
            public const int FiscalRemainingOutstanding = 51;

            /// <summary>
            /// Property Indexer for TotalDeltaWriteOffs 
            /// </summary>
            public const int TotalDeltaWriteOffs = 52;

            /// <summary>
            /// Property Indexer for TotalDeltaBankErrors 
            /// </summary>
            public const int TotalDeltaBankErrors = 53;

            /// <summary>
            /// Property Indexer for TotalDeltaExchangeGain 
            /// </summary>
            public const int TotalDeltaExchangeGain = 54;

            /// <summary>
            /// Property Indexer for TotalDeltaExchangeLoss 
            /// </summary>
            public const int TotalDeltaExchangeLoss = 55;

            /// <summary>
            /// Property Indexer for TotalDeltaCreditCardCharge 
            /// </summary>
            public const int TotalDeltaCreditCardCharge = 56;

            /// <summary>
            /// Property Indexer for TotalDeltaCleared 
            /// </summary>
            public const int TotalDeltaCleared = 57;

            /// <summary>
            /// Property Indexer for TotalDeltaFunctionalAmount 
            /// </summary>
            public const int TotalDeltaFunctionalAmount = 58;

            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 59;

            /// <summary>
            /// Property Indexer for StatementCurrency 
            /// </summary>
            public const int StatementCurrency = 60;

            /// <summary>
            /// Property Indexer for ReconciliationWriteOffSum 
            /// </summary>
            public const int ReconciliationWriteOffSum = 61;

            /// <summary>
            /// Property Indexer for ReconciliationPostingYear 
            /// </summary>
            public const int ReconciliationPostingYear = 62;

            /// <summary>
            /// Property Indexer for ReconciliationPostingPeriod 
            /// </summary>
            public const int ReconciliationPostingPeriod = 63;

            /// <summary>
            /// Property Indexer for ReconciliationDelta 
            /// </summary>
            public const int ReconciliationDelta = 64;

            /// <summary>
            /// Property Indexer for FiscalMiscellaneousEntry 
            /// </summary>
            public const int FiscalMiscellaneousEntry = 65;

            /// <summary>
            /// Property Indexer for WithdrawalMiscellaneousEntriesToFisc 
            /// </summary>
            public const int WithdrawalMiscEntriesToFisc = 66;

            /// <summary>
            /// Property Indexer for DepositMiscellaneousEntriesToFiscal 
            /// </summary>
            public const int DepositMiscEntriesToFiscal = 67;

            /// <summary>
            /// Property Indexer for WithdrawalMiscellaneousEntriesToFutu 
            /// </summary>
            public const int WithdrawalMiscEntriesToFutu = 68;

            /// <summary>
            /// Property Indexer for DepositMiscellaneousEntriesToFuture 
            /// </summary>
            public const int DepositMiscEntriesToFuture = 69;

            /// <summary>
            /// Property Indexer for PaymentPayeeName 
            /// </summary>
            public const int PaymentPayeeName = 70;

            /// <summary>
            /// Property Indexer for PaymentVendorName 
            /// </summary>
            public const int PaymentVendorName = 71;

            /// <summary>
            /// Property Indexer for BankEntryOrTransferNumber 
            /// </summary>
            public const int BankEntryOrTransferNumber = 72;

            /// <summary>
            /// Property Indexer for LinesProcessed 
            /// </summary>
            public const int LinesProcessed = 73;

            /// <summary>
            /// Property Indexer for ReverseInvoice 
            /// </summary>
            public const int ReverseInvoice = 74;

            /// <summary>
            /// Property Indexer for GLAccountofDiscrepancy 
            /// </summary>
            public const int GLAccountofDiscrepancy = 75;

            /// <summary>
            /// Property Indexer for ReconcilebyDetailReconciled 
            /// </summary>
            public const int ReconcilebyDetailReconciled = 76;

            /// <summary>
            /// Property Indexer for ReconcilebyDetailOutstanding 
            /// </summary>
            public const int ReconcilebyDetailOutstanding = 77;

            #endregion
        }
	}
}
	