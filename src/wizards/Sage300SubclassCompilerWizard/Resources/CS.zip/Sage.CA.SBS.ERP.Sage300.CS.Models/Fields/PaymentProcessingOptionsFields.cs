﻿namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of constants for Payment Processing Options model mapping 
    /// </summary>
    public partial class PaymentProcessingOptions
    {
        /// <summary>
        /// Business View Code.
        /// </summary>
        public const string EntityName = "YP0407";

        /// <summary>
        /// Contains list of Options Fields Constants.
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for DummyKey 
            /// </summary>
            public const string DummyKey = "DUMMY";
            /// <summary>
            /// Property for Phone 
            /// </summary>
            public const string Phone = "PHONE";
            /// <summary>
            /// Property for Fax 
            /// </summary>
            public const string Fax = "FAX";
            /// <summary>
            /// Property for ContactName 
            /// </summary>
            public const string ContactName = "CONTACT";
            /// <summary>
            /// Property for Requireinvoicingatshipping 
            /// </summary>
            public const string Requireinvoicingatshipping = "SWCAPTURE";
            /// <summary>
            /// Property for WarnBeforeForcingExpiredPre 
            /// </summary>
            public const string WarnBeforeForcingExpiredPre = "SWCFMFORCE";
            /// <summary>
            /// Property for TermsDiscOnAutomaticPayment
            /// </summary>
            public const string TermsDiscOnAutomaticPayment = "SWAPPLYDIS";

            #endregion
        }

        /// <summary>
        /// Contains list of Options Index Constants.
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for DummyKey 
            /// </summary>
            public const int DummyKey = 1;
            /// <summary>
            /// Property Indexer for Phone 
            /// </summary>
            public const int Phone = 2;
            /// <summary>
            /// Property Indexer for Fax 
            /// </summary>
            public const int Fax = 3;
            /// <summary>
            /// Property Indexer for ContactName 
            /// </summary>
            public const int ContactName = 4;
            /// <summary>
            /// Property Indexer for Requireinvoicingatshipping 
            /// </summary>
            public const int Requireinvoicingatshipping = 5;
            /// <summary>
            /// Property Indexer for WarnBeforeForcingExpiredPre 
            /// </summary>
            public const int WarnBeforeForcingExpiredPre = 6;
            /// <summary>
            /// Property Indexer for TermsDiscOnAutomaticPayment 
            /// </summary>
            public const int TermsDiscOnAutomaticPayment = 7;

            #endregion
        }
    }
}
