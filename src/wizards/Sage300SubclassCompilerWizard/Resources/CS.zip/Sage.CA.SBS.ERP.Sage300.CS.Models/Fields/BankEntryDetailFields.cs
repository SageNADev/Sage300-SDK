/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankEntries Constants 
    /// </summary>
    public partial class BankEntryDetail
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0460";

        /// <summary>
        /// Contains list of BankEntries Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for SequenceNumber 
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "LINE";
            /// <summary>
            /// Property for Bank 
            /// </summary>
            public const string Bank = "BANK";

            /// <summary>
            /// Property for POSTDATE 
            /// </summary>
            public const string POSTDATE = "POSTDATE";
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "DISTCODE";
            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "REFERENCE";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "COMMENT";
            /// <summary>
            /// Property for Amount 
            /// </summary>
            public const string Amount = "AMOUNT";
            /// <summary>
            /// Property for SourceAmount 
            /// </summary>
            public const string SourceAmount = "SRCEAMT";

            /// <summary>
            /// Property for RATETYPE 
            /// </summary>
            public const string RATETYPE = "RATETYPE";

            /// <summary>
            /// Property for SRCECURN 
            /// </summary>
            public const string SRCECURN = "SRCECURN";

            /// <summary>
            /// Property for RATEDATE 
            /// </summary>
            public const string RATEDATE = "RATEDATE";

            /// <summary>
            /// Property for RATE 
            /// </summary>
            public const string RATE = "RATE";

            /// <summary>
            /// Property for RATESPREAD 
            /// </summary>
            public const string RATESPREAD = "RATESPREAD";

            /// <summary>
            /// Property for RATEOP 
            /// </summary>
            public const string RATEOP = "RATEOP";
            /// <summary>
            /// Property for GOrLAccount 
            /// </summary>
            public const string GOrLAccount = "GLACCOUNT";
            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryType = "ENTRYTYPE";
            /// <summary>
            /// Property for Comments 
            /// </summary>
            public const string Comments = "BIGCOMMENT";
            /// <summary>
            /// Property for StatementAmount 
            /// </summary>
            public const string StatementAmount = "ENTRYAMT";
            /// <summary>
            /// Property for GrossSourceAmount 
            /// </summary>
            public const string GrossSourceAmount = "SRCEGROAMT";
            /// <summary>
            /// Property for GrossAmount 
            /// </summary>
            public const string GrossAmount = "FUNCGROAMT";
            /// <summary>
            /// Property for DistributionCodeDescription 
            /// </summary>
            public const string DistributionCodeDescription = "DISTCODED";
            /// <summary>
            /// Property for GOrLAccountDescription 
            /// </summary>
            public const string GOrLAccountDescription = "GLACCOUNTD";
            /// <summary>
            /// Property for Line 
            /// </summary>
            public const string Line = "LINEONE";
            /// <summary>
            /// Property for SetDefaultSetupValues 
            /// </summary>
            public const string SetDefaultSetupValues = "SETDEFAULT";
            /// <summary>
            /// Property for CallforCreateDistribution 
            /// </summary>
            public const string CallforCreateDistribution = "CREATEDIST";
            /// <summary>
            /// Property for Taxable 
            /// </summary>
            public const string Taxable = "SWTAXBL";
            /// <summary>
            /// Property for TaxAmountCalculation 
            /// </summary>
            public const string TaxAmountCalculation = "TXAMTCALC";
            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";
            /// <summary>
            /// Property for TaxAuthority1 
            /// </summary>
            public const string TaxAuthority1 = "TAXAUTH1";
            /// <summary>
            /// Property for TaxAuthority2 
            /// </summary>
            public const string TaxAuthority2 = "TAXAUTH2";
            /// <summary>
            /// Property for TaxAuthority3 
            /// </summary>
            public const string TaxAuthority3 = "TAXAUTH3";
            /// <summary>
            /// Property for TaxAuthority4 
            /// </summary>
            public const string TaxAuthority4 = "TAXAUTH4";
            /// <summary>
            /// Property for TaxAuthority5 
            /// </summary>
            public const string TaxAuthority5 = "TAXAUTH5";
            /// <summary>
            /// Property for TaxVendorClass1 
            /// </summary>
            public const string TaxVendorClass1 = "TAXVCLSS1";
            /// <summary>
            /// Property for TaxVendorClass2 
            /// </summary>
            public const string TaxVendorClass2 = "TAXVCLSS2";
            /// <summary>
            /// Property for TaxVendorClass3 
            /// </summary>
            public const string TaxVendorClass3 = "TAXVCLSS3";
            /// <summary>
            /// Property for TaxVendorClass4 
            /// </summary>
            public const string TaxVendorClass4 = "TAXVCLSS4";
            /// <summary>
            /// Property for TaxVendorClass5 
            /// </summary>
            public const string TaxVendorClass5 = "TAXVCLSS5";
            /// <summary>
            /// Property for TaxItemClass1 
            /// </summary>
            public const string TaxItemClass1 = "TAXICLSS1";
            /// <summary>
            /// Property for TaxItemClass2 
            /// </summary>
            public const string TaxItemClass2 = "TAXICLSS2";
            /// <summary>
            /// Property for TaxItemClass3 
            /// </summary>
            public const string TaxItemClass3 = "TAXICLSS3";
            /// <summary>
            /// Property for TaxItemClass4 
            /// </summary>
            public const string TaxItemClass4 = "TAXICLSS4";
            /// <summary>
            /// Property for TaxItemClass5 
            /// </summary>
            public const string TaxItemClass5 = "TAXICLSS5";
            /// <summary>
            /// Property for TaxInclude1 
            /// </summary>
            public const string TaxInclude1 = "TAXINCL1";
            /// <summary>
            /// Property for TaxInclude2 
            /// </summary>
            public const string TaxInclude2 = "TAXINCL2";
            /// <summary>
            /// Property for TaxInclude3 
            /// </summary>
            public const string TaxInclude3 = "TAXINCL3";
            /// <summary>
            /// Property for TaxInclude4 
            /// </summary>
            public const string TaxInclude4 = "TAXINCL4";
            /// <summary>
            /// Property for TaxInclude5 
            /// </summary>
            public const string TaxInclude5 = "TAXINCL5";
            /// <summary>
            /// Property for TaxBaseAmount1 
            /// </summary>
            public const string TaxBaseAmount1 = "BASETAX1";
            /// <summary>
            /// Property for TaxBaseAmount2 
            /// </summary>
            public const string TaxBaseAmount2 = "BASETAX2";
            /// <summary>
            /// Property for TaxBaseAmount3 
            /// </summary>
            public const string TaxBaseAmount3 = "BASETAX3";
            /// <summary>
            /// Property for TaxBaseAmount4 
            /// </summary>
            public const string TaxBaseAmount4 = "BASETAX4";
            /// <summary>
            /// Property for TaxBaseAmount5 
            /// </summary>
            public const string TaxBaseAmount5 = "BASETAX5";
            /// <summary>
            /// Property for TaxBaseCalculationMethod 
            /// </summary>
            public const string TaxBaseCalculationMethod = "TXCALCBASE";
            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "AMTTAX1";
            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "AMTTAX2";
            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "AMTTAX3";
            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "AMTTAX4";
            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "AMTTAX5";
            /// <summary>
            /// Property for TaxableAMount 
            /// </summary>
            public const string TaxableAMount = "AMTTXBL";
            /// <summary>
            /// Property for NonTaxableAmount 
            /// </summary>
            public const string NonTaxableAmount = "AMTNOTTXBL";
            /// <summary>
            /// Property for TaxTotal 
            /// </summary>
            public const string TaxTotal = "AMTTAXTOT";
            /// <summary>
            /// Property for DocumentTotalBeforeTax 
            /// </summary>
            public const string DocumentTotalBeforeTax = "AMTDOCTOT";
            /// <summary>
            /// Property for DocumentTotalIncludingTax 
            /// </summary>
            public const string DocumentTotalIncludingTax = "AMTNETTOT";
            /// <summary>
            /// Property for TaxDistributionamount 
            /// </summary>
            public const string TaxDistributionamount = "AMTDIST";
            /// <summary>
            /// Property for TotalIncludedAmount 
            /// </summary>
            public const string TotalIncludedAmount = "AMTINCLUDE";
            /// <summary>
            /// Property for TaxNetDistributionAmount 
            /// </summary>
            public const string TaxNetDistributionAmount = "AMTNETDIST";
            /// <summary>
            /// Property for TotalExcludedAmount 
            /// </summary>
            public const string TotalExcludedAmount = "AMTEXCLUDE";
            /// <summary>
            /// Property for TaxGrossDistributionAmount 
            /// </summary>
            public const string TaxGrossDistributionAmount = "AMTGRODIST";
            /// <summary>
            /// Property for TaxExpenseAmount1 
            /// </summary>
            public const string TaxExpenseAmount1 = "AMTEXPENS1";
            /// <summary>
            /// Property for TaxExpenseAmount2 
            /// </summary>
            public const string TaxExpenseAmount2 = "AMTEXPENS2";
            /// <summary>
            /// Property for TaxExpenseAmount3 
            /// </summary>
            public const string TaxExpenseAmount3 = "AMTEXPENS3";
            /// <summary>
            /// Property for TaxExpenseAmount4 
            /// </summary>
            public const string TaxExpenseAmount4 = "AMTEXPENS4";
            /// <summary>
            /// Property for TaxExpenseAmount5 
            /// </summary>
            public const string TaxExpenseAmount5 = "AMTEXPENS5";
            /// <summary>
            /// Property for TaxRecoverableAmount1 
            /// </summary>
            public const string TaxRecoverableAmount1 = "AMTRECVRB1";
            /// <summary>
            /// Property for TaxRecoverableAmount2 
            /// </summary>
            public const string TaxRecoverableAmount2 = "AMTRECVRB2";
            /// <summary>
            /// Property for TaxRecoverableAmount3 
            /// </summary>
            public const string TaxRecoverableAmount3 = "AMTRECVRB3";
            /// <summary>
            /// Property for TaxRecoverableAmount4 
            /// </summary>
            public const string TaxRecoverableAmount4 = "AMTRECVRB4";
            /// <summary>
            /// Property for TaxRecoverableAmount5 
            /// </summary>
            public const string TaxRecoverableAmount5 = "AMTRECVRB5";
            /// <summary>
            /// Property for TaxAllocatedAmount1 
            /// </summary>
            public const string TaxAllocatedAmount1 = "AMTALLOC1";
            /// <summary>
            /// Property for TaxAllocatedAmount2 
            /// </summary>
            public const string TaxAllocatedAmount2 = "AMTALLOC2";
            /// <summary>
            /// Property for TaxAllocatedAmount3 
            /// </summary>
            public const string TaxAllocatedAmount3 = "AMTALLOC3";
            /// <summary>
            /// Property for TaxAllocatedAmount4 
            /// </summary>
            public const string TaxAllocatedAmount4 = "AMTALLOC4";
            /// <summary>
            /// Property for TaxAllocatedAmount5 
            /// </summary>
            public const string TaxAllocatedAmount5 = "AMTALLOC5";
            /// <summary>
            /// Property for TotalTaxAllocatedAmount 
            /// </summary>
            public const string TotalTaxAllocatedAmount = "TOTAMTALOC";
            /// <summary>
            /// Property for TaxReportingAmount1 
            /// </summary>
            public const string TaxReportingAmount1 = "TXAMT1RC";
            /// <summary>
            /// Property for TaxReportingAmount2 
            /// </summary>
            public const string TaxReportingAmount2 = "TXAMT2RC";
            /// <summary>
            /// Property for TaxReportingAmount3 
            /// </summary>
            public const string TaxReportingAmount3 = "TXAMT3RC";
            /// <summary>
            /// Property for TaxReportingAmount4 
            /// </summary>
            public const string TaxReportingAmount4 = "TXAMT4RC";
            /// <summary>
            /// Property for TaxReportingAmount5 
            /// </summary>
            public const string TaxReportingAmount5 = "TXAMT5RC";
            /// <summary>
            /// Property for TaxReportingExpensed1 
            /// </summary>
            public const string TaxReportingExpensed1 = "TXEXPNS1RC";
            /// <summary>
            /// Property for TaxReportingExpensed2 
            /// </summary>
            public const string TaxReportingExpensed2 = "TXEXPNS2RC";
            /// <summary>
            /// Property for TaxReportingExpensed3 
            /// </summary>
            public const string TaxReportingExpensed3 = "TXEXPNS3RC";
            /// <summary>
            /// Property for TaxReportingExpensed4 
            /// </summary>
            public const string TaxReportingExpensed4 = "TXEXPNS4RC";
            /// <summary>
            /// Property for TaxReportingExpensed5 
            /// </summary>
            public const string TaxReportingExpensed5 = "TXEXPNS5RC";
            /// <summary>
            /// Property for TXRECVB1RC 
            /// </summary>
            public const string TXRECVB1RC = "TXRECVB1RC";
            /// <summary>
            /// Property for TXRECVB2RC 
            /// </summary>
            public const string TXRECVB2RC = "TXRECVB2RC";
            /// <summary>
            /// Property for TXRECVB3RC 
            /// </summary>
            public const string TXRECVB3RC = "TXRECVB3RC";
            /// <summary>
            /// Property for TXRECVB4RC 
            /// </summary>
            public const string TXRECVB4RC = "TXRECVB4RC";
            /// <summary>
            /// Property for TXRECVB5RC 
            /// </summary>
            public const string TXRECVB5RC = "TXRECVB5RC";
            /// <summary>
            /// Property for TaxReportingAllocatedAmount1 
            /// </summary>
            public const string TaxReportingAllocatedAmount1 = "TXALLOC1RC";
            /// <summary>
            /// Property for TaxReportingAllocatedAmount2 
            /// </summary>
            public const string TaxReportingAllocatedAmount2 = "TXALLOC2RC";
            /// <summary>
            /// Property for TaxReportingAllocatedAmount3 
            /// </summary>
            public const string TaxReportingAllocatedAmount3 = "TXALLOC3RC";
            /// <summary>
            /// Property for TaxReportingAllocatedAmount4 
            /// </summary>
            public const string TaxReportingAllocatedAmount4 = "TXALLOC4RC";
            /// <summary>
            /// Property for TaxReportingAllocatedAmount5 
            /// </summary>
            public const string TaxReportingAllocatedAmount5 = "TXALLOC5RC";
            /// <summary>
            /// Property for TotalTaxReportingAllocatedAm 
            /// </summary>
            public const string TotalTaxReportingAllocatedAm = "TXALOCRC";
            /// <summary>
            /// Property for TotalTaxReportingAmount 
            /// </summary>
            public const string TotalTaxReportingAmount = "TXTOTRC";
            /// <summary>
            /// Property for FunctionalNetofTax 
            /// </summary>
            public const string FunctionalNetofTax = "FUNNETTAX";
            /// <summary>
            /// Property for FunctionalGrossDistributionAm 
            /// </summary>
            public const string FunctionalGrossDistributionAm = "FUNGRODIS";
            /// <summary>
            /// Property for TaxVersion 
            /// </summary>
            public const string TaxVersion = "TAXVERSION";
            /// <summary>
            /// Property for TaxCalculationReportingMethod 
            /// </summary>
            public const string TaxCalculationReportingMethod = "TXCALCRMET";
            /// <summary>
            /// Property for TaxReportingCurrencyCode 
            /// </summary>
            public const string TaxReportingCurrencyCode = "CODECURNRC";
            /// <summary>
            /// Property for TaxReportingRate 
            /// </summary>
            public const string TaxReportingRate = "RATERC";
            /// <summary>
            /// Property for TaxReportingRateType 
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";
            /// <summary>
            /// Property for TaxReportingRateDate 
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";
            /// <summary>
            /// Property for TaxReportingRateOperation 
            /// </summary>
            public const string TaxReportingRateOperation = "RATEOPRC";
            /// <summary>
            /// Property for TaxExpenseAccount1 
            /// </summary>
            public const string TaxExpenseAccount1 = "EXPNSACNT1";
            /// <summary>
            /// Property for TaxExpenseAccount2 
            /// </summary>
            public const string TaxExpenseAccount2 = "EXPNSACNT2";
            /// <summary>
            /// Property for TaxExpenseAccount3 
            /// </summary>
            public const string TaxExpenseAccount3 = "EXPNSACNT3";
            /// <summary>
            /// Property for TaxExpenseAccount4 
            /// </summary>
            public const string TaxExpenseAccount4 = "EXPNSACNT4";
            /// <summary>
            /// Property for TaxExpenseAccount5 
            /// </summary>
            public const string TaxExpenseAccount5 = "EXPNSACNT5";
            /// <summary>
            /// Property for TaxRecoverableAccount1 
            /// </summary>
            public const string TaxRecoverableAccount1 = "RECBLACNT1";
            /// <summary>
            /// Property for TaxRecoverableAccount2 
            /// </summary>
            public const string TaxRecoverableAccount2 = "RECBLACNT2";
            /// <summary>
            /// Property for TaxRecoverableAccount3 
            /// </summary>
            public const string TaxRecoverableAccount3 = "RECBLACNT3";
            /// <summary>
            /// Property for TaxRecoverableAccount4 
            /// </summary>
            public const string TaxRecoverableAccount4 = "RECBLACNT4";
            /// <summary>
            /// Property for TaxRecoverableAccount5 
            /// </summary>
            public const string TaxRecoverableAccount5 = "RECBLACNT5";
            /// <summary>
            /// Property for TaxRate1 
            /// </summary>
            public const string TaxRate1 = "TAXRATE1";
            /// <summary>
            /// Property for TaxRate2 
            /// </summary>
            public const string TaxRate2 = "TAXRATE2";
            /// <summary>
            /// Property for TaxRate3 
            /// </summary>
            public const string TaxRate3 = "TAXRATE3";
            /// <summary>
            /// Property for TaxRate4 
            /// </summary>
            public const string TaxRate4 = "TAXRATE4";
            /// <summary>
            /// Property for TaxRate5 
            /// </summary>
            public const string TaxRate5 = "TAXRATE5";
            /// <summary>
            /// Property for TaxGroupDescription 
            /// </summary>
            public const string TaxGroupDescription = "TXGRPDESC";
            /// <summary>
            /// Property for TaxProcessCommand 
            /// </summary>
            public const string TaxProcessCommand = "PROCESSCMD";
            /// <summary>
            /// Property for TaxAuthorityDescription1 
            /// </summary>
            public const string TaxAuthorityDescription1 = "TXAU1DESC";
            /// <summary>
            /// Property for TaxAuthorityDescription2 
            /// </summary>
            public const string TaxAuthorityDescription2 = "TXAU2DESC";
            /// <summary>
            /// Property for TaxAuthorityDescription3 
            /// </summary>
            public const string TaxAuthorityDescription3 = "TXAU3DESC";
            /// <summary>
            /// Property for TaxAuthorityDescription4 
            /// </summary>
            public const string TaxAuthorityDescription4 = "TXAU4DESC";
            /// <summary>
            /// Property for TaxAuthorityDescription5 
            /// </summary>
            public const string TaxAuthorityDescription5 = "TXAU5DESC";
            /// <summary>
            /// Property for VendorTaxClassDescription1 
            /// </summary>
            public const string VendorTaxClassDescription1 = "VCLS1DESC";
            /// <summary>
            /// Property for VendorTaxClassDescription2 
            /// </summary>
            public const string VendorTaxClassDescription2 = "VCLS2DESC";
            /// <summary>
            /// Property for VendorTaxClassDescription3 
            /// </summary>
            public const string VendorTaxClassDescription3 = "VCLS3DESC";
            /// <summary>
            /// Property for VendorTaxClassDescription4 
            /// </summary>
            public const string VendorTaxClassDescription4 = "VCLS4DESC";
            /// <summary>
            /// Property for VendorTaxClassDescription5 
            /// </summary>
            public const string VendorTaxClassDescription5 = "VCLS5DESC";
            /// <summary>
            /// Property for ItemTaxClassDescription1 
            /// </summary>
            public const string ItemTaxClassDescription1 = "ICLS1DESC";
            /// <summary>
            /// Property for ItemTaxClassDescription2 
            /// </summary>
            public const string ItemTaxClassDescription2 = "ICLS2DESC";
            /// <summary>
            /// Property for ItemTaxClassDescription3 
            /// </summary>
            public const string ItemTaxClassDescription3 = "ICLS3DESC";
            /// <summary>
            /// Property for ItemTaxClassDescription4 
            /// </summary>
            public const string ItemTaxClassDescription4 = "ICLS4DESC";
            /// <summary>
            /// Property for ItemTaxClassDescription5 
            /// </summary>
            public const string ItemTaxClassDescription5 = "ICLS5DESC";
            /// <summary>
            /// Property for FunctionalTaxAmount1 
            /// </summary>
            public const string FunctionalTaxAmount1 = "FUNTXAMT1";
            /// <summary>
            /// Property for FunctionalTaxAmount2 
            /// </summary>
            public const string FunctionalTaxAmount2 = "FUNTXAMT2";
            /// <summary>
            /// Property for FunctionalTaxAmount3 
            /// </summary>
            public const string FunctionalTaxAmount3 = "FUNTXAMT3";
            /// <summary>
            /// Property for FunctionalTaxAmount4 
            /// </summary>
            public const string FunctionalTaxAmount4 = "FUNTXAMT4";
            /// <summary>
            /// Property for FunctionalTaxAmount5 
            /// </summary>
            public const string FunctionalTaxAmount5 = "FUNTXAMT5";
            /// <summary>
            /// Property for FunctionalTaxBaseAmount1 
            /// </summary>
            public const string FunctionalTaxBaseAmount1 = "FUNTXBSE1";
            /// <summary>
            /// Property for FunctionalTaxBaseAmount2 
            /// </summary>
            public const string FunctionalTaxBaseAmount2 = "FUNTXBSE2";
            /// <summary>
            /// Property for FunctionalTaxBaseAmount3 
            /// </summary>
            public const string FunctionalTaxBaseAmount3 = "FUNTXBSE3";
            /// <summary>
            /// Property for FunctionalTaxBaseAmount4 
            /// </summary>
            public const string FunctionalTaxBaseAmount4 = "FUNTXBSE4";
            /// <summary>
            /// Property for FunctionalTaxBaseAmount5 
            /// </summary>
            public const string FunctionalTaxBaseAmount5 = "FUNTXBSE5";
            /// <summary>
            /// Property for FunctionalTaxTotal 
            /// </summary>
            public const string FunctionalTaxTotal = "FUNTOTTAX";
            /// <summary>
            /// Property for FunctionalExpensedAmount1 
            /// </summary>
            public const string FunctionalExpensedAmount1 = "FUNTXEXP1";
            /// <summary>
            /// Property for FunctionalExpensedAmount2 
            /// </summary>
            public const string FunctionalExpensedAmount2 = "FUNTXEXP2";
            /// <summary>
            /// Property for FunctionalExpensedAmount3 
            /// </summary>
            public const string FunctionalExpensedAmount3 = "FUNTXEXP3";
            /// <summary>
            /// Property for FunctionalExpensedAmount4 
            /// </summary>
            public const string FunctionalExpensedAmount4 = "FUNTXEXP4";
            /// <summary>
            /// Property for FunctionalExpensedAmount5 
            /// </summary>
            public const string FunctionalExpensedAmount5 = "FUNTXEXP5";
            /// <summary>
            /// Property for FunctionalRecoverableAmount1 
            /// </summary>
            public const string FunctionalRecoverableAmount1 = "FUNTXRCB1";
            /// <summary>
            /// Property for FunctionalRecoverableAmount2 
            /// </summary>
            public const string FunctionalRecoverableAmount2 = "FUNTXRCB2";
            /// <summary>
            /// Property for FunctionalRecoverableAmount3 
            /// </summary>
            public const string FunctionalRecoverableAmount3 = "FUNTXRCB3";
            /// <summary>
            /// Property for FunctionalRecoverableAmount4 
            /// </summary>
            public const string FunctionalRecoverableAmount4 = "FUNTXRCB4";
            /// <summary>
            /// Property for FunctionalRecoverableAmount5 
            /// </summary>
            public const string FunctionalRecoverableAmount5 = "FUNTXRCB5";
            /// <summary>
            /// Property for FunctionalAllocatedAmount1 
            /// </summary>
            public const string FunctionalAllocatedAmount1 = "FUNTXALOC1";
            /// <summary>
            /// Property for FunctionalAllocatedAmount2 
            /// </summary>
            public const string FunctionalAllocatedAmount2 = "FUNTXALOC2";
            /// <summary>
            /// Property for FunctionalAllocatedAmount3 
            /// </summary>
            public const string FunctionalAllocatedAmount3 = "FUNTXALOC3";
            /// <summary>
            /// Property for FunctionalAllocatedAmount4 
            /// </summary>
            public const string FunctionalAllocatedAmount4 = "FUNTXALOC4";
            /// <summary>
            /// Property for FunctionalAllocatedAmount5 
            /// </summary>
            public const string FunctionalAllocatedAmount5 = "FUNTXALOC5";
            /// <summary>
            /// Property for FunctionalTotalTaxAllocated 
            /// </summary>
            public const string FunctionalTotalTaxAllocated = "FUNAMTALOC";
            /// <summary>
            /// Property for TaxReportingCurrencyDescripti 
            /// </summary>
            public const string TaxReportingCurrencyDescripti = "CURNRCDESC";
            /// <summary>
            /// Property for TaxReportingRateTypeDescripti 
            /// </summary>
            public const string TaxReportingRateTypeDescripti = "RATERCDESC";

            #endregion
        }


        /// <summary>
        /// Contains list of BankEntries Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for SequenceNumber 
            /// </summary>
            public const int SequenceNumber = 1;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 2;
            /// <summary>
            /// Property Indexer for Bank 
            /// </summary>
            public const int Bank = 3;

            /// <summary>
            /// Property Indexer for POSTDATE 
            /// </summary>
            public const int POSTDATE = 4;
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 5;
            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 6;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 7;
            /// <summary>
            /// Property Indexer for Amount 
            /// </summary>
            public const int Amount = 8;
            /// <summary>
            /// Property Indexer for SourceAmount 
            /// </summary>
            public const int SourceAmount = 9;

            /// <summary>
            /// Property Indexer for RATETYPE 
            /// </summary>
            public const int RATETYPE = 10;

            /// <summary>
            /// Property Indexer for SRCECURN 
            /// </summary>
            public const int SRCECURN = 11;

            /// <summary>
            /// Property Indexer for RATEDATE 
            /// </summary>
            public const int RATEDATE = 12;

            /// <summary>
            /// Property Indexer for RATE 
            /// </summary>
            public const int RATE = 13;

            /// <summary>
            /// Property Indexer for RATESPREAD 
            /// </summary>
            public const int RATESPREAD = 14;

            /// <summary>
            /// Property Indexer for RATEOP 
            /// </summary>
            public const int RATEOP = 15;
            /// <summary>
            /// Property Indexer for GOrLAccount 
            /// </summary>
            public const int GOrLAccount = 16;
            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryType = 17;
            /// <summary>
            /// Property Indexer for Comments 
            /// </summary>
            public const int Comments = 18;
            /// <summary>
            /// Property Indexer for StatementAmount 
            /// </summary>
            public const int StatementAmount = 26;
            /// <summary>
            /// Property Indexer for GrossSourceAmount 
            /// </summary>
            public const int GrossSourceAmount = 27;
            /// <summary>
            /// Property Indexer for GrossAmount 
            /// </summary>
            public const int GrossAmount = 28;
            /// <summary>
            /// Property Indexer for DistributionCodeDescription 
            /// </summary>
            public const int DistributionCodeDescription = 29;
            /// <summary>
            /// Property Indexer for GOrLAccountDescription 
            /// </summary>
            public const int GOrLAccountDescription = 30;
            /// <summary>
            /// Property Indexer for Line 
            /// </summary>
            public const int Line = 31;
            /// <summary>
            /// Property Indexer for SetDefaultSetupValues 
            /// </summary>
            public const int SetDefaultSetupValues = 32;
            /// <summary>
            /// Property Indexer for CallforCreateDistribution 
            /// </summary>
            public const int CallforCreateDistribution = 33;
            /// <summary>
            /// Property Indexer for Taxable 
            /// </summary>
            public const int Taxable = 50;
            /// <summary>
            /// Property Indexer for TaxAmountCalculation 
            /// </summary>
            public const int TaxAmountCalculation = 51;
            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 52;
            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 53;
            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 54;
            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 55;
            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 56;
            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 57;
            /// <summary>
            /// Property Indexer for TaxVendorClass1 
            /// </summary>
            public const int TaxVendorClass1 = 58;
            /// <summary>
            /// Property Indexer for TaxVendorClass2 
            /// </summary>
            public const int TaxVendorClass2 = 59;
            /// <summary>
            /// Property Indexer for TaxVendorClass3 
            /// </summary>
            public const int TaxVendorClass3 = 60;
            /// <summary>
            /// Property Indexer for TaxVendorClass4 
            /// </summary>
            public const int TaxVendorClass4 = 61;
            /// <summary>
            /// Property Indexer for TaxVendorClass5 
            /// </summary>
            public const int TaxVendorClass5 = 62;
            /// <summary>
            /// Property Indexer for TaxItemClass1 
            /// </summary>
            public const int TaxItemClass1 = 63;
            /// <summary>
            /// Property Indexer for TaxItemClass2 
            /// </summary>
            public const int TaxItemClass2 = 64;
            /// <summary>
            /// Property Indexer for TaxItemClass3 
            /// </summary>
            public const int TaxItemClass3 = 65;
            /// <summary>
            /// Property Indexer for TaxItemClass4 
            /// </summary>
            public const int TaxItemClass4 = 66;
            /// <summary>
            /// Property Indexer for TaxItemClass5 
            /// </summary>
            public const int TaxItemClass5 = 67;
            /// <summary>
            /// Property Indexer for TaxInclude1 
            /// </summary>
            public const int TaxInclude1 = 68;
            /// <summary>
            /// Property Indexer for TaxInclude2 
            /// </summary>
            public const int TaxInclude2 = 69;
            /// <summary>
            /// Property Indexer for TaxInclude3 
            /// </summary>
            public const int TaxInclude3 = 70;
            /// <summary>
            /// Property Indexer for TaxInclude4 
            /// </summary>
            public const int TaxInclude4 = 71;
            /// <summary>
            /// Property Indexer for TaxInclude5 
            /// </summary>
            public const int TaxInclude5 = 72;
            /// <summary>
            /// Property Indexer for TaxBaseAmount1 
            /// </summary>
            public const int TaxBaseAmount1 = 73;
            /// <summary>
            /// Property Indexer for TaxBaseAmount2 
            /// </summary>
            public const int TaxBaseAmount2 = 74;
            /// <summary>
            /// Property Indexer for TaxBaseAmount3 
            /// </summary>
            public const int TaxBaseAmount3 = 75;
            /// <summary>
            /// Property Indexer for TaxBaseAmount4 
            /// </summary>
            public const int TaxBaseAmount4 = 76;
            /// <summary>
            /// Property Indexer for TaxBaseAmount5 
            /// </summary>
            public const int TaxBaseAmount5 = 77;
            /// <summary>
            /// Property Indexer for TaxBaseCalculationMethod 
            /// </summary>
            public const int TaxBaseCalculationMethod = 78;
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 79;
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 80;
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 81;
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 82;
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 83;
            /// <summary>
            /// Property Indexer for TaxableAMount 
            /// </summary>
            public const int TaxableAMount = 84;
            /// <summary>
            /// Property Indexer for NonTaxableAmount 
            /// </summary>
            public const int NonTaxableAmount = 85;
            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 86;
            /// <summary>
            /// Property Indexer for DocumentTotalBeforeTax 
            /// </summary>
            public const int DocumentTotalBeforeTax = 87;
            /// <summary>
            /// Property Indexer for DocumentTotalIncludingTax 
            /// </summary>
            public const int DocumentTotalIncludingTax = 88;
            /// <summary>
            /// Property Indexer for TaxDistributionamount 
            /// </summary>
            public const int TaxDistributionamount = 89;
            /// <summary>
            /// Property Indexer for TotalIncludedAmount 
            /// </summary>
            public const int TotalIncludedAmount = 90;
            /// <summary>
            /// Property Indexer for TaxNetDistributionAmount 
            /// </summary>
            public const int TaxNetDistributionAmount = 91;
            /// <summary>
            /// Property Indexer for TotalExcludedAmount 
            /// </summary>
            public const int TotalExcludedAmount = 92;
            /// <summary>
            /// Property Indexer for TaxGrossDistributionAmount 
            /// </summary>
            public const int TaxGrossDistributionAmount = 93;
            /// <summary>
            /// Property Indexer for TaxExpenseAmount1 
            /// </summary>
            public const int TaxExpenseAmount1 = 94;
            /// <summary>
            /// Property Indexer for TaxExpenseAmount2 
            /// </summary>
            public const int TaxExpenseAmount2 = 95;
            /// <summary>
            /// Property Indexer for TaxExpenseAmount3 
            /// </summary>
            public const int TaxExpenseAmount3 = 96;
            /// <summary>
            /// Property Indexer for TaxExpenseAmount4 
            /// </summary>
            public const int TaxExpenseAmount4 = 97;
            /// <summary>
            /// Property Indexer for TaxExpenseAmount5 
            /// </summary>
            public const int TaxExpenseAmount5 = 98;
            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1 
            /// </summary>
            public const int TaxRecoverableAmount1 = 99;
            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2 
            /// </summary>
            public const int TaxRecoverableAmount2 = 100;
            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3 
            /// </summary>
            public const int TaxRecoverableAmount3 = 101;
            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4 
            /// </summary>
            public const int TaxRecoverableAmount4 = 102;
            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5 
            /// </summary>
            public const int TaxRecoverableAmount5 = 103;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1 
            /// </summary>
            public const int TaxAllocatedAmount1 = 104;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2 
            /// </summary>
            public const int TaxAllocatedAmount2 = 105;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3 
            /// </summary>
            public const int TaxAllocatedAmount3 = 106;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4 
            /// </summary>
            public const int TaxAllocatedAmount4 = 107;
            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5 
            /// </summary>
            public const int TaxAllocatedAmount5 = 108;
            /// <summary>
            /// Property Indexer for TotalTaxAllocatedAmount 
            /// </summary>
            public const int TotalTaxAllocatedAmount = 109;
            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 110;
            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 111;
            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 112;
            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 113;
            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 114;
            /// <summary>
            /// Property Indexer for TaxReportingExpensed1 
            /// </summary>
            public const int TaxReportingExpensed1 = 115;
            /// <summary>
            /// Property Indexer for TaxReportingExpensed2 
            /// </summary>
            public const int TaxReportingExpensed2 = 116;
            /// <summary>
            /// Property Indexer for TaxReportingExpensed3 
            /// </summary>
            public const int TaxReportingExpensed3 = 117;
            /// <summary>
            /// Property Indexer for TaxReportingExpensed4 
            /// </summary>
            public const int TaxReportingExpensed4 = 118;
            /// <summary>
            /// Property Indexer for TaxReportingExpensed5 
            /// </summary>
            public const int TaxReportingExpensed5 = 119;
            /// <summary>
            /// Property Indexer for TXRECVB1RC 
            /// </summary>
            public const int TXRECVB1RC = 120;
            /// <summary>
            /// Property Indexer for TXRECVB2RC 
            /// </summary>
            public const int TXRECVB2RC = 121;
            /// <summary>
            /// Property Indexer for TXRECVB3RC 
            /// </summary>
            public const int TXRECVB3RC = 122;
            /// <summary>
            /// Property Indexer for TXRECVB4RC 
            /// </summary>
            public const int TXRECVB4RC = 123;
            /// <summary>
            /// Property Indexer for TXRECVB5RC 
            /// </summary>
            public const int TXRECVB5RC = 124;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1 
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 125;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2 
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 126;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3 
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 127;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4 
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 128;
            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5 
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 129;
            /// <summary>
            /// Property Indexer for TotalTaxReportingAllocatedAm 
            /// </summary>
            public const int TotalTaxReportingAllocatedAm = 130;
            /// <summary>
            /// Property Indexer for TotalTaxReportingAmount 
            /// </summary>
            public const int TotalTaxReportingAmount = 131;
            /// <summary>
            /// Property Indexer for FunctionalNetofTax 
            /// </summary>
            public const int FunctionalNetofTax = 132;
            /// <summary>
            /// Property Indexer for FunctionalGrossDistributionAm 
            /// </summary>
            public const int FunctionalGrossDistributionAm = 133;
            /// <summary>
            /// Property Indexer for TaxVersion 
            /// </summary>
            public const int TaxVersion = 134;
            /// <summary>
            /// Property Indexer for TaxCalculationReportingMethod 
            /// </summary>
            public const int TaxCalculationReportingMethod = 135;
            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode 
            /// </summary>
            public const int TaxReportingCurrencyCode = 136;
            /// <summary>
            /// Property Indexer for TaxReportingRate 
            /// </summary>
            public const int TaxReportingRate = 137;
            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 138;
            /// <summary>
            /// Property Indexer for TaxReportingRateDate 
            /// </summary>
            public const int TaxReportingRateDate = 139;
            /// <summary>
            /// Property Indexer for TaxReportingRateOperation 
            /// </summary>
            public const int TaxReportingRateOperation = 140;
            /// <summary>
            /// Property Indexer for TaxExpenseAccount1 
            /// </summary>
            public const int TaxExpenseAccount1 = 141;
            /// <summary>
            /// Property Indexer for TaxExpenseAccount2 
            /// </summary>
            public const int TaxExpenseAccount2 = 142;
            /// <summary>
            /// Property Indexer for TaxExpenseAccount3 
            /// </summary>
            public const int TaxExpenseAccount3 = 143;
            /// <summary>
            /// Property Indexer for TaxExpenseAccount4 
            /// </summary>
            public const int TaxExpenseAccount4 = 144;
            /// <summary>
            /// Property Indexer for TaxExpenseAccount5 
            /// </summary>
            public const int TaxExpenseAccount5 = 145;
            /// <summary>
            /// Property Indexer for TaxRecoverableAccount1 
            /// </summary>
            public const int TaxRecoverableAccount1 = 146;
            /// <summary>
            /// Property Indexer for TaxRecoverableAccount2 
            /// </summary>
            public const int TaxRecoverableAccount2 = 147;
            /// <summary>
            /// Property Indexer for TaxRecoverableAccount3 
            /// </summary>
            public const int TaxRecoverableAccount3 = 148;
            /// <summary>
            /// Property Indexer for TaxRecoverableAccount4 
            /// </summary>
            public const int TaxRecoverableAccount4 = 149;
            /// <summary>
            /// Property Indexer for TaxRecoverableAccount5 
            /// </summary>
            public const int TaxRecoverableAccount5 = 150;
            /// <summary>
            /// Property Indexer for TaxRate1 
            /// </summary>
            public const int TaxRate1 = 151;
            /// <summary>
            /// Property Indexer for TaxRate2 
            /// </summary>
            public const int TaxRate2 = 152;
            /// <summary>
            /// Property Indexer for TaxRate3 
            /// </summary>
            public const int TaxRate3 = 153;
            /// <summary>
            /// Property Indexer for TaxRate4 
            /// </summary>
            public const int TaxRate4 = 154;
            /// <summary>
            /// Property Indexer for TaxRate5 
            /// </summary>
            public const int TaxRate5 = 155;
            /// <summary>
            /// Property Indexer for TaxGroupDescription 
            /// </summary>
            public const int TaxGroupDescription = 200;
            /// <summary>
            /// Property Indexer for TaxProcessCommand 
            /// </summary>
            public const int TaxProcessCommand = 201;
            /// <summary>
            /// Property Indexer for TaxAuthorityDescription1 
            /// </summary>
            public const int TaxAuthorityDescription1 = 202;
            /// <summary>
            /// Property Indexer for TaxAuthorityDescription2 
            /// </summary>
            public const int TaxAuthorityDescription2 = 203;
            /// <summary>
            /// Property Indexer for TaxAuthorityDescription3 
            /// </summary>
            public const int TaxAuthorityDescription3 = 204;
            /// <summary>
            /// Property Indexer for TaxAuthorityDescription4 
            /// </summary>
            public const int TaxAuthorityDescription4 = 205;
            /// <summary>
            /// Property Indexer for TaxAuthorityDescription5 
            /// </summary>
            public const int TaxAuthorityDescription5 = 206;
            /// <summary>
            /// Property Indexer for VendorTaxClassDescription1 
            /// </summary>
            public const int VendorTaxClassDescription1 = 207;
            /// <summary>
            /// Property Indexer for VendorTaxClassDescription2 
            /// </summary>
            public const int VendorTaxClassDescription2 = 208;
            /// <summary>
            /// Property Indexer for VendorTaxClassDescription3 
            /// </summary>
            public const int VendorTaxClassDescription3 = 209;
            /// <summary>
            /// Property Indexer for VendorTaxClassDescription4 
            /// </summary>
            public const int VendorTaxClassDescription4 = 210;
            /// <summary>
            /// Property Indexer for VendorTaxClassDescription5 
            /// </summary>
            public const int VendorTaxClassDescription5 = 211;
            /// <summary>
            /// Property Indexer for ItemTaxClassDescription1 
            /// </summary>
            public const int ItemTaxClassDescription1 = 212;
            /// <summary>
            /// Property Indexer for ItemTaxClassDescription2 
            /// </summary>
            public const int ItemTaxClassDescription2 = 213;
            /// <summary>
            /// Property Indexer for ItemTaxClassDescription3 
            /// </summary>
            public const int ItemTaxClassDescription3 = 214;
            /// <summary>
            /// Property Indexer for ItemTaxClassDescription4 
            /// </summary>
            public const int ItemTaxClassDescription4 = 215;
            /// <summary>
            /// Property Indexer for ItemTaxClassDescription5 
            /// </summary>
            public const int ItemTaxClassDescription5 = 216;
            /// <summary>
            /// Property Indexer for FunctionalTaxAmount1 
            /// </summary>
            public const int FunctionalTaxAmount1 = 217;
            /// <summary>
            /// Property Indexer for FunctionalTaxAmount2 
            /// </summary>
            public const int FunctionalTaxAmount2 = 218;
            /// <summary>
            /// Property Indexer for FunctionalTaxAmount3 
            /// </summary>
            public const int FunctionalTaxAmount3 = 219;
            /// <summary>
            /// Property Indexer for FunctionalTaxAmount4 
            /// </summary>
            public const int FunctionalTaxAmount4 = 220;
            /// <summary>
            /// Property Indexer for FunctionalTaxAmount5 
            /// </summary>
            public const int FunctionalTaxAmount5 = 221;
            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount1 
            /// </summary>
            public const int FunctionalTaxBaseAmount1 = 222;
            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount2 
            /// </summary>
            public const int FunctionalTaxBaseAmount2 = 223;
            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount3 
            /// </summary>
            public const int FunctionalTaxBaseAmount3 = 224;
            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount4 
            /// </summary>
            public const int FunctionalTaxBaseAmount4 = 225;
            /// <summary>
            /// Property Indexer for FunctionalTaxBaseAmount5 
            /// </summary>
            public const int FunctionalTaxBaseAmount5 = 226;
            /// <summary>
            /// Property Indexer for FunctionalTaxTotal 
            /// </summary>
            public const int FunctionalTaxTotal = 227;
            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount1 
            /// </summary>
            public const int FunctionalExpensedAmount1 = 228;
            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount2 
            /// </summary>
            public const int FunctionalExpensedAmount2 = 229;
            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount3 
            /// </summary>
            public const int FunctionalExpensedAmount3 = 230;
            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount4 
            /// </summary>
            public const int FunctionalExpensedAmount4 = 231;
            /// <summary>
            /// Property Indexer for FunctionalExpensedAmount5 
            /// </summary>
            public const int FunctionalExpensedAmount5 = 232;
            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount1 
            /// </summary>
            public const int FunctionalRecoverableAmount1 = 233;
            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount2 
            /// </summary>
            public const int FunctionalRecoverableAmount2 = 234;
            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount3 
            /// </summary>
            public const int FunctionalRecoverableAmount3 = 235;
            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount4 
            /// </summary>
            public const int FunctionalRecoverableAmount4 = 236;
            /// <summary>
            /// Property Indexer for FunctionalRecoverableAmount5 
            /// </summary>
            public const int FunctionalRecoverableAmount5 = 237;
            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount1 
            /// </summary>
            public const int FunctionalAllocatedAmount1 = 238;
            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount2 
            /// </summary>
            public const int FunctionalAllocatedAmount2 = 239;
            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount3 
            /// </summary>
            public const int FunctionalAllocatedAmount3 = 240;
            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount4 
            /// </summary>
            public const int FunctionalAllocatedAmount4 = 241;
            /// <summary>
            /// Property Indexer for FunctionalAllocatedAmount5 
            /// </summary>
            public const int FunctionalAllocatedAmount5 = 242;
            /// <summary>
            /// Property Indexer for FunctionalTotalTaxAllocated 
            /// </summary>
            public const int FunctionalTotalTaxAllocated = 243;
            /// <summary>
            /// Property Indexer for TaxReportingCurrencyDescripti 
            /// </summary>
            public const int TaxReportingCurrencyDescripti = 244;
            /// <summary>
            /// Property Indexer for TaxReportingRateTypeDescripti 
            /// </summary>
            public const int TaxReportingRateTypeDescripti = 245;

            #endregion
        }


    }
}
