/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace

namespace Sage.CA.SBS.ERP.Sage300.CS.Models

// ReSharper restore CheckNamespace
{
    /// <summary>
    ///     Contains list of TaxRates Constants
    /// </summary>
    public partial class TaxRate
    {
        /// <summary>
        ///     View Name
        /// </summary>
        public const string EntityName = "TX0004";

        /// <summary>
        ///     Contains list of TaxRates Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            ///     Property for TaxAuthority
            /// </summary>
            public const string TaxAuthority = "AUTHORITY";

            /// <summary>
            ///     Property for TransactionType
            /// </summary>
            public const string TransactionType = "TTYPE";

            /// <summary>
            ///     Property for BuyerClass
            /// </summary>
            public const string BuyerClass = "BUYERCLASS";

            /// <summary>
            ///     Property for ItemRate1
            /// </summary>
            public const string ItemRate1 = "ITEMRATE1";

            /// <summary>
            ///     Property for ItemRate2
            /// </summary>
            public const string ItemRate2 = "ITEMRATE2";

            /// <summary>
            ///     Property for ItemRate3
            /// </summary>
            public const string ItemRate3 = "ITEMRATE3";

            /// <summary>
            ///     Property for ItemRate4
            /// </summary>
            public const string ItemRate4 = "ITEMRATE4";

            /// <summary>
            ///     Property for ItemRate5
            /// </summary>
            public const string ItemRate5 = "ITEMRATE5";

            /// <summary>
            ///     Property for ItemRate6
            /// </summary>
            public const string ItemRate6 = "ITEMRATE6";

            /// <summary>
            ///     Property for ItemRate7
            /// </summary>
            public const string ItemRate7 = "ITEMRATE7";

            /// <summary>
            ///     Property for ItemRate8
            /// </summary>
            public const string ItemRate8 = "ITEMRATE8";

            /// <summary>
            ///     Property for ItemRate9
            /// </summary>
            public const string ItemRate9 = "ITEMRATE9";

            /// <summary>
            ///     Property for ItemRate10
            /// </summary>
            public const string ItemRate10 = "ITEMRATE10";

            /// <summary>
            ///     Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "LASTMAINT";

            #endregion
        }


        /// <summary>
        ///     Contains list of TaxRates Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            ///     Property Indexer for TaxAuthority
            /// </summary>
            public const int TaxAuthority = 1;

            /// <summary>
            ///     Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 2;

            /// <summary>
            ///     Property Indexer for BuyerClass
            /// </summary>
            public const int BuyerClass = 3;

            /// <summary>
            ///     Property Indexer for ItemRate1
            /// </summary>
            public const int ItemRate1 = 4;

            /// <summary>
            ///     Property Indexer for ItemRate2
            /// </summary>
            public const int ItemRate2 = 5;

            /// <summary>
            ///     Property Indexer for ItemRate3
            /// </summary>
            public const int ItemRate3 = 6;

            /// <summary>
            ///     Property Indexer for ItemRate4
            /// </summary>
            public const int ItemRate4 = 7;

            /// <summary>
            ///     Property Indexer for ItemRate5
            /// </summary>
            public const int ItemRate5 = 8;

            /// <summary>
            ///     Property Indexer for ItemRate6
            /// </summary>
            public const int ItemRate6 = 9;

            /// <summary>
            ///     Property Indexer for ItemRate7
            /// </summary>
            public const int ItemRate7 = 10;

            /// <summary>
            ///     Property Indexer for ItemRate8
            /// </summary>
            public const int ItemRate8 = 11;

            /// <summary>
            ///     Property Indexer for ItemRate9
            /// </summary>
            public const int ItemRate9 = 12;

            /// <summary>
            ///     Property Indexer for ItemRate10
            /// </summary>
            public const int ItemRate10 = 13;

            /// <summary>
            ///     Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 14;

            #endregion
        }
    }
}