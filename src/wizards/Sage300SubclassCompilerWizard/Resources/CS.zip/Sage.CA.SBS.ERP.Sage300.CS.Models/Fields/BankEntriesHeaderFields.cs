// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankEntriesHeader Constants 
    /// </summary>
    public partial class BankEntriesHeader
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "BK0450";

        /// <summary>
        /// Contains list of BankEntriesHeader Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for SequenceNumber 
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";
            /// <summary>
            /// Property for BankEntryNumber 
            /// </summary>
            public const string BankEntryNumber = "ENTRYNBR";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";
            /// <summary>
            /// Property for DateCreated 
            /// </summary>
            public const string DateCreated = "TRANSDATE";
            /// <summary>
            /// Property for BankEntryType 
            /// </summary>
            public const string BankEntryType = "TRANSTYPE";
            /// <summary>
            /// Property for EntryDescription 
            /// </summary>
            public const string EntryDescription = "REFERENCE";
            /// <summary>
            /// Property for EntryTotalWithoutTax 
            /// </summary>
            public const string EntryTotalWithoutTax = "TOTSRCEAMT";
            /// <summary>
            /// Property for FuncEntryTotalWithoutTax 
            /// </summary>
            public const string FuncEntryTotalWithoutTax = "TOTFUNCAMT";
            /// <summary>
            /// Property for EntryTotal 
            /// </summary>
            public const string EntryTotal = "TOTSRCEGRO";
            /// <summary>
            /// Property for FuncEntryTotal 
            /// </summary>
            public const string FuncEntryTotal = "TOTFUNCGRO";
            /// <summary>
            /// Property for ExchangeRateType 
            /// </summary>
            public const string ExchangeRateType = "RATETYPE";
            /// <summary>
            /// Property for BankEntryCurrency 
            /// </summary>
            public const string BankEntryCurrency = "SRCECURN";
            /// <summary>
            /// Property for ExchangeRateDate 
            /// </summary>
            public const string ExchangeRateDate = "RATEDATE";
            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "RATE";
            /// <summary>
            /// Property for RateSpread 
            /// </summary>
            public const string RateSpread = "RATESPREAD";
            /// <summary>
            /// Property for RateOperation 
            /// </summary>
            public const string RateOperation = "RATEOP";
            /// <summary>
            /// Property for BankEntryDate 
            /// </summary>
            public const string BankEntryDate = "POSTDATE";
            /// <summary>
            /// Property for BankEntryYear 
            /// </summary>
            public const string BankEntryYear = "POSTYEAR";
            /// <summary>
            /// Property for BankEntryPeriod 
            /// </summary>
            public const string BankEntryPeriod = "POSTPERIOD";
            /// <summary>
            /// Property for CompletedStatus 
            /// </summary>
            public const string CompletedStatus = "COMPLETED";
            /// <summary>
            /// Property for Comments 
            /// </summary>
            public const string Comments = "BIGCOMMENT";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "STATUS";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string TypeStatus = "STATUS";
            /// <summary>
            /// Property for ReconcilationDate 
            /// </summary>
            public const string ReconcilationDate = "RECDATE";
            /// <summary>
            /// Property for ReconcilationYear 
            /// </summary>
            public const string ReconcilationYear = "RECYEAR";
            /// <summary>
            /// Property for ReconcilationPeriod 
            /// </summary>
            public const string ReconcilationPeriod = "RECPERIOD";
            /// <summary>
            /// Property for NumberofLines 
            /// </summary>
            public const string NumberofLines = "LINES";
            /// <summary>
            /// Property for BankEntrySerialNumber 
            /// </summary>
            public const string BankEntrySerialNumber = "SERIAL";
            /// <summary>
            /// Property for RunId 
            /// </summary>
            public const string RunId = "RUNID";
            /// <summary>
            /// Property for PaymentType 
            /// </summary>
            public const string PaymentType = "TYPE";
            /// <summary>
            /// Property for OFXTransactionID 
            /// </summary>
            public const string OfxTransactionID = "OFXTID";
            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryType = "ENTRYTYPE";
            /// <summary>
            /// Property for DistributionSet 
            /// </summary>
            public const string DistributionSet = "DSETCODE";
            /// <summary>
            /// Property for PostingSequence 
            /// </summary>
            public const string PostingSequence = "PSTSEQ";
            /// <summary>
            /// Property for BankName 
            /// </summary>
            public const string BankName = "BANKD";
            /// <summary>
            /// Property for BankAccount 
            /// </summary>
            public const string BankAccount = "BKACCT";
            /// <summary>
            /// Property for BankStatementCurrency 
            /// </summary>
            public const string BankStatementCurrency = "BKSTMTCUR";
            /// <summary>
            /// Property for DistributionSetDesc 
            /// </summary>
            public const string DistributionSetDesc = "DSETCODED";
            /// <summary>
            /// Property for TotalStatementAmount 
            /// </summary>
            public const string TotalStatementAmount = "TOTSTMTAMT";
            /// <summary>
            /// Property for FiscalEntryAmount 
            /// </summary>
            public const string FiscalEntryAmount = "RECPENT";
            /// <summary>
            /// Property for ReconciledEntryAmount 
            /// </summary>
            public const string ReconciledEntryAmount = "RECPENTREC";
            /// <summary>
            /// Property for DefaultNewDocumentNumber 
            /// </summary>
            public const string DefaultNewDocumentNumber = "DEFENTNUM";
            /// <summary>
            /// Property for ProcessCommand 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";
            /// <summary>
            /// Property for AgingRecondays 
            /// </summary>
            public const string AgingRecondays = "AGERECLD";
            /// <summary>
            /// Property for KeepInputEntryNo 
            /// </summary>
            public const string KeepInputEntryNo = "RETENTNO";
            /// <summary>
            /// Property for BankEntryCurrencyDesc 
            /// </summary>
            public const string BankEntryCurrencyDesc = "SRCECURND";
            /// <summary>
            /// Property for DefaultBankCode 
            /// </summary>
            public const string DefaultBankCode = "DEFBANK";
            /// <summary>
            /// Property for ErrorinAutoBank 
            /// </summary>
            public const string ErrorinAutoBank = "VDEFBANK";

            #endregion
        }


        /// <summary>
        /// Contains list of BankEntriesHeader Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for SequenceNumber 
            /// </summary>
            public const int SequenceNumber = 1;
            /// <summary>
            /// Property Indexer for BankEntryNumber 
            /// </summary>
            public const int BankEntryNumber = 2;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 3;
            /// <summary>
            /// Property Indexer for DateCreated 
            /// </summary>
            public const int DateCreated = 4;
            /// <summary>
            /// Property Indexer for BankEntryType 
            /// </summary>
            public const int BankEntryType = 5;
            /// <summary>
            /// Property Indexer for EntryDescription 
            /// </summary>
            public const int EntryDescription = 6;
            /// <summary>
            /// Property Indexer for EntryTotalWithoutTax 
            /// </summary>
            public const int EntryTotalWithoutTax = 8;
            /// <summary>
            /// Property Indexer for FuncEntryTotalWithoutTax 
            /// </summary>
            public const int FuncEntryTotalWithoutTax = 9;
            /// <summary>
            /// Property Indexer for EntryTotal 
            /// </summary>
            public const int EntryTotal = 10;
            /// <summary>
            /// Property Indexer for FuncEntryTotal 
            /// </summary>
            public const int FuncEntryTotal = 11;
            /// <summary>
            /// Property Indexer for ExchangeRateType 
            /// </summary>
            public const int ExchangeRateType = 12;
            /// <summary>
            /// Property Indexer for BankEntryCurrency 
            /// </summary>
            public const int BankEntryCurrency = 13;
            /// <summary>
            /// Property Indexer for ExchangeRateDate 
            /// </summary>
            public const int ExchangeRateDate = 14;
            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 15;
            /// <summary>
            /// Property Indexer for RateSpread 
            /// </summary>
            public const int RateSpread = 16;
            /// <summary>
            /// Property Indexer for RateOperation 
            /// </summary>
            public const int RateOperation = 17;
            /// <summary>
            /// Property Indexer for BankEntryDate 
            /// </summary>
            public const int BankEntryDate = 18;
            /// <summary>
            /// Property Indexer for BankEntryYear 
            /// </summary>
            public const int BankEntryYear = 19;
            /// <summary>
            /// Property Indexer for BankEntryPeriod 
            /// </summary>
            public const int BankEntryPeriod = 20;
            /// <summary>
            /// Property Indexer for CompletedStatus 
            /// </summary>
            public const int CompletedStatus = 21;
            /// <summary>
            /// Property Indexer for Comments 
            /// </summary>
            public const int Comments = 22;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 23;
            /// <summary>
            /// Property Indexer for ReconcilationDate 
            /// </summary>
            public const int ReconcilationDate = 24;
            /// <summary>
            /// Property Indexer for ReconcilationYear 
            /// </summary>
            public const int ReconcilationYear = 25;
            /// <summary>
            /// Property Indexer for ReconcilationPeriod 
            /// </summary>
            public const int ReconcilationPeriod = 26;
            /// <summary>
            /// Property Indexer for NumberofLines 
            /// </summary>
            public const int NumberofLines = 27;
            /// <summary>
            /// Property Indexer for BankEntrySerialNumber 
            /// </summary>
            public const int BankEntrySerialNumber = 28;
            /// <summary>
            /// Property Indexer for RunId 
            /// </summary>
            public const int RunId = 29;
            /// <summary>
            /// Property Indexer for PaymentType 
            /// </summary>
            public const int PaymentType = 30;
            /// <summary>
            /// Property Indexer for OFXTransactionID 
            /// </summary>
            public const int OfxTransactionID = 36;
            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryType = 37;
            /// <summary>
            /// Property Indexer for DistributionSet 
            /// </summary>
            public const int DistributionSet = 38;
            /// <summary>
            /// Property Indexer for PostingSequence 
            /// </summary>
            public const int PostingSequence = 39;
            /// <summary>
            /// Property Indexer for BankName 
            /// </summary>
            public const int BankName = 50;
            /// <summary>
            /// Property Indexer for BankAccount 
            /// </summary>
            public const int BankAccount = 51;
            /// <summary>
            /// Property Indexer for BankStatementCurrency 
            /// </summary>
            public const int BankStatementCurrency = 52;
            /// <summary>
            /// Property Indexer for DistributionSetDesc 
            /// </summary>
            public const int DistributionSetDesc = 53;
            /// <summary>
            /// Property Indexer for TotalStatementAmount 
            /// </summary>
            public const int TotalStatementAmount = 54;
            /// <summary>
            /// Property Indexer for FiscalEntryAmount 
            /// </summary>
            public const int FiscalEntryAmount = 55;
            /// <summary>
            /// Property Indexer for ReconciledEntryAmount 
            /// </summary>
            public const int ReconciledEntryAmount = 56;
            /// <summary>
            /// Property Indexer for DefaultNewDocumentNumber 
            /// </summary>
            public const int DefaultNewDocumentNumber = 57;
            /// <summary>
            /// Property Indexer for ProcessCommand 
            /// </summary>
            public const int ProcessCommand = 58;
            /// <summary>
            /// Property Indexer for AgingRecondays 
            /// </summary>
            public const int AgingRecondays = 59;
            /// <summary>
            /// Property Indexer for KeepInputEntryNo 
            /// </summary>
            public const int KeepInputEntryNo = 62;
            /// <summary>
            /// Property Indexer for BankEntryCurrencyDesc 
            /// </summary>
            public const int BankEntryCurrencyDesc = 63;
            /// <summary>
            /// Property Indexer for DefaultBankCode 
            /// </summary>
            public const int DefaultBankCode = 64;
            /// <summary>
            /// Property Indexer for ErrorinAutoBank 
            /// </summary>
            public const int ErrorinAutoBank = 65;

            #endregion
        }


    }
}
