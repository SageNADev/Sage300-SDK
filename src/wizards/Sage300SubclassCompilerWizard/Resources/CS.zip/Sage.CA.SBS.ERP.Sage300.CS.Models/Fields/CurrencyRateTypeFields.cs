// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CurrencyRateType Constants 
    /// </summary>
    public partial class CurrencyRateType
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0004";

        /// <summary>
        /// Contains list of CurrencyRateType Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "RATEDESC";

            #endregion
        }

        /// <summary>
        /// Contains list of CurrencyRateType Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            #endregion
        }
    }
}