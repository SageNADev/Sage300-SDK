/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of TaxAuthorities Constants 
    /// </summary>
	public partial class TaxAuthority 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "TX0002";

        /// <summary>
        /// Contains list of TaxAuthorities Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for TaxAuthority 
        /// </summary>
	    public const string TaxAuthorityCode  = "AUTHORITY";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "DESC";
	            /// <summary>
        /// Property for TaxReportingCurrency 
        /// </summary>
	    public const string TaxReportingCurrency  = "SCURN";
	            /// <summary>
        /// Property for MaximumTaxAllowable 
        /// </summary>
	    public const string MaximumTaxAllowable  = "MAXTAX";
	            /// <summary>
        /// Property for NoTaxChargedBelow 
        /// </summary>
	    public const string NoTaxChargedBelow  = "MINTAX";
	            /// <summary>
        /// Property for TaxBase 
        /// </summary>
	    public const string TaxBase  = "TXBASE";
	            /// <summary>
        /// Property for AllowTaxInPrice 
        /// </summary>
	    public const string AllowTaxInPrice  = "INCLUDABLE";
	            /// <summary>
        /// Property for TaxLiabilityAccount 
        /// </summary>
	    public const string TaxLiabilityAccount  = "LIABILITY";
	            /// <summary>
        /// Property for ReportLevel 
        /// </summary>
	    public const string ReportLevel  = "AUDITLEVEL";
	            /// <summary>
        /// Property for TaxRecoverable 
        /// </summary>
	    public const string TaxRecoverable  = "RECOVERABL";
	            /// <summary>
        /// Property for RecoverableRate 
        /// </summary>
	    public const string RecoverableRate  = "RATERECOV";
	            /// <summary>
        /// Property for RecoverableTaxAccount 
        /// </summary>
	    public const string RecoverableTaxAccount  = "ACCTRECOV";
	            /// <summary>
        /// Property for ExpenseSeparately 
        /// </summary>
	    public const string ExpenseSeparately  = "EXPSEPARTE";
	            /// <summary>
        /// Property for ExpenseAccount 
        /// </summary>
	    public const string ExpenseAccount  = "ACCTEXP";
	            /// <summary>
        /// Property for LastMaintained 
        /// </summary>
	    public const string LastMaintained  = "LASTMAINT";
	            /// <summary>
        /// Property for TaxType 
        /// </summary>
	    public const string TaxType  = "TAXTYPE";
	            /// <summary>
        /// Property for ReportTaxonRetainageDocument 
        /// </summary>
	    public const string ReportTaxonRetainageDocument  = "TXRTGCTL";
        
        /// <summary>
        /// Property for Reference Number
        /// </summary>
        public const string RefNumber = "REFNUMBER";

        /// <summary>
        /// Property for Reference Name
        /// </summary>
        public const string RefName = "REFNAME";

        /// <summary>
        /// Property for ACCTWHT Name
        /// </summary>
        public const string AccountWithHolding = "ACCTWHT";

        /// <summary>
        /// Property for INPUTACCT Name
        /// </summary>
        public const string InputTaxAccount = "INPUTACCT";

        /// <summary>
        /// Property for OUTPUTACCT Name
        /// </summary>
        public const string OutputTaxAccount = "OUTPUTACCT";


	     
        #endregion
	    }


		/// <summary>
        /// Contains list of TaxAuthorities Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for TaxAuthority 
        /// </summary>
	    public const int TaxAuthorityCode  = 1;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 2;
	             /// <summary>
        /// Property Indexer for TaxReportingCurrency 
        /// </summary>
	    public const int TaxReportingCurrency  = 3;
	             /// <summary>
        /// Property Indexer for MaximumTaxAllowable 
        /// </summary>
	    public const int MaximumTaxAllowable  = 4;
	             /// <summary>
        /// Property Indexer for NoTaxChargedBelow 
        /// </summary>
	    public const int NoTaxChargedBelow  = 5;
	             /// <summary>
        /// Property Indexer for TaxBase 
        /// </summary>
	    public const int TaxBase  = 6;
	             /// <summary>
        /// Property Indexer for AllowTaxInPrice 
        /// </summary>
	    public const int AllowTaxInPrice  = 7;
	             /// <summary>
        /// Property Indexer for TaxLiabilityAccount 
        /// </summary>
	    public const int TaxLiabilityAccount  = 9;
	             /// <summary>
        /// Property Indexer for ReportLevel 
        /// </summary>
	    public const int ReportLevel  = 13;
	             /// <summary>
        /// Property Indexer for TaxRecoverable 
        /// </summary>
	    public const int TaxRecoverable  = 14;
	             /// <summary>
        /// Property Indexer for RecoverableRate 
        /// </summary>
	    public const int RecoverableRate  = 15;
	             /// <summary>
        /// Property Indexer for RecoverableTaxAccount 
        /// </summary>
	    public const int RecoverableTaxAccount  = 16;
	             /// <summary>
        /// Property Indexer for ExpenseSeparately 
        /// </summary>
	    public const int ExpenseSeparately  = 17;
	             /// <summary>
        /// Property Indexer for ExpenseAccount 
        /// </summary>
	    public const int ExpenseAccount  = 18;
	             /// <summary>
        /// Property Indexer for LastMaintained 
        /// </summary>
	    public const int LastMaintained  = 19;
	             /// <summary>
        /// Property Indexer for TaxType 
        /// </summary>
	    public const int TaxType  = 20;
	             /// <summary>
        /// Property Indexer for ReportTaxonRetainageDocument 
        /// </summary>
	    public const int ReportTaxonRetainageDocument  = 21;

            /// <summary>
            /// Property Index for Reference Number
            /// </summary>
            public const int RefNumber = 22;

            /// <summary>
            /// Property Index for Reference Name
            /// </summary>
            public const int RefName = 23;
            /// <summary>
            /// Property Indexer for ACCTWHT Name
            /// </summary>
            public const int AccountWithHolding = 24;

            /// <summary>
            /// Property Indexer for INPUTACCT Name
            /// </summary>
            public const int InputTaxAccount = 25;

            /// <summary>
            /// Property Indexer forOUTPUTACCT Name
            /// </summary>
            public const int OutputTaxAccount = 26;
	     
        #endregion
	    }

	
	}
}
	