//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankTransactionHeader Constants 
    /// </summary>
    public partial class BankTransactionHeader
    {
        /// <summary>
        /// Bank Transaction Header
        /// </summary>
        public const string EntityName = "BK0845";

        /// <summary>
        /// Contains list of BankTransactionHeader Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";
            /// <summary>
            /// Property for TransactionHeaderSerial 
            /// </summary>
            public const string TransactionHeaderSerial = "SERIAL";
            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";
            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRANSTYPE";
            /// <summary>
            /// Property for OldSerialNumber 
            /// </summary>
            public const string OldSerialNumber = "OLDSERIAL";
            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryType = "ENTRYTYPE";
            /// <summary>
            /// Property for TransactionReference 
            /// </summary>
            public const string TransactionReference = "REFERENCE";
            /// <summary>
            /// Property for TransactionDescription 
            /// </summary>
            public const string TransactionDescription = "DESC";
            /// <summary>
            /// Property for TransactionDate 
            /// </summary>
            public const string TransactionDate = "TRANSDATE";
            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";
            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCPERIOD";
            /// <summary>
            /// Property for TransactionSlipPrinted 
            /// </summary>
            public const string TransactionSlipPrinted = "PRINTED";
            /// <summary>
            /// Property for TransactionTotal 
            /// </summary>
            public const string TransactionTotal = "TOTAMOUNT";
            /// <summary>
            /// Property for TransactionTotalinStatement 
            /// </summary>
            public const string TransactionTotalinStatement = "TOTBALAMT";
            /// <summary>
            /// Property for FiscalTransactionTotal 
            /// </summary>
            public const string FiscalTransactionTotal = "TOTCLEARED";
            /// <summary>
            /// Property for NextTransactionDetailLine 
            /// </summary>
            public const string NextTransactionDetailLine = "NXTLINE";
            /// <summary>
            /// Property for Lines 
            /// </summary>
            public const string Lines = "LINES";
            /// <summary>
            /// Property for LinesOutstanding 
            /// </summary>
            public const string LinesOutstanding = "LINESPOST";
            /// <summary>
            /// Property for LinesReconciled 
            /// </summary>
            public const string LinesReconciled = "LINESREC";
            /// <summary>
            /// Property for TransactionStatus 
            /// </summary>
            public const string TransactionStatus = "STATUS";
            /// <summary>
            /// Property for ReconciliationError 
            /// </summary>
            public const string ReconciliationError = "RECERR";
            /// <summary>
            /// Property for ReconciliationErrorPending 
            /// </summary>
            public const string ReconciliationErrorPending = "RECERRPEND";
            /// <summary>
            /// Property for ReconciliationExchangeGain 
            /// </summary>
            public const string ReconciliationExchangeGain = "RECEXGAIN";
            /// <summary>
            /// Property for ReconciliationExchangeLoss 
            /// </summary>
            public const string ReconciliationExchangeLoss = "RECEXLOSS";
            /// <summary>
            /// Property for ReconciliationAmount 
            /// </summary>
            public const string ReconciliationAmount = "RECAMOUNT";
            /// <summary>
            /// Property for ReconciliationOutstandingAmt 
            /// </summary>
            public const string ReconciliationOutstandingAmt = "RECOUTSTND";
            /// <summary>
            /// Property for TransactionRecordedinSummary 
            /// </summary>
            public const string TransactionRecordedinSummary = "SUMMARY";
            /// <summary>
            /// Property for ReconciliationCreditCardCharg 
            /// </summary>
            public const string ReconciliationCreditCardCharg = "RECCCC";
            /// <summary>
            /// Property for AmountCleared 
            /// </summary>
            public const string AmountCleared = "RECCLEARED";
            /// <summary>
            /// Property for FunctionalTransactionAmount 
            /// </summary>
            public const string FunctionalTransactionAmount = "RECFUNCAMT";
            /// <summary>
            /// Property for FunctionalTransactionTotal 
            /// </summary>
            public const string FunctionalTransactionTotal = "TOTFUNCAMT";
            /// <summary>
            /// Property for ReconciliationClearedAmount 
            /// </summary>
            public const string ReconciliationClearedAmount = "TOCLEAR";
            /// <summary>
            /// Property for WriteOffAmount 
            /// </summary>
            public const string WriteOffAmount = "TOWRITEOFF";
            /// <summary>
            /// Property for OutstandingAmount 
            /// </summary>
            public const string OutstandingAmount = "TOREMAIN";
            /// <summary>
            /// Property for VarianceType 
            /// </summary>
            public const string VarianceType = "VARIANCE";
            /// <summary>
            /// Property for LinesCanReverseInvoice 
            /// </summary>
            public const string LinesCanReverseInvoice = "LINESREVIN";
            /// <summary>
            /// Property for ReconciliationDate 
            /// </summary>
            public const string ReconciliationDate = "POSTDATE";
            /// <summary>
            /// Property for ReconciliationStatus 
            /// </summary>
            public const string ReconciliationStatus = "RECSTATUS";
            /// <summary>
            /// Property for ReconciliationDescription 
            /// </summary>
            public const string ReconciliationDescription = "RECCOMMENT";
            /// <summary>
            /// Property for LinesJournalled 
            /// </summary>
            public const string LinesJournalled = "LINESJOUR";
            /// <summary>
            /// Property for LinesPurged 
            /// </summary>
            public const string LinesPurged = "LINESPUR";
            /// <summary>
            /// Property for LinesProcessed 
            /// </summary>
            public const string LinesProcessed = "LINESPROC";
            /// <summary>
            /// Property for ClearToFuturePeriod 
            /// </summary>
            public const string ClearToFuturePeriod = "TOCLEARF";
            /// <summary>
            /// Property for FiscalClearedToFuture 
            /// </summary>
            public const string FiscalClearedToFuture = "RECFCLR";
            /// <summary>
            /// Property for FiscalClearedToCurrent 
            /// </summary>
            public const string FiscalClearedToCurrent = "RECRCLR";
            /// <summary>
            /// Property for ReconciledandJournaledTransac 
            /// </summary>
            public const string ReconciledandJournaledTransac = "COMPLETED";
            /// <summary>
            /// Property for PaymentPayeeName 
            /// </summary>
            public const string PaymentPayeeName = "PAYORNAME";
            /// <summary>
            /// Property for PaymentVendorName 
            /// </summary>
            public const string PaymentVendorName = "VENDORNAME";
            /// <summary>
            /// Property for BankEntryOrTransferNumber 
            /// </summary>
            public const string BankEntryOrTransferNumber = "ENTRYNBR";
            /// <summary>
            /// Property for LinesCreditCard 
            /// </summary>
            public const string LinesCreditCard = "LINESCCC";
            /// <summary>
            /// Property for LinesExchangeDifference 
            /// </summary>
            public const string LinesExchangeDifference = "LINESEXCH";
            /// <summary>
            /// Property for ReverseInvoice 
            /// </summary>
            public const string ReverseInvoice = "REVINVC";
            /// <summary>
            /// Property for ReconcilebyDetailReconciled 
            /// </summary>
            public const string ReconcilebyDetailReconciled = "AMTDTLREC";
            /// <summary>
            /// Property for ReconcilebyDetailOutstanding 
            /// </summary>
            public const string ReconcilebyDetailOutstanding = "AMTDTLOUT";
            /// <summary>
            /// Property for CurrentPeriodsWriteOff 
            /// </summary>
            public const string CurrentPeriodsWriteOff = "RECWOSUMR";

            //TODO: The naming convention of this property has to be relooked
            /// <summary>
            /// Property for TOCLEARR 
            /// </summary>
            public const string TOCLEARR = "TOCLEARR";
            /// <summary>
            /// Property for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const string FiscalWriteOffToThisPeriod = "RECRWOSUM";
            /// <summary>
            /// Property for FiscalRemainingOutstanding 
            /// </summary>
            public const string FiscalRemainingOutstanding = "RECPREM";
            /// <summary>
            /// Property for TotalDeltaWriteOffs 
            /// </summary>
            public const string TotalDeltaWriteOffs = "RECTWO";
            /// <summary>
            /// Property for TotalDeltaBankErrors 
            /// </summary>
            public const string TotalDeltaBankErrors = "RECTERR";
            /// <summary>
            /// Property for TotalDeltaExchangeGain 
            /// </summary>
            public const string TotalDeltaExchangeGain = "RECTGAIN";
            /// <summary>
            /// Property for TotalDeltaExchangeLoss 
            /// </summary>
            public const string TotalDeltaExchangeLoss = "RECTLOSS";
            /// <summary>
            /// Property for TotalDeltaCreditCardCharge 
            /// </summary>
            public const string TotalDeltaCreditCardCharge = "RECTCCC";
            /// <summary>
            /// Property for TotalDeltaCleared 
            /// </summary>
            public const string TotalDeltaCleared = "RECTCLR";
            /// <summary>
            /// Property for TotalDeltaFunctionalAmount 
            /// </summary>
            public const string TotalDeltaFunctionalAmount = "RECTFUNAM";
            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "CURFUNC";
            /// <summary>
            /// Property for StatementCurrency 
            /// </summary>
            public const string StatementCurrency = "CURSTMT";
            /// <summary>
            /// Property for ReconciliationWriteOffSum 
            /// </summary>
            public const string ReconciliationWriteOffSum = "RECWOSUM";
            /// <summary>
            /// Property for ReconciliationpostingYear 
            /// </summary>
            public const string ReconciliationpostingYear = "POSTYEAR";
            /// <summary>
            /// Property for ReconciliationpostingPeriod 
            /// </summary>
            public const string ReconciliationpostingPeriod = "POSTPERIOD";
            /// <summary>
            /// Property for TotalDeposits 
            /// </summary>
            public const string TotalDeposits = "SUMDEPOSIT";
            /// <summary>
            /// Property for DepositsinTransit 
            /// </summary>
            public const string DepositsinTransit = "RECINTRANS";
            /// <summary>
            /// Property for DepositFunctionalTotal 
            /// </summary>
            public const string DepositFunctionalTotal = "FUNDTAMT";
            /// <summary>
            /// Property for SumofDepositTotalWriteOffs 
            /// </summary>
            public const string SumofDepositTotalWriteOffs = "RECDTWOSUM";
            /// <summary>
            /// Property for TotalDepositBankErrors 
            /// </summary>
            public const string TotalDepositBankErrors = "RECDTERR";
            /// <summary>
            /// Property for TotalDepositExchangeGain 
            /// </summary>
            public const string TotalDepositExchangeGain = "RECDTGAIN";
            /// <summary>
            /// Property for TotalDepositExchangeLoss 
            /// </summary>
            public const string TotalDepositExchangeLoss = "RECDTLOSS";
            /// <summary>
            /// Property for TotalDepositCreditCardCharge 
            /// </summary>
            public const string TotalDepositCreditCardCharge = "RECDTCCC";
            /// <summary>
            /// Property for TotalDepositCleared 
            /// </summary>
            public const string TotalDepositCleared = "RECDTCLR";
            /// <summary>
            /// Property for FiscalDepositWriteOffToThis 
            /// </summary>
            public const string FiscalDepositWriteOffToThis = "RECDPWOSUM";
            /// <summary>
            /// Property for FiscalDepositBankErrors 
            /// </summary>
            public const string FiscalDepositBankErrors = "RECDPERR";
            /// <summary>
            /// Property for FiscalDepositExchangeGain 
            /// </summary>
            public const string FiscalDepositExchangeGain = "RECDPGAIN";
            /// <summary>
            /// Property for FiscalDepositExchangeLoss 
            /// </summary>
            public const string FiscalDepositExchangeLoss = "RECDPLOSS";
            /// <summary>
            /// Property for FiscalDepositCreditCardCharg 
            /// </summary>
            public const string FiscalDepositCreditCardCharg = "RECDPCCC";
            /// <summary>
            /// Property for FiscalDepositCleared 
            /// </summary>
            public const string FiscalDepositCleared = "RECDPCLR";
            /// <summary>
            /// Property for DepositClearedwithExchangeRa 
            /// </summary>
            public const string DepositClearedwithExchangeRa = "RECDEXDIFF";
            /// <summary>
            /// Property for DepositsInTransitToFiscPer 
            /// </summary>
            public const string DepositsInTransitToFiscPer = "RECFCDEPIT";
            /// <summary>
            /// Property for FiscalDepositClearedToFuture 
            /// </summary>
            public const string FiscalDepositClearedToFuture = "RECDFCLR";
            /// <summary>
            /// Property for TotalChecks 
            /// </summary>
            public const string TotalChecks = "SUMCHECK";
            /// <summary>
            /// Property for ChecksOutstanding 
            /// </summary>
            public const string ChecksOutstanding = "RECWOUTSTD";
            /// <summary>
            /// Property for WithdrawalFunctionalTotal 
            /// </summary>
            public const string WithdrawalFunctionalTotal = "FUNWTAMT";
            /// <summary>
            /// Property for SumofWithdrawalTotalWriteOf 
            /// </summary>
            public const string SumofWithdrawalTotalWriteOf = "RECWTWOSUM";
            /// <summary>
            /// Property for TotalWithdrawalBankErrors 
            /// </summary>
            public const string TotalWithdrawalBankErrors = "RECWTERR";
            /// <summary>
            /// Property for TotalWithdrawalExchangeGain 
            /// </summary>
            public const string TotalWithdrawalExchangeGain = "RECWTGAIN";
            /// <summary>
            /// Property for TotalWithdrawalExchangeLoss 
            /// </summary>
            public const string TotalWithdrawalExchangeLoss = "RECWTLOSS";
            /// <summary>
            /// Property for TotalWithdrawalCreditCardCha 
            /// </summary>
            public const string TotalWithdrawalCreditCardCha = "RECWTCCC";
            /// <summary>
            /// Property for TotalWithdrawalCleared 
            /// </summary>
            public const string TotalWithdrawalCleared = "RECWTCLR";
            /// <summary>
            /// Property for FiscalWithdrawalWriteOffToT 
            /// </summary>
            public const string FiscalWithdrawalWriteOffToT = "RECWPWOSUM";
            /// <summary>
            /// Property for FiscalWithdrawalBankErrors 
            /// </summary>
            public const string FiscalWithdrawalBankErrors = "RECWPERR";
            /// <summary>
            /// Property for FiscalWithdrawalExchangeGain 
            /// </summary>
            public const string FiscalWithdrawalExchangeGain = "RECWPGAIN";
            /// <summary>
            /// Property for FiscalWithdrawalExchangeLoss 
            /// </summary>
            public const string FiscalWithdrawalExchangeLoss = "RECWPLOSS";
            /// <summary>
            /// Property for FiscalWithdrawalCreditCardCh 
            /// </summary>
            public const string FiscalWithdrawalCreditCardCh = "RECWPCCC";

            //TODO: The naming convention of this property has to be relooked
            /// <summary>
            /// Property for RECWPCLR 
            /// </summary>
            public const string RECWPCLR = "RECWPCLR";
            /// <summary>
            /// Property for ChecksClearedwithExchRateD 
            /// </summary>
            public const string ChecksClearedwithExchRateD = "RECWEXDIFF";
            /// <summary>
            /// Property for ChecksOutstandingToFiscPer 
            /// </summary>
            public const string ChecksOutstandingToFiscPer = "RECFCCHKOS";
            /// <summary>
            /// Property for FiscalWithdrawalClearedToFut 
            /// </summary>
            public const string FiscalWithdrawalClearedToFut = "RECWFCLR";
            /// <summary>
            /// Property for FiscalMiscellaneousEntry 
            /// </summary>
            public const string FiscalMiscellaneousEntry = "RECFCMISC";
            /// <summary>
            /// Property for PaymentMiscEntriesToFiscal 
            /// </summary>
            public const string PaymentMiscEntriesToFiscal = "RECFCWMISC";
            /// <summary>
            /// Property for DepositMiscEntriesToFiscal 
            /// </summary>
            public const string DepositMiscEntriesToFiscal = "RECFCDMISC";
            /// <summary>
            /// Property for PaymentMiscEntriesToFuture 
            /// </summary>
            public const string PaymentMiscEntriesToFuture = "RECFWMISC";
            /// <summary>
            /// Property for DepositMiscEntriesToFuture 
            /// </summary>
            public const string DepositMiscEntriesToFuture = "RECFDMISC";
            /// <summary>
            /// Property for FiscalDepositBookAmount 
            /// </summary>
            public const string FiscalDepositBookAmount = "RECPDEPB";
            /// <summary>
            /// Property for FiscalWithdrawalBookAmount 
            /// </summary>
            public const string FiscalWithdrawalBookAmount = "RECPCHKB";
            /// <summary>
            /// Property for DetailAccessPortal 
            /// </summary>
            public const string DetailAccessPortal = "DTLACCESS";
            /// <summary>
            /// Property for ReconciliationDelta 
            /// </summary>
            public const string ReconciliationDelta = "RECDELTA";
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";
            /// <summary>
            /// Property for TransactionSlipPrinted 
            /// </summary>
            public const string TransactionSlipPrintedString = "PRINTED";
            /// <summary>
            /// Property for TransactionStatus 
            /// </summary>
            public const string TransactionStatusString = "STATUS";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionTypeString = "TRANSTYPE";
            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryTypeString = "ENTRYTYPE";
            /// <summary>
            /// Property for TransactionRecordedinSummary 
            /// </summary>
            public const string TransactionRecordedinSummaryString = "SUMMARY";
            /// <summary>
            /// Property for VarianceType 
            /// </summary>
            public const string VarianceTypeString = "VARIANCE";
            /// <summary>
            /// Property for ReconciliationStatus 
            /// </summary>
            public const string ReconciliationStatusString = "RECSTATUS";
            /// <summary>
            /// Property for ReconciledandJournaledTransac 
            /// </summary>
            public const string ReconciledandJournaledTransacString = "COMPLETED";
            /// <summary>
            /// Property for ReverseInvoice 
            /// </summary>
            public const string ReverseInvoiceString = "REVINVC";
            /// <summary>
            /// Property for DetailAccessPortal 
            /// </summary>
            public const string DetailAccessPortalString = "DTLACCESS";
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCodeString = "PROCESSCMD";

            #endregion
        }

        /// <summary>
        /// Contains list of BankTransactionHeader Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;
            /// <summary>
            /// Property Indexer for TransactionHeaderSerial 
            /// </summary>
            public const int TransactionHeaderSerial = 2;
            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 3;
            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 4;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 5;
            /// <summary>
            /// Property Indexer for OldSerialNumber 
            /// </summary>
            public const int OldSerialNumber = 6;
            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryType = 7;
            /// <summary>
            /// Property Indexer for TransactionReference 
            /// </summary>
            public const int TransactionReference = 8;
            /// <summary>
            /// Property Indexer for TransactionDescription 
            /// </summary>
            public const int TransactionDescription = 9;
            /// <summary>
            /// Property Indexer for TransactionDate 
            /// </summary>
            public const int TransactionDate = 10;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 11;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 12;
            /// <summary>
            /// Property Indexer for TransactionSlipPrinted 
            /// </summary>
            public const int TransactionSlipPrinted = 13;
            /// <summary>
            /// Property Indexer for TransactionTotal 
            /// </summary>
            public const int TransactionTotal = 14;
            /// <summary>
            /// Property Indexer for TransactionTotalinStatement 
            /// </summary>
            public const int TransactionTotalinStatement = 15;
            /// <summary>
            /// Property Indexer for FiscalTransactionTotal 
            /// </summary>
            public const int FiscalTransactionTotal = 16;
            /// <summary>
            /// Property Indexer for NextTransactionDetailLine 
            /// </summary>
            public const int NextTransactionDetailLine = 17;
            /// <summary>
            /// Property Indexer for Lines 
            /// </summary>
            public const int Lines = 18;
            /// <summary>
            /// Property Indexer for LinesOutstanding 
            /// </summary>
            public const int LinesOutstanding = 19;
            /// <summary>
            /// Property Indexer for LinesReconciled 
            /// </summary>
            public const int LinesReconciled = 20;
            /// <summary>
            /// Property Indexer for TransactionStatus 
            /// </summary>
            public const int TransactionStatus = 21;
            /// <summary>
            /// Property Indexer for ReconciliationError 
            /// </summary>
            public const int ReconciliationError = 22;
            /// <summary>
            /// Property Indexer for ReconciliationErrorPending 
            /// </summary>
            public const int ReconciliationErrorPending = 23;
            /// <summary>
            /// Property Indexer for ReconciliationExchangeGain 
            /// </summary>
            public const int ReconciliationExchangeGain = 24;
            /// <summary>
            /// Property Indexer for ReconciliationExchangeLoss 
            /// </summary>
            public const int ReconciliationExchangeLoss = 25;
            /// <summary>
            /// Property Indexer for ReconciliationAmount 
            /// </summary>
            public const int ReconciliationAmount = 26;
            /// <summary>
            /// Property Indexer for ReconciliationOutstandingAmt 
            /// </summary>
            public const int ReconciliationOutstandingAmt = 27;
            /// <summary>
            /// Property Indexer for TransactionRecordedinSummary 
            /// </summary>
            public const int TransactionRecordedinSummary = 28;
            /// <summary>
            /// Property Indexer for ReconciliationCreditCardCharg 
            /// </summary>
            public const int ReconciliationCreditCardCharg = 29;
            /// <summary>
            /// Property Indexer for AmountCleared 
            /// </summary>
            public const int AmountCleared = 30;
            /// <summary>
            /// Property Indexer for FunctionalTransactionAmount 
            /// </summary>
            public const int FunctionalTransactionAmount = 31;
            /// <summary>
            /// Property Indexer for FunctionalTransactionTotal 
            /// </summary>
            public const int FunctionalTransactionTotal = 32;
            /// <summary>
            /// Property Indexer for ReconciliationClearedAmount 
            /// </summary>
            public const int ReconciliationClearedAmount = 33;
            /// <summary>
            /// Property Indexer for WriteOffAmount 
            /// </summary>
            public const int WriteOffAmount = 34;
            /// <summary>
            /// Property Indexer for OutstandingAmount 
            /// </summary>
            public const int OutstandingAmount = 35;
            /// <summary>
            /// Property Indexer for VarianceType 
            /// </summary>
            public const int VarianceType = 36;
            /// <summary>
            /// Property Indexer for LinesCanReverseInvoice 
            /// </summary>
            public const int LinesCanReverseInvoice = 37;
            /// <summary>
            /// Property Indexer for ReconciliationDate 
            /// </summary>
            public const int ReconciliationDate = 38;
            /// <summary>
            /// Property Indexer for ReconciliationStatus 
            /// </summary>
            public const int ReconciliationStatus = 39;
            /// <summary>
            /// Property Indexer for ReconciliationDescription 
            /// </summary>
            public const int ReconciliationDescription = 40;
            /// <summary>
            /// Property Indexer for LinesJournalled 
            /// </summary>
            public const int LinesJournalled = 41;
            /// <summary>
            /// Property Indexer for LinesPurged 
            /// </summary>
            public const int LinesPurged = 42;
            /// <summary>
            /// Property Indexer for LinesProcessed 
            /// </summary>
            public const int LinesProcessed = 43;
            /// <summary>
            /// Property Indexer for ClearToFuturePeriod 
            /// </summary>
            public const int ClearToFuturePeriod = 44;
            /// <summary>
            /// Property Indexer for FiscalClearedToFuture 
            /// </summary>
            public const int FiscalClearedToFuture = 45;
            /// <summary>
            /// Property Indexer for FiscalClearedToCurrent 
            /// </summary>
            public const int FiscalClearedToCurrent = 46;
            /// <summary>
            /// Property Indexer for ReconciledandJournaledTransac 
            /// </summary>
            public const int ReconciledandJournaledTransac = 47;
            /// <summary>
            /// Property Indexer for PaymentPayeeName 
            /// </summary>
            public const int PaymentPayeeName = 48;
            /// <summary>
            /// Property Indexer for PaymentVendorName 
            /// </summary>
            public const int PaymentVendorName = 49;
            /// <summary>
            /// Property Indexer for BankEntryOrTransferNumber 
            /// </summary>
            public const int BankEntryOrTransferNumber = 50;
            /// <summary>
            /// Property Indexer for LinesCreditCard 
            /// </summary>
            public const int LinesCreditCard = 51;
            /// <summary>
            /// Property Indexer for LinesExchangeDifference 
            /// </summary>
            public const int LinesExchangeDifference = 52;
            /// <summary>
            /// Property Indexer for ReverseInvoice 
            /// </summary>
            public const int ReverseInvoice = 53;
            /// <summary>
            /// Property Indexer for ReconcilebyDetailReconciled 
            /// </summary>
            public const int ReconcilebyDetailReconciled = 54;
            /// <summary>
            /// Property Indexer for ReconcilebyDetailOutstanding 
            /// </summary>
            public const int ReconcilebyDetailOutstanding = 55;
            /// <summary>
            /// Property Indexer for CurrentPeriodsWriteOff 
            /// </summary>
            public const int CurrentPeriodsWriteOff = 114;

            // TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for TOCLEARR 
            /// </summary>
            public const int TOCLEARR = 115;

            /// <summary>
            /// Property Indexer for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const int FiscalWriteOffToThisPeriod = 116;

            /// <summary>
            /// Property Indexer for FiscalRemainingOutstanding 
            /// </summary>
            public const int FiscalRemainingOutstanding = 117;

            /// <summary>
            /// Property Indexer for TotalDeltaWriteOffs 
            /// </summary>
            public const int TotalDeltaWriteOffs = 118;

            /// <summary>
            /// Property Indexer for TotalDeltaBankErrors 
            /// </summary>
            public const int TotalDeltaBankErrors = 119;
            /// <summary>
            /// Property Indexer for TotalDeltaExchangeGain 
            /// </summary>
            public const int TotalDeltaExchangeGain = 120;
            /// <summary>
            /// Property Indexer for TotalDeltaExchangeLoss 
            /// </summary>
            public const int TotalDeltaExchangeLoss = 121;
            /// <summary>
            /// Property Indexer for TotalDeltaCreditCardCharge 
            /// </summary>
            public const int TotalDeltaCreditCardCharge = 122;
            /// <summary>
            /// Property Indexer for TotalDeltaCleared 
            /// </summary>
            public const int TotalDeltaCleared = 123;
            /// <summary>
            /// Property Indexer for TotalDeltaFunctionalAmount 
            /// </summary>
            public const int TotalDeltaFunctionalAmount = 124;
            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 125;
            /// <summary>
            /// Property Indexer for StatementCurrency 
            /// </summary>
            public const int StatementCurrency = 126;
            /// <summary>
            /// Property Indexer for ReconciliationWriteOffSum 
            /// </summary>
            public const int ReconciliationWriteOffSum = 127;
            /// <summary>
            /// Property Indexer for ReconciliationpostingYear 
            /// </summary>
            public const int ReconciliationpostingYear = 128;
            /// <summary>
            /// Property Indexer for ReconciliationpostingPeriod 
            /// </summary>
            public const int ReconciliationpostingPeriod = 129;
            /// <summary>
            /// Property Indexer for TotalDeposits 
            /// </summary>
            public const int TotalDeposits = 130;
            /// <summary>
            /// Property Indexer for DepositsinTransit 
            /// </summary>
            public const int DepositsinTransit = 131;
            /// <summary>
            /// Property Indexer for DepositFunctionalTotal 
            /// </summary>
            public const int DepositFunctionalTotal = 132;
            /// <summary>
            /// Property Indexer for SumofDepositTotalWriteOffs 
            /// </summary>
            public const int SumofDepositTotalWriteOffs = 133;
            /// <summary>
            /// Property Indexer for TotalDepositBankErrors 
            /// </summary>
            public const int TotalDepositBankErrors = 134;
            /// <summary>
            /// Property Indexer for TotalDepositExchangeGain 
            /// </summary>
            public const int TotalDepositExchangeGain = 135;
            /// <summary>
            /// Property Indexer for TotalDepositExchangeLoss 
            /// </summary>
            public const int TotalDepositExchangeLoss = 136;
            /// <summary>
            /// Property Indexer for TotalDepositCreditCardCharge 
            /// </summary>
            public const int TotalDepositCreditCardCharge = 137;
            /// <summary>
            /// Property Indexer for TotalDepositCleared 
            /// </summary>
            public const int TotalDepositCleared = 138;
            /// <summary>
            /// Property Indexer for FiscalDepositWriteOffToThis 
            /// </summary>
            public const int FiscalDepositWriteOffToThis = 139;
            /// <summary>
            /// Property Indexer for FiscalDepositBankErrors 
            /// </summary>
            public const int FiscalDepositBankErrors = 140;
            /// <summary>
            /// Property Indexer for FiscalDepositExchangeGain 
            /// </summary>
            public const int FiscalDepositExchangeGain = 141;
            /// <summary>
            /// Property Indexer for FiscalDepositExchangeLoss 
            /// </summary>
            public const int FiscalDepositExchangeLoss = 142;
            /// <summary>
            /// Property Indexer for FiscalDepositCreditCardCharg 
            /// </summary>
            public const int FiscalDepositCreditCardCharg = 143;
            /// <summary>
            /// Property Indexer for FiscalDepositCleared 
            /// </summary>
            public const int FiscalDepositCleared = 144;
            /// <summary>
            /// Property Indexer for DepositClearedwithExchangeRa 
            /// </summary>
            public const int DepositClearedwithExchangeRa = 145;
            /// <summary>
            /// Property Indexer for DepositsInTransitToFiscPer 
            /// </summary>
            public const int DepositsInTransitToFiscPer = 146;
            /// <summary>
            /// Property Indexer for FiscalDepositClearedToFuture 
            /// </summary>
            public const int FiscalDepositClearedToFuture = 147;
            /// <summary>
            /// Property Indexer for TotalChecks 
            /// </summary>
            public const int TotalChecks = 148;
            /// <summary>
            /// Property Indexer for ChecksOutstanding 
            /// </summary>
            public const int ChecksOutstanding = 149;
            /// <summary>
            /// Property Indexer for WithdrawalFunctionalTotal 
            /// </summary>
            public const int WithdrawalFunctionalTotal = 150;
            /// <summary>
            /// Property Indexer for SumofWithdrawalTotalWriteOf 
            /// </summary>
            public const int SumofWithdrawalTotalWriteOf = 151;
            /// <summary>
            /// Property Indexer for TotalWithdrawalBankErrors 
            /// </summary>
            public const int TotalWithdrawalBankErrors = 152;
            /// <summary>
            /// Property Indexer for TotalWithdrawalExchangeGain 
            /// </summary>
            public const int TotalWithdrawalExchangeGain = 153;
            /// <summary>
            /// Property Indexer for TotalWithdrawalExchangeLoss 
            /// </summary>
            public const int TotalWithdrawalExchangeLoss = 154;
            /// <summary>
            /// Property Indexer for TotalWithdrawalCreditCardCha 
            /// </summary>
            public const int TotalWithdrawalCreditCardCha = 155;
            /// <summary>
            /// Property Indexer for TotalWithdrawalCleared 
            /// </summary>
            public const int TotalWithdrawalCleared = 156;
            /// <summary>
            /// Property Indexer for FiscalWithdrawalWriteOffToT 
            /// </summary>
            public const int FiscalWithdrawalWriteOffToT = 157;
            /// <summary>
            /// Property Indexer for FiscalWithdrawalBankErrors 
            /// </summary>
            public const int FiscalWithdrawalBankErrors = 158;
            /// <summary>
            /// Property Indexer for FiscalWithdrawalExchangeGain 
            /// </summary>
            public const int FiscalWithdrawalExchangeGain = 159;
            /// <summary>
            /// Property Indexer for FiscalWithdrawalExchangeLoss 
            /// </summary>
            public const int FiscalWithdrawalExchangeLoss = 160;
            /// <summary>
            /// Property Indexer for FiscalWithdrawalCreditCardCh 
            /// </summary>
            public const int FiscalWithdrawalCreditCardCh = 161;

            //TODO: The naming convention of this property has to be relooked
            /// <summary>
            /// Property Indexer for RECWPCLR 
            /// </summary>
            public const int RECWPCLR = 162;
            /// <summary>
            /// Property Indexer for ChecksClearedwithExchRateD 
            /// </summary>
            public const int ChecksClearedwithExchRateD = 163;
            /// <summary>
            /// Property Indexer for ChecksOutstandingToFiscPer 
            /// </summary>
            public const int ChecksOutstandingToFiscPer = 164;
            /// <summary>
            /// Property Indexer for FiscalWithdrawalClearedToFut 
            /// </summary>
            public const int FiscalWithdrawalClearedToFut = 165;
            /// <summary>
            /// Property Indexer for FiscalMiscellaneousEntry 
            /// </summary>
            public const int FiscalMiscellaneousEntry = 166;
            /// <summary>
            /// Property Indexer for PaymentMiscEntriesToFiscal 
            /// </summary>
            public const int PaymentMiscEntriesToFiscal = 167;
            /// <summary>
            /// Property Indexer for DepositMiscEntriesToFiscal 
            /// </summary>
            public const int DepositMiscEntriesToFiscal = 168;
            /// <summary>
            /// Property Indexer for PaymentMiscEntriesToFuture 
            /// </summary>
            public const int PaymentMiscEntriesToFuture = 169;
            /// <summary>
            /// Property Indexer for DepositMiscEntriesToFuture 
            /// </summary>
            public const int DepositMiscEntriesToFuture = 170;
            /// <summary>
            /// Property Indexer for FiscalDepositBookAmount 
            /// </summary>
            public const int FiscalDepositBookAmount = 171;
            /// <summary>
            /// Property Indexer for FiscalWithdrawalBookAmount 
            /// </summary>
            public const int FiscalWithdrawalBookAmount = 172;
            /// <summary>
            /// Property Indexer for DetailAccessPortal 
            /// </summary>
            public const int DetailAccessPortal = 173;
            /// <summary>
            /// Property Indexer for ReconciliationDelta 
            /// </summary>
            public const int ReconciliationDelta = 174;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 175;
            /// <summary>
            /// Property Indexer for TransactionSlipPrinted 
            /// </summary>
            public const int TransactionSlipPrintedString = 13;
            /// <summary>
            /// Property Indexer for TransactionStatus 
            /// </summary>
            public const int TransactionStatusString = 21;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionTypeString = 5;
            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryTypeString = 7;
            /// <summary>
            /// Property Indexer for TransactionRecordedinSummary 
            /// </summary>
            public const int TransactionRecordedinSummaryString = 28;
            /// <summary>
            /// Property Indexer for VarianceType 
            /// </summary>
            public const int VarianceTypeString = 36;
            /// <summary>
            /// Property Indexer for ReconciliationStatus 
            /// </summary>
            public const int ReconciliationStatusString = 39;
            /// <summary>
            /// Property Indexer for ReconciledandJournaledTransac 
            /// </summary>
            public const int ReconciledandJournaledTransacString = 47;
            /// <summary>
            /// Property Indexer for ReverseInvoice 
            /// </summary>
            public const int ReverseInvoiceString = 53;
            /// <summary>
            /// Property Indexer for DetailAccessPortal 
            /// </summary>
            public const int DetailAccessPortalString = 173;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCodeString = 175;
            /// <summary>
            /// Property Indexer for ReconciledFlag
            /// </summary>
            public const int ReconciledFlag = 9999;

            #endregion
        }

        /// <summary>
        /// Contains list of BankTransactionHeader Keys Constants, used for order by
        /// </summary>
        public class Keys
        {
            #region Properties

            /// <summary>
            /// Property Indexer for TransactionDate 
            /// </summary>
            public const int TransactionDate = 3;

            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 5;

            #endregion
        }
    }
}
