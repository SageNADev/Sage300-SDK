/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */

// Portions co-modified with OpenAI Codex
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class EmailAudit
    {
        public const string EntityName = "CS0025";

        public class Fields
        {
            public const string EmailId = "EMAILID";
            public const string SourceApplication = "SRCEAPPL";
            public const string SourceType = "SRCETYPE";
            public const string SourceLabel = "SRCLABEL";
            public const string Subject = "SUBJECT";
            public const string ToEmail = "TOEMAIL";
            public const string CcEmail = "CCEMAIL";
            public const string BccEmail = "BCCEMAIL";
            public const string FromEmail = "FROMEMAIL";
            public const string CreatedBy = "CREATEDBY";
            public const string CreateDate = "CREATEDATE";
            public const string CreateTime = "CREATETIME";
            public const string SentDate = "SENTDATE";
            public const string SentTime = "SENTTIME";
            public const string Status = "STATUS";
            public const string Attempts = "ATTEMPTS";
            public const string ErrorCode = "ERRORCODE";
            public const string ErrorMessage = "ERRORMSG";
            public const string NumberOfAttachments = "NUMATTACH";
            public const string AttachmentFileName = "NAMEATTACH";
            public const string DisplayedErrorMessage = "DISERRMSG";
        }

        public class Index
        {
            public const int EmailId = 1;
            public const int SourceApplication = 2;
            public const int SourceType = 3;
            public const int SourceLabel = 4;
            public const int Subject = 5;
            public const int ToEmail = 6;
            public const int CcEmail = 7;
            public const int BccEmail = 8;
            public const int FromEmail = 9;
            public const int CreatedBy = 10;
            public const int CreateDate = 11;
            public const int CreateTime = 12;
            public const int SentDate = 13;
            public const int SentTime = 14;
            public const int Status = 15;
            public const int Attempts = 16;
            public const int ErrorCode = 17;
            public const int ErrorMessage = 18;
            public const int NumberOfAttachments = 19;
            public const int AttachmentFileName = 20;
            public const int DisplayedErrorMessage = 50;
        }
    }
}
