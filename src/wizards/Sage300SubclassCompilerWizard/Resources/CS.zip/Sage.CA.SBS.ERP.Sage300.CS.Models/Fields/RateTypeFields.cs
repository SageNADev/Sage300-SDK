﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of RateType Fields Constants
    /// </summary>
    public partial class RateType
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "CS0004";

        /// <summary>
        ///  RateType Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Rate Type
            /// </summary>
            public const string Code = "RATETYPE";

            /// <summary>
            /// Audit Date
            /// </summary>
            public const string AuditDate = "AUDTDATE";

            /// <summary>
            /// Audit Time
            /// </summary>
            public const string AuditTime = "AUDTTIME";

            /// <summary>
            /// Audit User
            /// </summary>
            public const string AuditUser = "AUDTUSER";

            /// <summary>
            /// Audit Org
            /// </summary>
            public const string AuditOrgansiation = "AUDTORG";

            /// <summary>
            /// Description
            /// </summary>
            public const string Description = "RATEDESC";

            #endregion
        }
    }
}