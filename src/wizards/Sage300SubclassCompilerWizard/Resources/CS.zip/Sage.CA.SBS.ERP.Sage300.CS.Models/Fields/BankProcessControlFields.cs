// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankProcessControl Constants 
    /// </summary>
    public partial class BankProcessControl
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "BK0105";

        /// <summary>
        /// Contains list of BankProcessControl Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BankProcess 
            /// </summary>
            public const string BankProcess = "PROCESS";

            /// <summary>
            /// Property for ProcessStatus 
            /// </summary>
            public const string ProcessStatus = "OPERATION";

            #endregion
        }

        /// <summary>
        /// Contains list of BankProcessControl Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BankProcess 
            /// </summary>
            public const int BankProcess = 1;

            /// <summary>
            /// Property Indexer for ProcessStatus 
            /// </summary>
            public const int ProcessStatus = 2;

            #endregion
        }
    }
}