﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankCurrency Constants 
    /// </summary>
    public partial class BankCurrency
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "BK0002";

        /// <summary>
        /// Entity Name (same as ViewNamebut removing ViewName causes a lot of compilation errors as it is used in a lot of places)
        /// </summary>
        public const string EntityName = ViewName;

        /// <summary>
        /// Contains list of BankCurrency Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties  
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CURN";
            /// <summary>
            /// Property for CheckRateType 
            /// </summary>
            public const string CheckRateType = "RTYPCHK";
            /// <summary>
            /// Property for DepositRateType 
            /// </summary>
            public const string DepositRateType = "RTYPDEP";
            /// <summary>
            /// Property for ExchangeGainAccount 
            /// </summary>
            public const string ExchangeGainAccount = "GAINACCT";
            /// <summary>
            /// Property for ExchangeLossAccount 
            /// </summary>
            public const string ExchangeLossAccount = "LOSSACCT";
            /// <summary>
            /// Property for RoundingAccount 
            /// </summary>
            public const string RoundingAccount = "ROUNDACCT";
            /// <summary>
            /// Property for CurrencyDescription 
            /// </summary>
            public const string CurrencyDescription = "CURDESC";

            #endregion
        }


        /// <summary>
        /// Contains list of BankCurrency Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 2;
            /// <summary>
            /// Property Indexer for CheckRateType 
            /// </summary>
            public const int CheckRateType = 3;
            /// <summary>
            /// Property Indexer for DepositRateType 
            /// </summary>
            public const int DepositRateType = 4;
            /// <summary>
            /// Property Indexer for ExchangeGainAccount 
            /// </summary>
            public const int ExchangeGainAccount = 5;
            /// <summary>
            /// Property Indexer for ExchangeLossAccount 
            /// </summary>
            public const int ExchangeLossAccount = 6;
            /// <summary>
            /// Property Indexer for RoundingAccount 
            /// </summary>
            public const int RoundingAccount = 7;
            /// <summary>
            /// Property Indexer for CurrencyDescription 
            /// </summary>
            public const int CurrencyDescription = 11;

            #endregion
        }


    }
}
