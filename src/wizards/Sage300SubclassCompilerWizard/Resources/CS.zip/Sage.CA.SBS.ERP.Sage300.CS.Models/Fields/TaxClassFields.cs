/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of TaxClasses Constants 
    /// </summary>
    public partial class TaxClass
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "TX0001";

        /// <summary>
        /// Contains list of TaxClasses Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for TaxAuthority 
            /// </summary>
            public const string TaxAuthorityCode = "AUTHORITY";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "CLASSTYPE";
            /// <summary>
            /// Property for ClassType 
            /// </summary>
            public const string ClassType = "CLASSAXIS";
            /// <summary>
            /// Property for Class 
            /// </summary>
            public const string Class = "CLASS";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";
            /// <summary>
            /// Property for Exempt 
            /// </summary>
            public const string Exempt = "EXEMPT";

            #endregion
        }


        /// <summary>
        /// Contains list of TaxClasses Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for TaxAuthority 
            /// </summary>
            public const int TaxAuthorityCode = 1;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 2;
            /// <summary>
            /// Property Indexer for ClassType 
            /// </summary>
            public const int ClassType = 3;
            /// <summary>
            /// Property Indexer for Class 
            /// </summary>
            public const int Class = 4;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 5;
            /// <summary>
            /// Property Indexer for Exempt 
            /// </summary>
            public const int Exempt = 6;

            #endregion
        }

    }
}

