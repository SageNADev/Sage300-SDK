// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Class Post Entries 
    /// </summary>
    public partial class PostEntries
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "BK0465";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of Post Entries Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Posting Operation 
            /// </summary>
            public const string PostingOperation = "OPERATION";

            /// <summary>
            /// Property for From Sequence Number 
            /// </summary>
            public const string FromSequenceNumber = "FROMSEQ";

            /// <summary>
            /// Property for To Sequence Number 
            /// </summary>
            public const string ToSequenceNumber = "TOSEQ";

            /// <summary>
            /// Property for Bank Code 
            /// </summary>
            public const string BankCode = "FROMBANK";

            /// <summary>
            /// Property for To Bank Code 
            /// </summary>
            public const string ToBankCode = "TOBANK";

            /// <summary>
            /// Property for Bank Entry Date 
            /// </summary>
            public const string BankEntryDate = "FROMDATE";

            /// <summary>
            /// Property for To Bank Entry Date 
            /// </summary>
            public const string ToBankEntryDate = "TODATE";

            /// <summary>
            /// Property for Fiscal Year 
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for Fiscal Period 
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for Bank Entry Number 
            /// </summary>
            public const string BankEntryNumber = "FROMENTRNM";

            /// <summary>
            /// Property for To Bank Entry Number 
            /// </summary>
            public const string ToBankEntryNumber = "TOENTRYNBR";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of Post Entries Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Posting Operation 
            /// </summary>
            public const int PostingOperation = 1;

            /// <summary>
            /// Property Indexer for From Sequence Number 
            /// </summary>
            public const int FromSequenceNumber = 2;

            /// <summary>
            /// Property Indexer for To Sequence Number 
            /// </summary>
            public const int ToSequenceNumber = 3;

            /// <summary>
            /// Property Indexer for Bank Code 
            /// </summary>
            public const int BankCode = 4;

            /// <summary>
            /// Property Indexer for To Bank Code 
            /// </summary>
            public const int ToBankCode = 5;

            /// <summary>
            /// Property Indexer for Bank Entry Date 
            /// </summary>
            public const int BankEntryDate = 6;

            /// <summary>
            /// Property Indexer for To Bank Entry Date 
            /// </summary>
            public const int ToBankEntryDate = 7;

            /// <summary>
            /// Property Indexer for Fiscal Year 
            /// </summary>
            public const int FiscalYear = 8;

            /// <summary>
            /// Property Indexer for Fiscal Period 
            /// </summary>
            public const int FiscalPeriod = 9;

            /// <summary>
            /// Property Indexer for Bank Entry Number 
            /// </summary>
            public const int BankEntryNumber = 10;

            /// <summary>
            /// Property Indexer for To Bank Entry Number 
            /// </summary>
            public const int ToBankEntryNumber = 11;

            #endregion
        }

        #endregion
    }
}