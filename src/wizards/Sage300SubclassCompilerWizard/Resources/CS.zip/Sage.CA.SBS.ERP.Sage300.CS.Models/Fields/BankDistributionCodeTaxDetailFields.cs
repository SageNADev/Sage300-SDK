// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankDistributionCodeTaxDetail Constants 
    /// </summary>
    public partial class BankDistributionCodeTaxDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "BK0860";

        /// <summary>
        /// Contains list of BankDistributionCodeTaxDetail Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "TYPE";

            /// <summary>
            /// Property for TaxAuthority 
            /// </summary>
            public const string TaxAuthorityCode = "AUTHORITY";

            /// <summary>
            /// Property for ItemTaxClass 
            /// </summary>
            public const string ItemTaxClass = "TXCLASS";

            /// <summary>
            /// Property for TaxIncluded 
            /// </summary>
            public const string TaxIncluded = "INCLUDED";

            /// <summary>
            /// Property for TaxAuthorityDescription 
            /// </summary>
            public const string TaxAuthorityDescription = "TXAUTHDESC";

            /// <summary>
            /// Property for TaxClassDescription 
            /// </summary>
            public const string TaxClassDescription = "TXCLSSDESC";

            #endregion
        }

        /// <summary>
        /// Contains list of BankDistributionCodeTaxDetail Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 1;

            /// <summary>
            /// Property Indexer for TaxAuthority 
            /// </summary>
            public const int TaxAuthorityCode = 2;

            /// <summary>
            /// Property Indexer for ItemTaxClass 
            /// </summary>
            public const int ItemTaxClass = 3;

            /// <summary>
            /// Property Indexer for TaxIncluded 
            /// </summary>
            public const int TaxIncluded = 4;

            /// <summary>
            /// Property Indexer for TaxAuthorityDescription 
            /// </summary>
            public const int TaxAuthorityDescription = 8;

            /// <summary>
            /// Property Indexer for TaxClassDescription 
            /// </summary>
            public const int TaxClassDescription = 9;

            #endregion
        }
    }
}