﻿/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of ImportOFXStatements Constants 
    /// </summary>
  public partial  class ImportOFXStatement
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0870";

        /// <summary>
        /// Contains list of OFX Transactions Fields Constants
        /// </summary>
        public class Fields
         {
             #region Properties
            /// <summary>
             /// Property for Bank Code 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for Unique ID
            /// </summary>
            public const string UniqueID = "UNIQUE";

            /// <summary>
            /// Property for Serial Number of Bank Transaction
            /// </summary>
            public const string SerialNumberOfBankTransaction = "SERIAL";

            /// <summary>
            /// Property for Line Number of Bank Transaction
            /// </summary>
            public const string LineNumberOfBankTransaction = "LINE";

            /// <summary>
            /// Property for Posted Date
            /// </summary>
            public const string PostedDate = "Date";

            /// <summary>
            /// Property for Distribution Code
            /// </summary>
            public const string DistributionCode = "TYPE";

            /// <summary>
            /// Property for Withdrawal Number
            /// </summary>
            public const string WithdrawalNumber = "NUMBER";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for Source Amount
            /// </summary>
            public const string SourceAmount = "SRCEAMT";

            /// <summary>
            /// Property for Statement Currency
            /// </summary>
            public const string StatementCurrency = "STMTCURN";

            /// <summary>
            /// Property for Is Amount in Statement Currency
            /// </summary>
            public const string IsAmountInStatementCurrency = "AMTINSTMT";

            /// <summary>
            /// Property for Payee Code
            /// </summary>
            public const string PayeeCode = "PAYEEID";

            /// <summary>
            /// Property for Payee Name
            /// </summary>
            public const string PayeeName = "PAYEENAME";

            /// <summary>
            /// Property for Rate Type
            /// </summary>
            public const string RateType = "RATETYPE";
            
            /// <summary>
            /// Property for SourceCurrency
            /// </summary>
            public const string SourceCurrency = "SRCECURN";

            /// <summary>
            /// Property for Rate Date
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for Rate
            /// </summary>
            public const string Rate = "RATE";

            /// <summary>
            /// Property for Rate Spread
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for Rate Operator
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for G/L Account
            /// </summary>
            public const string GLAccount = "GLACCOUNT";

            /// <summary>
            /// Property for Post Now
            /// </summary>
            public const string PostNow = "POSTNOW";

            /// <summary>
            /// Property for Entry Type
            /// </summary>
            public const string EntryType = "ENTRYTYPE";

            /// <summary>
            /// Property for Transaction Type
            /// </summary>
            public const string TransactionType = "TRXTYPE"; //DistributionCode in Xml 

            /// <summary>
            /// Property for OFX Transaction ID
            /// </summary>
            public const string OFXTransactionID = "OFXTID";

            /// <summary>
            /// Property for Reconciliation Year
            /// </summary>
            public const string ReconciliationYear = "RECYEAR";

            /// <summary>
            /// Property for Reconciliation Period
            /// </summary>
            public const string ReconciliationPeriod = "RECPERIOD";

            /// <summary>
            /// Property for  Match Found
            /// </summary>
            public const string  MatchFound = "RECONCILED";

            /// <summary>
            /// Property for Memo
            /// </summary>
            public const string Memo = "Memo";

            #endregion
         }

      /// <summary>
        /// Contains list of OFX Transactions Index Constants
      /// </summary>
      public class Index
      {
          #region Properties
          /// <summary>
          /// Property Indexer for Bank Code 
          /// </summary>
          public const int BankCode = 1;

          /// <summary>
          /// Property for Unique ID
          /// </summary>
          public const int UniqueID = 2;

          /// <summary>
          /// Property Indexer for Serial Number of Bank Transaction
          /// </summary>
          public const int SerialNumberOfBankTransaction = 3;

          /// <summary>
          /// Property Indexer for Line Number of Bank Transaction
          /// </summary>
          public const int LineNumberOfBankTransaction = 4;

          /// <summary>
          /// Property Indexer for Posted Date
          /// </summary>
          public const int PostedDate = 5;

          /// <summary>
          /// Property Indexer for Distribution Code
          /// </summary>
          public const int DistributionCode = 6;

          /// <summary>
          /// Property Indexer for Withdrawal Number
          /// </summary>
          public const int WithdrawalNumber = 7;

          /// <summary>
          /// Property Indexer for Reference
          /// </summary>
          public const int Reference = 8;

          /// <summary>
          /// Property for Comment
          /// </summary>
          public const int Comment = 9;

          /// <summary>
          /// Property Indexer for Amount
          /// </summary>
          public const int Amount = 10;

          /// <summary>
          /// Property Indexer for Source Amount
          /// </summary>
          public const int SourceAmount = 11;

          /// <summary>
          /// Property for Statement Currency
          /// </summary>
          public const int StatementCurrency = 12;

          /// <summary>
          /// Property Indexer for Is Amount in Statement Currency
          /// </summary>
          public const int IsAmountInStatementCurrency = 13;

          /// <summary>
          /// Property Indexer for Payee Code
          /// </summary>
          public const int PayeeCode = 14;

          /// <summary>
          /// Property for Payee Name
          /// </summary>
          public const int PayeeName = 15;

          /// <summary>
          /// Property Indexer for Rate Type
          /// </summary>
          public const int RateType = 16;

          /// <summary>
          /// Property Indexer for SourceCurrency
          /// </summary>
          public const int SourceCurrency = 17;

          /// <summary>
          /// Property for Rate Date
          /// </summary>
          public const int RateDate = 18;

          /// <summary>
          /// Property Indexer for Rate
          /// </summary>
          public const int Rate = 19;

          /// <summary>
          /// Property for Rate Spread
          /// </summary>
          public const int RateSpread = 20;

          /// <summary>
          /// Property Indexer for Rate Operator
          /// </summary>
          public const int RateOperator = 21;

          /// <summary>
          /// Property Indexer for G/L Account
          /// </summary>
          public const int GLAccount = 22;

          /// <summary>
          /// Property for Post Now
          /// </summary>
          public const int PostNow = 23;

          /// <summary>
          /// Property Indexer for Entry Type
          /// </summary>
          public const int EntryType = 24;

          /// <summary>
          /// Property Indexer for Transaction Type
          /// </summary>
          public const int TransactionType = 25; //DistributionCode in Xml 

          /// <summary>
          /// Property Indexer for OFX Transaction ID
          /// </summary>
          public const int OFXTransactionID = 26;

          /// <summary>
          /// Property Indexer for Reconciliation Year
          /// </summary>
          public const int ReconciliationYear = 27;

          /// <summary>
          /// Property Indexer for Reconciliation Period
          /// </summary>
          public const int ReconciliationPeriod = 28;

          /// <summary>
          /// Property Indexer for Match Found 
          /// </summary>
          public const int MatchFound = 29;

          /// <summary>
          /// Property Indexer for Memo
          /// </summary>
          public const int Memo = 30;

          #endregion
      }
    }
}
