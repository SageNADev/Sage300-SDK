/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankDistributionSetHeader Constants 
    /// </summary>
	public partial class BankDistributionSetHeader 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "BK0445";

        /// <summary>
        /// Contains list of BankDistributionSetHeader Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for DistributionSetCode 
        /// </summary>
	    public const string DistributionSetCode  = "DSETCODE";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "DESC";
	            /// <summary>
        /// Property for LastMaintained 
        /// </summary>
	    public const string LastMaintained  = "LSTMNTND";
	            /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "INACTIVE";
        /// <summary>
        /// Property for Status 
        /// </summary>
        public const string StatusString = "INACTIVE";
	            /// <summary>
        /// Property for InactiveDate 
        /// </summary>
	    public const string InactiveDate  = "INACTDATE";
	            /// <summary>
        /// Property for Currency 
        /// </summary>
	    public const string Currency  = "DISTCUR";
	            /// <summary>
        /// Property for NumberofLines 
        /// </summary>
	    public const string NumberofLines  = "LINES";
	            /// <summary>
        /// Property for CurrencyDecimals 
        /// </summary>
	    public const string CurrencyDecimals  = "CURDEC";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of BankDistributionSetHeader Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for DistributionSetCode 
        /// </summary>
	    public const int DistributionSetCode  = 1;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 2;
	             /// <summary>
        /// Property Indexer for LastMaintained 
        /// </summary>
	    public const int LastMaintained  = 3;
	             /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 4;
	             /// <summary>
        /// Property Indexer for InactiveDate 
        /// </summary>
	    public const int InactiveDate  = 5;
	             /// <summary>
        /// Property Indexer for Currency 
        /// </summary>
	    public const int Currency  = 6;
	             /// <summary>
        /// Property Indexer for NumberofLines 
        /// </summary>
	    public const int NumberofLines  = 7;
	             /// <summary>
        /// Property Indexer for CurrencyDecimals 
        /// </summary>
	    public const int CurrencyDecimals  = 10;
	     
        #endregion
	    }

	
	}
}
	