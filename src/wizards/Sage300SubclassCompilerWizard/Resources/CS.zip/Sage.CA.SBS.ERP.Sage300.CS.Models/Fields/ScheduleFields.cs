// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Schedules Constants 
    /// </summary>
    public partial class Schedule
    {
        #region Entity Name

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "CS0030";

        #endregion

        /// <summary>
        /// Contains list of Schedules Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for ScheduleCode 
            /// </summary>
            public const string ScheduleCode = "SCHEDKEY";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "SCHEDDESC";

            /// <summary>
            /// Property for Interval 
            /// </summary>
            public const string Interval = "INTERVAL";

            /// <summary>
            /// Property for Interval 
            /// </summary>
            public const string IntervalString = "INTERVAL";

            /// <summary>
            /// Property for Frequency 
            /// </summary>
            public const string Frequency = "FREQUENCY";

            /// <summary>
            /// Property for Frequency 
            /// </summary>
            public const string FrequencyString = "FREQUENCY";

            /// <summary>
            /// Property for Phase 
            /// </summary>
            public const string Phase = "PHASE";

            /// <summary>
            /// Property for Weekday 
            /// </summary>
            public const string Weekday = "WEEKDAY";

            /// <summary>
            /// Property for Weekday 
            /// </summary>
            public const string WeekdayString = "WEEKDAY";

            /// <summary>
            /// Property for DayofMonth 
            /// </summary>
            public const string DayofMonth = "MONTHDAY";

            /// <summary>
            /// Property for DayofMonth string
            /// </summary>
            public const string DayofMonthString = "MONTHDAY";

            /// <summary>
            /// Property for WeekinMonth 
            /// </summary>
            public const string WeekinMonth = "WEEK";

            /// <summary>
            /// Property for DayofMonth string
            /// </summary>
            public const string WeekinMonthString = "WEEK";

            /// <summary>
            /// Property for Month 
            /// </summary>
            public const string Month = "MONTH";

            /// <summary>
            /// Property for Month 
            /// </summary>
            public const string MonthString = "MONTH";

            /// <summary>
            /// Property for SundayCall 
            /// </summary>
            public const string SundayCall = "WDFSUN";

            /// <summary>
            /// Property for SundayCall 
            /// </summary>
            public const string SundayCallString = "WDFSUN";

            /// <summary>
            /// Property for MondayCall 
            /// </summary>
            public const string MondayCall = "WDFMON";

            /// <summary>
            /// Property for MondayCall 
            /// </summary>
            public const string MondayCallString = "WDFMON";

            /// <summary>
            /// Property for TuesdayCall 
            /// </summary>
            public const string TuesdayCallString = "WDFTUE";

            /// <summary>
            /// Property for TuesdayCall 
            /// </summary>
            public const string TuesdayCall = "WDFTUE";

            /// <summary>
            /// Property for WednesdayCall 
            /// </summary>
            public const string WednesdayCallString = "WDFWED";

            /// <summary>
            /// Property for WednesdayCall 
            /// </summary>
            public const string WednesdayCall = "WDFWED";

            /// <summary>
            /// Property for ThursdayCall 
            /// </summary>
            public const string ThursdayCall = "WDFTHU";

            /// <summary>
            /// Property for ThursdayCall 
            /// </summary>
            public const string ThursdayCallString = "WDFTHU";

            /// <summary>
            /// Property for FridayCall 
            /// </summary>
            public const string FridayCall = "WDFFRI";

            /// <summary>
            /// Property for FridayCall 
            /// </summary>
            public const string FridayCallString = "WDFFRI";

            /// <summary>
            /// Property for SaturdayCall 
            /// </summary>
            public const string SaturdayCall = "WDFSAT";

            /// <summary>
            /// Property for SaturdayCall 
            /// </summary>
            public const string SaturdayCallString = "WDFSAT";

            /// <summary>
            /// Property for LastRunDate 
            /// </summary>
            public const string LastRunDate = "LASTDATE";

            /// <summary>
            /// Property for ScheduleStartDate 
            /// </summary>
            public const string ScheduleStartDate = "ACTIVEDATE";

            /// <summary>
            /// Property for RemindinAdvance 
            /// </summary>
            public const string RemindinAdvance = "REMINDLEAD";

            /// <summary>
            /// Property for UserMode 
            /// </summary>
            public const string UserMode = "USERMODE";

            /// <summary>
            /// Property for UserMode 
            /// </summary>
            public const string UserModeString = "USERMODE";

            /// <summary>
            /// Property for UserID 
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for CurrentRun 
            /// </summary>
            public const string CurrentRun = "RUNCURRENT";

            /// <summary>
            /// Property for NextRun 
            /// </summary>
            public const string NextRun = "RUNNEXT";

            /// <summary>
            /// Property for NextPossibleRunDate 
            /// </summary>
            public const string NextPossibleRunDate = "RUNSTART";

            /// <summary>
            /// Property for RunDate 
            /// </summary>
            public const string RunDate = "INVOKEDATE";

            /// <summary>
            /// Property for SuggestedRunDate 
            /// </summary>
            public const string SuggestedRunDate = "SUGGESTDAT";

            /// <summary>
            /// Property for UserName 
            /// </summary>
            public const string UserName = "USERNAME";

            /// <summary>
            /// Property for IsDue? 
            /// </summary>
            public const string IsDue = "ISDUE";

            /// <summary>
            /// Property for IsDue? 
            /// </summary>
            public const string IsDueString = "ISDUE";

            /// <summary>
            /// Property for Processed 
            /// </summary>
            public const string Processed = "ISRUN";

            /// <summary>
            /// Property for Processed 
            /// </summary>
            public const string ProcessedString = "ISRUN";

            /// <summary>
            /// Property for Filtration 
            /// </summary>
            public const string Filtration = "FILTRATION";

            /// <summary>
            /// Property for Filtration 
            /// </summary>
            public const string FiltrationString = "FILTRATION";

            /// <summary>
            /// Property for FilterDate 
            /// </summary>
            public const string FilterDate = "FILTERDATE";

            /// <summary>
            /// Property for Filter 
            /// </summary>
            public const string Filter = "FILTER";

            /// <summary>
            /// Property for RemindersTo 
            /// </summary>
            public const string RemindersTo = "REMIND";

            /// <summary>
            /// Property for Operation 
            /// </summary>
            public const string Operation = "OPERATION";

            /// <summary>
            /// Property for Operation 
            /// </summary>
            public const string OperationString = "OPERATION";

            #endregion
        }

        /// <summary>
        /// Contains list of Schedules Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ScheduleCode 
            /// </summary>
            public const int ScheduleCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Interval 
            /// </summary>
            public const int Interval = 3;

            /// <summary>
            /// Property Indexer for Frequency 
            /// </summary>
            public const int Frequency = 4;

            /// <summary>
            /// Property Indexer for Phase 
            /// </summary>
            public const int Phase = 5;

            /// <summary>
            /// Property Indexer for Weekday 
            /// </summary>
            public const int Weekday = 6;

            /// <summary>
            /// Property Indexer for DayofMonth 
            /// </summary>
            public const int DayofMonth = 7;

            /// <summary>
            /// Property Indexer for WeekinMonth 
            /// </summary>
            public const int WeekinMonth = 8;

            /// <summary>
            /// Property Indexer for Month 
            /// </summary>
            public const int Month = 9;

            /// <summary>
            /// Property Indexer for SundayCall 
            /// </summary>
            public const int SundayCall = 10;

            /// <summary>
            /// Property Indexer for MondayCall 
            /// </summary>
            public const int MondayCall = 11;

            /// <summary>
            /// Property Indexer for TuesdayCall 
            /// </summary>
            public const int TuesdayCall = 12;

            /// <summary>
            /// Property Indexer for WednesdayCall 
            /// </summary>
            public const int WednesdayCall = 13;

            /// <summary>
            /// Property Indexer for ThursdayCall 
            /// </summary>
            public const int ThursdayCall = 14;

            /// <summary>
            /// Property Indexer for FridayCall 
            /// </summary>
            public const int FridayCall = 15;

            /// <summary>
            /// Property Indexer for SaturdayCall 
            /// </summary>
            public const int SaturdayCall = 16;

            /// <summary>
            /// Property Indexer for LastRunDate 
            /// </summary>
            public const int LastRunDate = 17;

            /// <summary>
            /// Property Indexer for ScheduleStartDate 
            /// </summary>
            public const int ScheduleStartDate = 18;

            /// <summary>
            /// Property Indexer for RemindinAdvance 
            /// </summary>
            public const int RemindinAdvance = 19;

            /// <summary>
            /// Property Indexer for UserMode 
            /// </summary>
            public const int UserMode = 20;

            /// <summary>
            /// Property Indexer for UserID 
            /// </summary>
            public const int UserID = 21;

            /// <summary>
            /// Property Indexer for CurrentRun 
            /// </summary>
            public const int CurrentRun = 101;

            /// <summary>
            /// Property Indexer for NextRun 
            /// </summary>
            public const int NextRun = 102;

            /// <summary>
            /// Property Indexer for NextPossibleRunDate 
            /// </summary>
            public const int NextPossibleRunDate = 103;

            /// <summary>
            /// Property Indexer for RunDate 
            /// </summary>
            public const int RunDate = 106;

            /// <summary>
            /// Property Indexer for SuggestedRunDate 
            /// </summary>
            public const int SuggestedRunDate = 107;

            /// <summary>
            /// Property Indexer for UserName 
            /// </summary>
            public const int UserName = 111;

            /// <summary>
            /// Property Indexer for IsDue? 
            /// </summary>
            public const int IsDue = 112;

            /// <summary>
            /// Property Indexer for Processed 
            /// </summary>
            public const int Processed = 114;

            /// <summary>
            /// Property Indexer for Filtration 
            /// </summary>
            public const int Filtration = 115;

            /// <summary>
            /// Property Indexer for FilterDate 
            /// </summary>
            public const int FilterDate = 116;

            /// <summary>
            /// Property Indexer for Filter 
            /// </summary>
            public const int Filter = 117;

            /// <summary>
            /// Property Indexer for RemindersTo 
            /// </summary>
            public const int RemindersTo = 118;

            /// <summary>
            /// Property Indexer for Operation 
            /// </summary>
            public const int Operation = 121;

            #endregion
        }
    }
}