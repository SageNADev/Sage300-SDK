// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of BankTransactionDetails Constants 
    /// </summary>
    public partial class BankTransactionDetail
    {
        /// <summary>
        /// Bank Transaction Details
        /// </summary>
        public const string EntityName = "BK0840";

        /// <summary>
        /// Contains list of BankTransactionDetails Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";

            /// <summary>
            /// Property for TransactionHeaderSerial 
            /// </summary>
            public const string TransactionHeaderSerial = "SERIAL";

            /// <summary>
            /// Property for TransactionDetailLine 
            /// </summary>
            public const string TransactionDetailLine = "LINE";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPP";

            /// <summary>
            /// Property for TransactionDetailStatus 
            /// </summary>
            public const string TransactionDetailStatus = "STATUS";

            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for DetailTransactionType 
            /// </summary>
            public const string DetailTransactionType = "TYPE";

            /// <summary>
            /// Property for RemittanceID 
            /// </summary>
            public const string RemittanceID = "IDREMIT";

            /// <summary>
            /// Property for TransactionDate 
            /// </summary>
            public const string TransactionDate = "DATEREMIT";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "BTCHNBR";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "ENTRYNBR";

            /// <summary>
            /// Property for PostingSequenceNumber 
            /// </summary>
            public const string PostingSequenceNumber = "POSTSEQ";

            /// <summary>
            /// Property for TransactionReference 
            /// </summary>
            public const string TransactionReference = "REFERENCE";

            /// <summary>
            /// Property for TransactionDescription 
            /// </summary>
            public const string TransactionDescription = "COMMENT";

            /// <summary>
            /// Property for PayerCode 
            /// </summary>
            public const string PayerCode = "PAYORID";

            /// <summary>
            /// Property for PayeeName 
            /// </summary>
            public const string PayeeName = "PAYORNAME";

            /// <summary>
            /// Property for VendorName 
            /// </summary>
            public const string VendorName = "VENDORNAME";

            /// <summary>
            /// Property for SourceTransactionAmount 
            /// </summary>
            public const string SourceTransactionAmount = "SRCEAMOUNT";

            /// <summary>
            /// Property for FunctionalTransactionAmount 
            /// </summary>
            public const string FunctionalTransactionAmount = "FUNCAMOUNT";

            /// <summary>
            /// Property for ExchangeRateType 
            /// </summary>
            public const string ExchangeRateType = "RATETYPE";

            /// <summary>
            /// Property for ReceiptCurrency 
            /// </summary>
            public const string ReceiptCurrency = "SRCECURN";

            /// <summary>
            /// Property for ExchangeRateDate 
            /// </summary>
            public const string ExchangeRateDate = "RATEDATE";

            /// <summary>
            /// Property for ExchangeRate 
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateSpread 
            /// </summary>
            public const string RateSpread = "RATESPREAD";

            /// <summary>
            /// Property for RateOperation 
            /// </summary>
            public const string RateOperation = "RATEOP";

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "DISTCODE";

            /// <summary>
            /// Property for GLAccount 
            /// </summary>
            public const string GLAccount = "GLACCOUNT";

            /// <summary>
            /// Property for DrilldownType 
            /// </summary>
            public const string DrilldownType = "DDTYPE";

            /// <summary>
            /// Property for DrilldownLink 
            /// </summary>
            public const string DrilldownLink = "DDLINK";

            /// <summary>
            /// Property for ReconciliationStatus 
            /// </summary>
            public const string ReconciliationStatus = "RECSTATUS";

            /// <summary>
            /// Property for StatusChangeDate 
            /// </summary>
            public const string StatusChangeDate = "RECSTATCHG";

            /// <summary>
            /// Property for ReconciliationDescription 
            /// </summary>
            public const string ReconciliationDescription = "RECCOMMENT";

            /// <summary>
            /// Property for ClearedAmount 
            /// </summary>
            public const string ClearedAmount = "RECCLEARED";

            /// <summary>
            /// Property for ReconciliationPostingDate 
            /// </summary>
            public const string ReconciliationPostingDate = "POSTDATE";

            /// <summary>
            /// Property for ReconciliationPostingYear 
            /// </summary>
            public const string ReconciliationPostingYear = "POSTYEAR";

            /// <summary>
            /// Property for ReconciliationPostingPeriod 
            /// </summary>
            public const string ReconciliationPostingPeriod = "POSTPERIOD";

            /// <summary>
            /// Property for Reconciled 
            /// </summary>
            public const string Reconciled = "RECONCILED";

            /// <summary>
            /// Property for RemainingInTransitAmount 
            /// </summary>
            public const string RemainingInTransitAmount = "RECPENDING";

            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for CheckStockCode 
            /// </summary>
            public const string CheckStockCode = "CHKFORM";

            /// <summary>
            /// Property for OFXTransactionID 
            /// </summary>
            public const string OFXTransactionID = "OFXTID";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FSCYEAR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FSCPERIOD";

            /// <summary>
            /// Property for ReversalOrReturnDate 
            /// </summary>
            public const string ReversalOrReturnDate = "REVDATE";

            /// <summary>
            /// Property for SourceDocumentNumber 
            /// </summary>
            public const string SourceDocumentNumber = "SRCEDOCNUM";

            /// <summary>
            /// Property for CanReverseInvoice 
            /// </summary>
            public const string CanReverseInvoice = "CANREVINVC";

            /// <summary>
            /// Property for ReverseInvoice 
            /// </summary>
            public const string ReverseInvoice = "REVINVC";

            /// <summary>
            /// Property for ReconciledandJournaledTransaction 
            /// </summary>
            public const string ReconciledandJournaledTransaction = "COMPLETED";

            /// <summary>
            /// Property for PostingSequence 
            /// </summary>
            public const string PostingSequence = "PSTSEQ";

            /// <summary>
            /// Property for EntryType 
            /// </summary>
            public const string EntryType = "ENTRYTYPE";

            /// <summary>
            /// Property for DocumentPostedDate 
            /// </summary>
            public const string DocumentPostedDate = "POSTED";

            /// <summary>
            /// Property for LastReconciliationStatus 
            /// </summary>
            public const string LastReconciliationStatus = "LSTRECSTAT";

            /// <summary>
            /// Property for ReconciledBy 
            /// </summary>
            public const string ReconciledBy = "RECLEVEL";

            /// <summary>
            /// Property for ReconciliationError 
            /// </summary>
            public const string ReconciliationError = "RECERR";

            /// <summary>
            /// Property for ReconciliationErrorPending 
            /// </summary>
            public const string ReconciliationErrorPending = "RECERRPEND";

            /// <summary>
            /// Property for ReconciliationExchangeGain 
            /// </summary>
            public const string ReconciliationExchangeGain = "RECEXGAIN";

            /// <summary>
            /// Property for ReconciliationExchangeLoss 
            /// </summary>
            public const string ReconciliationExchangeLoss = "RECEXLOSS";

            /// <summary>
            /// Property for ReconciliationSuggestion 
            /// </summary>
            public const string ReconciliationSuggestion = "RECSUGGEST";

            /// <summary>
            /// Property for TransactionAmount 
            /// </summary>
            public const string TransactionAmount = "RECAMOUNT";

            /// <summary>
            /// Property for OutstandingAmount 
            /// </summary>
            public const string OutstandingAmount = "RECOUTSTND";

            /// <summary>
            /// Property for ReconciliationTarget 
            /// </summary>
            public const string ReconciliationTarget = "RECTARGET";

            /// <summary>
            /// Property for DistributionCodeDescription 
            /// </summary>
            public const string DistributionCodeDescription = "DCODEDESC";

            /// <summary>
            /// Property for GLAccountDescription 
            /// </summary>
            public const string GLAccountDescription = "GLACCOUNTD";

            /// <summary>
            /// Property for ReconciliationAmountDelta 
            /// </summary>
            public const string ReconciliationAmountDelta = "RECDELTA";

            /// <summary>
            /// Property for Line 
            /// </summary>
            public const string Line = "LINEONE";

            /// <summary>
            /// Property for LineOutstanding 
            /// </summary>
            public const string LineOutstanding = "LINEPOST";

            /// <summary>
            /// Property for LineReconciled 
            /// </summary>
            public const string LineReconciled = "LINEREC";

            /// <summary>
            /// Property for ReconciliationCreditCardCharges
            /// </summary>
            public const string ReconciliationCreditCardCharges = "RECCCC";

            /// <summary>
            /// Property for WriteOffAmount 
            /// </summary>
            public const string WriteOffAmount = "RECWOSUM";

            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const string FunctionalCurrency = "CURFUNC";

            /// <summary>
            /// Property for StatementCurrency 
            /// </summary>
            public const string StatementCurrency = "CURSTMT";

            /// <summary>
            /// Property for SummatedTransactionAmount 
            /// </summary>
            public const string SummatedTransactionAmount = "SUMAMOUNT";

            /// <summary>
            /// Property for ReconciliationSpread 
            /// </summary>
            public const string ReconciliationSpread = "RECSPREAD";

            /// <summary>
            /// Property for FiscalTransactionRemainingIn 
            /// </summary>
            public const string FiscalTransactionRemainingIn = "RECPAMOUNT";

            /// <summary>
            /// Property for FiscalOutstandingAmount 
            /// </summary>
            public const string FiscalOutstandingAmount = "RECPOUTSTD";

            /// <summary>
            /// Property for FiscalWriteOffs 
            /// </summary>
            public const string FiscalWriteOffs = "RECPWO";

            /// <summary>
            /// Property for FiscalBankErrors 
            /// </summary>
            public const string FiscalBankErrors = "RECPERR";

            /// <summary>
            /// Property for FiscalExchangeGain 
            /// </summary>
            public const string FiscalExchangeGain = "RECPGAIN";

            /// <summary>
            /// Property for FiscalExchangeLoss 
            /// </summary>
            public const string FiscalExchangeLoss = "RECPLOSS";

            /// <summary>
            /// Property for FiscalCreditCardCharge 
            /// </summary>
            public const string FiscalCreditCardCharge = "RECPCCC";

            /// <summary>
            /// Property for FiscalCleared 
            /// </summary>
            public const string FiscalCleared = "RECPCLR";

            /// <summary>
            /// Property for FiscalFunctionalAmount 
            /// </summary>
            public const string FiscalFunctionalAmount = "RECPFUNAM";

            /// <summary>
            /// Property for FiscalOriginalTransactionAmount
            /// </summary>
            public const string FiscalOriginalTransactionAmount = "RECPORIG";

            /// <summary>
            /// Property for TotalBookAmount 
            /// </summary>
            public const string TotalBookAmount = "RECTBOOK";

            /// <summary>
            /// Property for FiscalBookAmount 
            /// </summary>
            public const string FiscalBookAmount = "RECPBOOK";

            /// <summary>
            /// Property for TotalRemainingAmount 
            /// </summary>
            public const string TotalRemainingAmount = "RECTREMAIN";

            /// <summary>
            /// Property for FiscalRemainingAmount 
            /// </summary>
            public const string FiscalRemainingAmount = "RECPREMAIN";

            /// <summary>
            /// Property for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const string FiscalWriteOffToThisPeriod = "RECRWOSUM";

            /// <summary>
            /// Property for FiscalClearedToFuture 
            /// </summary>
            public const string FiscalClearedToFuture = "RECFCLR";

            /// <summary>
            /// Property for FiscalClearedToCurrent 
            /// </summary>
            public const string FiscalClearedToCurrent = "RECRCLR";

            /// <summary>
            /// Property for CurrentPeriodsWriteOff 
            /// </summary>
            public const string CurrentPeriodsWriteOff = "RECWOSUMR";

            /// <summary>
            /// Property for PostedFiscalClearedToFuture 
            /// </summary>
            public const string PostedFiscalClearedToFuture = "RECFCLRR";

            /// <summary>
            /// Property for NoOfDaysSinceReconciled 
            /// </summary>
            public const string NoOfDaysSinceReconciled = "AGERECLD";

            /// <summary>
            /// Property for StatementAmount 
            /// </summary>
            public const string StatementAmount = "STMTAMOUNT";

            /// <summary>
            /// Property for LineCreditCard 
            /// </summary>
            public const string LineCreditCard = "LINECCC";

            /// <summary>
            /// Property for LineExchangeDifference 
            /// </summary>
            public const string LineExchangeDifference = "LINEEXCH";

            /// <summary>
            /// Property for LineCanReverseInvoice 
            /// </summary>
            public const string LineCanReverseInvoice = "LINEREVINV";

            /// <summary>
            /// Property for BankStatementType 
            /// </summary>
            public const string BankStatementType = "CURRTYPE";

            /// <summary>
            /// Property for ReconciliationYear 
            /// </summary>
            public const string ReconciliationYear = "RECYEAR";

            /// <summary>
            /// Property for ReconciliationPeriod 
            /// </summary>
            public const string ReconciliationPeriod = "RECPERIOD";

            /// <summary>
            /// Property for ReconcileByDetailReconciled 
            /// </summary>
            public const string ReconcileByDetailReconciled = "AMTDTLREC";

            /// <summary>
            /// Property for ReconcileByDetailOutstanding 
            /// </summary>
            public const string ReconcileByDetailOutstanding = "AMTDTLOUT";


            /// <summary>
            /// Property for TransactionDetailStatus string value 
            /// </summary>
            public const string TransactionDetailStatusString = "STATUS";

            /// <summary>
            /// Property for TransactionType string value 
            /// </summary>
            public const string TransactionTypeString = "TRANSTYPE";

            /// <summary>
            /// Property for DetailTransactionType string value 
            /// </summary>
            public const string DetailTransactionTypeString = "TYPE";

            /// <summary>
            /// Property for RateOperation string value 
            /// </summary>
            public const string RateOperationString = "RATEOP";

            /// <summary>
            /// Property for RateOperation string value 
            /// </summary>
            public const string ReconciliationStatusString = "RECSTATUS";

            /// <summary>
            /// Property for RateOperation string value 
            /// </summary>
            public const string ReconciliationPostingPeriodString = "POSTPERIOD";

            /// <summary>
            /// Property for CanReverseInvoice string value 
            /// </summary>
            public const string CanReverseInvoiceString = "CANREVINVC";

            /// <summary>
            /// Property for ReverseInvoice string value 
            /// </summary>
            public const string ReverseInvoiceString = "REVINVC";

            /// <summary>
            /// Property for ReconciledandJournaledTransaction string value 
            /// </summary>
            public const string ReconciledandJournaledTransactionString = "COMPLETED";

            /// <summary>
            /// Property for ReconciledBy string value 
            /// </summary>
            public const string ReconciledByString = "RECLEVEL";

            /// <summary>
            /// Property for ReconciliationSuggestion string value 
            /// </summary>
            public const string ReconciliationSuggestionString = "RECSUGGEST";

            /// <summary>
            /// Property for ReconciliationTarget string value 
            /// </summary>
            public const string ReconciliationTargetString = "RECTARGET";

            #endregion
        }

        /// <summary>
        /// Contains list of BankTransactionDetails Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 1;

            /// <summary>
            /// Property Indexer for TransactionHeaderSerial 
            /// </summary>
            public const int TransactionHeaderSerial = 2;

            /// <summary>
            /// Property Indexer for TransactionDetailLine 
            /// </summary>
            public const int TransactionDetailLine = 3;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 4;

            /// <summary>
            /// Property Indexer for TransactionDetailStatus 
            /// </summary>
            public const int TransactionDetailStatus = 5;

            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 6;

            /// <summary>
            /// Property Indexer for DetailTransactionType 
            /// </summary>
            public const int DetailTransactionType = 7;

            /// <summary>
            /// Property Indexer for RemittanceID 
            /// </summary>
            public const int RemittanceID = 8;

            /// <summary>
            /// Property Indexer for TransactionDate 
            /// </summary>
            public const int TransactionDate = 9;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 10;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 11;

            /// <summary>
            /// Property Indexer for PostingSequenceNumber 
            /// </summary>
            public const int PostingSequenceNumber = 12;

            /// <summary>
            /// Property Indexer for TransactionReference 
            /// </summary>
            public const int TransactionReference = 13;

            /// <summary>
            /// Property Indexer for TransactionDescription 
            /// </summary>
            public const int TransactionDescription = 14;

            /// <summary>
            /// Property Indexer for PayerCode 
            /// </summary>
            public const int PayerCode = 15;

            /// <summary>
            /// Property Indexer for PayeeName 
            /// </summary>
            public const int PayeeName = 16;

            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
            public const int VendorName = 17;

            /// <summary>
            /// Property Indexer for SourceTransactionAmount 
            /// </summary>
            public const int SourceTransactionAmount = 18;

            /// <summary>
            /// Property Indexer for FunctionalTransactionAmount 
            /// </summary>
            public const int FunctionalTransactionAmount = 19;

            /// <summary>
            /// Property Indexer for ExchangeRateType 
            /// </summary>
            public const int ExchangeRateType = 20;

            /// <summary>
            /// Property Indexer for ReceiptCurrency 
            /// </summary>
            public const int ReceiptCurrency = 21;

            /// <summary>
            /// Property Indexer for ExchangeRateDate 
            /// </summary>
            public const int ExchangeRateDate = 22;

            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 23;

            /// <summary>
            /// Property Indexer for RateSpread 
            /// </summary>
            public const int RateSpread = 24;

            /// <summary>
            /// Property Indexer for RateOperation 
            /// </summary>
            public const int RateOperation = 25;

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 26;

            /// <summary>
            /// Property Indexer for GLAccount 
            /// </summary>
            public const int GLAccount = 27;

            /// <summary>
            /// Property Indexer for DrilldownType 
            /// </summary>
            public const int DrilldownType = 33;

            /// <summary>
            /// Property Indexer for DrilldownLink 
            /// </summary>
            public const int DrilldownLink = 34;

            /// <summary>
            /// Property Indexer for ReconciliationStatus 
            /// </summary>
            public const int ReconciliationStatus = 35;

            /// <summary>
            /// Property Indexer for StatusChangeDate 
            /// </summary>
            public const int StatusChangeDate = 36;

            /// <summary>
            /// Property Indexer for ReconciliationDescription 
            /// </summary>
            public const int ReconciliationDescription = 37;

            /// <summary>
            /// Property Indexer for ClearedAmount 
            /// </summary>
            public const int ClearedAmount = 38;

            /// <summary>
            /// Property Indexer for ReconciliationPostingDate 
            /// </summary>
            public const int ReconciliationPostingDate = 39;

            /// <summary>
            /// Property Indexer for ReconciliationPostingYear 
            /// </summary>
            public const int ReconciliationPostingYear = 40;

            /// <summary>
            /// Property Indexer for ReconciliationPostingPeriod 
            /// </summary>
            public const int ReconciliationPostingPeriod = 41;

            /// <summary>
            /// Property Indexer for Reconciled 
            /// </summary>
            public const int Reconciled = 42;

            /// <summary>
            /// Property Indexer for RemainingInTransitAmount 
            /// </summary>
            public const int RemainingInTransitAmount = 43;

            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 44;

            /// <summary>
            /// Property Indexer for CheckStockCode 
            /// </summary>
            public const int CheckStockCode = 45;

            /// <summary>
            /// Property Indexer for OFXTransactionID 
            /// </summary>
            public const int OFXTransactionID = 46;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 47;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 48;

            /// <summary>
            /// Property Indexer for ReversalOrReturnDate 
            /// </summary>
            public const int ReversalOrReturnDate = 49;

            /// <summary>
            /// Property Indexer for SourceDocumentNumber 
            /// </summary>
            public const int SourceDocumentNumber = 50;

            /// <summary>
            /// Property Indexer for CanReverseInvoice 
            /// </summary>
            public const int CanReverseInvoice = 51;

            /// <summary>
            /// Property Indexer for ReverseInvoice 
            /// </summary>
            public const int ReverseInvoice = 52;

            /// <summary>
            /// Property Indexer for ReconciledandJournaledTransactions 
            /// </summary>
            public const int ReconciledandJournaledTransaction = 53;

            /// <summary>
            /// Property Indexer for PostingSequence 
            /// </summary>
            public const int PostingSequence = 54;

            /// <summary>
            /// Property Indexer for EntryType 
            /// </summary>
            public const int EntryType = 55;

            /// <summary>
            /// Property Indexer for DocumentPostedDate 
            /// </summary>
            public const int DocumentPostedDate = 56;

            /// <summary>
            /// Property Indexer for LastReconciliationStatus 
            /// </summary>
            public const int LastReconciliationStatus = 57;

            /// <summary>
            /// Property Indexer for ReconciledBy 
            /// </summary>
            public const int ReconciledBy = 58;

            /// <summary>
            /// Property Indexer for ReconciliationError 
            /// </summary>
            public const int ReconciliationError = 80;

            /// <summary>
            /// Property Indexer for ReconciliationErrorPending 
            /// </summary>
            public const int ReconciliationErrorPending = 81;

            /// <summary>
            /// Property Indexer for ReconciliationExchangeGain 
            /// </summary>
            public const int ReconciliationExchangeGain = 82;

            /// <summary>
            /// Property Indexer for ReconciliationExchangeLoss 
            /// </summary>
            public const int ReconciliationExchangeLoss = 83;

            /// <summary>
            /// Property Indexer for ReconciliationSuggestion 
            /// </summary>
            public const int ReconciliationSuggestion = 84;

            /// <summary>
            /// Property Indexer for TransactionAmount 
            /// </summary>
            public const int TransactionAmount = 85;

            /// <summary>
            /// Property Indexer for OutstandingAmount 
            /// </summary>
            public const int OutstandingAmount = 86;

            /// <summary>
            /// Property Indexer for ReconciliationTarget 
            /// </summary>
            public const int ReconciliationTarget = 87;

            /// <summary>
            /// Property Indexer for DistributionCodeDescription 
            /// </summary>
            public const int DistributionCodeDescription = 88;

            /// <summary>
            /// Property Indexer for GLAccountDescription 
            /// </summary>
            public const int GLAccountDescription = 89;

            /// <summary>
            /// Property Indexer for ReconciliationAmountDelta 
            /// </summary>
            public const int ReconciliationAmountDelta = 90;

            /// <summary>
            /// Property Indexer for Line 
            /// </summary>
            public const int Line = 91;

            /// <summary>
            /// Property Indexer for LineOutstanding 
            /// </summary>
            public const int LineOutstanding = 92;

            /// <summary>
            /// Property Indexer for LineReconciled 
            /// </summary>
            public const int LineReconciled = 93;

            /// <summary>
            /// Property Indexer for ReconciliationCreditCardCharges
            /// </summary>
            public const int ReconciliationCreditCardCharges = 95;

            /// <summary>
            /// Property Indexer for WriteOffAmount 
            /// </summary>
            public const int WriteOffAmount = 96;

            /// <summary>
            /// Property Indexer for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 97;

            /// <summary>
            /// Property Indexer for StatementCurrency 
            /// </summary>
            public const int StatementCurrency = 98;

            /// <summary>
            /// Property Indexer for SummatedTransactionAmount 
            /// </summary>
            public const int SummatedTransactionAmount = 99;

            /// <summary>
            /// Property Indexer for ReconciliationSpread 
            /// </summary>
            public const int ReconciliationSpread = 100;

            /// <summary>
            /// Property Indexer for FiscalTransactionRemainingIn 
            /// </summary>
            public const int FiscalTransactionRemainingIn = 101;

            /// <summary>
            /// Property Indexer for FiscalOutstandingAmount 
            /// </summary>
            public const int FiscalOutstandingAmount = 102;

            /// <summary>
            /// Property Indexer for FiscalWriteOffs 
            /// </summary>
            public const int FiscalWriteOffs = 103;

            /// <summary>
            /// Property Indexer for FiscalBankErrors 
            /// </summary>
            public const int FiscalBankErrors = 104;

            /// <summary>
            /// Property Indexer for FiscalExchangeGain 
            /// </summary>
            public const int FiscalExchangeGain = 105;

            /// <summary>
            /// Property Indexer for FiscalExchangeLoss 
            /// </summary>
            public const int FiscalExchangeLoss = 106;

            /// <summary>
            /// Property Indexer for FiscalCreditCardCharge 
            /// </summary>
            public const int FiscalCreditCardCharge = 107;

            /// <summary>
            /// Property Indexer for FiscalCleared 
            /// </summary>
            public const int FiscalCleared = 108;

            /// <summary>
            /// Property Indexer for FiscalFunctionalAmount 
            /// </summary>
            public const int FiscalFunctionalAmount = 109;

            /// <summary>
            /// Property Indexer for FiscalOriginalTransactionAmount 
            /// </summary>
            public const int FiscalOriginalTransactionAmount = 110;

            /// <summary>
            /// Property Indexer for TotalBookAmount 
            /// </summary>
            public const int TotalBookAmount = 111;

            /// <summary>
            /// Property Indexer for FiscalBookAmount 
            /// </summary>
            public const int FiscalBookAmount = 112;

            /// <summary>
            /// Property Indexer for TotalRemainingAmount 
            /// </summary>
            public const int TotalRemainingAmount = 113;

            /// <summary>
            /// Property Indexer for FiscalRemainingAmount 
            /// </summary>
            public const int FiscalRemainingAmount = 114;

            /// <summary>
            /// Property Indexer for FiscalWriteOffToThisPeriod 
            /// </summary>
            public const int FiscalWriteOffToThisPeriod = 115;

            /// <summary>
            /// Property Indexer for FiscalClearedToFuture 
            /// </summary>
            public const int FiscalClearedToFuture = 116;

            /// <summary>
            /// Property Indexer for FiscalClearedToCurrent 
            /// </summary>
            public const int FiscalClearedToCurrent = 117;

            /// <summary>
            /// Property Indexer for CurrentPeriodsWriteOff 
            /// </summary>
            public const int CurrentPeriodsWriteOff = 118;

            /// <summary>
            /// Property Indexer for PostedFiscalClearedToFuture 
            /// </summary>
            public const int PostedFiscalClearedToFuture = 119;

            /// <summary>
            /// Property Indexer for NoOfDaysSinceReconciled 
            /// </summary>
            public const int NoOfDaysSinceReconciled = 120;

            /// <summary>
            /// Property Indexer for StatementAmount 
            /// </summary>
            public const int StatementAmount = 121;

            /// <summary>
            /// Property Indexer for LineCreditCard 
            /// </summary>
            public const int LineCreditCard = 122;

            /// <summary>
            /// Property Indexer for LineExchangeDifference 
            /// </summary>
            public const int LineExchangeDifference = 123;

            /// <summary>
            /// Property Indexer for LineCanReverseInvoice 
            /// </summary>
            public const int LineCanReverseInvoice = 124;

            /// <summary>
            /// Property Indexer for BankStatementType 
            /// </summary>
            public const int BankStatementType = 125;

            /// <summary>
            /// Property Indexer for ReconciliationYear 
            /// </summary>
            public const int ReconciliationYear = 126;

            /// <summary>
            /// Property Indexer for ReconciliationPeriod 
            /// </summary>
            public const int ReconciliationPeriod = 127;

            /// <summary>
            /// Property Indexer for ReconcileByDetailReconciled 
            /// </summary>
            public const int ReconcileByDetailReconciled = 128;

            /// <summary>
            /// Property Indexer for ReconcileByDetailOutstanding 
            /// </summary>
            public const int ReconcileByDetailOutstanding = 129;

            #endregion
        }
    }
}
