// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of PayslipDay Constants
    /// </summary>
    public partial class PayslipDay
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "HQ0007";


        #region Fields Properties

        /// <summary>
        /// Contains list of PayslipDay Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for PaymentDate
            /// </summary>
            public const string PaymentDate = "TRANSDATE";

            /// <summary>
            /// Property for LastPayslipRecordNumber
            /// </summary>
            public const string LastPayslipRecordNumber = "LASTRECNUM";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for IncludeInactiveAndTerminated
            /// </summary>
            public const string IncludeInactiveAndTerminated = "SHOWALL";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of PayslipDay Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for PaymentDate
            /// </summary>
            public const int PaymentDate = 1;

            /// <summary>
            /// Property Indexer for LastPayslipRecordNumber
            /// </summary>
            public const int LastPayslipRecordNumber = 2;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 50;

            /// <summary>
            /// Property Indexer for IncludeInactiveAndTerminated
            /// </summary>
            public const int IncludeInactiveAndTerminated = 51;


        }

        #endregion

    }
}