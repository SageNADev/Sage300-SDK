// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
     /// <summary>
     /// Contains list of TransferAudit Constants
     /// </summary>
     public partial class TransferAudit
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "BK0033";

          #region Properties
          /// <summary>
          /// Contains list of TransferAudit Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for PostingSequence
               /// </summary>
               public const string PostingSequence = "PSTSEQ";

               /// <summary>
               /// Property for KeySequence
               /// </summary>
               public const string KeySequence = "KEYSEQ";

               /// <summary>
               /// Property for TransferNumber
               /// </summary>
               public const string TransferNumber = "TRANSFERNR";

               /// <summary>
               /// Property for Date
               /// </summary>
               public const string Date = "DATE";

               /// <summary>
               /// Property for TransferAdjustmentGLAccount
               /// </summary>
               public const string TransferAdjustmentGLAccount = "GLACCOUNT";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for Reference
               /// </summary>
               public const string Reference = "REFERENCE";

               /// <summary>
               /// Property for FiscalYear
               /// </summary>
               public const string FiscalYear = "FISCYEAR";

               /// <summary>
               /// Property for FiscalPeriod
               /// </summary>
               public const string FiscalPeriod = "FISCPERIOD";

               /// <summary>
               /// Property for TransferBankCode
               /// </summary>
               public const string TransferBankCode = "OBANK";

               /// <summary>
               /// Property for TransferBank
               /// </summary>
               public const string TransferBank = "ODESC";

               /// <summary>
               /// Property for TransferBankGLAccount
               /// </summary>
               public const string TransferBankGLAccount = "OGLACCOUNT";

               /// <summary>
               /// Property for TransferSourceCurrency
               /// </summary>
               public const string TransferSourceCurrency = "OSRCECURN";

               /// <summary>
               /// Property for TransferRateDate
               /// </summary>
               public const string TransferRateDate = "ORATEDATE";

               /// <summary>
               /// Property for TransferRateType
               /// </summary>
               public const string TransferRateType = "ORATETYPE";

               /// <summary>
               /// Property for TransferRateFactor
               /// </summary>
               public const string TransferRateFactor = "ORATE";

               /// <summary>
               /// Property for TransferRateSpread
               /// </summary>
               public const string TransferRateSpread = "ORATESPREA";

               /// <summary>
               /// Property for TransferRateOperator
               /// </summary>
               public const string TransferRateOperator = "ORATEOP";

               /// <summary>
               /// Property for TransferSourceAmount
               /// </summary>
               public const string TransferSourceAmount = "OSAMOUNT";

               /// <summary>
               /// Property for TransferFunctionalAmount
               /// </summary>
               public const string TransferFunctionalAmount = "OFAMOUNT";

               /// <summary>
               /// Property for DepositBankCode
               /// </summary>
               public const string DepositBankCode = "DBANK";

               /// <summary>
               /// Property for DepositBank
               /// </summary>
               public const string DepositBank = "DDESC";

               /// <summary>
               /// Property for DepositBankGLAccount
               /// </summary>
               public const string DepositBankGLAccount = "DGLACCOUNT";

               /// <summary>
               /// Property for DepositSourceCurrency
               /// </summary>
               public const string DepositSourceCurrency = "DSRCECURN";

               /// <summary>
               /// Property for DepositRateDate
               /// </summary>
               public const string DepositRateDate = "DRATEDATE";

               /// <summary>
               /// Property for DepositRateType
               /// </summary>
               public const string DepositRateType = "DRATETYPE";

               /// <summary>
               /// Property for DepositRateFactor
               /// </summary>
               public const string DepositRateFactor = "DRATE";

               /// <summary>
               /// Property for DepositRateSpread
               /// </summary>
               public const string DepositRateSpread = "DRATESPREA";

               /// <summary>
               /// Property for DepositRateOperator
               /// </summary>
               public const string DepositRateOperator = "DRATEOP";

               /// <summary>
               /// Property for DepositSourceAmount
               /// </summary>
               public const string DepositSourceAmount = "DSAMOUNT";

               /// <summary>
               /// Property for DepositFunctionalAmount
               /// </summary>
               public const string DepositFunctionalAmount = "DFAMOUNT";

               /// <summary>
               /// Property for SourceRateFactor
               /// </summary>
               public const string SourceRateFactor = "TRATE";

               /// <summary>
               /// Property for SourceRateOperator
               /// </summary>
               public const string SourceRateOperator = "TRATEOP";

               /// <summary>
               /// Property for SourceSourceCurrency
               /// </summary>
               public const string SourceSourceCurrency = "TSRCECURN";

               /// <summary>
               /// Property for SourceSourceAmount
               /// </summary>
               public const string SourceSourceAmount = "TSAMOUNT";

               /// <summary>
               /// Property for SourceFunctionalAmount
               /// </summary>
               public const string SourceFunctionalAmount = "TFAMOUNT";

               /// <summary>
               /// Property for TransferCurrencyStatement
               /// </summary>
               public const string TransferCurrencyStatement = "OCURNSTMT";

               /// <summary>
               /// Property for TransferMulticurrency
               /// </summary>
               public const string TransferMulticurrency = "OMULTICUR";

               /// <summary>
               /// Property for DepositCurrencyStatement
               /// </summary>
               public const string DepositCurrencyStatement = "DCURNSTMT";

               /// <summary>
               /// Property for DepositMulticurrency
               /// </summary>
               public const string DepositMulticurrency = "DMULTICUR";

               /// <summary>
               /// Property for TransferBankCurrencyDescripti
               /// </summary>
               public const string TransferBankCurrencyDescripti = "OSRCECURND";

               /// <summary>
               /// Property for DepositBankCurrencyDescriptio
               /// </summary>
               public const string DepositBankCurrencyDescriptio = "DSRCECURND";

               /// <summary>
               /// Property for FunctionalCurrency
               /// </summary>
               public const string FunctionalCurrency = "FUNCTCURN";

               /// <summary>
               /// Property for PostDate
               /// </summary>
               public const string PostDate = "POSTDATE";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of TransferAudit Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for PostingSequence
               /// </summary>
               public const int PostingSequence = 1;

               /// <summary>
               /// Property Indexer for KeySequence
               /// </summary>
               public const int KeySequence = 2;

               /// <summary>
               /// Property Indexer for TransferNumber
               /// </summary>
               public const int TransferNumber = 3;

               /// <summary>
               /// Property Indexer for Date
               /// </summary>
               public const int Date = 4;

               /// <summary>
               /// Property Indexer for TransferAdjustmentGLAccount
               /// </summary>
               public const int TransferAdjustmentGLAccount = 5;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 6;

               /// <summary>
               /// Property Indexer for Reference
               /// </summary>
               public const int Reference = 7;

               /// <summary>
               /// Property Indexer for FiscalYear
               /// </summary>
               public const int FiscalYear = 8;

               /// <summary>
               /// Property Indexer for FiscalPeriod
               /// </summary>
               public const int FiscalPeriod = 9;

               /// <summary>
               /// Property Indexer for TransferBankCode
               /// </summary>
               public const int TransferBankCode = 10;

               /// <summary>
               /// Property Indexer for TransferBank
               /// </summary>
               public const int TransferBank = 11;

               /// <summary>
               /// Property Indexer for TransferBankGLAccount
               /// </summary>
               public const int TransferBankGLAccount = 12;

               /// <summary>
               /// Property Indexer for TransferSourceCurrency
               /// </summary>
               public const int TransferSourceCurrency = 13;

               /// <summary>
               /// Property Indexer for TransferRateDate
               /// </summary>
               public const int TransferRateDate = 14;

               /// <summary>
               /// Property Indexer for TransferRateType
               /// </summary>
               public const int TransferRateType = 15;

               /// <summary>
               /// Property Indexer for TransferRateFactor
               /// </summary>
               public const int TransferRateFactor = 16;

               /// <summary>
               /// Property Indexer for TransferRateSpread
               /// </summary>
               public const int TransferRateSpread = 17;

               /// <summary>
               /// Property Indexer for TransferRateOperator
               /// </summary>
               public const int TransferRateOperator = 18;

               /// <summary>
               /// Property Indexer for TransferSourceAmount
               /// </summary>
               public const int TransferSourceAmount = 19;

               /// <summary>
               /// Property Indexer for TransferFunctionalAmount
               /// </summary>
               public const int TransferFunctionalAmount = 20;

               /// <summary>
               /// Property Indexer for DepositBankCode
               /// </summary>
               public const int DepositBankCode = 21;

               /// <summary>
               /// Property Indexer for DepositBank
               /// </summary>
               public const int DepositBank = 22;

               /// <summary>
               /// Property Indexer for DepositBankGLAccount
               /// </summary>
               public const int DepositBankGLAccount = 23;

               /// <summary>
               /// Property Indexer for DepositSourceCurrency
               /// </summary>
               public const int DepositSourceCurrency = 24;

               /// <summary>
               /// Property Indexer for DepositRateDate
               /// </summary>
               public const int DepositRateDate = 25;

               /// <summary>
               /// Property Indexer for DepositRateType
               /// </summary>
               public const int DepositRateType = 26;

               /// <summary>
               /// Property Indexer for DepositRateFactor
               /// </summary>
               public const int DepositRateFactor = 27;

               /// <summary>
               /// Property Indexer for DepositRateSpread
               /// </summary>
               public const int DepositRateSpread = 28;

               /// <summary>
               /// Property Indexer for DepositRateOperator
               /// </summary>
               public const int DepositRateOperator = 29;

               /// <summary>
               /// Property Indexer for DepositSourceAmount
               /// </summary>
               public const int DepositSourceAmount = 30;

               /// <summary>
               /// Property Indexer for DepositFunctionalAmount
               /// </summary>
               public const int DepositFunctionalAmount = 31;

               /// <summary>
               /// Property Indexer for SourceRateFactor
               /// </summary>
               public const int SourceRateFactor = 32;

               /// <summary>
               /// Property Indexer for SourceRateOperator
               /// </summary>
               public const int SourceRateOperator = 33;

               /// <summary>
               /// Property Indexer for SourceSourceCurrency
               /// </summary>
               public const int SourceSourceCurrency = 34;

               /// <summary>
               /// Property Indexer for SourceSourceAmount
               /// </summary>
               public const int SourceSourceAmount = 35;

               /// <summary>
               /// Property Indexer for SourceFunctionalAmount
               /// </summary>
               public const int SourceFunctionalAmount = 36;

               /// <summary>
               /// Property Indexer for TransferCurrencyStatement
               /// </summary>
               public const int TransferCurrencyStatement = 49;

               /// <summary>
               /// Property Indexer for TransferMulticurrency
               /// </summary>
               public const int TransferMulticurrency = 50;

               /// <summary>
               /// Property Indexer for DepositCurrencyStatement
               /// </summary>
               public const int DepositCurrencyStatement = 52;

               /// <summary>
               /// Property Indexer for DepositMulticurrency
               /// </summary>
               public const int DepositMulticurrency = 53;

               /// <summary>
               /// Property Indexer for TransferBankCurrencyDescripti
               /// </summary>
               public const int TransferBankCurrencyDescripti = 55;

               /// <summary>
               /// Property Indexer for DepositBankCurrencyDescriptio
               /// </summary>
               public const int DepositBankCurrencyDescriptio = 56;

               /// <summary>
               /// Property Indexer for FunctionalCurrency
               /// </summary>
               public const int FunctionalCurrency = 57;

               /// <summary>
               /// Property Indexer for PostDate
               /// </summary>
               public const int PostDate = 58;

          }
          #endregion

     }
}
