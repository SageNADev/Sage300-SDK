// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankPostingJournal Constants 
    /// </summary>
	public partial class BankPostingJournal 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "BK0011";

        /// <summary>
        /// Contains list of BankPostingJournal Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for PostingSequence 
        /// </summary>
	    public const string PostingSequence  = "PSTSEQ";
	            /// <summary>
        /// Property for BankCode 
        /// </summary>
	    public const string BankCode  = "BANK";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "NAME";
	            /// <summary>
        /// Property for AddressLine1 
        /// </summary>
	    public const string AddressLine1  = "ADDR1";
	            /// <summary>
        /// Property for AddressLine2 
        /// </summary>
	    public const string AddressLine2  = "ADDR2";
	            /// <summary>
        /// Property for AddressLine3 
        /// </summary>
	    public const string AddressLine3  = "ADDR3";
	            /// <summary>
        /// Property for AddressLine4 
        /// </summary>
	    public const string AddressLine4  = "ADDR4";
	            /// <summary>
        /// Property for City 
        /// </summary>
	    public const string City  = "CITY";
	            /// <summary>
        /// Property for State 
        /// </summary>
	    public const string State  = "STATE";
	            /// <summary>
        /// Property for Country 
        /// </summary>
	    public const string Country  = "COUNTRY";
	            /// <summary>
        /// Property for ZipOrPostalCode 
        /// </summary>
	    public const string ZipOrPostalCode  = "POSTAL";
	            /// <summary>
        /// Property for Contact 
        /// </summary>
	    public const string Contact  = "CONTACT";
	            /// <summary>
        /// Property for PhoneNumber 
        /// </summary>
	    public const string PhoneNumber  = "PHONE";
	            /// <summary>
        /// Property for FaxNumber 
        /// </summary>
	    public const string FaxNumber  = "FAX";
	            /// <summary>
        /// Property for TransitNumber 
        /// </summary>
	    public const string TransitNumber  = "TRANSIT";
	            /// <summary>
        /// Property for MulticurrencySwitch 
        /// </summary>
	    public const string MulticurrencySwitch  = "MULTICUR";
	            /// <summary>
        /// Property for StatementCurrency 
        /// </summary>
	    public const string StatementCurrency  = "CURNSTMT";
	            /// <summary>
        /// Property for InactiveSwitch 
        /// </summary>
	    public const string InactiveSwitch  = "INACTIVE";
	            /// <summary>
        /// Property for DateInactived 
        /// </summary>
	    public const string DateInactived  = "INACTDATE";
	            /// <summary>
        /// Property for BankAccountNumber 
        /// </summary>
	    public const string BankAccountNumber  = "BKACCT";
	            /// <summary>
        /// Property for BankGOrLAccount 
        /// </summary>
	    public const string BankGOrLAccount  = "IDACCT";
	            /// <summary>
        /// Property for BankErrorGOrLAccount 
        /// </summary>
	    public const string BankErrorGOrLAccount  = "IDACCTERR";
	            /// <summary>
        /// Property for ErrorSpread 
        /// </summary>
	    public const string ErrorSpread  = "ERRSPREAD";
	            /// <summary>
        /// Property for LastMaintained 
        /// </summary>
	    public const string LastMaintained  = "LSTMNTND";
	            /// <summary>
        /// Property for FiscalYear 
        /// </summary>
	    public const string FiscalYear  = "RECFY";
	            /// <summary>
        /// Property for FiscalPeriod 
        /// </summary>
	    public const string FiscalPeriod  = "RECFP";
	            /// <summary>
        /// Property for LastFiscalYear 
        /// </summary>
	    public const string LastFiscalYear  = "RECLSTFY";
	            /// <summary>
        /// Property for LastFiscalPeriod 
        /// </summary>
	    public const string LastFiscalPeriod  = "RECLSTFP";
	            /// <summary>
        /// Property for LastReconciliationDate 
        /// </summary>
	    public const string LastReconciliationDate  = "RECLSTDATE";
	            /// <summary>
        /// Property for LastClosingStatementBalance 
        /// </summary>
	    public const string LastClosingStatementBalance  = "RECLSTBAL";
	            /// <summary>
        /// Property for ReconciliationDate 
        /// </summary>
	    public const string ReconciliationDate  = "RECDATE";
	            /// <summary>
        /// Property for StatementDate 
        /// </summary>
	    public const string StatementDate  = "RECSTMTDAT";
	            /// <summary>
        /// Property for ClosingStatementBalance 
        /// </summary>
	    public const string ClosingStatementBalance  = "RECSTMTBAL";
	            /// <summary>
        /// Property for DepositsinTransit 
        /// </summary>
	    public const string DepositsinTransit  = "RECINTRANS";
	            /// <summary>
        /// Property for ChecksOutstanding 
        /// </summary>
	    public const string ChecksOutstanding  = "RECOUTSTND";
	            /// <summary>
        /// Property for BankErrorPendingAmount 
        /// </summary>
	    public const string BankErrorPendingAmount  = "RECBKERRPN";
	            /// <summary>
        /// Property for BankEntriesAmount 
        /// </summary>
	    public const string BankEntriesAmount  = "RECBKENT";
	            /// <summary>
        /// Property for BankErrorAmount 
        /// </summary>
	    public const string BankErrorAmount  = "RECBKERR";
	            /// <summary>
        /// Property for ExchangeAmountGained 
        /// </summary>
	    public const string ExchangeAmountGained  = "RECEXGAIN";
	            /// <summary>
        /// Property for ExchangeAmountLost 
        /// </summary>
	    public const string ExchangeAmountLost  = "RECEXLOSS";
	            /// <summary>
        /// Property for TotalDeposits 
        /// </summary>
	    public const string TotalDeposits  = "RECDEPOSIT";
	            /// <summary>
        /// Property for TotalChecks 
        /// </summary>
	    public const string TotalChecks  = "RECCHECK";
	            /// <summary>
        /// Property for DepositsToFiscalPeriod 
        /// </summary>
	    public const string DepositsToFiscalPeriod  = "RECFCDEP";
	            /// <summary>
        /// Property for ChecksToFiscalPeriod 
        /// </summary>
	    public const string ChecksToFiscalPeriod  = "RECFCCHK";
	            /// <summary>
        /// Property for DepositsInTransitToFiscalPe 
        /// </summary>
	    public const string DepositsInTransitToFiscalPe  = "RECFCDEPIT";
	            /// <summary>
        /// Property for ChecksOutstandingToFiscalPer 
        /// </summary>
	    public const string ChecksOutstandingToFiscalPer  = "RECFCCHKOS";
	            /// <summary>
        /// Property for RecalculateFiscalPeriodData 
        /// </summary>
	    public const string RecalculateFiscalPeriodData  = "RECRECALC";
	            /// <summary>
        /// Property for AdjustedBookBalance 
        /// </summary>
	    public const string AdjustedBookBalance  = "ADJBOOKBAL";
	            /// <summary>
        /// Property for AdjustedStatementBalance 
        /// </summary>
	    public const string AdjustedStatementBalance  = "ADJSTMTBAL";
	            /// <summary>
        /// Property for BankReconciliationBalanced 
        /// </summary>
	    public const string BankReconciliationBalanced  = "BALANCES";
	            /// <summary>
        /// Property for AdjustedBalanceDifference 
        /// </summary>
	    public const string AdjustedBalanceDifference  = "ADJBALDIFF";
	            /// <summary>
        /// Property for NextCheckSerialNumber 
        /// </summary>
	    public const string NextCheckSerialNumber  = "CHKSERIAL";
	            /// <summary>
        /// Property for NextDepositNumber 
        /// </summary>
	    public const string NextDepositNumber  = "NXTDEPOSIT";
	            /// <summary>
        /// Property for NextDepositSerialNumber 
        /// </summary>
	    public const string NextDepositSerialNumber  = "DEPSERIAL";
	            /// <summary>
        /// Property for CurrentBalance 
        /// </summary>
	    public const string CurrentBalance  = "RECAVAIL";
	            /// <summary>
        /// Property for ReconciliationBookBalance 
        /// </summary>
	    public const string ReconciliationBookBalance  = "RECBOOKBAL";
	            /// <summary>
        /// Property for LastStatementDate 
        /// </summary>
	    public const string LastStatementDate  = "RECLSMDATE";
	            /// <summary>
        /// Property for BankEntriesToFiscalPeriod 
        /// </summary>
	    public const string BankEntriesToFiscalPeriod  = "RECFCBKENT";
	            /// <summary>
        /// Property for ExchangeGainToFiscalPeriod 
        /// </summary>
	    public const string ExchangeGainToFiscalPeriod  = "RECFCGAIN";
	            /// <summary>
        /// Property for ExchangeLossToFiscalPeriod 
        /// </summary>
	    public const string ExchangeLossToFiscalPeriod  = "RECFCLOSS";
	            /// <summary>
        /// Property for BankErrorPendingToFiscalPer 
        /// </summary>
	    public const string BankErrorPendingToFiscalPer  = "RECFCERRPN";
	            /// <summary>
        /// Property for BankErrorToFiscalPeriod 
        /// </summary>
	    public const string BankErrorToFiscalPeriod  = "RECFCERR";
	            /// <summary>
        /// Property for ReconciledEntriesToFiscalPer 
        /// </summary>
	    public const string ReconciledEntriesToFiscalPer  = "RECFCENTRE";
	            /// <summary>
        /// Property for CreditCardChargeGOrLAccount 
        /// </summary>
	    public const string CreditCardChargeGOrLAccount  = "IDACCTCCC";
	            /// <summary>
        /// Property for CreditCardChargeSpread 
        /// </summary>
	    public const string CreditCardChargeSpread  = "CCCSPREAD";
	            /// <summary>
        /// Property for ExchangeRateDifferenceSpread 
        /// </summary>
	    public const string ExchangeRateDifferenceSpread  = "EXSPREAD";
	            /// <summary>
        /// Property for TotalWithdrawalBankErrors 
        /// </summary>
	    public const string TotalWithdrawalBankErrors  = "RECWTERR";
	            /// <summary>
        /// Property for TotalWithdrawalWriteOffs 
        /// </summary>
	    public const string TotalWithdrawalWriteOffs  = "RECWTWO";
	            /// <summary>
        /// Property for TotalWithdrawalExchangeGain 
        /// </summary>
	    public const string TotalWithdrawalExchangeGain  = "RECWTGAIN";
	            /// <summary>
        /// Property for TotalWithdrawalExchangeLoss 
        /// </summary>
	    public const string TotalWithdrawalExchangeLoss  = "RECWTLOSS";
	            /// <summary>
        /// Property for TotalWithdrawalCreditCardCha 
        /// </summary>
	    public const string TotalWithdrawalCreditCardCha  = "RECWTCCC";
	            /// <summary>
        /// Property for TotalWithdrawalCleared 
        /// </summary>
	    public const string TotalWithdrawalCleared  = "RECWTCLR";
	            /// <summary>
        /// Property for TotalWithdrawalFunctionalAmou 
        /// </summary>
	    public const string TotalWithdrawalFunctionalAmou  = "RECWTFUNAM";
	            /// <summary>
        /// Property for FiscalWithdrawalBankErrors 
        /// </summary>
	    public const string FiscalWithdrawalBankErrors  = "RECWPERR";
	            /// <summary>
        /// Property for FiscalWithdrawalWriteOffs 
        /// </summary>
	    public const string FiscalWithdrawalWriteOffs  = "RECWPWO";
	            /// <summary>
        /// Property for FiscalWithdrawalExchangeGain 
        /// </summary>
	    public const string FiscalWithdrawalExchangeGain  = "RECWPGAIN";
	            /// <summary>
        /// Property for FiscalWithdrawalExchangeLoss 
        /// </summary>
	    public const string FiscalWithdrawalExchangeLoss  = "RECWPLOSS";
	            /// <summary>
        /// Property for FiscalWithdrawalCreditCardCh 
        /// </summary>
	    public const string FiscalWithdrawalCreditCardCh  = "RECWPCCC";
	            /// <summary>
        /// Property for FiscalWithdrawalCleared 
        /// </summary>
	    public const string FiscalWithdrawalCleared  = "RECWPCLR";
	            /// <summary>
        /// Property for FiscalWithdrawalFunctionalAmo 
        /// </summary>
	    public const string FiscalWithdrawalFunctionalAmo  = "RECWPFUNAM";
	            /// <summary>
        /// Property for TotalDepositBankErrors 
        /// </summary>
	    public const string TotalDepositBankErrors  = "RECDTERR";
	            /// <summary>
        /// Property for TotalDepositWriteOffs 
        /// </summary>
	    public const string TotalDepositWriteOffs  = "RECDTWO";
	            /// <summary>
        /// Property for TotalDepositExchangeGain 
        /// </summary>
	    public const string TotalDepositExchangeGain  = "RECDTGAIN";
	            /// <summary>
        /// Property for TotalDepositExchangeLoss 
        /// </summary>
	    public const string TotalDepositExchangeLoss  = "RECDTLOSS";
	            /// <summary>
        /// Property for TotalDepositCreditCardCharge 
        /// </summary>
	    public const string TotalDepositCreditCardCharge  = "RECDTCCC";
	            /// <summary>
        /// Property for TotalDepositCleared 
        /// </summary>
	    public const string TotalDepositCleared  = "RECDTCLR";
	            /// <summary>
        /// Property for TotalDepositFunctionalAmounts 
        /// </summary>
	    public const string TotalDepositFunctionalAmounts  = "RECDTFUNAM";
	            /// <summary>
        /// Property for FiscalDepositBankErrors 
        /// </summary>
	    public const string FiscalDepositBankErrors  = "RECDPERR";
	            /// <summary>
        /// Property for FiscalDepositWriteOffs 
        /// </summary>
	    public const string FiscalDepositWriteOffs  = "RECDPWO";
	            /// <summary>
        /// Property for FiscalDepositExchangeGain 
        /// </summary>
	    public const string FiscalDepositExchangeGain  = "RECDPGAIN";
	            /// <summary>
        /// Property for FiscalDepositExchangeLoss 
        /// </summary>
	    public const string FiscalDepositExchangeLoss  = "RECDPLOSS";
	            /// <summary>
        /// Property for FiscalDepositCreditCardCharg 
        /// </summary>
	    public const string FiscalDepositCreditCardCharg  = "RECDPCCC";
	            /// <summary>
        /// Property for FiscalDepositCleared 
        /// </summary>
	    public const string FiscalDepositCleared  = "RECDPCLR";
	            /// <summary>
        /// Property for FiscalDepositFunctionalAmount 
        /// </summary>
	    public const string FiscalDepositFunctionalAmount  = "RECDPFUNAM";
	            /// <summary>
        /// Property for BankStatementType 
        /// </summary>
	    public const string BankStatementType  = "CURRTYPE";
	            /// <summary>
        /// Property for TotalWriteOffs 
        /// </summary>
	    public const string TotalWriteOffs  = "RECTWO";
	            /// <summary>
        /// Property for TotalCreditCardCharges 
        /// </summary>
	    public const string TotalCreditCardCharges  = "RECTCCC";
	            /// <summary>
        /// Property for FiscalPeriodWriteOff 
        /// </summary>
	    public const string FiscalPeriodWriteOff  = "RECPWO";
	            /// <summary>
        /// Property for FiscalPeriodCreditCardCharge 
        /// </summary>
	    public const string FiscalPeriodCreditCardCharge  = "RECPCCC";
	            /// <summary>
        /// Property for SumofWithdrawalTotalWriteOf 
        /// </summary>
	    public const string SumofWithdrawalTotalWriteOf  = "RECWTWOSUM";
	            /// <summary>
        /// Property for SumofDepositTotalWriteOffs 
        /// </summary>
	    public const string SumofDepositTotalWriteOffs  = "RECDTWOSUM";
	            /// <summary>
        /// Property for SumofWithdrawalFiscalWriteO 
        /// </summary>
	    public const string SumofWithdrawalFiscalWriteO  = "RECWPWOSUM";
	            /// <summary>
        /// Property for SumofDepositFiscalWriteOffs 
        /// </summary>
	    public const string SumofDepositFiscalWriteOffs  = "RECDPWOSUM";
	            /// <summary>
        /// Property for FunctionalCurrency 
        /// </summary>
	    public const string FunctionalCurrency  = "CURFUNC";
	            /// <summary>
        /// Property for BankSequence 
        /// </summary>
	    public const string BankSequence  = "BANKSEQ";
	            /// <summary>
        /// Property for TaxGroupCode 
        /// </summary>
	    public const string TaxGroupCode  = "CODETXGRP";
	            /// <summary>
        /// Property for TaxAuthorization1 
        /// </summary>
	    public const string TaxAuthorization1  = "TAXAUTH1";
	            /// <summary>
        /// Property for TaxAuthorization2 
        /// </summary>
	    public const string TaxAuthorization2  = "TAXAUTH2";
	            /// <summary>
        /// Property for TaxAuthorization3 
        /// </summary>
	    public const string TaxAuthorization3  = "TAXAUTH3";
	            /// <summary>
        /// Property for TaxAuthorization4 
        /// </summary>
	    public const string TaxAuthorization4  = "TAXAUTH4";
	            /// <summary>
        /// Property for TaxAuthorization5 
        /// </summary>
	    public const string TaxAuthorization5  = "TAXAUTH5";
	            /// <summary>
        /// Property for VendorTaxClass1 
        /// </summary>
	    public const string VendorTaxClass1  = "TXVCLSS1";
	            /// <summary>
        /// Property for VendorTaxClass2 
        /// </summary>
	    public const string VendorTaxClass2  = "TXVCLSS2";
	            /// <summary>
        /// Property for VendorTaxClass3 
        /// </summary>
	    public const string VendorTaxClass3  = "TXVCLSS3";
	            /// <summary>
        /// Property for VendorTaxClass4 
        /// </summary>
	    public const string VendorTaxClass4  = "TXVCLSS4";
	            /// <summary>
        /// Property for VendorTaxClass5 
        /// </summary>
	    public const string VendorTaxClass5  = "TXVCLSS5";
	            /// <summary>
        /// Property for WithdrawalsClearedToCurrent 
        /// </summary>
	    public const string WithdrawalsClearedToCurrent  = "RECWRCLR";
	            /// <summary>
        /// Property for DepositsClearedToCurrent 
        /// </summary>
	    public const string DepositsClearedToCurrent  = "RECDRCLR";
	            /// <summary>
        /// Property for PostingDate 
        /// </summary>
	    public const string PostingDate  = "POSTDATE";
	            /// <summary>
        /// Property for LastReconciliationPostingDate 
        /// </summary>
	    public const string LastReconciliationPostingDate  = "LSTPOSTDAT";
	            /// <summary>
        /// Property for DefaultReconciliationDescripti 
        /// </summary>
	    public const string DefaultReconciliationDescripti  = "RECCOMMENT";
	            /// <summary>
        /// Property for ChecksClearedwithExchRateD 
        /// </summary>
	    public const string ChecksClearedwithExchRateD  = "RECWEXDIFF";
	            /// <summary>
        /// Property for DepositClearedwithExchangeRa 
        /// </summary>
	    public const string DepositClearedwithExchangeRa  = "RECDEXDIFF";
	            /// <summary>
        /// Property for LastAvailableStatementBalance 
        /// </summary>
	    public const string LastAvailableStatementBalance  = "LSTSTMTBAL";
	            /// <summary>
        /// Property for WithdrawalsClearedToFuture 
        /// </summary>
	    public const string WithdrawalsClearedToFuture  = "RECWFCLR";
	            /// <summary>
        /// Property for DepositsClearedToFuture 
        /// </summary>
	    public const string DepositsClearedToFuture  = "RECDFCLR";
	            /// <summary>
        /// Property for FiscalRemainingOutStanding 
        /// </summary>
	    public const string FiscalRemainingOutStanding  = "RECWPREM";
	            /// <summary>
        /// Property for FiscalRemainingInTransit 
        /// </summary>
	    public const string FiscalRemainingInTransit  = "RECDPREM";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of BankPostingJournal Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for PostingSequence 
        /// </summary>
	    public const int PostingSequence  = 1;
	             /// <summary>
        /// Property Indexer for BankCode 
        /// </summary>
	    public const int BankCode  = 2;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 3;
	             /// <summary>
        /// Property Indexer for AddressLine1 
        /// </summary>
	    public const int AddressLine1  = 4;
	             /// <summary>
        /// Property Indexer for AddressLine2 
        /// </summary>
	    public const int AddressLine2  = 5;
	             /// <summary>
        /// Property Indexer for AddressLine3 
        /// </summary>
	    public const int AddressLine3  = 6;
	             /// <summary>
        /// Property Indexer for AddressLine4 
        /// </summary>
	    public const int AddressLine4  = 7;
	             /// <summary>
        /// Property Indexer for City 
        /// </summary>
	    public const int City  = 8;
	             /// <summary>
        /// Property Indexer for State 
        /// </summary>
	    public const int State  = 9;
	             /// <summary>
        /// Property Indexer for Country 
        /// </summary>
	    public const int Country  = 10;
	             /// <summary>
        /// Property Indexer for ZipOrPostalCode 
        /// </summary>
	    public const int ZipOrPostalCode  = 11;
	             /// <summary>
        /// Property Indexer for Contact 
        /// </summary>
	    public const int Contact  = 12;
	             /// <summary>
        /// Property Indexer for PhoneNumber 
        /// </summary>
	    public const int PhoneNumber  = 15;
	             /// <summary>
        /// Property Indexer for FaxNumber 
        /// </summary>
	    public const int FaxNumber  = 16;
	             /// <summary>
        /// Property Indexer for TransitNumber 
        /// </summary>
	    public const int TransitNumber  = 17;
	             /// <summary>
        /// Property Indexer for MulticurrencySwitch 
        /// </summary>
	    public const int MulticurrencySwitch  = 18;
	             /// <summary>
        /// Property Indexer for StatementCurrency 
        /// </summary>
	    public const int StatementCurrency  = 19;
	             /// <summary>
        /// Property Indexer for InactiveSwitch 
        /// </summary>
	    public const int InactiveSwitch  = 20;
	             /// <summary>
        /// Property Indexer for DateInactived 
        /// </summary>
	    public const int DateInactived  = 21;
	             /// <summary>
        /// Property Indexer for BankAccountNumber 
        /// </summary>
	    public const int BankAccountNumber  = 22;
	             /// <summary>
        /// Property Indexer for BankGOrLAccount 
        /// </summary>
	    public const int BankGOrLAccount  = 24;
	             /// <summary>
        /// Property Indexer for BankErrorGOrLAccount 
        /// </summary>
	    public const int BankErrorGOrLAccount  = 25;
	             /// <summary>
        /// Property Indexer for ErrorSpread 
        /// </summary>
	    public const int ErrorSpread  = 26;
	             /// <summary>
        /// Property Indexer for LastMaintained 
        /// </summary>
	    public const int LastMaintained  = 27;
	             /// <summary>
        /// Property Indexer for FiscalYear 
        /// </summary>
	    public const int FiscalYear  = 28;
	             /// <summary>
        /// Property Indexer for FiscalPeriod 
        /// </summary>
	    public const int FiscalPeriod  = 29;
	             /// <summary>
        /// Property Indexer for LastFiscalYear 
        /// </summary>
	    public const int LastFiscalYear  = 30;
	             /// <summary>
        /// Property Indexer for LastFiscalPeriod 
        /// </summary>
	    public const int LastFiscalPeriod  = 31;
	             /// <summary>
        /// Property Indexer for LastReconciliationDate 
        /// </summary>
	    public const int LastReconciliationDate  = 32;
	             /// <summary>
        /// Property Indexer for LastClosingStatementBalance 
        /// </summary>
	    public const int LastClosingStatementBalance  = 33;
	             /// <summary>
        /// Property Indexer for ReconciliationDate 
        /// </summary>
	    public const int ReconciliationDate  = 34;
	             /// <summary>
        /// Property Indexer for StatementDate 
        /// </summary>
	    public const int StatementDate  = 35;
	             /// <summary>
        /// Property Indexer for ClosingStatementBalance 
        /// </summary>
	    public const int ClosingStatementBalance  = 36;
	             /// <summary>
        /// Property Indexer for DepositsinTransit 
        /// </summary>
	    public const int DepositsinTransit  = 37;
	             /// <summary>
        /// Property Indexer for ChecksOutstanding 
        /// </summary>
	    public const int ChecksOutstanding  = 38;
	             /// <summary>
        /// Property Indexer for BankErrorPendingAmount 
        /// </summary>
	    public const int BankErrorPendingAmount  = 39;
	             /// <summary>
        /// Property Indexer for BankEntriesAmount 
        /// </summary>
	    public const int BankEntriesAmount  = 40;
	             /// <summary>
        /// Property Indexer for BankErrorAmount 
        /// </summary>
	    public const int BankErrorAmount  = 41;
	             /// <summary>
        /// Property Indexer for ExchangeAmountGained 
        /// </summary>
	    public const int ExchangeAmountGained  = 42;
	             /// <summary>
        /// Property Indexer for ExchangeAmountLost 
        /// </summary>
	    public const int ExchangeAmountLost  = 43;
	             /// <summary>
        /// Property Indexer for TotalDeposits 
        /// </summary>
	    public const int TotalDeposits  = 44;
	             /// <summary>
        /// Property Indexer for TotalChecks 
        /// </summary>
	    public const int TotalChecks  = 45;
	             /// <summary>
        /// Property Indexer for DepositsToFiscalPeriod 
        /// </summary>
	    public const int DepositsToFiscalPeriod  = 46;
	             /// <summary>
        /// Property Indexer for ChecksToFiscalPeriod 
        /// </summary>
	    public const int ChecksToFiscalPeriod  = 47;
	             /// <summary>
        /// Property Indexer for DepositsInTransitToFiscalPe 
        /// </summary>
	    public const int DepositsInTransitToFiscalPe  = 48;
	             /// <summary>
        /// Property Indexer for ChecksOutstandingToFiscalPer 
        /// </summary>
	    public const int ChecksOutstandingToFiscalPer  = 49;
	             /// <summary>
        /// Property Indexer for RecalculateFiscalPeriodData 
        /// </summary>
	    public const int RecalculateFiscalPeriodData  = 50;
	             /// <summary>
        /// Property Indexer for AdjustedBookBalance 
        /// </summary>
	    public const int AdjustedBookBalance  = 51;
	             /// <summary>
        /// Property Indexer for AdjustedStatementBalance 
        /// </summary>
	    public const int AdjustedStatementBalance  = 52;
	             /// <summary>
        /// Property Indexer for BankReconciliationBalanced 
        /// </summary>
	    public const int BankReconciliationBalanced  = 53;
	             /// <summary>
        /// Property Indexer for AdjustedBalanceDifference 
        /// </summary>
	    public const int AdjustedBalanceDifference  = 54;
	             /// <summary>
        /// Property Indexer for NextCheckSerialNumber 
        /// </summary>
	    public const int NextCheckSerialNumber  = 55;
	             /// <summary>
        /// Property Indexer for NextDepositNumber 
        /// </summary>
	    public const int NextDepositNumber  = 56;
	             /// <summary>
        /// Property Indexer for NextDepositSerialNumber 
        /// </summary>
	    public const int NextDepositSerialNumber  = 57;
	             /// <summary>
        /// Property Indexer for CurrentBalance 
        /// </summary>
	    public const int CurrentBalance  = 58;
	             /// <summary>
        /// Property Indexer for ReconciliationBookBalance 
        /// </summary>
	    public const int ReconciliationBookBalance  = 59;
	             /// <summary>
        /// Property Indexer for LastStatementDate 
        /// </summary>
	    public const int LastStatementDate  = 60;
	             /// <summary>
        /// Property Indexer for BankEntriesToFiscalPeriod 
        /// </summary>
	    public const int BankEntriesToFiscalPeriod  = 61;
	             /// <summary>
        /// Property Indexer for ExchangeGainToFiscalPeriod 
        /// </summary>
	    public const int ExchangeGainToFiscalPeriod  = 62;
	             /// <summary>
        /// Property Indexer for ExchangeLossToFiscalPeriod 
        /// </summary>
	    public const int ExchangeLossToFiscalPeriod  = 63;
	             /// <summary>
        /// Property Indexer for BankErrorPendingToFiscalPer 
        /// </summary>
	    public const int BankErrorPendingToFiscalPer  = 64;
	             /// <summary>
        /// Property Indexer for BankErrorToFiscalPeriod 
        /// </summary>
	    public const int BankErrorToFiscalPeriod  = 65;
	             /// <summary>
        /// Property Indexer for ReconciledEntriesToFiscalPer 
        /// </summary>
	    public const int ReconciledEntriesToFiscalPer  = 66;
	             /// <summary>
        /// Property Indexer for CreditCardChargeGOrLAccount 
        /// </summary>
	    public const int CreditCardChargeGOrLAccount  = 67;
	             /// <summary>
        /// Property Indexer for CreditCardChargeSpread 
        /// </summary>
	    public const int CreditCardChargeSpread  = 68;
	             /// <summary>
        /// Property Indexer for ExchangeRateDifferenceSpread 
        /// </summary>
	    public const int ExchangeRateDifferenceSpread  = 69;
	             /// <summary>
        /// Property Indexer for TotalWithdrawalBankErrors 
        /// </summary>
	    public const int TotalWithdrawalBankErrors  = 70;
	             /// <summary>
        /// Property Indexer for TotalWithdrawalWriteOffs 
        /// </summary>
	    public const int TotalWithdrawalWriteOffs  = 71;
	             /// <summary>
        /// Property Indexer for TotalWithdrawalExchangeGain 
        /// </summary>
	    public const int TotalWithdrawalExchangeGain  = 72;
	             /// <summary>
        /// Property Indexer for TotalWithdrawalExchangeLoss 
        /// </summary>
	    public const int TotalWithdrawalExchangeLoss  = 73;
	             /// <summary>
        /// Property Indexer for TotalWithdrawalCreditCardCha 
        /// </summary>
	    public const int TotalWithdrawalCreditCardCha  = 74;
	             /// <summary>
        /// Property Indexer for TotalWithdrawalCleared 
        /// </summary>
	    public const int TotalWithdrawalCleared  = 75;
	             /// <summary>
        /// Property Indexer for TotalWithdrawalFunctionalAmou 
        /// </summary>
	    public const int TotalWithdrawalFunctionalAmou  = 76;
	             /// <summary>
        /// Property Indexer for FiscalWithdrawalBankErrors 
        /// </summary>
	    public const int FiscalWithdrawalBankErrors  = 77;
	             /// <summary>
        /// Property Indexer for FiscalWithdrawalWriteOffs 
        /// </summary>
	    public const int FiscalWithdrawalWriteOffs  = 78;
	             /// <summary>
        /// Property Indexer for FiscalWithdrawalExchangeGain 
        /// </summary>
	    public const int FiscalWithdrawalExchangeGain  = 79;
	             /// <summary>
        /// Property Indexer for FiscalWithdrawalExchangeLoss 
        /// </summary>
	    public const int FiscalWithdrawalExchangeLoss  = 80;
	             /// <summary>
        /// Property Indexer for FiscalWithdrawalCreditCardCh 
        /// </summary>
	    public const int FiscalWithdrawalCreditCardCh  = 81;
	             /// <summary>
        /// Property Indexer for FiscalWithdrawalCleared 
        /// </summary>
	    public const int FiscalWithdrawalCleared  = 82;
	             /// <summary>
        /// Property Indexer for FiscalWithdrawalFunctionalAmo 
        /// </summary>
	    public const int FiscalWithdrawalFunctionalAmo  = 83;
	             /// <summary>
        /// Property Indexer for TotalDepositBankErrors 
        /// </summary>
	    public const int TotalDepositBankErrors  = 84;
	             /// <summary>
        /// Property Indexer for TotalDepositWriteOffs 
        /// </summary>
	    public const int TotalDepositWriteOffs  = 85;
	             /// <summary>
        /// Property Indexer for TotalDepositExchangeGain 
        /// </summary>
	    public const int TotalDepositExchangeGain  = 86;
	             /// <summary>
        /// Property Indexer for TotalDepositExchangeLoss 
        /// </summary>
	    public const int TotalDepositExchangeLoss  = 87;
	             /// <summary>
        /// Property Indexer for TotalDepositCreditCardCharge 
        /// </summary>
	    public const int TotalDepositCreditCardCharge  = 88;
	             /// <summary>
        /// Property Indexer for TotalDepositCleared 
        /// </summary>
	    public const int TotalDepositCleared  = 89;
	             /// <summary>
        /// Property Indexer for TotalDepositFunctionalAmounts 
        /// </summary>
	    public const int TotalDepositFunctionalAmounts  = 90;
	             /// <summary>
        /// Property Indexer for FiscalDepositBankErrors 
        /// </summary>
	    public const int FiscalDepositBankErrors  = 91;
	             /// <summary>
        /// Property Indexer for FiscalDepositWriteOffs 
        /// </summary>
	    public const int FiscalDepositWriteOffs  = 92;
	             /// <summary>
        /// Property Indexer for FiscalDepositExchangeGain 
        /// </summary>
	    public const int FiscalDepositExchangeGain  = 93;
	             /// <summary>
        /// Property Indexer for FiscalDepositExchangeLoss 
        /// </summary>
	    public const int FiscalDepositExchangeLoss  = 94;
	             /// <summary>
        /// Property Indexer for FiscalDepositCreditCardCharg 
        /// </summary>
	    public const int FiscalDepositCreditCardCharg  = 95;
	             /// <summary>
        /// Property Indexer for FiscalDepositCleared 
        /// </summary>
	    public const int FiscalDepositCleared  = 96;
	             /// <summary>
        /// Property Indexer for FiscalDepositFunctionalAmount 
        /// </summary>
	    public const int FiscalDepositFunctionalAmount  = 97;
	             /// <summary>
        /// Property Indexer for BankStatementType 
        /// </summary>
	    public const int BankStatementType  = 98;
	             /// <summary>
        /// Property Indexer for TotalWriteOffs 
        /// </summary>
	    public const int TotalWriteOffs  = 99;
	             /// <summary>
        /// Property Indexer for TotalCreditCardCharges 
        /// </summary>
	    public const int TotalCreditCardCharges  = 100;
	             /// <summary>
        /// Property Indexer for FiscalPeriodWriteOff 
        /// </summary>
	    public const int FiscalPeriodWriteOff  = 101;
	             /// <summary>
        /// Property Indexer for FiscalPeriodCreditCardCharge 
        /// </summary>
	    public const int FiscalPeriodCreditCardCharge  = 102;
	             /// <summary>
        /// Property Indexer for SumofWithdrawalTotalWriteOf 
        /// </summary>
	    public const int SumofWithdrawalTotalWriteOf  = 103;
	             /// <summary>
        /// Property Indexer for SumofDepositTotalWriteOffs 
        /// </summary>
	    public const int SumofDepositTotalWriteOffs  = 104;
	             /// <summary>
        /// Property Indexer for SumofWithdrawalFiscalWriteO 
        /// </summary>
	    public const int SumofWithdrawalFiscalWriteO  = 105;
	             /// <summary>
        /// Property Indexer for SumofDepositFiscalWriteOffs 
        /// </summary>
	    public const int SumofDepositFiscalWriteOffs  = 106;
	             /// <summary>
        /// Property Indexer for FunctionalCurrency 
        /// </summary>
	    public const int FunctionalCurrency  = 107;
	             /// <summary>
        /// Property Indexer for BankSequence 
        /// </summary>
	    public const int BankSequence  = 108;
	             /// <summary>
        /// Property Indexer for TaxGroupCode 
        /// </summary>
	    public const int TaxGroupCode  = 109;
	             /// <summary>
        /// Property Indexer for TaxAuthorization1 
        /// </summary>
	    public const int TaxAuthorization1  = 110;
	             /// <summary>
        /// Property Indexer for TaxAuthorization2 
        /// </summary>
	    public const int TaxAuthorization2  = 111;
	             /// <summary>
        /// Property Indexer for TaxAuthorization3 
        /// </summary>
	    public const int TaxAuthorization3  = 112;
	             /// <summary>
        /// Property Indexer for TaxAuthorization4 
        /// </summary>
	    public const int TaxAuthorization4  = 113;
	             /// <summary>
        /// Property Indexer for TaxAuthorization5 
        /// </summary>
	    public const int TaxAuthorization5  = 114;
	             /// <summary>
        /// Property Indexer for VendorTaxClass1 
        /// </summary>
	    public const int VendorTaxClass1  = 115;
	             /// <summary>
        /// Property Indexer for VendorTaxClass2 
        /// </summary>
	    public const int VendorTaxClass2  = 116;
	             /// <summary>
        /// Property Indexer for VendorTaxClass3 
        /// </summary>
	    public const int VendorTaxClass3  = 117;
	             /// <summary>
        /// Property Indexer for VendorTaxClass4 
        /// </summary>
	    public const int VendorTaxClass4  = 118;
	             /// <summary>
        /// Property Indexer for VendorTaxClass5 
        /// </summary>
	    public const int VendorTaxClass5  = 119;
	             /// <summary>
        /// Property Indexer for WithdrawalsClearedToCurrent 
        /// </summary>
	    public const int WithdrawalsClearedToCurrent  = 120;
	             /// <summary>
        /// Property Indexer for DepositsClearedToCurrent 
        /// </summary>
	    public const int DepositsClearedToCurrent  = 121;
	             /// <summary>
        /// Property Indexer for PostingDate 
        /// </summary>
	    public const int PostingDate  = 122;
	             /// <summary>
        /// Property Indexer for LastReconciliationPostingDate 
        /// </summary>
	    public const int LastReconciliationPostingDate  = 123;
	             /// <summary>
        /// Property Indexer for DefaultReconciliationDescripti 
        /// </summary>
	    public const int DefaultReconciliationDescripti  = 124;
	             /// <summary>
        /// Property Indexer for ChecksClearedwithExchRateD 
        /// </summary>
	    public const int ChecksClearedwithExchRateD  = 125;
	             /// <summary>
        /// Property Indexer for DepositClearedwithExchangeRa 
        /// </summary>
	    public const int DepositClearedwithExchangeRa  = 126;
	             /// <summary>
        /// Property Indexer for LastAvailableStatementBalance 
        /// </summary>
	    public const int LastAvailableStatementBalance  = 127;
	             /// <summary>
        /// Property Indexer for WithdrawalsClearedToFuture 
        /// </summary>
	    public const int WithdrawalsClearedToFuture  = 128;
	             /// <summary>
        /// Property Indexer for DepositsClearedToFuture 
        /// </summary>
	    public const int DepositsClearedToFuture  = 129;
	             /// <summary>
        /// Property Indexer for FiscalRemainingOutStanding 
        /// </summary>
	    public const int FiscalRemainingOutStanding  = 197;
	             /// <summary>
        /// Property Indexer for FiscalRemainingInTransit 
        /// </summary>
	    public const int FiscalRemainingInTransit  = 198;
	     
        #endregion
	    }

	
	}
}
	