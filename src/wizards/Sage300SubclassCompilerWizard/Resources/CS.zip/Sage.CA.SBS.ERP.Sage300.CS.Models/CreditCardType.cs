// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
	public partial class CreditCardType : ModelBase
	{
  		/// <summary>
        /// Gets or sets CreditCardType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CreditCardType", ResourceType = typeof(BankCreditCardTypeResx))]
 		[ViewField(Name = Fields.CreditCardTypeName, Id = Index.CreditCardTypeName, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
 		public string CreditCardTypeName {get; set;}
		 
  		/// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(BankCreditCardTypeResx))]
 		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
 		public string Description {get; set;}
		 
  		/// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(BankCreditCardTypeResx))]
 		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
 		public Status Status {get; set;}
		
		/// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(BankCreditCardTypeResx))]
		[ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime LastMaintained {get; set;}
	
		/// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(BankCreditCardTypeResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate {get; set;}

        /// <summary>
        /// Gets Status string value
        /// </summary>
        [IgnoreExportImport]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }
	}
}
