/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for WithholdingTaxRate
    /// </summary>
    public partial class WithholdingTaxRate : ModelBase
    {
        /// <summary>
        /// Gets or sets TaxAuthority
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionType", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets WithholdingTaxBase
        /// </summary>
        [Display(Name = "WithholdingTaxBase", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.WithholdingTaxBase, Id = Index.WithholdingTaxBase, FieldType = EntityFieldType.Int, Size = 2)]
        public WithholdingTaxBase WithholdingTaxBase { get; set; }

        /// <summary>
        /// Gets or sets Num1099CPRSCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Num1099CPRSCode", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.Num1099CPRSCode, Id = Index.Num1099CPRSCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Num1099CPRSCode { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass1Rate, Id = Index.BuyerClass1ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass2Rate, Id = Index.BuyerClass1ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass3Rate, Id = Index.BuyerClass1ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass4Rate, Id = Index.BuyerClass1ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass5Rate, Id = Index.BuyerClass1ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass6Rate, Id = Index.BuyerClass1ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass7Rate, Id = Index.BuyerClass1ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass8Rate, Id = Index.BuyerClass1ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass9Rate, Id = Index.BuyerClass1ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass1ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass1ItemClass10Rate, Id = Index.BuyerClass1ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass1ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass1Rate, Id = Index.BuyerClass2ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass2Rate, Id = Index.BuyerClass2ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass3Rate, Id = Index.BuyerClass2ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass4Rate, Id = Index.BuyerClass2ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass5Rate, Id = Index.BuyerClass2ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass6Rate, Id = Index.BuyerClass2ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass7Rate, Id = Index.BuyerClass2ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass8Rate, Id = Index.BuyerClass2ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass9Rate, Id = Index.BuyerClass2ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass2ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass2ItemClass10Rate, Id = Index.BuyerClass2ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass2ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass1Rate, Id = Index.BuyerClass3ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass2Rate, Id = Index.BuyerClass3ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass3Rate, Id = Index.BuyerClass3ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass4Rate, Id = Index.BuyerClass3ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass5Rate, Id = Index.BuyerClass3ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass6Rate, Id = Index.BuyerClass3ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass7Rate, Id = Index.BuyerClass3ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass8Rate, Id = Index.BuyerClass3ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass9Rate, Id = Index.BuyerClass3ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass3ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass3ItemClass10Rate, Id = Index.BuyerClass3ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass3ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass1Rate, Id = Index.BuyerClass4ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass2Rate, Id = Index.BuyerClass4ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass3Rate, Id = Index.BuyerClass4ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass4Rate, Id = Index.BuyerClass4ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass5Rate, Id = Index.BuyerClass4ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass6Rate, Id = Index.BuyerClass4ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass7Rate, Id = Index.BuyerClass4ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass8Rate, Id = Index.BuyerClass4ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass9Rate, Id = Index.BuyerClass4ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass4ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass4ItemClass10Rate, Id = Index.BuyerClass4ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass4ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass1Rate, Id = Index.BuyerClass5ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass2Rate, Id = Index.BuyerClass5ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass3Rate, Id = Index.BuyerClass5ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass4Rate, Id = Index.BuyerClass5ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass5Rate, Id = Index.BuyerClass5ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass6Rate, Id = Index.BuyerClass5ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass7Rate, Id = Index.BuyerClass5ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass8Rate, Id = Index.BuyerClass5ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass9Rate, Id = Index.BuyerClass5ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass5ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass5ItemClass10Rate, Id = Index.BuyerClass5ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass5ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass1Rate, Id = Index.BuyerClass6ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass2Rate, Id = Index.BuyerClass6ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass3Rate, Id = Index.BuyerClass6ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass4Rate, Id = Index.BuyerClass6ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass5Rate, Id = Index.BuyerClass6ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass6Rate, Id = Index.BuyerClass6ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass7Rate, Id = Index.BuyerClass6ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass8Rate, Id = Index.BuyerClass6ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass9Rate, Id = Index.BuyerClass6ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass6ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass6ItemClass10Rate, Id = Index.BuyerClass6ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass6ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass1Rate, Id = Index.BuyerClass7ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass2Rate, Id = Index.BuyerClass7ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass3Rate, Id = Index.BuyerClass7ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass4Rate, Id = Index.BuyerClass7ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass5Rate, Id = Index.BuyerClass7ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass6Rate, Id = Index.BuyerClass7ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass7Rate, Id = Index.BuyerClass7ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass8Rate, Id = Index.BuyerClass7ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass9Rate, Id = Index.BuyerClass7ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass7ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass7ItemClass10Rate, Id = Index.BuyerClass7ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass7ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass1Rate, Id = Index.BuyerClass8ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass2Rate, Id = Index.BuyerClass8ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass3Rate, Id = Index.BuyerClass8ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass4Rate, Id = Index.BuyerClass8ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass5Rate, Id = Index.BuyerClass8ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass6Rate, Id = Index.BuyerClass8ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass7Rate, Id = Index.BuyerClass8ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass8Rate, Id = Index.BuyerClass8ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass9Rate, Id = Index.BuyerClass8ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass8ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass8ItemClass10Rate, Id = Index.BuyerClass8ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass8ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass1Rate, Id = Index.BuyerClass9ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass2Rate, Id = Index.BuyerClass9ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass3Rate, Id = Index.BuyerClass9ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass4Rate, Id = Index.BuyerClass9ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass5Rate, Id = Index.BuyerClass9ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass6Rate, Id = Index.BuyerClass9ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass7Rate, Id = Index.BuyerClass9ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass8Rate, Id = Index.BuyerClass9ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass9Rate, Id = Index.BuyerClass9ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass9ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass9ItemClass10Rate, Id = Index.BuyerClass9ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass9ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass1Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass1Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass1Rate, Id = Index.BuyerClass10ItemClass1Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass1Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass2Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass2Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass2Rate, Id = Index.BuyerClass10ItemClass2Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass2Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass3Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass3Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass3Rate, Id = Index.BuyerClass10ItemClass3Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass3Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass4Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass4Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass4Rate, Id = Index.BuyerClass10ItemClass4Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass4Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass5Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass5Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass5Rate, Id = Index.BuyerClass10ItemClass5Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass5Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass6Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass6Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass6Rate, Id = Index.BuyerClass10ItemClass6Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass6Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass7Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass7Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass7Rate, Id = Index.BuyerClass10ItemClass7Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass7Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass8Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass8Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass8Rate, Id = Index.BuyerClass10ItemClass8Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass8Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass9Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass9Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass9Rate, Id = Index.BuyerClass10ItemClass9Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass9Rate { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass10Rate
        /// </summary>
        [Display(Name = "BuyerClass10ItemClass10Rate", ResourceType = typeof (WithholdingTaxRateResx))]
        [ViewField(Name = Fields.BuyerClass10ItemClass10Rate, Id = Index.BuyerClass10ItemClass10Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal BuyerClass10ItemClass10Rate { get; set; }

        /// <summary>
        /// Gets or sets WithholdingTaxAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WithholdingTaxAccount", ResourceType = typeof(WithholdingTaxRateResx))]
        [ViewField(Name = Fields.WithholdingTaxAccount, Id = Index.WithholdingTaxAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string WithholdingTaxAccount { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        public string TransactionTypeString => EnumUtility.GetStringValue(TransactionType);

        /// <summary>
        /// Gets WithholdingTaxBase string value
        /// </summary>
        public string WithholdingTaxBaseString => EnumUtility.GetStringValue(WithholdingTaxBase);

        #endregion
    }
}
