﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of properties for Address
    /// </summary>
    public class Address : ModelBase
    {
        /// <summary>
        ///  Gets or sets AddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Address", ResourceType = typeof (CompanyProfileResx))]
        public string AddressLine1 { get; set; }

        /// <summary>
        ///  Gets or sets AddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Address2", ResourceType = typeof (CompanyProfileResx))]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Address3", ResourceType = typeof (CompanyProfileResx))]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Address4", ResourceType = typeof (CompanyProfileResx))]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof (CompanyProfileResx))]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StateProv", ResourceType = typeof (CompanyProfileResx))]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets ZipCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ZpPostal", ResourceType = typeof (CompanyProfileResx))]
        public string ZipCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof (CompanyProfileResx))]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Phone Number
        /// </summary>
        [Display(Name = "PhoneNumber", ResourceType = typeof (CompanyProfileResx))]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets Fax Number
        /// </summary>
        [Display(Name = "ContactFax", ResourceType = typeof (CompanyProfileResx))]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof (CompanyProfileResx))]
        public string Contact { get; set; }
    }
}