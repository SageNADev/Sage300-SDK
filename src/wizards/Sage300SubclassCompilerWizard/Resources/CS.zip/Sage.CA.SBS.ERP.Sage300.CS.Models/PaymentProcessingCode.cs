﻿using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class PaymentProcessingCode : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets ProcessingCode 
        /// </summary>
        [Key]
        [Display(Name = "ProcessingCode", ResourceType = typeof(PaymentProcessingCodeResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ProcessingCode { get; set; }
		 
  		/// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(PaymentProcessingCodeResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Description {get; set;}
		 
  		/// <summary>
        /// Gets or sets Bank 
        /// </summary>
        [Display(Name = "Bank", ResourceType = typeof(PaymentProcessingCodeResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string Bank {get; set;}
		 
  		/// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [Display(Name = "CurrencyCode", ResourceType = typeof(PaymentProcessingCodeResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string CurrencyCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets MerchantID 
        /// </summary>
        [Display(Name = "MerchantID", ResourceType = typeof(PaymentProcessingCodeResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyNumeric, ErrorMessageResourceName = "OnlyNumbersMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string MerchantID {get; set;}

        /// <summary>
        /// Binary field
        /// </summary>
        public byte[] MerchantInformation { get; set; }
		
  		/// <summary>
        /// Gets or sets CurrencyDescription 
        /// </summary>
        [Display(Name = "CurrencyDescription", ResourceType = typeof(PaymentProcessingCodeResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string CurrencyDescription {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankDescription 
        /// </summary>
        [Display(Name = "BankDescription", ResourceType = typeof(PaymentProcessingCodeResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankDescription {get; set;}
		 
  		/// <summary>
        /// Gets or sets MerchantKey 
        /// </summary>
        [Display(Name = "MerchantKey", ResourceType = typeof(PaymentProcessingCodeResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string MerchantKey {get; set;}

        /// <summary>
        /// Home currency for single currency company
        /// </summary>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Multi currency indicator
        /// </summary>
        public bool MultiCurrency { get; set; }
	
	}
}

