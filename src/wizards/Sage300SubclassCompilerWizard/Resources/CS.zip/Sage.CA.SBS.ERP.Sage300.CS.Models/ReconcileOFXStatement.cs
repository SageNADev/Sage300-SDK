// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. 

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Model for ReconcileOFXStatement
    /// </summary>
    public partial class ReconcileOFXStatement : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public ReconcileOFXStatement()
        {
            ImportOFXStatement = new EnumerableResponse<ImportOFXStatement>();
            ReconcileOrder = new List<MatchDepositsBy>();
            DeleteList= new List<string>();
        }

        /// <summary>
        /// Property for Operation 
        /// </summary>
        [ViewField(Name = Fields.Operation, Id = Index.Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public OperationType Operation { get; set; }

        /// <summary>
        /// Property for Mode 
        /// </summary>
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public Mode Mode { get; set; }

        /// <summary>
        /// Property for BankCode 
        /// </summary>
        [Display(Name = "BankCode", ResourceType = typeof(ReconcileOFXStatementResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceType = typeof(AnnotationsResx),ErrorMessageResourceName = "AlphaNumeric")]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Property for Number 
        /// </summary>
        [ViewField(Name = Fields.Number, Id = Index.Number, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal Number { get; set; }

        /// <summary>
        /// Property for SerialNumber 
        /// </summary>
        [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Property for LineNumber 
        /// </summary>
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineNumber { get; set; }

        /// <summary>
        /// Property for OFXID 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.OFXID, Id = Index.OFXID, FieldType = EntityFieldType.Char, Size = 50)]
        public string OFXID { get; set; }

        /// <summary>
        /// Property for UnmatUniqueID 
        /// </summary>
        [ViewField(Name = Fields.UnmatUniqueID, Id = Index.UnmatUniqueID, FieldType = EntityFieldType.Long, Size = 4)]
        public long UnmatUniqueID { get; set; }

        /// <summary>
        /// Property for FromBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromBank, Id = Index.FromBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string FromBank { get; set; }

        /// <summary>
        /// Gets or sets ToBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToBank, Id = Index.ToBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string ToBank { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Property for FiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Property for ReconciliationDate 
        /// </summary>
        [Display(Name = "ReconciliationDate", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ? ReconciliationDate { get; set; }

        /// <summary>
        /// Property for ReconciliationCutoffDate 
        /// </summary>
        [Display(Name = "CutOffDate", ResourceType = typeof(ReconcileOFXStatementResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ? ReconciliationCutoffDate { get; set; }

        /// <summary>
        /// Property for TransactionsMatched 
        /// </summary>
        [ViewField(Name = Fields.TransactionsMatched, Id = Index.TransactionsMatched, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionsMatched { get; set; }

        /// <summary>
        /// Property for TotalTransactionsProcessed 
        /// </summary>
        [ViewField(Name = Fields.TotalTransactionsProcessed, Id = Index.TotalTransactionsProcessed, FieldType = EntityFieldType.Int, Size = 2)]
        public int TotalTransactionsProcessed { get; set; }

        /// <summary>
        /// Property for TotalTransactionsCleared 
        /// </summary>
        [ViewField(Name = Fields.TotalTransactionsCleared, Id = Index.TotalTransactionsCleared, FieldType = EntityFieldType.Int, Size = 2)]
        public int TotalTransactionsCleared { get; set; }

        /// <summary>
        /// Property for Autodeletematchedtransactions 
        /// </summary>
        [ViewField(Name = Fields.Autodeletematchedtransactions, Id = Index.Autodeletematchedtransactions, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Autodeletematchedtransactions { get; set; }

        /// <summary>
        /// Property for SuggestedReconciliationStatus 
        /// </summary>
        [ViewField(Name = Fields.SuggestedReconciliationStatus, Id = Index.SuggestedReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int SuggestedReconciliationStatus { get; set; }

        /// <summary>
        /// Property for PostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ? PostingDate { get; set; }

        /// <summary>
        /// Property for MatchDepositsBy 
        /// </summary>
        [ViewField(Name = Fields.MatchDepositsBy, Id = Index.MatchDepositsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public MatchDepositsBy MatchDepositsBy { get; set; }

        /// <summary>
        /// Gets Data in Import OFX statement Screen for BankCode
        /// </summary>
        public EnumerableResponse<ImportOFXStatement> ImportOFXStatement { get; set; }

        /// <summary>
        /// Gets Fiscal Year Start Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ? LastPostDate { get; set; }

        /// <summary>
        /// Get Multicurrency for Bank
        /// </summary>
        public string IsMultiCurrencyBank { get; set; }

        /// <summary>
        /// Gets or sets Reconcile Order
        /// </summary>
        public IList<MatchDepositsBy> ReconcileOrder { get; set; }

        /// <summary>
        /// Gets or sets  Delete List
        /// </summary>
        public IList<string> DeleteList  {get;set;}
    }
}
