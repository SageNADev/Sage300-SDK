/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Check Stock
    /// </summary>
    public partial class CheckStock : ModelBase
    {
        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BankFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets CheckStockCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ChkformFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CheckStockCode, Id = Index.CheckStockCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CheckStockCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets NextCheckNumber 
        /// </summary>
        [Display(Name = "NextCheckNumber", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.NextCheckNumber, Id = Index.NextCheckNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal NextCheckNumber { get; set; }

        /// <summary>
        /// Gets or sets StockType 
        /// </summary>
        [Display(Name = "StockType", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.StockType, Id = Index.StockType, FieldType = EntityFieldType.Int, Size = 2)]
        public StockType StockType { get; set; }

        /// <summary>
        /// Gets or sets Account Type String
        /// </summary>
        /// <value>The type of the account.</value>
        public string StockTypeString
        {
            get { return EnumUtility.GetStringValue(StockType); }
        }

        /// <summary>
        /// Gets or sets CheckForm 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckForm", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CheckForm, Id = Index.CheckForm, FieldType = EntityFieldType.Char, Size = 20)]
        public string CheckForm { get; set; }

        /// <summary>
        /// Gets or sets AdviceForm 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdviceForm", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.AdviceForm, Id = Index.AdviceForm, FieldType = EntityFieldType.Char, Size = 20)]
        public string AdviceForm { get; set; }

        /// <summary>
        /// Gets or sets AdviceLinesPerPage 
        /// </summary>
        [Display(Name = "AdviceLinesPerPage", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.AdviceLinesPerPage, Id = Index.AdviceLinesPerPage, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal AdviceLinesPerPage { get; set; }

        /// <summary>
        /// Gets or sets Language 
        /// </summary>
        [Display(Name = "Language", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Language, Id = Index.Language, FieldType = EntityFieldType.Int, Size = 2)]
        public Language Language { get; set; }

        /// <summary>
        /// Gets or sets Language String
        /// </summary>
        /// <value>The type of the account.</value>
        public string LanguageString
        {
            get { return EnumUtility.GetStringValue(Language); }
        }

        /// <summary>
        /// Gets or sets the sequential line number for the recurring entry detail items
        /// </summary>
        /// <value>The line number.</value>
        [IgnoreExportImport]
        public int LineNumber { get; set; }

        /// <summary>
        /// gets or sets IsCheckStockLocked
        /// </summary>
        public bool IsCheckStockLocked { get; set; }

        /// <summary>
        /// gets or sets SemaphoreCheckStockUsed
        /// </summary>
        public string SemaphoreCheckStockUsed { get; set; }
    }
}
