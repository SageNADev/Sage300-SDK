/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is Bank Transfers Details Entity
    /// </summary>
    public partial class BankTransfersDetails : ModelBase
    {

        /// <summary>
        /// Gets or sets TransferNumber 
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
 		public string TransferNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets ChargeLine 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        public ChargeLine ChargeLine { get; set; }

        /// <summary>
        /// Gets or sets ChargeTransactionType 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ChargeTransactionType { get; set; }

        /// <summary>
        /// Gets or sets ChargeGOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ChargeGorLAccount { get; set; }

        /// <summary>
        /// Gets or sets ChargeSourceAmount 
        /// </summary>

        public decimal ChargeSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets ChargeFunctionalAmount 
        /// </summary>

        public decimal ChargeFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets PostTransferCharge? 
        /// </summary>

        public long PostTransferCharge { get; set; }

        /// <summary>
        /// Gets or sets ChargeBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ChargeBank { get; set; }

        /// <summary>
        /// Gets or sets ChargeSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ChargeSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ExchangeRateType { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public DateTime ExchangeRateDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>

        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>

        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets TransferBankChargeCurDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TransferBankChargeCurDesc { get; set; }

        /// <summary>
        /// Gets or sets ChargeTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ChargeTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets ChargeGOrLDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ChargeGorLDescription { get; set; }

        /// <summary>
        /// Gets or sets Taxable 
        /// </summary>

        public Taxable Taxable { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountCalculation 
        /// </summary>
        [Display(Name="TaxCalcAmount",ResourceType = typeof(BKCommonResx))]
        public Taxable TaxAmountCalculation { get; set; }

        /// <summary>
        /// Gets or Sets CalculateTaxAmount
        /// </summary>
        /// <value>Boolean</value>
        [Display(Name = "TaxCalcAmount", ResourceType = typeof(BKCommonResx))]
        public bool CalculateTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(BKCommonResx))]
        public string TaxGroup { get; set; }

        
        /// <summary>
        /// Gets or sets TaxBaseCalculationMethod 
        /// </summary>
        [Display(Name = "TaxBaseCalc", ResourceType = typeof(BKCommonResx))]
        public Taxable TaxBaseCalculationMethod { get; set; }

        /// <summary>
        /// Gets or Sets CalculateBaseAmount
        /// </summary>
        /// <value>Boolean</value>
        [Display(Name = "TaxBaseCalc", ResourceType = typeof(BKCommonResx))]
        public bool CalculateBaseAmount { get; set; }


        /// <summary>
        /// Gets or sets TaxableAmount 
        /// </summary>

        public decimal TaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets NonTaxableAmount 
        /// </summary>

        public decimal NonTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TaxTotal", ResourceType = typeof(BKCommonResx))]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DocumentTotalBeforeTax 
        /// </summary>

        public decimal DocumentTotalBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets DocumentTotalIncludingTax 
        /// </summary>

        public decimal DocumentTotalIncludingTax { get; set; }

        /// <summary>
        /// Gets or sets TotalIncludedAmount 
        /// </summary>
        [Display(Name = "TaxInclude", ResourceType = typeof(BKCommonResx))]
        public decimal TotalIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalExcludedAmount 
        /// </summary>
        [Display(Name = "TaxExcluded", ResourceType = typeof(BKCommonResx))]
        public decimal TotalExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxNetDistributionAmount 
        /// </summary>
        [Display(Name = "TaxNet", ResourceType = typeof(BKCommonResx))]
        public decimal TaxNetDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxDistributionamount 
        /// </summary>
        public decimal TaxDistributionamount { get; set; }

        /// <summary>
        /// Gets or sets TaxGrossDistributionAmount 
        /// </summary>

        public decimal TaxGrossDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1 
        /// </summary>

        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2 
        /// </summary>

        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3 
        /// </summary>

        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4 
        /// </summary>

        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5 
        /// </summary>

        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAMount1 
        /// </summary>

        public decimal TaxRecoverableAMount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAMount2 
        /// </summary>

        public decimal TaxRecoverableAMount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAMount3 
        /// </summary>

        public decimal TaxRecoverableAMount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAMount4 
        /// </summary>

        public decimal TaxRecoverableAMount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAMount5 
        /// </summary>

        public decimal TaxRecoverableAMount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1 
        /// </summary>

        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2 
        /// </summary>

        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3 
        /// </summary>

        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4 
        /// </summary>

        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5 
        /// </summary>

        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAllocatedAmount 
        /// </summary>

        public decimal TotalTaxAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>

        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>

        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>

        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>

        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>

        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed1 
        /// </summary>

        public decimal TaxReportingExpensed1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed2 
        /// </summary>

        public decimal TaxReportingExpensed2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed3 
        /// </summary>

        public decimal TaxReportingExpensed3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed4 
        /// </summary>

        public decimal TaxReportingExpensed4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed5 
        /// </summary>

        public decimal TaxReportingExpensed5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1 
        /// </summary>

        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2 
        /// </summary>

        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3 
        /// </summary>

        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4 
        /// </summary>

        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5 
        /// </summary>

        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1 
        /// </summary>

        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2 
        /// </summary>

        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3 
        /// </summary>

        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4 
        /// </summary>

        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5 
        /// </summary>

        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxReportingAllocAmt 
        /// </summary>

        public decimal TotalTaxReportingAllocAmt { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxReportingAmount 
        /// </summary>
        [Display(Name = "TaxTotalRC", ResourceType = typeof(BKCommonResx))]
        public decimal TotalTaxReportingAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxVersion 
        /// </summary>

        public long TaxVersion { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationReportingMethod 
        /// </summary>
        [Display(Name = "TaxReptCalc", ResourceType = typeof(BKCommonResx))]
        public Taxable TaxCalculationReportingMethod { get; set; }

        /// <summary>
        /// Gets or sets CalculateTaxReporting
        /// </summary>
        [Display(Name = "TaxReptCalc", ResourceType = typeof(BKCommonResx))]
        public bool CalculateTaxReporting { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxCurn", ResourceType = typeof(BKCommonResx))]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRate 
        /// </summary>
        [Display(Name = "TaxRate", ResourceType = typeof(BKCommonResx))]
        public decimal TaxReportingRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxRateType", ResourceType = typeof(BKCommonResx))]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRateDate", ResourceType = typeof(BKCommonResx))]
        public DateTime TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation 
        /// </summary>

        public RateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount1 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxExpenseAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount2 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxExpenseAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount3 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxExpenseAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount4 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxExpenseAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount5 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxExpenseAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount1 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxRecoverableAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount2 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxRecoverableAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount3 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxRecoverableAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount4 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxRecoverableAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount5 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxRecoverableAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1 
        /// </summary>

        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2 
        /// </summary>

        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3 
        /// </summary>

        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4 
        /// </summary>

        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5 
        /// </summary>

        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(BKCommonResx))]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxProcessCommand 
        /// </summary>

        public TaxProcessCommand TaxProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxAuthorityDescription1 { get; set; }

        
        /// <summary>
        /// Gets or sets FunctionalTaxAmount1 
        /// </summary>

        public decimal FunctionalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount2 
        /// </summary>

        public decimal FunctionalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount3 
        /// </summary>

        public decimal FunctionalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount4 
        /// </summary>

        public decimal FunctionalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount5 
        /// </summary>

        public decimal FunctionalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount1 
        /// </summary>

        public decimal FunctionalTaxBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount2 
        /// </summary>

        public decimal FunctionalTaxBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount3 
        /// </summary>

        public decimal FunctionalTaxBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount4 
        /// </summary>

        public decimal FunctionalTaxBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount5 
        /// </summary>

        public decimal FunctionalTaxBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalNetofTax 
        /// </summary>

        public decimal FunctionalNetofTax { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxTotal 
        /// </summary>

        public decimal FunctionalTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount1 
        /// </summary>

        public decimal FunctionalExpensedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount2 
        /// </summary>

        public decimal FunctionalExpensedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount3 
        /// </summary>

        public decimal FunctionalExpensedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount4 
        /// </summary>

        public decimal FunctionalExpensedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount5 
        /// </summary>

        public decimal FunctionalExpensedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount1 
        /// </summary>

        public decimal FunctionalRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount2 
        /// </summary>

        public decimal FunctionalRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount3 
        /// </summary>

        public decimal FunctionalRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount4 
        /// </summary>

        public decimal FunctionalRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount5 
        /// </summary>

        public decimal FunctionalRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount1 
        /// </summary>

        public decimal FunctionalAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount2 
        /// </summary>

        public decimal FunctionalAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount3 
        /// </summary>

        public decimal FunctionalAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount4 
        /// </summary>

        public decimal FunctionalAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount5 
        /// </summary>

        public decimal FunctionalAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalGrossDistribAmount 
        /// </summary>

        public decimal FunctionalGrossDistribAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTotalTaxAllocated 
        /// </summary>

        public decimal FunctionalTotalTaxAllocated { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxReportingCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateTypeDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string TaxReportingRateTypeDesc { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Sets and Gets Enumerable Response of TaxGroupAuthority
        /// </summary>
        public EnumerableResponse<TaxGroupAuthority> TaxGroupAuthority { get; set; }
    }
}
