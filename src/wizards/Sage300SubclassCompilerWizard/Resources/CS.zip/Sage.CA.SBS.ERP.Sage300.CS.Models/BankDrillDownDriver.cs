// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

# region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class BankDrillDownDriver : ModelBase
    {

        /// <summary>
        /// Gets or sets DrilldownApplicationCode 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DrilldownApplicationCode, Id = Index.DrilldownApplicationCode, FieldType = EntityFieldType.Char, Size = 2)]
        public string DrilldownApplicationCode { get; set; }

        /// <summary>
        /// Gets or sets DrilldownDistributionCode 
        /// </summary>

        [ViewField(Name = Fields.DrilldownDistributionCode, Id = Index.DrilldownDistributionCode, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrilldownDistributionCode { get; set; }

        /// <summary>
        /// Gets or sets DrilldownLink 
        /// </summary>

        [ViewField(Name = Fields.DrilldownLink, Id = Index.DrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrilldownLink { get; set; }

        /// <summary>
        /// Gets or sets DrilldownType 
        /// </summary>

        [ViewField(Name = Fields.DrilldownType, Id = Index.DrilldownType, FieldType = EntityFieldType.Int, Size = 2)]
        public DrilldownType DrilldownType { get; set; }

        /// <summary>
        /// Gets or sets RotoIDofUIObject 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RotoIDofUiObject, Id = Index.RotoIDofUiObject, FieldType = EntityFieldType.Char, Size = 6)]
        public string RotoIDofUiObject { get; set; }

        /// <summary>
        /// Gets or sets Parameters 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Parameters, Id = Index.Parameters, FieldType = EntityFieldType.Char, Size = 250)]
        public string Parameters { get; set; }

        /// <summary>
        /// Gets or sets DocumentKey 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocumentKey, Id = Index.DocumentKey, FieldType = EntityFieldType.Char, Size = 40)]
        public string DocumentKey { get; set; }

        /// <summary>
        /// Post Sequence To Launch CS - Bank Transfer
        /// </summary>
        public string PostSequence { get; set; }

        /// <summary>
        /// Key Sequence To Launch CS - Bank Transfer
        /// </summary>
        public string KeySequence { get; set; }

        /// <summary>
        /// Sequence Type to launch CS - Bank Transfer
        /// </summary>
        public string SequenceType { get; set; }
    }
}
