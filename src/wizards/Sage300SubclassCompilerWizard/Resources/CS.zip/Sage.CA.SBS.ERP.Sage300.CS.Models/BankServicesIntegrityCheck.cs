// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class BankServicesIntegrityCheck : ModelBase
    {
        /// <summary>
        /// Gets or sets IntegrityCheckOptionNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.IntegrityCheckOptionNumber, Id = Index.IntegrityCheckOptionNumber, FieldType = EntityFieldType.Char, Size = 4)]
        public string IntegrityCheckOptionNumber { get; set; }

        /// <summary>
        /// Gets or sets Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Date, Id = Index.Date, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets FromBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FromBank, Id = Index.FromBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string FromBank { get; set; }

        /// <summary>
        /// Gets or sets ToBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToBank, Id = Index.ToBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string ToBank { get; set; }

        /// <summary>
        /// Gets or sets DataCheck 
        /// </summary>
        [ViewField(Name = Fields.DataCheck, Id = Index.DataCheck, FieldType = EntityFieldType.Int, Size = 2)]
        public DataCheck DataCheck { get; set; }

        /// <summary>
        /// Gets or sets OrphanCheck 
        /// </summary>
        [ViewField(Name = Fields.OrphanCheck, Id = Index.OrphanCheck, FieldType = EntityFieldType.Int, Size = 2)]
        public DataCheck OrphanCheck { get; set; }

        /// <summary>
        /// Gets or sets RestartRecovery 
        /// </summary>
        [ViewField(Name = Fields.RestartRecovery, Id = Index.RestartRecovery, FieldType = EntityFieldType.Int, Size = 2)]
        public DataCheck RestartRecovery { get; set; }

        /// <summary>
        /// Gets or sets Logerror 
        /// </summary>
        [ViewField(Name = Fields.Logerror, Id = Index.Logerror, FieldType = EntityFieldType.Bool, Size = 2)]
        public Logerror Logerror { get; set; }

        /// <summary>
        /// Gets or sets JournalControl 
        /// </summary>
        [ViewField(Name = Fields.JournalControl, Id = Index.JournalControl, FieldType = EntityFieldType.Int, Size = 2)]
        public DataCheck JournalControl { get; set; }
    }
}
