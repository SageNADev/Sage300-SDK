﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region references

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    ///  Contains list of properties for RateType
    /// </summary>
    public partial class RateType : ModelBase
    {
        #region Properties

        /// <summary>
        /// Gets or sets Code
        /// </summary>
        [Key]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets AuditDate
        /// </summary>
        public DateTime AuditDate { get; set; }

        /// <summary>
        /// Gets or sets AuditTime
        /// </summary>
        public DateTime AuditTime { get; set; }

        /// <summary>
        /// Gets or sets AuditUser
        /// </summary>
        public string AuditUser { get; set; }

        /// <summary>
        /// Gets or sets AuditOrg
        /// </summary>
        public string AuditOrganisation { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets RateType (Need to see if Code and this or doing the same job)
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        public string RateTypeField { get; set; }

        #endregion
    }
}