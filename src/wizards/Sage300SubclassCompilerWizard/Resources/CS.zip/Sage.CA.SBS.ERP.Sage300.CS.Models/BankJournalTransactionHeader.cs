// Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. 
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Model class for the BankJournalTransactionHeader
    /// </summary>
    public partial class BankJournalTransactionHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionHeaderSerial 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.TransactionHeaderSerial, Id = Index.TransactionHeaderSerial, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long TransactionHeaderSerial { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber 
        /// </summary>        
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>        
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public BankEntryType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets OldSerialNumber 
        /// </summary>
        [ViewField(Name = Fields.OldSerialNumber, Id = Index.OldSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long OldSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public EntryType EntryType { get; set; }

        /// <summary>
        /// Gets or sets TransactionReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TransactionReference, Id = Index.TransactionReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionReference { get; set; }

        /// <summary>
        /// Gets or sets TransactionDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TransactionDescription, Id = Index.TransactionDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionDescription { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransactionSlipPrinted 
        /// </summary>
        [ViewField(Name = Fields.TransactionSlipPrinted, Id = Index.TransactionSlipPrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency TransactionSlipPrinted { get; set; }

        /// <summary>
        /// Gets or sets TransactionTotal 
        /// </summary>
        [ViewField(Name = Fields.TransactionTotal, Id = Index.TransactionTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionTotal { get; set; }

        /// <summary>
        /// Gets or sets TransactionRemainingBalanceAmount 
        /// </summary>
        [ViewField(Name = Fields.TransactionRemainingBalanceAmt, Id = Index.TransactionRemainingBalanceAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionRemainingBalanceAmt { get; set; }

        /// <summary>
        /// Gets or sets FiscalTransactionTotal 
        /// </summary>
        [ViewField(Name = Fields.FiscalTransactionTotal, Id = Index.FiscalTransactionTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalTransactionTotal { get; set; }

        /// <summary>
        /// Gets or sets NextTransactionDetailLine 
        /// </summary>
        [ViewField(Name = Fields.NextTransactionDetailLine, Id = Index.NextTransactionDetailLine, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextTransactionDetailLine { get; set; }

        /// <summary>
        /// Gets or sets Lines 
        /// </summary>
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets LinesInTransit 
        /// </summary>
        [ViewField(Name = Fields.LinesInTransit, Id = Index.LinesInTransit, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesInTransit { get; set; }

        /// <summary>
        /// Gets or sets LinesReconciled 
        /// </summary>
        [ViewField(Name = Fields.LinesReconciled, Id = Index.LinesReconciled, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesReconciled { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus 
        /// </summary>
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionStatus TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationError 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationError, Id = Index.ReconciliationError, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationError { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationErrorPending 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationErrorPending, Id = Index.ReconciliationErrorPending, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationErrorPending { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeGain 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationExchangeGain, Id = Index.ReconciliationExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeLoss 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationExchangeLoss, Id = Index.ReconciliationExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationDepositAmount 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationDepositAmount, Id = Index.ReconciliationDepositAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationDepositAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationInTransitAmt 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationInTransitAmt, Id = Index.ReconciliationInTransitAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationInTransitAmt { get; set; }

        /// <summary>
        /// Gets or sets TransactionRecordedInSummary 
        /// </summary>
        [ViewField(Name = Fields.TransactionRecordedInSummary, Id = Index.TransactionRecordedInSummary, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionRecordedinSummary TransactionRecordedInSummary { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationCreditCardCharges 
        /// </summary>
        public decimal ReconciliationCreditCardCharges { get; set; }

        /// <summary>
        /// Gets or sets AmountCleared 
        /// </summary>
        [ViewField(Name = Fields.AmountCleared, Id = Index.AmountCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountCleared { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTransactionAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTransactionAmount, Id = Index.FunctionalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTransactionTotal 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTransactionTotal, Id = Index.FunctionalTransactionTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTransactionTotal { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationClearedAmount 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationClearedAmount, Id = Index.ReconciliationClearedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationClearedAmount { get; set; }

        /// <summary>
        /// Gets or sets WriteOffAmount 
        /// </summary>
        [ViewField(Name = Fields.WriteOffAmount, Id = Index.WriteOffAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WriteOffAmount { get; set; }

        /// <summary>
        /// Gets or sets InTransitAmount 
        /// </summary>
        [ViewField(Name = Fields.InTransitAmount, Id = Index.InTransitAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InTransitAmount { get; set; }

        /// <summary>
        /// Gets or sets VarianceType 
        /// </summary>
        [ViewField(Name = Fields.VarianceType, Id = Index.VarianceType, FieldType = EntityFieldType.Int, Size = 2)]
        public VarianceType VarianceType { get; set; }

        /// <summary>
        /// Gets or sets LinesCanReverseInvoice 
        /// </summary>
        [ViewField(Name = Fields.LinesCanReverseInvoice, Id = Index.LinesCanReverseInvoice, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesCanReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets DefaultPostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DefaultPostingDate { get; set; }

        /// <summary>
        /// Gets or sets DefaultReconciliationStatus 
        /// </summary>
        [ViewField(Name = Fields.DefaultReconciliationStatus, Id = Index.DefaultReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultReconciliationStatus DefaultReconciliationStatus { get; set; }

        /// <summary>
        /// Gets Reconciliation status string
        /// </summary>
        [IgnoreExportImport]
        public string ReconciliationStatusString
        {
            get { return EnumUtility.GetStringValue(DefaultReconciliationStatus); }
        }

        /// <summary>
        /// Gets the reconcileFlag
        /// </summary>
        [IgnoreExportImport]
        public bool ReconcileFlag{
            get
            {
                return 
                (
                    DefaultReconciliationStatus == DefaultReconciliationStatus.Cleared ||
                    DefaultReconciliationStatus == DefaultReconciliationStatus.Clearedwithcreditcardcharge ||
                    DefaultReconciliationStatus ==
                    DefaultReconciliationStatus.Clearedwithexchangeratedifference ||
                    DefaultReconciliationStatus == DefaultReconciliationStatus.Clearedwithwriteoff ||
                    DefaultReconciliationStatus == DefaultReconciliationStatus.Clearedwithbankerror ||
                    DefaultReconciliationStatus == DefaultReconciliationStatus.Reversed ||
                    DefaultReconciliationStatus == DefaultReconciliationStatus.Void ||
                    DefaultReconciliationStatus == DefaultReconciliationStatus.Continuation ||
                    DefaultReconciliationStatus == DefaultReconciliationStatus.ReconcileByDepositDetail ||
                    (
                        DefaultReconciliationStatus == DefaultReconciliationStatus.NotPosted &&
                        TransactionType == BankEntryType.Withdrawals &&
                        EntryType == EntryType.Subledger
                    ));
            }
        }

        /// <summary>
        /// Gets or sets DefaultReconciliationDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DefaultReconciliationDesc, Id = Index.DefaultReconciliationDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultReconciliationDesc { get; set; }

        /// <summary>
        /// Gets or sets LinesJournalled 
        /// </summary>
        public long LinesJournalled { get; set; }

        /// <summary>
        /// Gets or sets LinesPurged 
        /// </summary>
        [ViewField(Name = Fields.LinesPurged, Id = Index.LinesPurged, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesPurged { get; set; }

        /// <summary>
        /// Gets or sets ClearToFuturePeriod 
        /// </summary>
        [ViewField(Name = Fields.ClearToFuturePeriod, Id = Index.ClearToFuturePeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClearToFuturePeriod { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToFuture 
        /// </summary>
        [ViewField(Name = Fields.FiscalClearedToFuture, Id = Index.FiscalClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToCurrent 
        /// </summary>
        [ViewField(Name = Fields.FiscalClearedToCurrent, Id = Index.FiscalClearedToCurrent, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToCurrent { get; set; }

        /// <summary>
        /// Gets or sets ReconciledAndJournaledTransactions 
        /// </summary>
        public ReconciledandJournaledTransac ReconciledAndJournaledTrans { get; set; }

        /// <summary>
        /// Gets or sets CurrentPeriodsWriteOff 
        /// </summary>
        [ViewField(Name = Fields.CurrentPeriodsWriteOff, Id = Index.CurrentPeriodsWriteOff, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentPeriodsWriteOff { get; set; }

        /// <summary>
        /// Gets or sets ClearToReconciliationPeriod 
        /// </summary>
        [ViewField(Name = Fields.ClearToReconciliationPeriod, Id = Index.ClearToReconciliationPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClearToReconciliationPeriod { get; set; }

        /// <summary>
        /// Gets or sets FiscalWriteOffToThisPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalWriteOffToThisPeriod, Id = Index.FiscalWriteOffToThisPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWriteOffToThisPeriod { get; set; }

        /// <summary>
        /// Gets or sets FiscalRemainingOutstanding 
        /// </summary>
        [ViewField(Name = Fields.FiscalRemainingOutstanding, Id = Index.FiscalRemainingOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalRemainingOutstanding { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaWriteOffs 
        /// </summary>
        [ViewField(Name = Fields.TotalDeltaWriteOffs, Id = Index.TotalDeltaWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaBankErrors 
        /// </summary>
        [ViewField(Name = Fields.TotalDeltaBankErrors, Id = Index.TotalDeltaBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaBankErrors { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaExchangeGain 
        /// </summary>
        [ViewField(Name = Fields.TotalDeltaExchangeGain, Id = Index.TotalDeltaExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaExchangeLoss 
        /// </summary>
        [ViewField(Name = Fields.TotalDeltaExchangeLoss, Id = Index.TotalDeltaExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaCreditCardCharge 
        /// </summary>
        [ViewField(Name = Fields.TotalDeltaCreditCardCharge, Id = Index.TotalDeltaCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaCreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaCleared 
        /// </summary>
        [ViewField(Name = Fields.TotalDeltaCleared, Id = Index.TotalDeltaCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaCleared { get; set; }

        /// <summary>
        /// Gets or sets TotalDeltaFunctionalAmount 
        /// </summary>
        [ViewField(Name = Fields.TotalDeltaFunctionalAmount, Id = Index.TotalDeltaFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeltaFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationWriteOffSum 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationWriteOffSum, Id = Index.ReconciliationWriteOffSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationWriteOffSum { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ReconciliationpostingYear { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingPeriod 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationPostingPeriod, Id = Index.ReconciliationPostingPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationPostingPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationDelta 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationDelta, Id = Index.ReconciliationDelta, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationDelta { get; set; }

        /// <summary>
        /// Gets or sets FiscalMiscellaneousEntry 
        /// </summary>
        [ViewField(Name = Fields.FiscalMiscellaneousEntry, Id = Index.FiscalMiscellaneousEntry, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalMiscellaneousEntry { get; set; }

        /// <summary>
        /// Gets or sets WithdrawalMiscellaneousEntriesToFisc 
        /// </summary>
        [ViewField(Name = Fields.WithdrawalMiscEntriesToFisc, Id = Index.WithdrawalMiscEntriesToFisc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WithdrawalMiscEntriesToFisc { get; set; }

        /// <summary>
        /// Gets or sets DepositMiscellaneousEntriesToFiscal 
        /// </summary>
        [ViewField(Name = Fields.DepositMiscEntriesToFiscal, Id = Index.DepositMiscEntriesToFiscal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositMiscEntriesToFiscal { get; set; }

        /// <summary>
        /// Gets or sets WithdrawalMiscellaneouscEntriesToFutu 
        /// </summary>
        [ViewField(Name = Fields.WithdrawalMiscEntriesToFutu, Id = Index.WithdrawalMiscEntriesToFutu, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WithdrawalMiscEntriesToFutu { get; set; }

        /// <summary>
        /// Gets or sets DepositMiscellaneousEntriesToFuture 
        /// </summary>
        [ViewField(Name = Fields.DepositMiscEntriesToFuture, Id = Index.DepositMiscEntriesToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositMiscEntriesToFuture { get; set; }

        /// <summary>
        /// Gets or sets PaymentPayeeName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PaymentPayeeName, Id = Index.PaymentPayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentPayeeName { get; set; }

        /// <summary>
        /// Gets or sets PaymentVendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PaymentVendorName, Id = Index.PaymentVendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PaymentVendorName { get; set; }

        /// <summary>
        /// Gets or sets BankEntryOrTransferNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.BankEntryOrTransferNumber, Id = Index.BankEntryOrTransferNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string BankEntryOrTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets LinesProcessed 
        /// </summary>
        [ViewField(Name = Fields.LinesProcessed, Id = Index.LinesProcessed, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesProcessed { get; set; }

        /// <summary>
        /// Gets or sets ReverseInvoice 
        /// </summary>
        [ViewField(Name = Fields.ReverseInvoice, Id = Index.ReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency ReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccountOfDiscrepancy 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string GLAccountOfDiscrepancy { get; set; }

        /// <summary>
        /// Gets or sets ReconcilebyDetailReconciled 
        /// </summary>
        [ViewField(Name = Fields.ReconcilebyDetailReconciled, Id = Index.ReconcilebyDetailReconciled, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconcilebyDetailReconciled { get; set; }

        /// <summary>
        /// Gets or sets ReconcilebyDetailOutstanding 
        /// </summary>
        [ViewField(Name = Fields.ReconcilebyDetailOutstanding, Id = Index.ReconcilebyDetailOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconcilebyDetailOutstanding { get; set; }
    }
}
