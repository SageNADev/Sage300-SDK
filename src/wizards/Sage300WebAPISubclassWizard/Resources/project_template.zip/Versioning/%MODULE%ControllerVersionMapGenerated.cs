using Microsoft.Web.Http;

namespace Sage.CA.SBS.ERP.Sage300.%MODULE%.WebApi.Controllers
{
    /// <summary>
    /// Class %CONTROLLER%Controller
    /// </summary>
    [ApiVersion("1.0")]
    public partial class %CONTROLLER%Controller { }

    
}